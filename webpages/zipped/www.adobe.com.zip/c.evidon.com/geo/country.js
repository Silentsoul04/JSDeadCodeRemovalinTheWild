(function() {
    var country = {
        'code': 'nl',
        'id': 8,
        'defaultLangauge': 'nl'
    };

    if (!window.evidon) window.evidon = {};

    if (window.evidon.notice) {
        window.evidon.notice.setLocation(country);
    } else {
        window.evidon.location = country;
    }
})();