// Qualaroo for wikia.com
// (C) 2019 Qualaroo. All rights reserved.
// qualaroo.com

//$ site: 46125, generated: 2019-04-26 08:45:40 UTC
//$ client: 2.0.55

! function() {
    var e = document,
        t = e.getElementsByTagName("script")[0],
        r = e.createElement("script");
    r.type = "text/javascript", r.async = !0, r.src = "https://cl.qualaroo.com/ki.js/52510/bgJqoo.js", t.parentNode.insertBefore(r, t)
}();