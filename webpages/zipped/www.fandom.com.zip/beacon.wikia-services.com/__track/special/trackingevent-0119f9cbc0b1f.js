var beacon_id = "9upVytsoj2";
var session_id = "TLhKlZsGMh";
var varnishTime = "Tue, 08 Oct 2019 22:24:28 GMT";