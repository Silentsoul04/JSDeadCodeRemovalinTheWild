processGoogleToken({
    "newToken": "ChEI8Ofw7AUQoffkn4u3-YW1ARIvAEr-9XDj715EYHcAjUhsLlsqHHnCZHs3ASlB6FKFxaMmDRqJ3ZbAJePeUB-0jds",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-08-22",
    "pucrd": ""
});