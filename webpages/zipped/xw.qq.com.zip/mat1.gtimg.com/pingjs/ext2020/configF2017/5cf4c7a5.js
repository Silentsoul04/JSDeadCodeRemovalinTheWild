/*------------Modifier: < alberttian > 2019-9-23 13:39:46------------*/
var apub_5cf4c7a5 = {
    "title": "\u79fb\u52a8\u817e\u8baf\u7f51-\u5168\u7ad9\u76ae\u80a4\u8fd0\u8425(\u65b0\u7248)",
    "img": "https://mat1.gtimg.com/rain/apub2019/7e82d989ac0c.guoqing2",
    "bgcolor": "#E20400",
    "navcolor": "",
    "navfontcolor": "",
    "fontcolor": "",
    "underlinecolor": "#FFEC3D",
    "biglogo": "",
    "logo": "",
    "starttime": "2019-09-23T00:00",
    "endtime": "2019-10-07T23:59",
    "time": "2019-09-23 09:23:19",
    "schemaId": "5cf4c723fcd88920bd9653f0",
    "btype": "xw"
}