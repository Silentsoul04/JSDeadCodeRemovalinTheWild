var sj_fader = function() {
    return new sj_anim(function(n, t) {
        sj_so(n, t)
    })
}