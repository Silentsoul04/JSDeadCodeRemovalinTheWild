processGoogleToken({
    "newToken": "ChEI8Ofw7AUQoffkn4u3-YW1ARIvAEr-9XD1Rut9IH6KB20khuMbvXL3StqNfuTrVDcPFx-fLCctgEmiPnnwYbZW5o0",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-08-22",
    "pucrd": ""
});