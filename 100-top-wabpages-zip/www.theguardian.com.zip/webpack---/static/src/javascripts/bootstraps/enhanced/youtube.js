// @flow

import { checkElemsForVideos } from 'common/modules/atoms/youtube';

export const init = () => {
    checkElemsForVideos();
};
