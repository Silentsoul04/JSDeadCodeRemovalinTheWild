// @flow

// this HAS to be a default export; the scripts from DFP expect it to be there
/* eslint-disable guardian-frontend/no-default-export */
export default `${window.location.protocol}//tpc.googlesyndication.com`;
