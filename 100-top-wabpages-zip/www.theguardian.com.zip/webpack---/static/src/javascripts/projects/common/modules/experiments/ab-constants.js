// @flow

export const participationsKey = 'gu.ab.participations';
export const NOT_IN_TEST = 'notintest';

export const notInTestVariant = {
    id: NOT_IN_TEST,
    test: () => {},
};
