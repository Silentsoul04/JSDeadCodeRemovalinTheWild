typeof orb.orb_fig === 'function' && orb.orb_fig({
'uk':0,
'ck':1,
'ad':1,
'ap':2,
'tb':0,
'mb':0,
'eu':1});
