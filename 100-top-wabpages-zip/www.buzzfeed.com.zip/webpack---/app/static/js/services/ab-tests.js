import { SHOPPING_TESTS } from '@buzzfeed/buzzblocks/js/services/amazon-tests';
import { AD_TESTS } from '@buzzfeed/adlib/js/services/ab-tests';
import { BUZZBLOCKS_TESTS } from '@buzzfeed/buzzblocks/js/services/ab-tests';

export default [].concat(SHOPPING_TESTS, AD_TESTS, BUZZBLOCKS_TESTS);
