export default {
  bfo: {
    displayName: 'BuzzFeed'
  },
  bfn: {
    displayName: 'BuzzFeed News'
  },
  bfreviews: {
    displayName: 'BuzzFeed Reviews'
  },
  tasty: {
    displayName: 'BuzzFeed Tasty'
  },
  goodful: {
    displayName: 'BuzzFeed Goodful'
  },
  asis: {
    displayName: 'BuzzFeed As Is'
  },
  bringme: {
    displayName: 'BuzzFeed Bring Me'
  },
};
