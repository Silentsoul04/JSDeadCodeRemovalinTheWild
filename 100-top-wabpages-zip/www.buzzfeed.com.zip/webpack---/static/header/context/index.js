import createContext from 'preact-context/dist/esm/context';

export const I18n = createContext({});
export const Config = createContext({});
export const Theme = createContext('light');
