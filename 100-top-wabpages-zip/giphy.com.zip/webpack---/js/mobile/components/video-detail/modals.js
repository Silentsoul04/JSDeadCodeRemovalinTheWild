const Modals = {
    SHARE: 'share',
    INFO: 'info',
}

export default Modals
