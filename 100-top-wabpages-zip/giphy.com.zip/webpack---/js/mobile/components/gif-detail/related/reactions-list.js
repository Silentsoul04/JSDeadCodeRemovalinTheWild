export default [
    {
        label: '😃',
        search: 'excited',
    },
    {
        label: '😍',
        search: 'love',
    },
    {
        label: '😔',
        search: 'sad',
    },
    {
        label: '🤔',
        search: 'confused',
    },
    {
        label: '😂',
        search: 'lol',
    },
    {
        label: '😱',
        search: 'scared',
    },
]
