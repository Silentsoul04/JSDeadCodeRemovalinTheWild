export const highestZIndex = 2147483647
export const aboveNavZIndex = 500
export const belowNavZIndex = 498
export const modalZIndex = 2147483646
export const messagesZIndex = 999999
export const belowMessagesZIndex = 999998
