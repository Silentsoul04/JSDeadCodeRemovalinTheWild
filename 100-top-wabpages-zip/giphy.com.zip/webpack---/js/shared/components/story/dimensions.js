export const SLIM = {
    width: 208,
    height: 112,
}

export const SMALL_PORTRAIT = {
    width: 160,
    height: 200,
}
