const Actions = {
    facebook: 'Facebook Share',
    instagram: 'Instagram Share',
    reddit: 'Reddit Share',
    pinterest: 'Pinterest Share',
    twitter: 'Twitter Share',
    sms: 'SMS Share',
}
export default Actions
