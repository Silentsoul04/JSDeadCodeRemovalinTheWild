const LoadHelper = require('@exp/exp-utils/helper/load');

const _pageLoadHelper = new LoadHelper();

module.exports = _pageLoadHelper;
