// Abstract class
class VisitHelper {
  // be overwritten by TCC and TCCL
  getVisitInfo() {
    return;
  }
}

module.exports = VisitHelper;
