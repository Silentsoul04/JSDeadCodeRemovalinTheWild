window['_HB_KEYWORD_ON'] = true;
window['_HB_OFFICIAL_ON'] = true;
window['_HB_C2C_ON'] = true;
window['_HB_ON'] = true;