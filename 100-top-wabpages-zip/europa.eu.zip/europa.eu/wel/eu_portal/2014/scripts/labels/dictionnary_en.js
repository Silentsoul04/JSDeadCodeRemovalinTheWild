
	var dictionnary = {
		"multipage":
			{
			"prev":"",
			"next":"",
			"page_num":"",
			"of_num":""
			},
		"countries":
			{
			"austria" : "Austria",
			"belgium" : "Belgium",
			"bulgaria" : "Bulgaria",
			"cyprus" : "Cyprus",
			"czechrepublic" : "Czech Republic",
			"denmark" : "Denmark",
			"estonia" : "Estonia",
			"finland" : "Finland",
			"france" : "France",
			"germany" : "Germany",
			"greece" : "Greece",
			"hungary" : "Hungary",
			"ireland" : "Ireland",
			"italy" : "Italy",
			"latvia" : "Latvia",
			"lithuania" : "Lithuania",
			"luxembourg" : "Luxembourg",
			"malta" : "Malta",
			"netherlands" : "Netherlands",
			"poland" : "Poland",
			"portugal" : "Portugal",
			"romania" : "Romania",
			"slovakia" : "Slovakia",
			"slovenia" : "Slovenia",
			"spain" : "Spain",
			"sweden" : "Sweden",
			"unitedkingdom" : "United Kingdom",
			"croatia" : "Croatia",
			"albania" : "Albania",
			"andorra" : "Andorra",
			"belarus" : "Belarus",
			"bosnia" : "Bosnia and Herzegovina",
			"iceland" : "Iceland",
			"fyrom" : "Former Yugoslav Republic of Macedonia",
			"moldova" : "Moldova",
			"monaco" : "Monaco",
			"montenegro" : "Montenegro",
			"norway" : "Norway",
			"san_marino" : "San Marino",
			"serbia" : "Serbia",
			"switzerland" : "Switzerland",
			"ukraine" : "Ukraine",
			"vatican" : "Vatican City State",
			"turkey" : "Turkey",
			"russia" : "Russia"
			},
		"leaflet":
			{
			"contact_point":""
			}
		}
	