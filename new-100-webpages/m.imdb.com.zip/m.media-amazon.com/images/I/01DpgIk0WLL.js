(window.webpackJsonpBoomer = window.webpackJsonpBoomer || []).push([
    ["commons.is-what"], {
        fVIbqf811m: function(t, n, o) {
            "use strict";

            function r(t) {
                return Object.prototype.toString.call(t).slice(8, -1)
            }

            function c(t) {
                return "Object" === r(t) && (t.constructor === Object && Object.getPrototypeOf(t) === Object.prototype)
            }

            function e(t) {
                return "Array" === r(t)
            }

            function u(t) {
                return "Symbol" === r(t)
            }
            o.d(n, "b", function() {
                return c
            }), o.d(n, "a", function() {
                return e
            }), o.d(n, "c", function() {
                return u
            })
        }
    }
]);