(window.webpackJsonpBoomer = window.webpackJsonpBoomer || []).push([
    ["npm.detect-node"], {
        s1DKtra4BZM: function(o, e) {
            o.exports = !1
        }
    }
]);