(window.webpackJsonpBoomer = window.webpackJsonpBoomer || []).push([
    ["npm.inherits"], {
        F04SI4wmNl: function(o, t) {
            "function" == typeof Object.create ? o.exports = function(o, t) {
                t && (o.super_ = t, o.prototype = Object.create(t.prototype, {
                    constructor: {
                        value: o,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    }
                }))
            } : o.exports = function(o, t) {
                if (t) {
                    o.super_ = t;
                    var e = function() {};
                    e.prototype = t.prototype, o.prototype = new e, o.prototype.constructor = o
                }
            }
        }
    }
]);