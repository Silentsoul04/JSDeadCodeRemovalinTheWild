(window.webpackJsonpBoomer = window.webpackJsonpBoomer || []).push([
    ["npm.timers-browserify"], {
        Mu2eQLIQub: function(e, t, i) {
            (function(e) {
                var o = void 0 !== e && e || "undefined" != typeof self && self || window,
                    n = Function.prototype.apply;

                function l(e, t) {
                    this._id = e, this._clearFn = t
                }
                t.setTimeout = function() {
                    return new l(n.call(setTimeout, o, arguments), clearTimeout)
                }, t.setInterval = function() {
                    return new l(n.call(setInterval, o, arguments), clearInterval)
                }, t.clearTimeout = t.clearInterval = function(e) {
                    e && e.close()
                }, l.prototype.unref = l.prototype.ref = function() {}, l.prototype.close = function() {
                    this._clearFn.call(o, this._id)
                }, t.enroll = function(e, t) {
                    clearTimeout(e._idleTimeoutId), e._idleTimeout = t
                }, t.unenroll = function(e) {
                    clearTimeout(e._idleTimeoutId), e._idleTimeout = -1
                }, t._unrefActive = t.active = function(e) {
                    clearTimeout(e._idleTimeoutId);
                    var t = e._idleTimeout;
                    t >= 0 && (e._idleTimeoutId = setTimeout(function() {
                        e._onTimeout && e._onTimeout()
                    }, t))
                }, i("HtNaIRzYkf"), t.setImmediate = "undefined" != typeof self && self.setImmediate || void 0 !== e && e.setImmediate || this && this.setImmediate, t.clearImmediate = "undefined" != typeof self && self.clearImmediate || void 0 !== e && e.clearImmediate || this && this.clearImmediate
            }).call(this, i("qv/MW4HMFk"))
        }
    }
]);