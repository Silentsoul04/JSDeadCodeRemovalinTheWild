(window.webpackJsonpBoomer = window.webpackJsonpBoomer || []).push([
    ["commons.is-buffer"], {
        "G//j3SrOR8": function(o, n) {
            /*!
             * Determine if an object is a Buffer
             *
             * @author   Feross Aboukhadijeh <https://feross.org>
             * @license  MIT
             */
            o.exports = function(o) {
                return null != o && null != o.constructor && "function" == typeof o.constructor.isBuffer && o.constructor.isBuffer(o)
            }
        }
    }
]);