(("undefined" !== typeof self ? self : this).webpackJsonp = ("undefined" !== typeof self ? self : this).webpackJsonp || []).push([
    [10], {
        YnKU: function(n, e, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/HealthCheck", function() {
                return t("sB/I")
            }])
        },
        "sB/I": function(n, e, t) {
            "use strict";
            t.r(e);
            var s = t("ERkP"),
                o = t.n(s).a.createElement;

            function r() {
                return o("main", null, "ok")
            }
            r.getInitialProps = function(n) {
                return n.res && n.res.setHeader("Cache-Control", "no-store"), {}
            }, t.d(e, "default", function() {
                return r
            })
        }
    },
    [
        ["YnKU", 1, 0]
    ]
]);