processGoogleToken({
    "newToken": "ChAI8K377AUQ2M__gqiooptUEi8AnMhKYZt-1DNtKvJuSo6P58Z5fw9oEvYfK1bhSD4zIWLhM00F1Y_B09RkGR4J2w",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-10-11",
    "pucrd": ""
});