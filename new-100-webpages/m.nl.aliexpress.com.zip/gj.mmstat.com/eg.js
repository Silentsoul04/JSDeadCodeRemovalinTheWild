window.goldlog = (window.goldlog || {});
goldlog.Etag = "JbUkFmzY0HwCAZFsUKbgco0O";
goldlog.stag = 1;