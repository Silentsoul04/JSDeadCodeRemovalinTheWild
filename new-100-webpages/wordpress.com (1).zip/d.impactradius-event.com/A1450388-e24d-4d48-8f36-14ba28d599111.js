(function(w, d) {
    var io = {
        util: {
            getQueryParam: function(p) {
                var url = window.location.search,
                    match;
                if (window.location.href.indexOf("#") !== -1) {
                    url += "&" + window.location.href.split("#")[1]
                }
                match = new RegExp("[?&]" + p + "=([^&]*)", "i").exec(url);
                return match ? io.util.safeDecodeURIComponent(match[1]) : null
            },
            hasValue: function(value) {
                return value !== null && value !== undefined
            },
            strContains: function(str, value) {
                return str.indexOf(value) !== -1
            },
            addListener: function(el, ev, fn) {
                if (el) {
                    if (el.attachEvent) {
                        el.attachEvent("on" + ev, function() {
                            fn.call(el)
                        })
                    } else {
                        el.addEventListener(ev, fn, false)
                    }
                }
            },
            removeListener: function(el, ev, fn) {
                if (el.removeEventListener) {
                    el.removeEventListener(ev, fn, false)
                }
                if (el.detachEvent) {
                    el.detachEvent("on" + ev, fn)
                }
            },
            getDaysInMs: function(days) {
                var d = new Date();
                d.setDate(d.getDate() + days);
                return d
            },
            getBaseDomain: function() {
                var s = "IR_gbd";
                if (io.util.hasValue(io.util.getCookie(s))) {
                    return io.util.getCookie(s)
                }
                var domain = window.location.hostname;
                if (domain) {
                    try {
                        var i = 0,
                            p = domain.split(".");
                        while (i < (p.length - 1) && !io.util.hasValue(io.util.getCookie(s))) {
                            domain = p.slice(-1 - (++i)).join(".");
                            document.cookie = s + "=" + domain + ";domain=" + domain + ";path=/;"
                        }
                    } catch (e) {
                        io.util.logErrors("Shared Utils", "getBaseDomain() error", "domain:" + domain + " msg:" + e.message)
                    }
                }
                return domain
            },
            setCookie: function(n, v, days, domain, path) {
                var cValue = n + "=" + encodeURIComponent(v),
                    bDomain;
                if (days) {
                    cValue += "; expires=" + io.util.getDaysInMs(days).toUTCString()
                }
                if (path) {
                    cValue += "; path=" + encodeURIComponent(path)
                } else {
                    cValue += "; path=/"
                }
                if (domain) {
                    cValue += "; domain=" + encodeURIComponent(domain)
                } else {
                    bDomain = io.util.getBaseDomain();
                    if (bDomain) {
                        cValue += "; domain=" + bDomain
                    }
                }
                document.cookie = cValue;
                return v
            },
            deleteCookie: function(n) {
                io.util.setCookie(n, "", -1)
            },
            getCookie: function(n) {
                var cks = document.cookie.split(";"),
                    len = cks.length,
                    x, a, b;
                for (x = 0; x < len; x++) {
                    a = cks[x].substr(0, cks[x].indexOf("="));
                    b = cks[x].substr(cks[x].indexOf("=") + 1);
                    a = a.replace(/^\s+|\s+$/g, "");
                    if (a == n) {
                        return io.util.safeDecodeURIComponent(b)
                    }
                }
            },
            extractDomain: function(url) {
                var matches = url.match(/^https?\:\/\/([^\/:?#]+)(?:[\/:?#]|$)/i);
                return (matches && matches[1]) || ""
            },
            isPaymentSite: function(ref) {
                return /\b(paypal|billmelater|worldpay|authorize)\b/.test(io.util.extractDomain(ref))
            },
            log: function() {
                var args = [],
                    msg, i = 0;
                for (; i < arguments.length; i++) {
                    args[i] = arguments[i]
                }
                if (typeof console != "undefined" && console && console.log) {
                    msg = args[0];
                    console.log(msg, args.slice(1, args.length))
                }
            },
            extend: function(target, source) {
                if (target === undefined || target === null) {
                    throw new TypeError("Cannot convert undefined or null to object")
                }
                var output = Object(target);
                if (source !== undefined && source !== null) {
                    for (var nextKey in source) {
                        if (Object.prototype.hasOwnProperty.call(source, nextKey)) {
                            output[nextKey] = source[nextKey]
                        }
                    }
                }
                return output
            },
            logErrors: function(loc, evt, msg, version, accountId) {
                try {
                    var img = document.createElement("img"),
                        src = "//logs-01.loggly.com/inputs/9b965af4-52fb-46fa-be1b-8dc5fb0aad05/tag/jsinsight/1*1.gif?",
                        agent = navigator && navigator.userAgent ? navigator.userAgent : "unavailable";
                    if (version) {
                        src += "ver=" + version + "&"
                    }
                    if (accountId) {
                        src += "acid=" + accountId + "&"
                    }
                    src += "type=" + loc + "&msg=" + encodeURIComponent(msg) + "&event=" + evt + "&agent=" + encodeURIComponent(agent);
                    img.src = src;
                    img.width = img.height = img.border = 0;
                    img.style.position = "absolute";
                    img.style.width = img.style.height = "0px";
                    img.style.visibility = "hidden";
                    io.util.onDomReady(function() {
                        document.body.appendChild(img)
                    })
                } catch (e) {
                    io.util.log(loc + " (in utils)", evt, msg + " | " + e.message)
                }
            },
            onDomReady: function(onLoad) {
                var isTop, testDiv, scrollIntervalId, isBrowser = typeof window !== "undefined" && window.document,
                    isPageLoaded = !isBrowser,
                    doc = isBrowser ? document : null,
                    readyCalls = [];

                function runCallbacks(callbacks) {
                    var i;
                    for (i = 0; i < callbacks.length; i += 1) {
                        callbacks[i](doc)
                    }
                }

                function callReady() {
                    var callbacks = readyCalls;
                    if (isPageLoaded) {
                        if (callbacks.length) {
                            readyCalls = [];
                            runCallbacks(callbacks)
                        }
                    }
                }

                function pageLoaded() {
                    if (document.body) {
                        if (!isPageLoaded) {
                            isPageLoaded = true;
                            if (scrollIntervalId) {
                                clearInterval(scrollIntervalId)
                            }
                            callReady()
                        }
                    } else {
                        setTimeout(pageLoaded, 30)
                    }
                }
                if (isBrowser) {
                    if (document.addEventListener) {
                        document.addEventListener("DOMContentLoaded", pageLoaded, false);
                        window.addEventListener("load", pageLoaded, false)
                    } else {
                        if (window.attachEvent) {
                            window.attachEvent("onload", pageLoaded);
                            testDiv = document.createElement("div");
                            try {
                                isTop = window.frameElement === null
                            } catch (e) {}
                            if (testDiv.doScroll && isTop && window.external) {
                                scrollIntervalId = setInterval(function() {
                                    try {
                                        testDiv.doScroll();
                                        pageLoaded()
                                    } catch (e) {}
                                }, 30)
                            }
                        }
                    }
                    if (document.readyState === "complete") {
                        pageLoaded()
                    }
                }
                if (isPageLoaded) {
                    onLoad(doc)
                } else {
                    readyCalls.push(onLoad)
                }
            },
            safeDecodeURIComponent: function(s) {
                if (s) {
                    s = s.replace(/\+/g, " ");
                    s = s.replace(/%([EF][0-9A-F])%([89AB][0-9A-F])%([89AB][0-9A-F])/gi, function(code, hex1, hex2, hex3) {
                        var n1 = parseInt(hex1, 16) - 224;
                        var n2 = parseInt(hex2, 16) - 128;
                        if (n1 == 0 && n2 < 32) {
                            return code
                        }
                        var n3 = parseInt(hex3, 16) - 128;
                        var n = (n1 << 12) + (n2 << 6) + n3;
                        if (n > 65535) {
                            return code
                        }
                        return String.fromCharCode(n)
                    });
                    s = s.replace(/%([CD][0-9A-F])%([89AB][0-9A-F])/gi, function(code, hex1, hex2) {
                        var n1 = parseInt(hex1, 16) - 192;
                        if (n1 < 2) {
                            return code
                        }
                        var n2 = parseInt(hex2, 16) - 128;
                        return String.fromCharCode((n1 << 6) + n2)
                    });
                    s = s.replace(/%([0-7][0-9A-F])/gi, function(code, hex) {
                        return String.fromCharCode(parseInt(hex, 16))
                    })
                }
                return s
            },
            isEmpty: function(value) {
                return !io.util.hasValue(value) || value === ""
            },
            trim: function(str) {
                if (typeof String.prototype.trim === "function") {
                    return str.trim()
                } else {
                    return str.replace(/^\s+|\s+$/g, "")
                }
            },
            arrayContains: function(array, item) {
                if ("indexOf" in Array.prototype) {
                    return array.indexOf(item) !== -1
                }
                var i, ln;
                for (i = 0, ln = array.length; i < ln; i++) {
                    if (array[i] === item) {
                        return true
                    }
                }
                return false
            }
        },
        irdv: "14",
        uttcdn: "d.impactradius-event.com"
    };
    var u = io.util;
    io.JSON = io.JSON || {};
    io.JSON.parse = function(text, reviver) {
        var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
        var j;

        function e(obj) {
            return Function('"use strict";return (' + obj + ")")()
        }

        function walk(holder, key) {
            var k;
            var v;
            var value = holder[key];
            if (value && typeof value === "object") {
                for (k in value) {
                    if (Object.prototype.hasOwnProperty.call(value, k)) {
                        v = walk(value, k);
                        if (v !== undefined) {
                            value[k] = v
                        } else {
                            delete value[k]
                        }
                    }
                }
            }
            return reviver.call(holder, key, value)
        }
        text = String(text);
        cx.lastIndex = 0;
        if (cx.test(text)) {
            text = text.replace(cx, function(a) {
                return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4)
            })
        }
        if (/^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ":").replace(/\w+\s*\:/g, ":"))) {
            j = e("(" + text + ")");
            return typeof reviver === "function" ? walk({
                "": j
            }, "") : j
        }
        u.logErrors("UTT", "IRF.JSON.parse error", text)
    };
    var referrer = d.referrer || "";
    var landingPage = w.location.href || "";
    var cookiePrefix = "IR_";
    var uuidCkName = cookiePrefix + "PI";
    var uuidAndNextXhrExpiry = u.getCookie(uuidCkName);
    var timeStamp = new Date().getTime();
    var blackListMatchingId = -1;
    var reporter = {};
    var mcfg = null;
    var sessionCb = [];
    var viewCb = [];
    var domMode = false;
    var idSeed = 1000;
    var hasInvokedIdentify = false;
    var referrerDomain;
    var slug = "__url_slug__";
    var sessionCookie;
    var version;
    var accountId;
    var configs;

    function doReporter(id, obj) {
        reporter[id] = obj
    }

    function setCampaignDefaults(cfg) {
        cfg.cp = cfg.cp || {
            utm_campaign: {
                "default": {
                    p: ["adcampaign"]
                }
            },
            utm_content: {
                "default": {
                    p: ["adtype"]
                }
            },
            utm_term: {
                "default": {
                    p: ["kw"]
                }
            }
        };
        return cfg
    }

    function replaceSubmissionSlug(url, type, slugs) {
        if (!slugs) {
            return url
        }
        return url.replace(slug, slugs[type])
    }

    function getSlugObject(beacon, xhr, image, iframe) {
        return {
            beacon: beacon,
            xhr: xhr,
            img: image,
            iframe: iframe
        }
    }

    function stripProtocol(url) {
        return url.replace(/https?:\/\//i, "")
    }

    function onDomReady(fn, useDomReady) {
        if (useDomReady) {
            u.onDomReady(fn)
        } else {
            fn()
        }
    }

    function extractQueryParam(url, param, decode) {
        var match;
        if (!url || !param) {
            return null
        }
        url = url.replace("#", "&");
        match = new RegExp("[?&]" + param + "=([^&]*)", "i").exec(url);
        var value = match && match[1];
        return decode ? u.safeDecodeURIComponent(value) : value
    }

    function regexMatch(pattern, value) {
        if (!pattern) {
            return false
        }
        try {
            return new RegExp(pattern).test(value)
        } catch (e) {
            u.log("Bad expr: " + pattern + " -- " + e);
            return false
        }
    }

    function getCookieName(campId) {
        return cookiePrefix + campId
    }

    function getReporter(id) {
        return reporter[id]
    }

    function getTrackDomain(camp) {
        return (w.location.protocol === "http:" ? "http:" : "https:") + "//" + camp.td
    }

    function getDefinedUrl(urlsArray) {
        var x = 0;
        var xx = urlsArray.length;
        while (x < xx) {
            if (u.hasValue(urlsArray[x])) {
                return urlsArray[x]
            }
            x += 1
        }
        return ""
    }

    function doBeacon(url, slugs) {
        url = replaceSubmissionSlug(url, "beacon", slugs);
        var parts = url.split("?");
        var beaconResponse = url.length < 8191 && w.navigator.sendBeacon ? w.navigator.sendBeacon(parts[0], parts[1]) : false;
        return beaconResponse ? {
            beacon: true,
            len: url.length
        } : false
    }

    function buildQueryParam(n, v, omitAmpersand) {
        return (omitAmpersand ? "" : "&") + encodeURIComponent(n) + "=" + encodeURIComponent(v)
    }

    function setMatchedConfig(config) {
        mcfg = config;
        return mcfg
    }

    function getCampaignConfig(cid) {
        var matchedcfg;
        var lpNoProto = stripProtocol(landingPage);
        var x = 0;
        var xx = configs.length;
        var cfg;

        function setMatchedConfigDefaults(cfg) {
            setCampaignDefaults(cfg);
            sessionCookie = u.getCookie(getCookieName(cfg.id));
            return cfg
        }
        while (x < xx) {
            cfg = configs[x];
            if (cfg.id == cid || (!cid && cfg.d && regexMatch(cfg.d, lpNoProto))) {
                matchedcfg = setMatchedConfigDefaults(cfg);
                break
            }
            x += 1
        }
        if (!matchedcfg && !cid && configs.length === 1 && u.isEmpty(configs[0]["d"])) {
            matchedcfg = setMatchedConfigDefaults(configs[0])
        }
        return matchedcfg
    }

    function logErrors(evt, msg) {
        u.logErrors("UTT", evt, msg, version, accountId)
    }

    function getCampaignConfigFromTracker(trackId, options) {
        var x = 0;
        var xx = configs.length;
        var y;
        var yy;
        var tids;
        var cfg;
        while (x < xx) {
            cfg = configs[x];
            tids = cfg.ti;
            y = 0;
            yy = tids.length;
            while (y < yy) {
                if (tids[y] == trackId) {
                    cfg = setCampaignDefaults(cfg);
                    if ((cfg.vs || options.verifySiteDefinitionMatch) && !regexMatch(cfg.d, stripProtocol(landingPage))) {
                        logErrors("verifySiteDefinitionMatch exit", "no matching site definition for landing page");
                        return null
                    }
                    sessionCookie = u.getCookie(getCookieName(cfg.id));
                    return cfg
                }
                y += 1
            }
            x += 1
        }
        return null
    }

    function isNewSession(inactivityWin) {
        var lastActivity;
        if (sessionCookie) {
            lastActivity = parseInt(sessionCookie.split("|")[0], 10);
            if (timeStamp - lastActivity <= inactivityWin * 60 * 1000) {
                return false
            }
        }
        return true
    }

    function getCurrentSessionId(iw) {
        if (isNewSession(iw)) {
            return timeStamp
        }
        return sessionCookie.split("|")[2]
    }

    function getCookieMsId(iw) {
        return isNewSession(iw) ? 0 : sessionCookie.split("|")[1]
    }

    function getGatewayClickId() {
        return sessionCookie && sessionCookie.split("|")[3]
    }

    function getGoogleClickId(iw) {
        return isNewSession(iw) ? "" : sessionCookie.split("|")[4]
    }

    function setSessionCookie(camp, msId, clickId, sessionId, googleClickId) {
        var value = timeStamp + "|" + (msId || getCookieMsId(camp.iw));
        value += "|" + (sessionId || getCurrentSessionId(camp.iw));
        clickId = clickId || getGatewayClickId();
        value += "|" + (clickId || "");
        value += "|" + (googleClickId || getGoogleClickId(camp.iw));
        sessionCookie = u.setCookie(getCookieName(camp.id), value)
    }

    function getUUID() {
        return uuidAndNextXhrExpiry ? uuidAndNextXhrExpiry.split("|")[0] : ""
    }

    function isUUIDAvailable() {
        var uuidExp = uuidAndNextXhrExpiry ? parseInt(uuidAndNextXhrExpiry.split("|")[1], 10) : "";
        return !u.isEmpty(getUUID()) && (uuidExp > timeStamp)
    }

    function setUUIDAndNextXhrExpiry(uuid) {
        uuid = getUUID() || uuid;
        uuidAndNextXhrExpiry = (!u.isEmpty(uuid) ? uuid : timeStamp.toString() + "." + Math.random().toString(36).substring(2, 15)) + "|" + (timeStamp + (24 * 60 * 60 * 1000));
        u.setCookie(uuidCkName, uuidAndNextXhrExpiry, 720)
    }

    function getOptionsOverrides(options, campCfg) {
        return u.extend({
            node: campCfg.tag || "img",
            domReady: campCfg.domReady
        }, options)
    }

    function getMappedQueryString(props, omap, imap) {
        var tagSrc = "";
        var i;
        var len;
        var n;
        var items = typeof props.items === "object" && !props.items.length ? [props.items] : props.items;
        var it;
        var id;
        var p;
        imap = imap || {
            promocodedesc: "pd",
            promocode: "p",
            sku: "sku",
            price: "pr",
            subtotal: "amt",
            quantity: "qty",
            name: "nme",
            mpn: "ms",
            subcategory: "sc",
            deliverytype: "dt",
            discount: "r",
            category: "cat",
            totaldiscount: "tr",
            totalrebate: "rbt",
            brand: "bnd",
            referenceid: "refid"
        };
        omap = omap || {
            ordersubtotalprediscount: "oabd",
            ordersubtotalpostdiscount: "amount",
            referenceid: "refid",
            customeremail: "custemail",
            customerid: "custid",
            searchterm: "searchtxt",
            actiontrackerid: "irchannel",
            customercity: "custct",
            customercountry: "custctry",
            customerpostcode: "postcode",
            customerregion: "custrgn",
            orderrebate: "rebate",
            orderdiscount: "odsc",
            money1: "mny1",
            money2: "mny2",
            money3: "mny3",
            date1: "date1",
            date2: "date2",
            date3: "date3",
            numeric1: "num1",
            numeric2: "num2",
            numeric3: "num3",
            text1: "str1",
            text2: "str2",
            text3: "str3",
            orderpromocodedesc: "pmod",
            orderpromocode: "pmoc",
            note: "note",
            siteversion: "sitever",
            sitecategory: "sitecat",
            hearaboutus: "hrau",
            ordershipping: "st",
            customerstatus: "cs",
            currencycode: "currcd",
            ordertax: "tax",
            giftpurchase: "gp",
            orderid: "oid",
            paymenttype: "pt",
            locationname: "ln",
            locationtype: "lt",
            locationid: "li"
        };

        function getNameFromMap(p, map) {
            var np = p.toLowerCase();
            if (map[np]) {
                return map[np]
            }
            if (/^enc/.test(p) && map[np.slice(3)]) {
                return "e_" + map[np.slice(3)]
            }
            return p
        }

        function hasDifferentMappedItemName(p, inmap) {
            return p === "sku" || p !== getNameFromMap(p, inmap)
        }
        for (n in props) {
            if (props.hasOwnProperty(n)) {
                if (n === "items" && items) {
                    i = 0;
                    len = items.length;
                    while (i < len) {
                        it = items[i];
                        id = i + 1;
                        for (p in it) {
                            if (it.hasOwnProperty(p)) {
                                if (hasDifferentMappedItemName(p, imap)) {
                                    tagSrc += "&" + getNameFromMap(p, imap) + id + "=" + encodeURIComponent(it[p])
                                }
                            }
                        }
                        if (it.custparam) {
                            tagSrc += "&cup" + id + "=" + encodeURIComponent(encodeURIComponent(it.custparam["name"]) + "=" + encodeURIComponent(it.custparam["value"]))
                        }
                        i += 1
                    }
                } else {
                    if (props[n]) {
                        tagSrc += "&" + getNameFromMap(n, omap) + "=" + encodeURIComponent(props[n])
                    }
                }
            }
        }
        return tagSrc.substring(1)
    }

    function doXHR(url, slugs, successCallback, errorCallback) {
        var xhr = false;
        var type = "POST";
        var firedErrorCb = false;
        var startTime = new Date().getTime();
        var parts = url.split("?");

        function fireErrorCallback(code, msg, xhrObj) {
            if (!firedErrorCb) {
                errorCallback(code)
            }
            firedErrorCb = true;
            logErrors("doXHR problem", +msg + ": " + xhrObj.readyState + ", status: " + xhrObj.status + ", ts: " + timeStamp + ", time: " + (new Date().getTime() - startTime) + ", text: " + xhrObj.statusText + ", url: " + url)
        }
        try {
            url = replaceSubmissionSlug(parts[0], "xhr", slugs);
            xhr = new XMLHttpRequest();
            if (xhr && typeof XDomainRequest === "undefined" && "withCredentials" in xhr) {
                xhr.open(type, url, true);
                xhr.withCredentials = true;
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
            } else {
                logErrors("doXHR support", "XHR is not supported");
                return false
            }
            xhr.timeout = 5000;
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        if (successCallback) {
                            successCallback(io.JSON.parse(xhr.responseText))
                        }
                    } else {
                        fireErrorCallback("f", "XHR readyState", xhr)
                    }
                }
            };
            xhr.ontimeout = function() {
                fireErrorCallback("t", "doXHR timeout", xhr)
            };
            xhr.onerror = function() {
                fireErrorCallback("e", "doXHR error", xhr)
            };
            xhr.onabort = function() {
                fireErrorCallback("a", "doXHR abort", xhr)
            };
            xhr.send(parts[1]);
            return xhr
        } catch (e) {
            fireErrorCallback("c", "catch: " + e.message, xhr);
            return false
        }
    }

    function doDomNode(url, options, slugs) {
        function appendTag(tag, useDomReady) {
            try {
                onDomReady(function() {
                    d.body.appendChild(tag)
                }, useDomReady)
            } catch (e) {
                logErrors("appendTag() error", e.message);
                if (!useDomReady) {
                    onDomReady(function() {
                        d.body.appendChild(tag)
                    }, true)
                }
            }
        }
        var type = options.tag || options.node;
        url = replaceSubmissionSlug(url, type, slugs);
        var node = d.createElement(type);
        if (type === "iframe") {
            node.frameborder = 0
        } else {
            node.border = 0
        }
        if (options.id) {
            node.id = options.id
        }
        node.style.position = "absolute";
        node.style.visibility = "hidden";
        if (url) {
            node.src = url
        }
        node.width = 0;
        node.height = 0;
        node.style.width = "0px";
        node.style.height = "0px";
        node.style.border = "0px";
        appendTag(node, options.domReady);
        return node
    }

    function doSessionSpecificTasks(me, camp, msId, clickId, passedSessionId, googleClickId) {
        if (sessionCb.length && isNewSession(camp.iw)) {
            var x = 0;
            var xx = sessionCb.length;
            try {
                while (x < xx) {
                    sessionCb[x].call(me, camp, getUUID(), timeStamp, msId);
                    x += 1
                }
                sessionCb = []
            } catch (e) {
                logErrors("doSessionCallback error", e.message)
            }
        }
        setSessionCookie(camp, msId, clickId, passedSessionId, googleClickId)
    }

    function getId(prefix) {
        return "IR-" + (prefix || "") + (++idSeed)
    }

    function doTracking(url, campaign, options, type, slugs, callback, requiresPostback, gatewayClickId) {
        options.id = options.id || getId();

        function appendCommonParams(preUrl) {
            var param = "";
            if (gatewayClickId) {
                preUrl += buildQueryParam("clickid", gatewayClickId)
            }
            if (getGoogleClickId(campaign.iw)) {
                preUrl += buildQueryParam("irgclid", getGoogleClickId(campaign.iw))
            }
            param += version + "|";
            param += getUUID();
            param += "|" + getCurrentSessionId(campaign.iw);
            return preUrl + buildQueryParam("_ir", param)
        }

        function getTrackingMethod(obj) {
            return obj.beacon ? "beacon" : (!obj.style ? "xhr" : options.node)
        }

        function doCallbacksAndReporter(obj, fullUrl, passedMethod) {
            if (callback) {
                callback()
            }
            var method = passedMethod || getTrackingMethod(obj);
            doReporter(options.id, {
                type: type,
                options: options,
                obj: obj,
                method: method,
                slug: slugs[method],
                ref: referrer,
                lp: landingPage,
                ver: version,
                mcfg: mcfg,
                url: fullUrl
            })
        }

        function doPostbacks(postbacks) {
            if (postbacks) {
                onDomReady(function() {
                    try {
                        for (var x = 0, xx = postbacks.length; x < xx; ++x) {
                            var pb = postbacks[x];
                            if (pb.u) {
                                doDomNode(pb.u, {
                                    node: pb.t === "if" ? "iframe" : "img"
                                })
                            } else {
                                if (pb.c) {
                                    var node = doDomNode(false, {
                                            tag: "iframe",
                                            id: "impactPiggyFrame" + x
                                        }),
                                        doc = node.contentDocument ? node.contentDocument : (node.contentWindow ? node.contentWindow.document : node.document);
                                    doc.open();
                                    doc.write(pb.c);
                                    doc.close()
                                }
                            }
                        }
                    } catch (e) {
                        logErrors("doPostbacks error", e.message)
                    }
                }, true)
            }
        }

        function track(failValue) {
            var urlWithParams = appendCommonParams(url),
                obj, pb = function(responseText) {
                    doPostbacks(responseText.tps)
                },
                xhrf = "xhrf";

            function xhrFailureDomBackupMethod(mobj, val) {
                mobj = doDomNode(urlWithParams + buildQueryParam(xhrf, val), options, slugs);
                doCallbacksAndReporter(mobj, replaceSubmissionSlug(urlWithParams, getTrackingMethod(mobj), slugs))
            }
            if (failValue) {
                urlWithParams += buildQueryParam(xhrf, failValue)
            }
            if (domMode) {
                obj = doDomNode(urlWithParams, options, slugs)
            } else {
                if (options.tag) {
                    switch (options.tag) {
                        case "xhr":
                            obj = doXHR(urlWithParams, slugs, pb, function(val) {
                                var innerUrl = urlWithParams + buildQueryParam(xhrf, val);
                                obj = doBeacon(innerUrl, slugs) || doDomNode(innerUrl, options, slugs);
                                doCallbacksAndReporter(obj, replaceSubmissionSlug(urlWithParams, getTrackingMethod(obj), slugs))
                            }) || doBeacon(urlWithParams, slugs) || doDomNode(urlWithParams, options, slugs);
                            break;
                        case "img":
                            obj = doDomNode(urlWithParams, options, slugs);
                            break;
                        case "iframe":
                            obj = doDomNode(urlWithParams, options, slugs);
                            break;
                        default:
                            obj = doBeacon(urlWithParams, slugs) || doXHR(urlWithParams, slugs, pb, function(val) {
                                xhrFailureDomBackupMethod(obj, val)
                            }) || doDomNode(urlWithParams, options, slugs)
                    }
                } else {
                    if (requiresPostback) {
                        obj = doXHR(urlWithParams, slugs, pb, function(val) {
                            xhrFailureDomBackupMethod(obj, val)
                        }) || doDomNode(urlWithParams, options, slugs)
                    } else {
                        obj = doBeacon(urlWithParams, slugs) || doXHR(urlWithParams, slugs, pb, function(val) {
                            xhrFailureDomBackupMethod(obj, val)
                        }) || doDomNode(urlWithParams, options, slugs)
                    }
                }
            }
            if (obj) {
                doCallbacksAndReporter(obj, replaceSubmissionSlug(urlWithParams, getTrackingMethod(obj), slugs))
            }
        }
        try {
            if (!domMode && !isUUIDAvailable()) {
                if (options.tag && options.tag !== "xhr") {
                    setUUIDAndNextXhrExpiry();
                    track()
                } else {
                    var urlAndParams = appendCommonParams(url),
                        xhrObj = doXHR(urlAndParams, slugs, function(responseText) {
                            setUUIDAndNextXhrExpiry(responseText.fpc);
                            doPostbacks(responseText.tps);
                            doCallbacksAndReporter(xhrObj, replaceSubmissionSlug(urlAndParams, "xhr", slugs), "xhr")
                        }, function(failValue) {
                            setUUIDAndNextXhrExpiry();
                            track(failValue)
                        }) || function() {
                            setUUIDAndNextXhrExpiry();
                            doDomNode(urlAndParams, options, slugs);
                            doCallbacksAndReporter(xhrObj, replaceSubmissionSlug(urlAndParams, options.tag, slugs), options.tag)
                        }()
                }
            } else {
                setUUIDAndNextXhrExpiry();
                track()
            }
        } catch (e) {
            logErrors("doTracking error", e.message)
        }
    }

    function Event(a, v, c) {
        configs = c;
        version = v;
        accountId = a
    }
    Event.prototype = {
        enforceDomNode: function() {
            domMode = true
        },
        setNewSessionCallback: function(cb) {
            sessionCb.push(cb);
            return this
        },
        setPageViewCallback: function(cb) {
            viewCb = cb;
            return this
        },
        secureConversion: function(trackerId, encryptStr, iv, props, options) {
            props = props || {};
            options = options || {};
            try {
                landingPage = getDefinedUrl([options.pageUrl, landingPage]);
                var camp = setMatchedConfig(getCampaignConfigFromTracker(trackerId, options));
                if (!camp) {
                    logErrors("secureConversion() exit", "campaign not found for tracker:" + trackerId);
                    return this
                }
                options = getOptionsOverrides(options, camp.ccc);
                var src = getTrackDomain(camp) + "/" + slug + "/" + trackerId + "/" + camp.id + "?edata=" + encodeURIComponent(encryptStr) + "&iv=" + encodeURIComponent(iv);
                doSessionSpecificTasks(this, camp);
                doTracking(src, camp, options, "secureConversion", getSlugObject("bconv", "xconv", "jconv", "jifconv"), false, true)
            } catch (e) {
                logErrors("secureConversion() error", e.message)
            }
        },
        identify: function(props, options) {
            function getMatchingRule(config) {
                function hasMatchingAndRules(andRules) {
                    function ruleMet(rule) {
                        function matchesRule(rule, value) {
                            function safeLowerCase(val) {
                                return typeof val === "string" ? val.toLowerCase() : val
                            }

                            function contains(value, ruleValue) {
                                return safeLowerCase(value).indexOf(safeLowerCase(ruleValue)) !== -1
                            }

                            function matches(val1, val2) {
                                return safeLowerCase(val1) === safeLowerCase(val2)
                            }
                            var ruleValue = rule.v,
                                ruleOperator = rule.o;
                            if (ruleOperator !== "np" && !u.hasValue(value)) {
                                return false
                            }

                            function matchesAny(rVals, value) {
                                rVals = rVals.split(",");
                                for (var x = 0, len = rVals.length; x < len; ++x) {
                                    if (matches(rVals[x], value)) {
                                        return true
                                    }
                                }
                                return false
                            }

                            function containsAny(rVals, value) {
                                rVals = rVals.split(",");
                                for (var x = 0, len = rVals.length; x < len; ++x) {
                                    if (contains(value, rVals[x])) {
                                        return true
                                    }
                                }
                                return false
                            }
                            switch (ruleOperator) {
                                case "m":
                                    return matches(ruleValue, value);
                                case "c":
                                    return value && contains(value, ruleValue);
                                case "sw":
                                    return value && safeLowerCase(value).lastIndexOf(safeLowerCase(ruleValue), 0) === 0;
                                case "ew":
                                    return value && value.length >= ruleValue.length && safeLowerCase(value).substr(value.length - ruleValue.length) == safeLowerCase(ruleValue);
                                case "r":
                                    return regexMatch(ruleValue, value);
                                case "nm":
                                    return !matches(ruleValue, value);
                                case "nc":
                                    return !contains(value, ruleValue);
                                case "nr":
                                    return !regexMatch(ruleValue, value);
                                case "ma":
                                    return matchesAny(ruleValue, value);
                                case "ca":
                                    return value && containsAny(ruleValue, value);
                                case "p":
                                    return u.hasValue(value);
                                case "np":
                                    return !u.hasValue(value)
                            }
                        }
                        var ruleAttribute = rule.a,
                            ruleValue = rule.v;

                        function getQueryString(url) {
                            if (url.indexOf("?") !== -1) {
                                return url.split("?")[1] || ""
                            }
                            return ""
                        }

                        function matchesQueryParamRule(url) {
                            var o = rule.o,
                                negRule = o === "nm" || o === "nc" || o === "nr";
                            var pv = extractQueryParam(url, ruleAttribute, ruleValue && !u.strContains(ruleValue, "%2") && !u.strContains(ruleValue, "+"));
                            return (!u.hasValue(pv) && negRule) || matchesRule(rule, pv)
                        }
                        switch (rule.t) {
                            case "rd":
                                return matchesRule(rule, referrerDomain);
                            case "ru":
                                return matchesRule(rule, referrer);
                            case "rq":
                                return matchesRule(rule, getQueryString(referrer));
                            case "rp":
                                return matchesQueryParamRule(referrer);
                            case "lu":
                                return matchesRule(rule, landingPage);
                            case "ld":
                                return matchesRule(rule, u.extractDomain(landingPage));
                            case "lq":
                                return matchesRule(rule, getQueryString(landingPage));
                            case "lp":
                                return matchesQueryParamRule(landingPage)
                        }
                    }
                    for (var x = 0, len = andRules.length; x < len; ++x) {
                        if (!ruleMet(andRules[x])) {
                            return false
                        }
                    }
                    return true
                }
                var id, y, yy, item;
                if (config) {
                    for (var x = 0, xx = config.length; x < xx; ++x) {
                        item = config[x];
                        for (id in item) {
                            if (item.hasOwnProperty(id)) {
                                for (y = 0, yy = item[id]["r"].length; y < yy; ++y) {
                                    if (hasMatchingAndRules(item[id]["r"][y])) {
                                        if (item[id]["b"]) {
                                            return blackListMatchingId
                                        }
                                        return id
                                    }
                                }
                            }
                        }
                    }
                }
                return null
            }
            props = props || {};
            options = options || {};

            function hasIRGatewayParam(lp, gClickId, c) {
                return !u.isEmpty(extractQueryParam(lp, c.gp, true)) || !u.isEmpty(gClickId)
            }

            function shouldEval(newSess, ref, c, rd, lp, gClickId, googClickId) {
                function intraSite() {
                    if (c.d && ref) {
                        var referrerPath = stripProtocol(ref.split("?")[0]);
                        return regexMatch(c.d, referrerPath)
                    }
                    return rd == (w.location.port ? w.location.hostname + ":" + w.location.port : w.location.hostname)
                }
                if (!intraSite() && !hasIRGatewayParam(lp, gClickId, c) && !u.hasValue(googClickId)) {
                    if (!newSess && u.isPaymentSite(ref)) {
                        return false
                    }
                    return true
                }
                return false
            }

            function getMsId(id, isChannel, lp, gClickId, c) {
                if (hasIRGatewayParam(lp, gClickId, c)) {
                    return -1
                }
                if (!id) {
                    return 0
                }
                if (isChannel) {
                    return "c-" + id
                }
                return id
            }

            function getSlugs(isChannel) {
                function appendForChannel(value) {
                    return isChannel ? value + "h" : value
                }
                return getSlugObject(appendForChannel("bc"), appendForChannel("xc"), appendForChannel("pc"), appendForChannel("ifc"))
            }

            function getDltValue(prop, alt, c, lp) {
                if (c.dlt && c.dlt[prop]) {
                    return extractQueryParam(lp, c.dlt[prop], true) || alt
                }
                return alt
            }

            function buildTagSrc(undefSrcValue, matchId, isChannel, lp, c, rd, ref) {
                function getKeywords(r) {
                    var a = /[\?|&](q|p|query|encquery|terms|rdata|szukaj|k|qt|qs|wd|text)=([^&#]*)/.exec(r);
                    if (a) {
                        return u.safeDecodeURIComponent(a[2])
                    }
                    return ""
                }

                function extractSrcParams(msId, isChannel) {
                    var src = "";
                    var params = "subId1,subId2,subId3,sharedid,aadid,trafcat,trafsrc,irck,irak,iratid,irappid,matchtype,adnetwork,adposition,adplacement,adcampaign,adcampaigngroup,adgroup,adcampaignid,adgroupid,adcampaigngroupid,addisttype,adtype,adname,adid,prodcat,prodsubcat,prodsku,param1,param2,param3,param4,subacctid,subacctname,subclkid,kw,kwid,custid";
                    var ps = params.split(",");
                    var v;
                    var x = 0;
                    var xx;
                    var mmap;
                    var splitParams;
                    for (var i = 0, ii = ps.length; i < ii; ++i) {
                        v = extractQueryParam(lp, ps[i], true);
                        if (v) {
                            src += buildQueryParam(ps[i], v)
                        }
                    }
                    for (i in c.cp) {
                        if (c.cp.hasOwnProperty(i)) {
                            v = extractQueryParam(lp, i, true);
                            if (v) {
                                mmap = !isChannel ? (c.cp[i][msId] || c.cp[i]["default"]) : c.cp[i]["default"];
                                if (!mmap) {
                                    continue
                                }
                                if (!mmap.o && mmap.p && mmap.p.length) {
                                    src += buildQueryParam(mmap.p[0], v)
                                } else {
                                    if (mmap.o === 1 && mmap.d) {
                                        splitParams = v.split(mmap.d);
                                        for (x = 0, xx = mmap.p.length; x < xx; ++x) {
                                            if (splitParams[x]) {
                                                src += buildQueryParam(mmap.p[x], splitParams[x])
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return src
                }

                function isSeo(r) {
                    return /\b(google|yahoo|msn|bing|aol|lycos|ask|altavista|netscape|cnn|looksmart|about|mamma|alltheweb|gigablast|voila|virgilio|live|baidu|alice|yandex|najdi|club-internet|mama|seznam|search|szukaj|netsprint|google.interia|szukacz|yam|pchome)\b/.test(r)
                }
                var tagParams = "",
                    tagPath = slug + "/" + matchId + "/" + getDltValue("adid", c.ad, c, lp) + "/" + c.id + "?";
                tagParams += extractSrcParams(matchId, isChannel);
                if (isSeo(rd)) {
                    tagParams += buildQueryParam("searchtxt", getKeywords(ref))
                }
                if (isChannel) {
                    if (undefSrcValue) {
                        tagParams += buildQueryParam("irmm_srcname", undefSrcValue)
                    } else {
                        if (rd) {
                            tagParams += buildQueryParam("irmm_domain", rd)
                        }
                    }
                }
                tagParams += buildQueryParam("srcref", ref);
                tagParams += buildQueryParam("landurl", lp);
                tagParams += "&" + getMappedQueryString(props, {
                    customeremail: "custemail",
                    customerid: "custid"
                });
                return getTrackDomain(c) + "/" + tagPath + tagParams.substr(1)
            }
            try {
                landingPage = getDefinedUrl([options.pageUrl, landingPage]);
                referrer = getDefinedUrl([options.referrerUrl, referrer]);
                var undefSrcValue, camp = setMatchedConfig(getCampaignConfig(props.campaignId)),
                    nsess, matchingId, nodeSrc, isChannel, hasFiredIdentify;
                if (!camp) {
                    logErrors("identify() exit", "No campaign for landing page: " + landingPage);
                    doReporter(options.id || getId(), {
                        type: "Identify",
                        options: options,
                        ref: referrer,
                        lp: landingPage,
                        ver: version,
                        nofiremsg: "No Campaign"
                    });
                    return this
                }
                var gatewayClickId = extractQueryParam(landingPage, camp.gc, true);
                if (gatewayClickId) {
                    var passedSessionId = extractQueryParam(landingPage, "_ics", true)
                }
                var googleClickId = extractQueryParam(landingPage, "irgclid", true);
                options = getOptionsOverrides(options, camp.csc);
                referrerDomain = u.extractDomain(referrer);
                nsess = isNewSession(camp.iw);
                if (!hasInvokedIdentify && shouldEval(nsess, referrer, camp, referrerDomain, landingPage, gatewayClickId, googleClickId)) {
                    matchingId = getDltValue("mpid", getMatchingRule(camp.pc), camp, landingPage);
                    if (!matchingId) {
                        matchingId = getMatchingRule(camp.sc)
                    }
                    if (!matchingId) {
                        matchingId = getMatchingRule(camp.cc);
                        if (camp.up) {
                            undefSrcValue = extractQueryParam(landingPage, camp.up, true)
                        }
                        if (!matchingId) {
                            if (referrerDomain || undefSrcValue) {
                                isChannel = true;
                                matchingId = camp.oc
                            } else {
                                matchingId = camp.dc
                            }
                            if (!undefSrcValue && matchingId && matchingId === camp.dc) {
                                if (nsess) {
                                    matchingId = camp.ds
                                } else {
                                    matchingId = null
                                }
                            }
                        } else {
                            isChannel = true
                        }
                    }
                    if (matchingId && getMsId(matchingId, isChannel, landingPage, googleClickId, camp) !== getCookieMsId(camp.iw) && matchingId !== blackListMatchingId) {
                        nodeSrc = buildTagSrc(undefSrcValue, matchingId, isChannel, landingPage, camp, referrerDomain, referrer);
                        if (!nsess) {
                            nodeSrc += buildQueryParam("isc", "1")
                        }
                        doTracking(nodeSrc, camp, options, "identify", getSlugs(isChannel), null, null, gatewayClickId);
                        hasFiredIdentify = true
                    }
                }
                doSessionSpecificTasks(this, camp, getMsId(matchingId, isChannel, landingPage, googleClickId, camp), gatewayClickId, passedSessionId, googleClickId);
                if (!hasFiredIdentify) {
                    doReporter(options.id || getId(), {
                        type: "Identify",
                        options: options,
                        ref: referrer,
                        lp: landingPage,
                        ver: version,
                        mcfg: mcfg,
                        nofiremsg: "No matching source"
                    });
                    this.identifyUser(props, options, camp)
                }
                if (camp.csc["fq"] && (nsess || hasFiredIdentify)) {
                    this.trackQuality(u.extend({
                        requestType: "click",
                        subSourceId: undefSrcValue || props.subSourceId || "",
                        sourceId: matchingId || props.sourceId || ""
                    }, props), u.extend(options, {
                        noPassProps: true
                    }), camp)
                }
                if (camp.ld) {
                    this.autoCrossDomainLinks(props, options, camp)
                }
                hasInvokedIdentify = true
            } catch (e) {
                logErrors("identify() error", e.message)
            }
            return this
        },
        trackQuality: function(props, options, passedCampaign) {
            props = props || {};
            options = options || {};

            function deletePropertyAndGetValue(prop) {
                var val = props[prop];
                delete props[prop];
                return val
            }
            landingPage = getDefinedUrl([options.pageUrl], landingPage);
            var propCampaign = deletePropertyAndGetValue("campaignId");
            var camp = passedCampaign || setMatchedConfig(getCampaignConfig(propCampaign)) || {};
            var iw = camp.iw || 30;
            var fqObj = {
                org: deletePropertyAndGetValue("orgId") || camp.fq || "not_set",
                rt: deletePropertyAndGetValue("requestType") || "click",
                p: deletePropertyAndGetValue("sourceId") || getCookieMsId(iw) || "",
                sl: deletePropertyAndGetValue("score") || "0",
                rd: deletePropertyAndGetValue("pageUrl") || landingPage,
                a: deletePropertyAndGetValue("subSourceId") || "",
                rf: document.referrer,
                cmp: propCampaign || camp.id || ""
            };
            if (!u.isEmpty(props.sessionId) || !u.isEmpty(getUUID())) {
                fqObj.s = deletePropertyAndGetValue("sessionId") || getUUID() + "." + getCurrentSessionId(iw)
            }
            if (!options.noPassProps) {
                fqObj = u.extend(props, fqObj)
            }
            var qs = [];
            for (var key in fqObj) {
                if (fqObj.hasOwnProperty(key)) {
                    qs.push(encodeURIComponent(key) + "=" + encodeURIComponent(fqObj[key]))
                }
            }
            var scriptElement = document.createElement("script");
            scriptElement[["s", "c"].join("r")] = "https://fqtag.com/implement.js?" + qs.join("&");
            scriptElement.async = true;
            scriptElement.id = options.id ? "fq" + options.id : "fq" + getId();
            d.body.appendChild(scriptElement)
        },
        trackConversion: function(trackId, props, options) {
            props = props || {};
            options = options || {};

            function fireConversionPixel(props, campaign, trackId, options) {
                try {
                    var src = getTrackDomain(campaign) + "/" + slug + "/" + trackId + "/" + campaign.id + "?" + getMappedQueryString(props);
                    options = getOptionsOverrides(options, campaign.ccc);
                    doTracking(src, campaign, options, "trackConversion", getSlugObject("bconv", "xconv", "jconv", "jifconv"), false, true)
                } catch (e) {
                    logErrors("fireConversionPixel() error", e.message)
                }
            }
            try {
                landingPage = getDefinedUrl([options.pageUrl, landingPage]);
                var camp = setMatchedConfig(getCampaignConfigFromTracker(trackId, options));
                if (!camp) {
                    logErrors("trackConversion() exit", "campaign not found for tracker:" + trackId);
                    return this
                }
                doSessionSpecificTasks(this, camp);
                fireConversionPixel(props, camp, trackId, options);
                if (camp.ccc["fq"]) {
                    var passedParams = {
                        requestType: "action"
                    };
                    if (props.orderid) {
                        passedParams.stId = props.orderid
                    }
                    this.trackQuality(u.extend(props, passedParams), u.extend(options, {
                        noPassProps: true
                    }), camp)
                }
            } catch (e) {
                logErrors("trackConversion() error", e.message)
            }
        },
        track: function(evt, props, options) {
            props = props || {};
            options = options || {};
            try {
                if (props.actionTrackerId) {
                    this.trackConversion(props.actionTrackerId, props, options)
                } else {
                    landingPage = getDefinedUrl([options.pageUrl, landingPage]);
                    var camp = setMatchedConfig(getCampaignConfig(props.campaignId));
                    if (!camp) {
                        logErrors("track() exit", "campaign not found for event:" + evt);
                        return this
                    }
                    options = getOptionsOverrides(options, camp.cec);
                    var src = getTrackDomain(camp) + "/" + slug + "/" + getCookieMsId(camp.iw) + "/" + camp.id + "?evt=" + encodeURIComponent(evt) + "&" + getMappedQueryString(props);
                    doSessionSpecificTasks(this, camp);
                    doTracking(src, camp, options, "Track (" + evt + ")", getSlugObject("evb", "evx", "evp", "evi"))
                }
            } catch (e) {
                logErrors("track() error", e.message)
            }
        },
        trackCart: function(trackerId, props, options) {
            props = props || {};
            options = options || {};
            try {
                landingPage = getDefinedUrl([options.pageUrl, landingPage]);
                var camp = setMatchedConfig(getCampaignConfigFromTracker(trackerId, options));
                var src;
                if (!camp) {
                    logErrors("trackCart() exit", "campaign not found for tracker:" + trackerId);
                    return this
                }
                src = getTrackDomain(camp) + "/" + slug + "/" + trackerId + "/" + camp.id + "?" + getMappedQueryString(props);
                options = getOptionsOverrides(options, camp.ccc);
                doSessionSpecificTasks(this, camp);
                doTracking(src, camp, options, "trackCart", getSlugObject("ceb", "cex", "ce", "ce"))
            } catch (e) {
                logErrors("trackCart() error", e.message)
            }
        },
        generateClickId: function(callback, props, options) {
            props = props || {};
            options = options || {};
            landingPage = getDefinedUrl([options.pageUrl, landingPage]);
            var camp = getCampaignConfig(props.campaignId),
                slugs = getSlugObject("xur", "xur", "xur", "xur");
            if (getGatewayClickId()) {
                return callback ? callback(getGatewayClickId()) : getGatewayClickId()
            }

            function jsGenerate() {
                var istest = options.test,
                    s = timeStamp.toString() + "-" + (istest ? "1" : "0") + "-" + getUUID(),
                    a = s.split(""),
                    shifted = new Array(a.length),
                    prev = 0,
                    off, letters = "abcdefghijklmnopqrsuvwxyz",
                    alphabet = "~-".concat(letters, letters.toUpperCase(), "0123456789").split(""),
                    map = {},
                    r;
                for (var i = 0, ii = alphabet.length; i < ii; ++i) {
                    map[alphabet[i]] = i
                }
                a.reverse();
                ii = a.length;
                for (i = 0; i < ii; ++i) {
                    off = map[a[i]];
                    if (off !== undefined) {
                        off += prev;
                        off %= alphabet.length;
                        shifted[i] = alphabet[off];
                        prev = off
                    } else {
                        shifted[i] = a[i]
                    }
                }
                r = "~" + shifted.join("");
                return r
            }

            function setUuidAndDoCallback(uuid) {
                setUUIDAndNextXhrExpiry(uuid);
                callback(jsGenerate())
            }
            if (isUUIDAvailable()) {
                if (callback) {
                    callback(jsGenerate())
                } else {
                    return jsGenerate()
                }
            } else {
                if (callback) {
                    doXHR(getTrackDomain(camp) + "/" + slug + "/" + camp.id, slugs, function(responseText) {
                        setUuidAndDoCallback(responseText.fpc)
                    }, function() {
                        setUuidAndDoCallback()
                    }) || setUuidAndDoCallback()
                } else {
                    setUUIDAndNextXhrExpiry();
                    return jsGenerate()
                }
            }
        },
        identifyUser: function(props, options, passedCampaign) {
            props = props || {};
            options = options ? u.extend({}, options) : {};
            for (var p in props) {
                if (props.hasOwnProperty(p)) {
                    var prop = props[p] ? u.trim(props[p].toString()) : null;
                    delete props[p];
                    if (!u.isEmpty(prop)) {
                        props[p.toLowerCase()] = prop
                    }
                }
            }
            landingPage = getDefinedUrl([options.pageUrl, landingPage]);
            referrer = getDefinedUrl([options.referrerUrl, referrer]);
            var camp = passedCampaign || setMatchedConfig(getCampaignConfig(props.campaignId));
            if (!props.customeremail && !props.customerid && u.isEmpty(getGatewayClickId())) {
                return this
            }
            if (!camp) {
                logErrors("identifyUser() exit", "No campaign for landing page: " + landingPage);
                return this
            }
            var src = getTrackDomain(camp) + "/" + slug + "/" + camp.id + "?";
            src += getMappedQueryString(props, {
                customeremail: "custemail",
                customerid: "custid"
            });
            options.id = options.id ? options.id + "-idUser" : getId();
            if (!passedCampaign) {
                doSessionSpecificTasks(this, camp, null)
            }
            doTracking(src, camp, options, "identifyUser", getSlugObject("cur", "xur", "ur", "iur"))
        },
        crossDomainLink: function(url, callback, props, options, passedCampaign) {
            props = props || {};
            options = options || {};
            var me = this;
            var camp = passedCampaign || getCampaignConfig(props.campaignId);

            function getLink() {
                var hasQueryString = u.strContains(url, "?");
                url += (!hasQueryString ? "?" : "");
                url += buildQueryParam("_ics", getCurrentSessionId(), !hasQueryString);
                url += buildQueryParam(props.clickParam || camp.gc || "clickid", me.generateClickId());
                return url
            }

            function doUuidAndCallback(uuid) {
                setUUIDAndNextXhrExpiry(uuid);
                callback(getLink())
            }
            if (isUUIDAvailable()) {
                if (callback) {
                    callback(getLink())
                } else {
                    return getLink()
                }
            } else {
                if (callback) {
                    doXHR(getTrackDomain(camp) + "/" + slug + "/" + camp.id, getSlugObject("xur", "xur", "xur", "xur"), function(responseText) {
                        doUuidAndCallback(responseText.fpc)
                    }, function() {
                        doUuidAndCallback()
                    }) || doUuidAndCallback()
                } else {
                    setUUIDAndNextXhrExpiry();
                    return getLink()
                }
            }
        },
        autoCrossDomainLinks: function(props, options, passedCampaign) {
            props = props || {};
            options = options || {};
            var me = this;
            w.MutationObserver = w.MutationObserver || function(w) {
                function v(a) {
                    this.i = [];
                    this.m = a
                }

                function I(a) {
                    (function c() {
                        var d = a.takeRecords();
                        d.length && a.m(d, a);
                        a.h = setTimeout(c, v._period)
                    })()
                }

                function p(a) {
                    var b = {
                            type: null,
                            target: null,
                            addedNodes: [],
                            removedNodes: [],
                            previousSibling: null,
                            nextSibling: null,
                            attributeName: null,
                            attributeNamespace: null,
                            oldValue: null
                        },
                        c;
                    for (c in a) {
                        b[c] !== w && a[c] !== w && (b[c] = a[c])
                    }
                    return b
                }

                function J(a, b) {
                    var c = C(a, b);
                    return function(d) {
                        var f = d.length,
                            n;
                        b.a && 3 === a.nodeType && a.nodeValue !== c.a && d.push(new p({
                            type: "characterData",
                            target: a,
                            oldValue: c.a
                        }));
                        b.b && c.b && A(d, a, c.b, b.f);
                        if (b.c || b.g) {
                            n = K(d, a, c, b)
                        }
                        if (n || d.length !== f) {
                            c = C(a, b)
                        }
                    }
                }

                function L(a, b) {
                    return b.value
                }

                function M(a, b) {
                    return "style" !== b.name ? b.value : a.style.cssText
                }

                function A(a, b, c, d) {
                    for (var f = {}, n = b.attributes, k, g, x = n.length; x--;) {
                        k = n[x], g = k.name, d && d[g] === w || (D(b, k) !== c[g] && a.push(p({
                            type: "attributes",
                            target: b,
                            attributeName: g,
                            oldValue: c[g],
                            attributeNamespace: k.namespaceURI
                        })), f[g] = !0)
                    }
                    for (g in c) {
                        f[g] || a.push(p({
                            target: b,
                            type: "attributes",
                            attributeName: g,
                            oldValue: c[g]
                        }))
                    }
                }

                function K(a, b, c, d) {
                    function f(b, c, f, k, y) {
                        var g = b.length - 1;
                        y = -~((g - y) / 2);
                        for (var h, l, e; e = b.pop();) {
                            h = f[e.j], l = k[e.l], d.c && y && Math.abs(e.j - e.l) >= g && (a.push(p({
                                type: "childList",
                                target: c,
                                addedNodes: [h],
                                removedNodes: [h],
                                nextSibling: h.nextSibling,
                                previousSibling: h.previousSibling
                            })), y--), d.b && l.b && A(a, h, l.b, d.f), d.a && 3 === h.nodeType && h.nodeValue !== l.a && a.push(p({
                                type: "characterData",
                                target: h,
                                oldValue: l.a
                            })), d.g && n(h, l)
                        }
                    }

                    function n(b, c) {
                        for (var g = b.childNodes, q = c.c, x = g.length, v = q ? q.length : 0, h, l, e, m, t, z = 0, u = 0, r = 0; u < x || r < v;) {
                            m = g[u], t = (e = q[r]) && e.node, m === t ? (d.b && e.b && A(a, m, e.b, d.f), d.a && e.a !== w && m.nodeValue !== e.a && a.push(p({
                                type: "characterData",
                                target: m,
                                oldValue: e.a
                            })), l && f(l, b, g, q, z), d.g && (m.childNodes.length || e.c && e.c.length) && n(m, e), u++, r++) : (k = !0, h || (h = {}, l = []), m && (h[e = E(m)] || (h[e] = !0, -1 === (e = F(q, m, r, "node")) ? d.c && (a.push(p({
                                type: "childList",
                                target: b,
                                addedNodes: [m],
                                nextSibling: m.nextSibling,
                                previousSibling: m.previousSibling
                            })), z++) : l.push({
                                j: u,
                                l: e
                            })), u++), t && t !== g[u] && (h[e = E(t)] || (h[e] = !0, -1 === (e = F(g, t, u)) ? d.c && (a.push(p({
                                type: "childList",
                                target: c.node,
                                removedNodes: [t],
                                nextSibling: q[r + 1],
                                previousSibling: q[r - 1]
                            })), z--) : l.push({
                                j: e,
                                l: r
                            })), r++))
                        }
                        l && f(l, b, g, q, z)
                    }
                    var k;
                    n(b, c);
                    return k
                }

                function C(a, b) {
                    var c = !0;
                    return function f(a) {
                        var k = {
                            node: a
                        };
                        !b.a || 3 !== a.nodeType && 8 !== a.nodeType ? (b.b && c && 1 === a.nodeType && (k.b = G(a.attributes, function(c, f) {
                            if (!b.f || b.f[f.name]) {
                                c[f.name] = D(a, f)
                            }
                            return c
                        })), c && (b.c || b.a || b.b && b.g) && (k.c = N(a.childNodes, f)), c = b.g) : k.a = a.nodeValue;
                        return k
                    }(a)
                }

                function E(a) {
                    try {
                        return a.id || (a.mo_id = a.mo_id || H++)
                    } catch (b) {
                        try {
                            return a.nodeValue
                        } catch (c) {
                            return H++
                        }
                    }
                }

                function N(a, b) {
                    for (var c = [], d = 0; d < a.length; d++) {
                        c[d] = b(a[d], d, a)
                    }
                    return c
                }

                function G(a, b) {
                    for (var c = {}, d = 0; d < a.length; d++) {
                        c = b(c, a[d], d, a)
                    }
                    return c
                }

                function F(a, b, c, d) {
                    for (; c < a.length; c++) {
                        if ((d ? a[c][d] : a[c]) === b) {
                            return c
                        }
                    }
                    return -1
                }
                v._period = 30;
                v.prototype = {
                    observe: function(a, b) {
                        for (var c = {
                                b: !!(b.attributes || b.attributeFilter || b.attributeOldValue),
                                c: !!b.childList,
                                g: !!b.subtree,
                                a: !(!b.characterData && !b.characterDataOldValue)
                            }, d = this.i, f = 0; f < d.length; f++) {
                            d[f].s === a && d.splice(f, 1)
                        }
                        b.attributeFilter && (c.f = G(b.attributeFilter, function(a, b) {
                            a[b] = !0;
                            return a
                        }));
                        d.push({
                            s: a,
                            o: J(a, c)
                        });
                        this.h || I(this)
                    },
                    takeRecords: function() {
                        for (var a = [], b = this.i, c = 0; c < b.length; c++) {
                            b[c].o(a)
                        }
                        return a
                    },
                    disconnect: function() {
                        this.i = [];
                        clearTimeout(this.h);
                        this.h = null
                    }
                };
                var B = document.createElement("i");
                B.style.top = 0;
                var D = (B = "null" != B.attributes.style.value) ? L : M,
                    H = 1;
                return v
            }(void 0);
            var allLinks = d.getElementsByTagName("a");
            var camp = passedCampaign || setMatchedConfig(getCampaignConfig(props.campaignId));
            var a;
            var href;
            var domain = u.extractDomain(landingPage);
            var hrefDomain;

            function doLinks(links) {
                for (var x = 0, xx = links.length; x < xx; x++) {
                    a = links[x];
                    href = a.href;
                    if (!u.isEmpty(href)) {
                        hrefDomain = u.extractDomain(href);
                        if (!u.strContains(hrefDomain, domain)) {
                            if ((props.domains && u.arrayContains(props.domains, hrefDomain)) || regexMatch(camp.d, stripProtocol(href))) {
                                a.href = me.crossDomainLink(href, null, props, options, camp)
                            }
                        }
                    }
                }
            }
            doLinks(allLinks);
            new MutationObserver(function(mutationsList, observer) {
                for (var x = 0, xx = mutationsList.length; x < xx; x++) {
                    doLinks(mutationsList[x].target.getElementsByTagName("a"))
                }
            }).observe(d.body, {
                childList: true,
                subtree: true
            })
        }
    };
    w.ImpactRadiusEvent = Event;
    var irEvent = new ImpactRadiusEvent("A1450388-e24d-4d48-8f36-14ba28d599111", "U26", [{
        id: "10138",
        td: "automattic.4oqh.net",
        ad: "626085",
        iw: 30,
        ti: [],
        d: "(?:(?:.*?\\.wordpress\\.com)|(?:^wordpress\\.com)|(?:.*?\\.jetpack\\.com)|(?:^jetpack\\.com)|(?:.*?\\.woocommerce)|(?:^woocommerce)|(?:.*?\\.com)|(?:^com)|(?:.*?\\.192\\.0\\.92\\.123)|(?:^192\\.0\\.92\\.123))",
        gp: "irgwc",
        gc: "irclickid",
        csc: {
            domReady: 1,
            tag: "img"
        },
        ccc: {
            domReady: 1,
            tag: "iframe"
        },
        cec: {
            domReady: 1,
            tag: "img"
        }
    }]);
    if (typeof irEvent !== "undefined") {
        var v = "ire_o",
            eventQueue = w[v] && w[w[v]].a ? w[w[v]].a : [];

        function fireEvent(a) {
            var ar = Array.prototype.slice.call(a);
            irEvent[ar.shift()].apply(irEvent, ar)
        }
        for (var x = 0, xx = eventQueue.length; x < xx; x++) {
            fireEvent(eventQueue[x])
        }
        w.ire = function() {
            fireEvent(arguments)
        };
        w.irEvent = irEvent
    }
})(window, document);