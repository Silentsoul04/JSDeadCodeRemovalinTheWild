(function(g) {
    var e = window.AmazonUIPageJS || window.P,
        k = e._namespace || e.attributeErrors,
        f = k ? k("AmazonUIPromise", "AmazonUI") : e;
    f.guardFatal ? f.guardFatal(g)(f, window) : f.execute(function() {
        g(f, window)
    })
})(function(g, e, k) {
    g.register("3p-promise", function() {
        function f() {}

        function g(a, b) {
            return function() {
                a.apply(b, arguments)
            }
        }

        function c(a) {
            if ("object" !== typeof this) throw new TypeError("Promises must be constructed via new");
            if ("function" !== typeof a) throw new TypeError("not a function");
            this._state = 0;
            this._handled = !1;
            this._value = k;
            this._deferreds = [];
            r(a, this)
        }

        function t(a, b) {
            for (; 3 === a._state;) a = a._value;
            0 === a._state ? a._deferreds.push(b) : (a._handled = !0, n(function() {
                var d = 1 === a._state ? b.onFulfilled : b.onRejected;
                if (null === d)(1 === a._state ? p : h)(b.promise, a._value);
                else {
                    var m;
                    try {
                        m = d(a._value)
                    } catch (c) {
                        h(b.promise, c);
                        return
                    }
                    p(b.promise, m)
                }
            }))
        }

        function p(a, b) {
            try {
                if (b === a) throw new TypeError("A promise cannot be resolved with itself.");
                if (b && ("object" === typeof b || "function" === typeof b)) {
                    var d = b.then;
                    if (b instanceof c) {
                        a._state = 3;
                        a._value = b;
                        q(a);
                        return
                    }
                    if ("function" === typeof d) {
                        r(g(d, b), a);
                        return
                    }
                }
                a._state = 1;
                a._value = b;
                q(a)
            } catch (m) {
                h(a, m)
            }
        }

        function h(a, b) {
            a._state = 2;
            a._value = b;
            q(a)
        }

        function q(a) {
            2 === a._state && 0 === a._deferreds.length && n(function() {
                a._handled || u(a._value)
            });
            for (var b = 0, d = a._deferreds.length; b < d; b++) t(a, a._deferreds[b]);
            a._deferreds = null
        }

        function v(a, b, d) {
            this.onFulfilled = "function" === typeof a ? a : null;
            this.onRejected = "function" === typeof b ? b : null;
            this.promise = d
        }

        function r(a, b) {
            var d = !1;
            try {
                a(function(a) {
                    d ||
                        (d = !0, p(b, a))
                }, function(a) {
                    d || (d = !0, h(b, a))
                })
            } catch (c) {
                d || (d = !0, h(b, c))
            }
        }
        if ("function" === typeof e.Promise) return e.Promise;
        var w = setTimeout,
            n = "function" === typeof setImmediate && setImmediate || function(a) {
                w(a, 0)
            },
            u = function(a) {
                "undefined" !== typeof console && console && console.warn("Possible Unhandled Promise Rejection:", a)
            };
        c.prototype["catch"] = function(a) {
            return this.then(null, a)
        };
        c.prototype.then = function(a, b) {
            var d = new this.constructor(f);
            t(this, new v(a, b, d));
            return d
        };
        c.all = function(a) {
            var b = Array.prototype.slice.call(a);
            return new c(function(a, c) {
                function f(e, l) {
                    try {
                        if (l && ("object" === typeof l || "function" === typeof l)) {
                            var h = l.then;
                            if ("function" === typeof h) {
                                h.call(l, function(a) {
                                    f(e, a)
                                }, c);
                                return
                            }
                        }
                        b[e] = l;
                        0 === --g && a(b)
                    } catch (k) {
                        c(k)
                    }
                }
                if (0 === b.length) return a([]);
                for (var g = b.length, e = 0; e < b.length; e++) f(e, b[e])
            })
        };
        c.resolve = function(a) {
            return a && "object" === typeof a && a.constructor === c ? a : new c(function(b) {
                b(a)
            })
        };
        c.reject = function(a) {
            return new c(function(b, d) {
                d(a)
            })
        };
        c.race = function(a) {
            return new c(function(b, d) {
                for (var c =
                        0, e = a.length; c < e; c++) a[c].then(b, d)
            })
        };
        c._setImmediateFn = function(a) {
            n = a
        };
        c._setUnhandledRejectionFn = function(a) {
            u = a
        };
        return c
    })
});
/* ******** */
(function(p) {
    var q = window.AmazonUIPageJS || window.P,
        u = q._namespace || q.attributeErrors,
        d = u ? u("AmazonUIBaseJS", "AmazonUI") : q;
    d.guardFatal ? d.guardFatal(p)(d, window) : d.execute(function() {
        p(d, window)
    })
})(function(p, q, u) {
    "use strict";
    p.when("jQuery").register("a-base", function(d) {
        return {
            version: function() {
                return "3.0"
            },
            $: d
        }
    });
    "use strict";
    p.when("p-recorder-events", "jQuery", "a-analytics", "a-util", "a-constants", "prv:a-post-atf").register("prv:a-declarative-analytics", function(d, k, f, b, g, e) {
        function n() {
            m();
            b.objectIsEmpty(c) || (k("[data-action]").each(function() {
                var a = this.getAttribute("data-action");
                t[a] = !0
            }), m(), c = {})
        }

        function m() {
            b.each(c, function(h, l) {
                t[h.daName] && (f.count("usage:tti", h.latency), delete c[l], a[l] = h)
            })
        }
        var r = q.ue_t0 || q.aPageStart || Date.now(),
            c = {},
            a = {},
            t = {};
        return 0 < d.length && q.ue ? {
            notify: function(h, l) {
                if (h && l && -1 !== b.indexOfArray(d, l)) {
                    var t = h + "/" + l;
                    if (!a[t] && !c[t]) {
                        var g = Date.now() - r;
                        c[t] = {
                            daName: h,
                            eventType: l,
                            latency: g
                        };
                        e.execute(n)
                    }
                }
            }
        } : {
            notify: g.constants.NOOP,
            setOptions: g.constants.NOOP
        }
    });
    "use strict";
    p.register("prv:a-guard", function() {
        function d(d, f) {
            return d._guard && "function" === typeof f ? d._guard(f) : f
        }
        return {
            fn: d,
            obj: function(k, f) {
                if (!k._guard) return f;
                var b = {},
                    g;
                for (g in f) f.hasOwnProperty(g) && (b[g] = d(k, f[g]));
                return b
            }
        }
    });
    "use strict";
    p.when("p-recorder-events", "a-analytics").register("a-timing-analytics", function(d, k) {
        function f(e) {
            b[e] = !0;
            0 !== d.length && q.uet && q.uex && q.uet("bb", e, g)
        }
        var b = {},
            g = {
                wb: 1
            };
        f("declarative");
        f("A");
        f("dropdown");
        f("carousel");
        return {
            startWidgetLogging: f,
            stopWidgetLogging: function(e) {
                0 !== d.length && q.uet && q.uex && e in b && (q.uet("cf", e, g), q.uex("ld", e, g))
            }
        }
    });
    "use strict";
    p.when("p-recorder-events", "jQuery", "a-analytics", "a-util", "prv:a-event-context", "prv:a-post-atf", "prv:a-collect-p-debug").register("a-event-analytics", function(d, k, f, b, g, e, n) {
        function m(a, h) {
            a = a + ":" + h;
            return a in z ? (h = z[a], delete z[a], h) : []
        }

        function r(a, h) {
            if (!(h in A)) return [];
            var c = [],
                l = b.filter(A[h], function(h) {
                    var l = k(h[0]).closest(a).length;
                    l && c.push(h[1]);
                    return !l
                });
            A[h] = l;
            return c
        }

        function c(a, h, c) {
            var l = m(a, h);
            if (l && l.length) try {
                f.increment("usage:true_udac", l.length);
                var t = "aui|udac|true_udac|" + h + "|" + a + "|see: https://tiny.amazon.com/1jppzyki8",
                    d = {
                        daName: a,
                        eventType: h,
                        events: []
                    };
                p.when("afterLoad").execute("logUdac", function() {
                    b.each(l, function(a) {
                        a = g.from(a).collect(F).collect(B).collect(C).dump();
                        d.events.push({
                            atf: a.isATF,
                            xpath: a.xpath,
                            selector: a.cssSelector,
                            feature: a.feature,
                            data: a.daData,
                            eventLatency: a.eventLatency,
                            handlerLatency: c,
                            attributionChain: b.attributionChain(a.target)
                        })
                    });
                    p.log(t, "WARN", JSON && JSON.stringify ? JSON.stringify(d) : "")
                })
            } catch (x) {}
        }

        function a(a, h, c) {
            var l = r(a, h);
            if (l && l.length) try {
                f.increment("usage:true_ujac", l.length);
                var t = b.xpath(l[0]._subject),
                    d = "aui|ujac|true_ujac|" + h + "|" + t + "|see: https://tiny.amazon.com/1jppzyki8",
                    x = {
                        xpath: t,
                        eventType: h,
                        events: []
                    };
                p.when("afterLoad").execute("logUjac", function() {
                    b.each(l, function(a) {
                        a = g.from(a).collect(F).collect(B).collect(C).dump();
                        x.events.push({
                            atf: a.isATF,
                            xpath: a.xpath,
                            selector: a.cssSelector,
                            feature: a.feature,
                            eventLatency: a.eventLatency,
                            handlerLatency: c,
                            attributionChain: b.attributionChain(a.target)
                        })
                    });
                    p.log(d, "WARN", JSON && JSON.stringify ? JSON.stringify(x) : "")
                })
            } catch (e) {}
        }

        function t(a) {
            return "unknown" !== typeof a.type
        }

        function h(a) {
            return k.event.fix(a)
        }

        function l(a) {
            return -1 !== b.indexOfArray(d, a.type)
        }

        function y(a) {
            return a.target !== document
        }

        function v(a) {
            return {
                eventType: a.type
            }
        }

        function x(a) {
            a = k(a.target).closest("[data-action]").get(0);
            return a === u ? null : a
        }

        function w(a) {
            return a.target
        }

        function G(a) {
            return {
                daName: a.getAttribute("data-action")
            }
        }

        function H(a) {
            var h = a.getAttribute("data-action");
            return {
                daData: a.getAttribute("data-" + h) || ""
            }
        }

        function F(a) {
            return {
                isATF: b.isATF(a)
            }
        }

        function B(a) {
            return {
                xpath: b.xpath(a),
                cssSelector: b.cssSelector(a)
            }
        }

        function I(a) {
            return {
                target: a.target
            }
        }

        function C(a) {
            var h;
            if (a = k(a).closest(J).get(0)) h = a.getAttribute(K), h || (a = a.id) && a.length > D.length && a.indexOf(D) === a.length - D.length && (h = a.slice(0, a.length - D.length));
            return {
                feature: h || ""
            }
        }

        function L(a) {
            return function() {
                return {
                    eventLatency: a
                }
            }
        }
        var z = {},
            A = {},
            J =
            "[id$\x3d_feature_div],.feature",
            K = "data-feature-name",
            D = "_feature_div",
            E = q.ue_t0 || q.aPageStart || Date.now();
        return {
            handle: function(a, c) {
                if (0 !== d.length) {
                    2 > arguments.length && (c = Date.now() - E);
                    var b = (new g(a)).filter(t).transform(h).filter(l).filter(y).collect(v).collect(L(c)).collect(I),
                        e = g.fromEventContext(b).transform(x).collect(G).collect(H),
                        b = b.transform(w);
                    if (e = e.dump()) {
                        var f = e.daName + ":" + e.eventType;
                        f in z || (z[f] = []);
                        z[f].push(e)
                    }
                    if (b = b.dump()) e = b.eventType, f = b._subject, e in A || (A[e] = []), A[e].push([f,
                        b
                    ])
                }
            },
            notifyDeclarativeAction: function(a, h) {
                0 !== d.length && (c(a, h, Date.now() - E), n())
            },
            notifyJquery: function(h, c) {
                0 !== d.length && (b.each(c.split(" "), function(c) {
                    a(h, c, Date.now() - E)
                }), n())
            }
        }
    });
    p.when("a-util", "a-class").register("prv:a-event-context", function(d, k) {
        var f = k.createClass({
            init: function(b, d) {
                this.subject = b;
                this.collected = d || {}
            },
            transform: function(b) {
                if (null === this.subject) return this;
                var d;
                try {
                    d = b(this.subject)
                } catch (e) {
                    return this.subject = null, this
                }
                this.subject = d;
                return this
            },
            filter: function(b) {
                return this.transform(function(d) {
                    return b(d) ?
                        d : null
                })
            },
            collect: function(b) {
                var g = this;
                return this.transform(function(e) {
                    try {
                        var f = b(e);
                        g.collected = d.extend(g.collected, f)
                    } catch (m) {}
                    return e
                })
            },
            dump: function() {
                if (null === this.subject) return null;
                this.collected._subject = this.subject;
                return this.collected
            }
        });
        f.from = function(b) {
            return new f(b._subject, b)
        };
        f.fromEventContext = function(b) {
            return new f(b.subject, b.collected)
        };
        return f
    });
    "use strict";
    p.register("priv:a-visibility", function() {
        function d(d) {
            for (var f = ["hidden", "webkitHidden", "mozHidden",
                    "msHidden", "oHidden"
                ], b = 0; b < f.length; b += 1)
                if (f[b] in d) return f[b]
        }
        return function(k) {
            var f = d(k);
            return f ? function() {
                return k[f]
            } : function() {
                return !1
            }
        }
    });
    "use strict";
    p.register("prv:a-private-util", function() {
        var d;
        try {
            d = navigator.userAgent
        } catch (k) {
            d = ""
        }
        return {
            ua: d,
            safeFeatureTest: function(d) {
                try {
                    return d()
                } catch (f) {
                    return !1
                }
            }
        }
    });
    "use strict";
    p.when("priv:a-visibility", "prv:a-guard", "prv:a-private-util").register("a-util", function(d, k, f) {
        function b(c) {
            if (g(c)) return [c];
            if (c.jQuery) return c.get();
            var a = Object.prototype.toString.call(c);
            return "[object String]" === a ? Array.prototype.slice.call(document.querySelectorAll(c)) : "[object Array]" === a ? c.filter(c, g) : "object" === typeof c && /^\[object (HTMLCollection|NodeList|Object)\]$/.test(a) && "number" === typeof c.length && (0 === c.length || "object" === typeof c[0] && 0 < c[0].nodeType) ? Array.prototype.slice.call(c) : []
        }

        function g(c) {
            return c instanceof Element || c instanceof HTMLDocument
        }
        var e = f.ua;
        d = {
            now: Date.now,
            isPageHidden: d(document)
        };
        f = [function(c) {
                return {
                    each: function(a,
                        c, h) {
                        if (null !== a)
                            if (Array.prototype.forEach && a.forEach === Array.prototype.forEach) a.forEach(c, h);
                            else if (a.length === +a.length)
                            for (var l = 0, b = a.length; l < b; l++) l in a && c.call(h, a[l], l, a);
                        else
                            for (l in a) a.hasOwnProperty(l) && c.call(h, a[l], l, a)
                    },
                    map: function(a, b, h) {
                        var l = [];
                        if (null === a) return l;
                        if (Array.prototype.map && a.map === Array.prototype.map) return a.map(b, h);
                        c.each(a, function(a, c, d) {
                            l[l.length] = b.call(h, a, c, d)
                        });
                        a.length === +a.length && (l.length = a.length);
                        return l
                    },
                    reduce: function(a, b, h, l) {
                        var d = 2 < arguments.length;
                        null === a && (a = []);
                        if (Array.prototype.reduce && a.reduce === Array.prototype.reduce) return d ? a.reduce(b, h) : a.reduce(b);
                        c.each(a, function(a, c, e) {
                            d ? h = b.call(l, h, a, c, e) : (h = a, d = !0)
                        });
                        d || p.error("Reduce of empty array with no initial value", "A.util", "reduce");
                        return h
                    },
                    filter: function(a, b, h) {
                        var l = [];
                        if (null === a) return l;
                        if (Array.prototype.filter && a.filter === Array.prototype.filter) return a.filter(b, h || a);
                        c.each(a, function(c, d, e) {
                            b.call(h || a, c, d, e) && l.push(c)
                        });
                        return l
                    },
                    range: function(a, c, h) {
                        c === u && (c = a || 0,
                            a = 0);
                        h = h || 1;
                        c = Math.max(Math.ceil((c - a) / h), 0);
                        for (var l = Array(c), b = 0; b < c; b++, a += h) l[b] = a;
                        return l
                    },
                    breaker: {}
                }
            }, function(c) {
                return {
                    throttle: function(a, b, h) {
                        var l, d, e, g = k.fn(this, a),
                            f = null,
                            m = 0;
                        h = h || {};
                        var n = function() {
                            m = !1 === h.leading ? 0 : c.now();
                            f = null;
                            e = g.apply(l, d);
                            l = d = null
                        };
                        return function() {
                            var g = c.now();
                            m || !1 !== h.leading || (m = g);
                            var x = b - (g - m);
                            l = this;
                            d = arguments;
                            0 >= x ? (clearTimeout(f), f = null, m = g, e = a.apply(l, d), l = d = null) : f || !1 === h.trailing || (f = setTimeout(n, x));
                            return e
                        }
                    },
                    sequence: function() {
                        var a = [].slice,
                            b = a.call(arguments).reverse(),
                            h = this;
                        return c.reduce(b, function(c, b) {
                            return function() {
                                var d = a.call(arguments);
                                d.push(c);
                                b.apply(h, d)
                            }
                        }, function() {})
                    },
                    debounce: function(a, b, h) {
                        var l, d, e, g, f, m = k.fn(this, a),
                            n = function() {
                                var a = c.now() - g;
                                a < b ? l = setTimeout(n, b - a) : (l = null, h || (f = m.apply(e, d), e = d = null))
                            };
                        return function() {
                            e = this;
                            d = arguments;
                            g = c.now();
                            var m = h && !l;
                            l || (l = setTimeout(n, b));
                            m && (f = a.apply(e, d), e = d = null);
                            return f
                        }
                    },
                    delay: function(a, c) {
                        var h = k.fn(this, a),
                            b = Array.prototype.slice.call(arguments, 2);
                        return setTimeout(function() {
                            return h.apply(null,
                                b)
                        }, c)
                    },
                    animationFrameDelay: function(a) {
                        return this.delay(a, 16)
                    },
                    interval: function(a, c) {
                        a = k.fn(this, a);
                        return setInterval(a, c)
                    },
                    once: function(a) {
                        var c = !1,
                            h = k.fn(this, a),
                            b;
                        return function() {
                            c || (c = !0, b = h.apply(this, arguments));
                            return b
                        }
                    },
                    rest: function(a, c) {
                        if (a) {
                            var h = Math.max(c === u ? a.length - 1 : c, 0);
                            return function() {
                                for (var c = arguments, b = -1, d = Math.max(c.length - h, 0), e = Array(d); ++b < d;) e[b] = c[b + h];
                                switch (h) {
                                    case 0:
                                        return a.call(this, e);
                                    case 1:
                                        return a.call(this, c[0], e);
                                    case 2:
                                        return a.call(this, c[0], c[1],
                                            e)
                                }
                                d = Array(h + 1);
                                for (b = -1; ++b < h;) d[b] = c[b];
                                d[h] = e;
                                return a.apply(this, d)
                            }
                        }
                    },
                    parseFunctionName: function(a) {
                        return a.name ? "anonymous" === a.name ? "" : a.name : (a = a.toString().match(/^function\s*([^\s(]+)/)) ? a[1] : ""
                    }
                }
            }, function(c) {
                function a(h) {
                    var c;
                    "object" !== typeof h && "function" !== typeof h && (h = {});
                    for (var b = 1; b < arguments.length; b++) {
                        var l = arguments[b];
                        if (null != l)
                            for (var d in l) {
                                var t = l[d];
                                if (h !== t && t !== u) {
                                    var f = h[d];
                                    g(t) || (c = e(t)) ? (c && !e(f) ? f = [] : c || g(f) || (f = {}), c = !1, a(f, t)) : f = t;
                                    h[d] = f
                                }
                            }
                    }
                    return h
                }

                function b(a,
                    h) {
                    a = a || {};
                    h = h || {};
                    var c = {},
                        l;
                    for (l in a) a.hasOwnProperty(l) && (c[l] = "object" === typeof a[l] && a[l] ? b(a[l], h[l]) : a[l] !== h[l]);
                    for (l in h) h.hasOwnProperty(l) && !c[l] && (c[l] = "object" === typeof h[l] && h[l] ? b(h[l], a[l]) : h[l] !== a[l]);
                    return c
                }

                function h(a, c) {
                    var b;
                    if (a === c) return !0;
                    if (e(a)) {
                        if (!e(c) || a.length !== c.length) return !1;
                        for (b = a.length; b--;)
                            if (!h(a[b], c[b])) return !1;
                        return !0
                    }
                    if (g(a)) {
                        if (!g(c) || l(a) && !l(c)) return !1;
                        for (b in a)
                            if (!h(a[b], c[b])) return !1;
                        return !0
                    }
                    return !1
                }

                function l(a) {
                    for (var h in a)
                        if (a.hasOwnProperty(h)) return !1;
                    return !0
                }

                function d(a) {
                    if (!("function" === typeof a || "object" === typeof a && a)) return [];
                    if (Object.keys) return Object.keys(a);
                    var h = [],
                        c;
                    for (c in a) a.hasOwnProperty(c) && h.push(c);
                    return h
                }

                function e(a) {
                    return Array.isArray ? Array.isArray(a) : "[object Array]" === Object.prototype.toString.call(a)
                }

                function g(a) {
                    if (!a || "object" !== typeof a || a.nodeType || a === q) return !1;
                    try {
                        if (a.constructor && !a.hasOwnProperty("constructor") && !a.constructor.prototype.hasOwnProperty("isPrototypeOf")) return !1
                    } catch (h) {
                        return !1
                    }
                    for (var c in a);
                    return c === u || a.hasOwnProperty(c)
                }

                function f(a, h, c) {
                    Object.defineProperty(a, h, {
                        value: c,
                        writable: !1
                    });
                    return c
                }

                function m(a, h, c) {
                    a.hasOwnProperty(h) || (a[h] = c);
                    return c
                }
                return {
                    keys: d,
                    values: function(a) {
                        for (var h = d(a), c = Array(h.length), b = 0; b < h.length; b++) c[b] = a[h[b]];
                        return c
                    },
                    extend: a,
                    mixin: function(a, h, c) {
                        if (c)
                            for (var b = 0, l = c.length; b < l; b++) a[c[b]] = h[c[b]];
                        else
                            for (b in h) "function" === typeof h[b] && (a[b] = h[b])
                    },
                    diff: b,
                    equals: h,
                    copy: function(h) {
                        return e(h) ? a([], h) : g(h) ? a({}, h) : h
                    },
                    indexOfArray: function(a,
                        h, c) {
                        if (Array.prototype.indexOf && a.indexOf === Array.prototype.indexOf) return a.indexOf(h, c);
                        a && a instanceof Array || p.error("Invalid arr passed to A.indexOfArray: " + a, "A.util", "indexOfArray");
                        c = parseInt(c, 10);
                        c = isNaN(c) ? 0 : c;
                        if (!isFinite(c)) return -1;
                        for (var b = a.length; c < b; c++)
                            if (a[c] === h) return c;
                        return -1
                    },
                    isArray: e,
                    isPlainObject: g,
                    isFiniteNumber: function(a) {
                        return "number" === typeof a && !isNaN(a) && isFinite(a)
                    },
                    objectIsEmpty: l,
                    constProp: "function" === typeof Object.defineProperty ? f : m
                }
            }, function(c) {
                var a = {
                        "\x26": "\x26amp;",
                        "\x3c": "\x26lt;",
                        "\x3e": "\x26gt;",
                        '"': "\x26quot;",
                        "'": "\x26#39;",
                        "/": "\x26#x2F;"
                    },
                    b = /^\s+/,
                    h = /\s+$/,
                    l = new RegExp("[" + c.keys(a).join("") + "]", "g"),
                    d = /([!"#$%&'\(\)*+,./:;<=>?@\[\\\]^`{|}~])/g;
                return {
                    trim: function(a) {
                        return String.prototype.trim ? String.prototype.trim.call(a) : a.replace(b, "").replace(h, "")
                    },
                    contains: function(a, h) {
                        return -1 !== ("" + a).indexOf(h)
                    },
                    escapeHtml: function(h) {
                        return ("" + h).replace(l, function(h) {
                            return a[h]
                        })
                    },
                    escapeJquerySelector: function(a) {
                        return ("" + a).replace(d,
                            "\\$1")
                    },
                    parseJSON: function(a) {
                        return JSON.parse(a)
                    }
                }
            }, function(c) {
                function a(a) {
                    return c.map(b, function(c) {
                        var b = a.getAttribute(c);
                        return b && "[" + c + "\x3d" + b + "]"
                    }).join("")
                }
                var b = ["id", "cel_widget_id", "data-feature-name", "data-action", "data-aui-build-date"];
                return {
                    xpath: function(a) {
                        if ("" !== a.id) return '//*[@id\x3d"' + a.id + '"]';
                        if (a === document.documentElement) return "/html";
                        var b = c.indexOfArray(c.filter(a.parentNode.childNodes, function(c) {
                            return c.tagName === a.tagName
                        }), a);
                        if (-1 === b) throw Error("can not evaluate xpath of element `" +
                            a.tagName + (a.id ? "#" + a.id : "") + "`");
                        return c.xpath(a.parentNode) + "/" + a.tagName + "[" + (b + 1) + "]"
                    },
                    cssSelector: function(a) {
                        var c = [a.tagName || ""];
                        a.className && a.className.trim && c.push("." + a.className.trim().replace(/\s+/g, "."));
                        a.id && c.push("#" + a.id);
                        return c.join("")
                    },
                    attributionChain: function(h) {
                        var b = [];
                        do b.push(a(h)), h = h.parentElement; while (h);
                        return c.filter(b, Boolean).reverse().join(" ")
                    }
                }
            }, function(c) {
                return {
                    hide: function(a) {
                        c.each(b(a), function(a) {
                            c.addClass(a, "aok-hidden")
                        })
                    },
                    show: function(a) {
                        c.each(b(a),
                            function(a) {
                                c.removeClass(a, "aok-hidden")
                            })
                    }
                }
            }, function(c) {
                function a() {
                    b = {};
                    for (var a = (document.cookie || "").split(";"), l = a.length - 1; 0 <= l; l--) {
                        var d = a[l].split("\x3d"),
                            e = c.trim(d[0]);
                        if (e) {
                            var g = b,
                                d = d.slice(1).join("\x3d"),
                                d = c.trim(d);
                            /^"/.test(d) && (d = d.slice(1, -1).replace(/\\(.)/g, "$1"));
                            d = q.decodeURIComponent(d);
                            g[e] = d
                        }
                    }
                }
                var b;
                return {
                    cookies: {
                        get: function(c) {
                            b || a();
                            return b[c]
                        },
                        getAll: function() {
                            b || a();
                            return c.extend({}, b)
                        },
                        refresh: function() {
                            b = null
                        }
                    }
                }
            }, function(c) {
                return {
                    onScreen: function(a, b) {
                        if (!a) return !1;
                        a.jquery && (a = a[0]);
                        if (!a) return !1;
                        b = "number" === typeof b && !isNaN(b) && isFinite(b) ? b : 100;
                        if (1 !== a.nodeType || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length)) return !1;
                        var h = c.size(q),
                            d = c.scroll(q),
                            e = d.top,
                            g = q.innerHeight ? q.innerHeight : h.height,
                            f = e + g,
                            d = d.left,
                            h = q.innerWidth ? q.innerWidth : h.width,
                            m = d + h,
                            e = e - b,
                            f = f + b,
                            d = d - b,
                            m = m + b,
                            n = c.offset(a),
                            k = c.size(a);
                        a = n.top;
                        b = k.height;
                        var r = a + b,
                            n = n.left,
                            k = k.width,
                            B = n + k;
                        return (a >= e && a < f || r > e && r <= f || b > g && a <= e && r >= f) && (n >= d && n < m || B > d && B <= m || k > h && n <= d && B >= m)
                    }
                }
            },
            function(c) {
                return {
                    isATF: function(a, b) {
                        b = "number" === typeof b && !isNaN(b) && isFinite(b) ? b : 100;
                        b = c.size(q).height + b;
                        a = c.offset(a).top;
                        return 0 <= a && a < b
                    }
                }
            },
            function(c) {
                function a(a, c) {
                    return a.classList ? a.classList.contains(c) : 0 <= (" " + a.className + " ").indexOf(" " + c + " ")
                }
                var b = document.createElement("fakeelement"),
                    h = {
                        transition: "transitionend",
                        OTransition: "oTransitionEnd",
                        MozTransition: "transitionend",
                        WebkitTransition: "webkitTransitionEnd"
                    },
                    d = null;
                return {
                    setCssImportant: function(a, c, b) {
                        a = a.jquery ? a[0] : a;
                        "undefined" !== typeof a && (a = a.style, a.cssText = a.cssText.replace(new RegExp(c + "\\s*:\\s*[.^;]*(\\s*;)?", "gmi"), ""), a.cssText += c + ": " + b + " !important;")
                    },
                    hasClass: a,
                    addClass: function(c, b) {
                        a(c, b) || (c.classList ? c.classList.add(b) : c.className += " " + b)
                    },
                    removeClass: function(c, b) {
                        a(c, b) && (c.classList ? c.classList.remove(b) : c.className = (" " + c.className + " ").replace(new RegExp(" " + b + " ", "g"), " ").replace(/  /g, " ").replace(/^ | $/g, ""))
                    },
                    offset: function(a) {
                        a.jquery && (a = a[0]);
                        a = a.getBoundingClientRect();
                        var c =
                            document.documentElement,
                            b = document.body;
                        return {
                            top: a.top + (q.pageYOffset || c.scrollTop) - (c && c.clientTop || b && b.clientTop || 0),
                            left: a.left + (q.pageXOffset || c.scrollLeft) - (c && c.clientLeft || b && b.clientLeft || 0)
                        }
                    },
                    size: function(a) {
                        var c = document.documentElement,
                            b = document.body;
                        if (a === q) return {
                            width: c.clientWidth,
                            height: c.clientHeight
                        };
                        if (9 === a.nodeType) return {
                            width: Math.max(c.clientWidth, b.scrollWidth, c.scrollWidth, b.offsetWidth, c.offsetWidth),
                            height: Math.max(c.clientHeight, b.scrollHeight, c.scrollHeight, b.offsetHeight,
                                c.offsetHeight)
                        };
                        var h = q.getComputedStyle(a),
                            c = parseFloat(h.borderTopWidth),
                            b = parseFloat(h.borderBottomWidth),
                            d = parseFloat(h.borderLeftWidth),
                            l = parseFloat(h.borderRightWidth),
                            e = parseFloat(h.paddingTop),
                            g = parseFloat(h.paddingBottom),
                            f = parseFloat(h.paddingLeft),
                            h = parseFloat(h.paddingRight);
                        return {
                            width: a.offsetWidth - d - l - f - h,
                            height: a.offsetHeight - b - c - e - g
                        }
                    },
                    scroll: function(a) {
                        var c = document.documentElement,
                            b = document.body;
                        return a ? a === q || 9 === a.nodeType ? {
                            top: "pageYOffset" in q ? q.pageYOffset : c.scrollTop ||
                                b.scrollTop,
                            left: "pageXOffset" in q ? q.pageXOffset : c.scrollLeft || b.scrollLeft
                        } : {
                            top: a.scrollTop,
                            left: a.scrollLeft
                        } : null
                    },
                    getTransitionEndEvent: function() {
                        /UCBrowser/.exec(e) && (d = h.WebkitTransition);
                        if (null === d)
                            for (var a in h)
                                if (b.style[a] !== u) {
                                    d = h[a];
                                    break
                                }
                        return d
                    },
                    reflowCssChanges: function(a) {
                        c.each(a, function(a) {})
                    }
                }
            },
            function(c) {
                return {
                    widescreen: function() {
                        return c.hasClass(document.documentElement, "a-ws")
                    }
                }
            }
        ];
        for (var n = 0; n < f.length; n++) {
            var m = f[n](d),
                r;
            for (r in m) d[r] = m[r]
        }
        return d
    });
    "use strict";
    p.when("p-detect", "a-util", "prv:a-private-util").register("prv:a-capabilities", function(d, k, f) {
        var b = {},
            g = /Trident/.test(f.ua);
        k.each({
            isChrome: function() {
                return /Chrome/.test(f.ua)
            },
            isUCBrowser: function() {
                return /UCBrowser/.test(f.ua)
            },
            isSafari: function() {
                var b = document.documentElement.style;
                return !("MozAppearance" in b) && "webkitAppearance" in b && /^Apple/.test(navigator.vendor)
            },
            isAndroidStockGuess: function() {
                var b = !1;
                d.capabilities.android && !/Chrome|Opera|Firefox|UCBrowser/.test(f.ua) && (b = /AppleWebKit\/(\d+\.\d+)/.exec(f.ua),
                    b = b[1] && "535" > b[1]);
                return b
            },
            isFirefox: function() {
                return /Firefox/.test(f.ua)
            },
            isIE: function() {
                return g
            },
            isIE10: function() {
                return g && "onmspointerup" in document && !("onpointerup" in document)
            },
            isIE10Plus: function() {
                return g && ("onpointerup" in document || "onmspointerup" in document)
            },
            isIE11Plus: function() {
                return g && "onpointerup" in document
            },
            isiOS8: function() {
                return d.capabilities.ios && /Version\/8\./.test(f.ua)
            },
            isIETouchCapable: function() {
                return b.isIE10Plus && /Touch;/.test(f.ua)
            },
            isMetroIEGuess: function() {
                var e = !0;
                try {
                    e = new ActiveXObject("htmlfile")
                } catch (g) {
                    e = !1
                }
                return b.isIE10Plus && !d.capabilities.mobile && !e
            }
        }, function(d, g) {
            b[g] = f.safeFeatureTest(d)
        });
        return b
    });
    "use strict";
    p.when("p-detect", "prv:a-capabilities", "a-util", "prv:a-private-util").register("a-detect", function(d, k, f, b) {
        var g = f.copy(d),
            e = function() {
                var d = /(?:Android\s+|Windowshop.*Android\/|Android\/)(\d+(?:\.\d+)*)/.exec(b.ua);
                return d && d[1]
            },
            n = {};
        f.each({
            isAmazonApp: function() {
                return /(Windowshop|Amazon|Amazon\.com)\//.test(f.cookies.get("amzn-app-id"))
            },
            isGen5App: function() {
                return /Windowshop.*(?:KFOT|KFTH|KFJWA|KFJWI|KFTT)/.test(b.ua)
            },
            isAndroid: function() {
                return g.capabilities.android
            },
            androidVersion: function() {
                return e()
            },
            isAndroidKitkatPlus: function() {
                var b = e();
                return b && null !== b.match(/(^4\.[4-9]|^[5-9]|^\d\d)/)
            },
            isOldAndroid: function() {
                return /Android\s[12]/.test(b.ua)
            },
            pointerPrefix: function() {
                return "onmspointerup" in document || "onpointerup" in document ? "onpointerup" in document ? "pointer" : "MSPointer" : !1
            },
            actionMode: function() {
                var b = g.capabilities.pointerPrefix;
                return b ? b : g.capabilities.touch ? "touch" : "mouse"
            }
        }, function(d, e) {
            g.capabilities[e] = b.safeFeatureTest(d)
        });
        f.extend(g.capabilities, k);
        f.each({
            start: {
                mouse: "down",
                touch: "start",
                pointer: "down",
                MSPointer: "Down"
            },
            end: {
                mouse: "up",
                touch: "end",
                pointer: "up",
                MSPointer: "Up"
            },
            move: {
                mouse: "move",
                touch: "move",
                pointer: "move",
                MSPointer: "Move"
            },
            enter: {
                mouse: "enter",
                touch: "enter",
                pointer: "enter"
            },
            leave: {
                mouse: "leave",
                touch: "leave",
                pointer: "leave"
            },
            cancel: {
                touch: "cancel",
                pointer: "cancel",
                MSPointer: "Cancel"
            },
            over: {
                mouse: "over",
                pointer: "over",
                MSPointer: "Over"
            },
            out: {
                mouse: "out",
                pointer: "out",
                MSPointer: "Out"
            }
        }, function(b, d) {
            var c = g.capabilities.actionMode,
                a = "string" === typeof b ? b : b[c];
            n[d] = a ? c + a : b.mouse === u ? "" : "mouse" + b.mouse
        });
        g.action = n;
        d = {};
        "pointer" === g.capabilities.pointerPrefix ? (d.touch = "touch", d.pen = "pen", d.mouse = "mouse", d.unknown = "") : "MSPointer" === g.capabilities.pointerPrefix && (d.touch = 2, d.pen = 3, d.mouse = 4);
        g.pointerType = d;
        return g
    });
    "use strict";
    p.when("prv:a-guard").register("a-defer", function(d) {
        function k(d) {
            var f =
                0,
                m = setTimeout(function() {
                    k(d)
                }, 0);
            if (0 === d.length) clearTimeout(m), b = !1;
            else {
                var r = Date.now();
                d.shift().call();
                g += Date.now() - r;
                50 < g && (f = 50, g = 0);
                setTimeout(function() {
                    k(d)
                }, f);
                clearTimeout(m)
            }
        }
        var f = [],
            b = !1,
            g = 0;
        return {
            defer: function(e) {
                f.push(d.fn(this, e));
                b || (b = !0, setTimeout(function() {
                    k(f)
                }, 0))
            },
            pauseDeferred: function() {},
            executeDeferred: function() {}
        }
    });
    "use strict";
    p.when("a-util").register("a-events", function(d) {
        function k(a, b) {
            for (var c = a.length; c--;) b(a[c], c, a) || a.splice(c, 1)
        }

        function f(a) {
            var c =
                a.shift();
            if (c === u) return t;
            try {
                !1 === c.fn.apply(q, c.args) && k(a, function(a) {
                    return a.id !== c.id
                })
            } catch (b) {
                (c.logError || p.logError)(b, "Event execution failed for event " + c.topic, "FATAL")
            }
        }

        function b(c, b) {
            if (m(c)) {
                var g = y++,
                    f = a[c];
                b = b || [];
                var t = d.map(f, function(a) {
                    return {
                        topic: c,
                        id: g,
                        fn: a.guard ? a.guard(a.fn) : a.fn,
                        args: b,
                        logError: a.logError
                    }
                });
                f.occurred && e(c);
                f.isTimeSliced ? h(t) : l(t)
            }
        }

        function g(c, b, h) {
            if ("function" === typeof b) return h = {
                fn: b,
                logError: h && h.logError,
                guard: h && h.guard
            }, (a[c] = a[c] || []).unshift(h), {
                event: c,
                callback: b
            }
        }

        function e(c) {
            a[c].length = 0
        }

        function n(c, b) {
            function h(c) {
                k(a[c], function(a) {
                    return a.fn !== b
                })
            }
            d.each(d.filter(c.split(" "), m), b ? h : e)
        }

        function m(c) {
            return a.hasOwnProperty(c) && 0 < a[c].length
        }

        function r(c, h) {
            var l = a[c] = a[c] || [];
            l.occurred || (l.isTimeSliced = !1 !== h, l.occurred = !0, g(c, function() {
                p.register(c, function() {
                    var a = q.aPageStart;
                    return {
                        time: a ? d.now() - a : 0
                    }
                })
            }), b(c))
        }

        function c(a, c) {
            var b = this.on;
            this.on = function() {
                return b.apply(this, arguments)
            };
            this.on._guard = a;
            this.on._logError =
                c;
            for (var h in b) b.hasOwnProperty(h) && (this.on[h] = b[h]);
            this.constructor = u
        }
        var a = {},
            t = {},
            h = function() {
                function a() {
                    c = !0;
                    for (var h = d.now(); 50 > d.now() - h;)
                        if (f(b) === t) {
                            c = !1;
                            return
                        }
                    d.delay(a, 15)
                }
                var c = !1,
                    b = [];
                return function(h) {
                    Array.prototype.push.apply(b, h);
                    c || a()
                }
            }(),
            l = function() {
                var a = !1,
                    c = [];
                return function(b) {
                    Array.prototype.push.apply(c, b);
                    if (!a) {
                        for (a = !0; f(c) !== t;);
                        a = !1
                    }
                }
            }(),
            y = 0,
            v = function() {
                var c = function(c, h, l) {
                    var e = c.split(" "),
                        f = [],
                        t = h;
                    !0 === l && (t = function() {
                        h.apply(q, arguments);
                        n(c, t)
                    });
                    var m = this ? {
                        logError: this._logError,
                        guard: this._guard
                    } : {};
                    d.each(e, function(c) {
                        (a[c] || []).occurred ? (g(c, h, m), b(c)) : f.push(g(c, t, m).event)
                    });
                    return {
                        event: f.join(" "),
                        callback: t
                    }
                };
                d.each("ready load unload afterLoad scroll resize orientationchange zoom".split(" "), function(a) {
                    c[a] = function(b, h) {
                        c.call(this, a, b, h)
                    }
                });
                return c
            }();
        c.prototype = {
            isListening: m,
            on: v,
            one: function(a, c) {
                var b = a.split(" ");
                if (1 < b.length) p.error("A.one only accepts a single event name, but was provided with: " + b.length + ", (" + a +
                    ")", "A.events", "one");
                else return v(a, c, !0)
            },
            off: function(a, c) {
                var b;
                "object" === typeof a ? (b = a.event, a = a.callback) : (b = a, a = c);
                return n(b, a)
            },
            trigger: function(a) {
                for (var c = arguments.length, h = Array(c), d = 0; d < c; d++) h[d] = arguments[d];
                h.shift();
                b(a, h)
            },
            events: {
                defaults: {
                    input: "change",
                    select: "change",
                    a: "click",
                    button: "click",
                    form: "submit"
                }
            }
        };
        c.prototype.constructor = c;
        p.when("p-detect").execute("prv:a-register-load-events", function(a) {
            function c(a, b) {
                q.attachEvent ? q.attachEvent("on" + a, b) : q.addEventListener(a,
                    b, !1)
            }
            var b = d.once(function() {
                    r("beforeLoad");
                    r("load");
                    d.delay(function() {
                        r("beforeAfterLoad");
                        r("afterLoad")
                    }, 1500)
                }),
                h = d.once(function() {
                    a.responsiveGridEnabled() && a.toggleResponsiveGrid(!0);
                    r("beforeReady");
                    r("ready");
                    r("afterReady");
                    "complete" === document.readyState && b()
                });
            (function(a) {
                "loading" != document.readyState ? a() : document.addEventListener ? document.addEventListener("DOMContentLoaded", a) : document.attachEvent("onreadystatechange", function() {
                    "loading" != document.readyState && a()
                })
            })(h);
            p.when("a-bodyBegin").execute(function() {
                r("bodyBegin")
            });
            p.when("a-domready").execute(h);
            c("load", b);
            c("unload", function() {
                r("unload", !1)
            })
        });
        return c.prototype
    });
    "use strict";
    p.when("a-util", "a-events").register("a-prefix", function(d, k) {
        function f(b) {
            return b.toLowerCase().replace(/-(.)/g, function(b, c) {
                return c.toUpperCase()
            })
        }
        var b = {
                transitionend: null
            },
            g = document.createElement("div").style,
            e = {},
            n = ["o", "ms", "moz", "webkit"];
        k.on("beforeReady", function() {
            if (q.addEventListener) {
                var e = document.createElement("div"),
                    g = function(c) {
                        b.transitionend = c.type;
                        this.removeEventListener("webkitTransitionEnd",
                            g, !1);
                        this.removeEventListener("transitionend", g, !1);
                        this.removeEventListener("otransitionend", g, !1);
                        this.removeEventListener("oTransitionEnd", g, !1)
                    };
                e.setAttribute("style", "position:absolute;top:0px;z-index:-1;transition:top 1ms ease;-webkit-transition:top 1ms ease;-moz-transition:top 1ms ease;-o-transition:top 1ms ease;");
                e.addEventListener("transitionend", g, !1);
                e.addEventListener("webkitTransitionEnd", g, !1);
                e.addEventListener("otransitionend", g, !1);
                this.addEventListener("oTransitionEnd", g, !1);
                document.body.appendChild(e);
                d.delay(function() {
                    e.style.top = "100px";
                    d.delay(function() {
                        e.parentNode.removeChild(e);
                        e = g = null;
                        d.each(b, function(c) {})
                    }, 100)
                }, 0)
            }
        });
        return {
            prefixes: {
                getStyle: function(b) {
                    if (!e[b]) {
                        var d = f(b);
                        if (d in g) e[b] = d;
                        else
                            for (var d = d.charAt(0).toUpperCase() + d.slice(1), c = n.length; c--;) {
                                var a = n[c] + d;
                                a in g && (e[b] = a)
                            }
                    }
                    return e[b]
                },
                getEvent: function(d) {
                    return d ? b[d.toLowerCase()] : u
                }
            }
        }
    });
    "use strict";
    p.when("jQuery", "a-util", "a-events", "a-event-analytics", "a-timing-analytics", "prv:a-declarative-analytics",
        "p-recorder-stop", "prv:a-tnr").register("a-declarative", function(d, k, f, b, g, e, n, m) {
        function r(a) {
            var e = d(a.currentTarget),
                h = d(a.target);
            if ("submit" === a.type) {
                var l = h.closest("form");
                l.length && (h = l)
            }
            if (l = e.data("action")) l = l.split(" "), k.each(l, function(d) {
                var l = c[d] || {},
                    g = e.data(d),
                    n = a.type,
                    k = {
                        $target: h,
                        $currentTarget: e,
                        targetTag: h.prop("tagName").toLowerCase(),
                        type: n,
                        action: d,
                        data: g,
                        $event: a,
                        $declarativeParent: e
                    };
                d = "a:declarative:" + d;
                n = d + ":" + n;
                f.trigger(d, k);
                f.trigger(n, k);
                f.isListening(n) || b.handle(a);
                k = !1;
                g ? k = !!g.allowLinkDefault : l && (k = !!l.allowLinkDefault);
                "click" !== a.type || k ? l = !1 : (l = h.closest("a"), l = l.length && ("#" === l[0].href || a.currentTarget === l[0] || l.parent(".a-declarative").length));
                l && a.preventDefault()
            })
        }
        var c = {};
        n();
        d(document).delegate(".a-declarative", "blur click dblclick focus focusin focusout mousedown mouseup mouseenter mouseleave mousemove change submit touchstart touchend touchmove touchcancel keydown keyup keypress MSPointerDown pointerdown MSPointerUp pointerup MSPointerMove pointermove MSPointerCancel pointercancel MSPointerOver pointerenter MSPointerOut pointerleave",
            r).delegate(".a-gesture", "tap swipe swipe-horizontal swipe-vertical pan-horizontal pan-vertical doubleTap", r);
        n = function() {
            var a, d, h, l;
            switch (arguments.length) {
                case 2:
                    a = arguments[0];
                    l = arguments[1];
                    break;
                case 3:
                    a = arguments[0];
                    d = arguments[1];
                    l = arguments[2];
                    break;
                case 4:
                    a = arguments[0], d = arguments[1], h = arguments[2], l = arguments[3]
            }
            if (a) {
                "string" === typeof a && (a = k.trim(a).split(" "));
                var g = this,
                    n = m.wrapDeclarativeActionHandler(l);
                k.each(a, function(a) {
                    var l = "a:declarative:" + a;
                    c[a] = h || {};
                    d ? (d = "string" === typeof d ?
                        k.trim(d).split(" ") : d, k.each(d, function(c) {
                            f.on.call(g, l + ":" + c, n);
                            b.notifyDeclarativeAction(a, c);
                            e.notify(a, c)
                        })) : f.on.call(g, l, n)
                })
            }
        };
        n.create = function(a, c, b) {
            var l = a.jquery && a.length ? a : d(a);
            if (l.length && c) {
                var e = l.data("action");
                l.data("action", e ? e + " " + c : c).data(c, b ? b : {});
                l.addClass("a-declarative")
            }
            return a
        };
        n.remove = function(a, c) {
            var b = a.jquery && a.length ? a : d(a);
            if (!b.length) return a;
            var l = b.data("action");
            if (!l) return a;
            var e = l.split(" ");
            c ? (c = c.split(" "), k.each(c, function(a) {
                var c = k.indexOfArray(e,
                    a);
                0 <= c && (e.splice(c, 1), b.data(a, null))
            })) : (k.each(e, function(a) {
                b.data(a, null)
            }), e = []);
            e.length ? b.data("action", e.join(" ")) : b.data("action", null).removeClass("a-declarative");
            return a
        };
        g.stopWidgetLogging("declarative");
        return {
            declarative: n
        }
    });
    "use strict";
    p.when("a-util", "jQuery", "a-declarative").register("a-draggable", function(d, k, f) {
        var b, g = {
                _maxZIndex: 0,
                _isInit: !1,
                _draggables: [],
                _init: function() {
                    this._isInit || (this._isInit = !0, this._maxZIndex = 975)
                },
                create: function(c) {
                    this._init();
                    c._zimIndex ||
                        (c._zimIndex = 975, this._maxZIndex += 1, this._draggables.push(c));
                    this.acquireFocus(c)
                },
                acquireFocus: function(c) {
                    c.css("zIndex", this._maxZIndex);
                    b.css("zIndex", this._maxZIndex - 1);
                    for (var a = 0; a < this._draggables.length; a++) {
                        var d = this._draggables[a];
                        d[0] !== c[0] && d._zimIndex > c._zimIndex && (d._zimIndex -= d._zimIndex > this._maxZIndex - 1 ? 2 : 1, d.css("zIndex", d._zimIndex))
                    }
                    c._zimIndex = this._maxZIndex
                }
            },
            e = function(c) {
                var a = c.$event;
                d.contains("touchstart touchend touchmove", c.type) && (a = a.originalEvent.touches[0]);
                return {
                    x: a.clientX,
                    y: a.clientY
                }
            },
            n = function(c) {
                var a = c.data.$draggable,
                    b = a.data("a-draggables"),
                    h = e(c);
                b.isMouseDown && (a.css({
                    left: h.x - b.clickOffset.x,
                    top: h.y - b.clickOffset.y
                }), c.$event.preventDefault())
            },
            m = function(c) {
                var a = c.$event.target || c.$event.srcElement,
                    d = c.data.$draggable,
                    h = d.data("a-draggables");
                g.acquireFocus(d);
                a = k(a).closest(h.$handle, d);
                h.isMouseDown = 0 < a.length;
                h.isMouseDown && (b && b.removeClass("aok-hidden"), a = e(c), h.clickOffset = {
                        x: a.x - parseFloat(d.css("left")),
                        y: a.y - parseFloat(d.css("top"))
                    },
                    d.data("a-draggables", h), b.data("a-draggables", h), c.$event.preventDefault())
            },
            r = function(c) {
                c = c.data.$draggable;
                var a = c.data("a-draggables");
                a.isMouseDown = !1;
                c.data("a-draggables", a);
                b && b.addClass("aok-hidden")
            };
        return {
            draggable: function(c, a) {
                c = c.jquery ? c : k(c);
                a = {
                    isMouseDown: !1,
                    $draggable: c,
                    $handle: a && a.handle ? a.handle : c
                };
                a.$handle = a.$handle.jquery ? a.$handle : k(a.handle);
                a.$handle.css("cursor", "move");
                b || (b = k("\x3cdiv\x3e", {
                        id: "a-draggables-mousedown-layer",
                        "class": "aok-hidden"
                    }).appendTo("body"),
                    f.declarative.create(b, "a-draggables", a));
                g.create(a.$draggable);
                f.declarative.create(a.$draggable, "a-draggables", a);
                f.declarative("a-draggables", ["mousedown", "touchstart"], m);
                f.declarative("a-draggables", ["mouseup", "touchend"], r);
                f.declarative("a-draggables", ["mousemove", "touchmove"], n)
            }
        }
    });
    "use strict";
    p.when("jQuery", "a-util", "a-events", "a-declarative", "a-constants", "a-analytics").register("a-state", function(d, k, f, b, g, e) {
        function n(a, b, h, l) {
            var e = !(a in c);
            if (null === b || d.isArray(b) || d.isPlainObject(b)) {
                var n =
                    k.copy(c[a]);
                n && b && !l && (d.isArray(n) || d.isPlainObject(n)) ? k.extend(c[a], b) : c[a] = k.copy(b);
                b = k.diff(n, c[a]);
                l = k.copy(c[a]);
                h || f.trigger("a:state:update:" + a, l, b, n);
                e && p.declare(g.constants.PAGESTATE_LOADED_MODULE_PREFIX + a, l);
                return l
            }
            p.error("Invalid value passed to A.state with a namespace of " + a + ".  Value: " + b, "A.state", "updateNamespace")
        }

        function m(a, c, b) {
            if (1 === c.length) return a[c.shift()] = b, a;
            a[c.shift()] = m({}, c, b);
            return a
        }

        function r() {
            for (var a = document.getElementsByTagName("script"), b = 0, h = a.length; b <
                h; b++)
                if (!d.data(a[b], "a-eval")) {
                    var l = d(a[b]),
                        g = l.attr("data-a-state");
                    if (g) {
                        var f;
                        try {
                            f = k.parseJSON(g)
                        } catch (m) {
                            throw e.logError("[AUI] key value interface for accessing state data parsing failed", "ERROR", JSON.stringify({
                                xpath: k.xpath(a[b]),
                                cssSelector: k.cssSelector(a[b]),
                                custody: k.attributionChain(a[b])
                            })), m;
                        }
                        if (f.key) {
                            var r;
                            try {
                                r = k.parseJSON(l.html())
                            } catch (m) {
                                p.logError(m, "State parsing failed for state " + f.key, "ERROR");
                                continue
                            }
                            d.data(a[b], "a-eval", !0);
                            (l = c[f.key]) && k.extend(r, l);
                            n(f.key, r)
                        }
                    }
                }
        }
        var c = {};
        b.declarative("a-state", function(a) {
            var c = a.$target,
                b = a.data.key,
                d = a.data[a.type];
            d || f.events.defaults[a.targetTag] !== a.type || (d = c.attr("name"));
            d && b && (c.is("select") && (c = c.find(":selected")), typeof c.val() !== u && "string" === typeof d && (a = c.val(), c.is("input[type\x3dcheckbox]") && !c.prop("checked") && (a = null), d = m({}, d.split("."), a)), n(b, d))
        });
        b = function(a, b, h) {
            return b === u ? k.copy(c[a]) : n(a, b, !!h)
        };
        b.bind = function(a, c) {
            f.on("a:state:update:" + a, c)
        };
        b.replace = function(a, c, b) {
            return n(a, c, !!b, !0)
        };
        f.on("beforeReady", r);
        b.parse = r;
        return {
            state: b
        }
    });
    "use strict";
    p.when("prv:a-guard", "jQuery", "a-util", "a-events", "a-declarative", "a-state").register("a-ajax", function(d, k, f, b, g, e) {
        function n(a, c) {
            if (!a) return "";
            var b = "string" === typeof a;
            if ("string" === c) return b ? a : "";
            if ("json" === c) {
                if (b) return a;
                try {
                    return JSON && JSON.stringify ? JSON.stringify(a) : ""
                } catch (d) {
                    p.logError(d, "AJAX POST failed to convert JSON object to string")
                }
                return ""
            }
            return b ? "" : k.param(a)
        }

        function m(a, b) {
            a && 0 !== a.length && ("string" ===
                typeof a && "" === f.trim(a) ? b && b(a) : (a[0] instanceof Array || (a = [a]), f.each(a, function(d) {
                    var e = c[d[0]];
                    e ? e.apply(q, d) : ((e = b) || p.error("There is no handler for the streaming ajax command: " + a[0], "A.ajax", "chunkHandler"), e(d))
                })))
        }
        var r = function() {
                q.XMLHttpRequest || (q.XMLHttpRequest = function() {
                    return new ActiveXObject("Microsoft.XMLHTTP")
                });
                var a = function() {
                        function a() {
                            0 < c.length ? c.pop().send() : b--
                        }
                        var c = [],
                            b = 0,
                            d = 0,
                            h = 0;
                        return {
                            add: function(a) {
                                4 > b ? (a.send(), b++) : (c.push(a), d++, c.length > h && (h = c.length), (a =
                                    q.ue) && a.count && (a.count("aui:ajax:queued", d), a.count("aui:ajax:maxQueued", h)))
                            },
                            complete: a,
                            abort: function(b) {
                                b = f.indexOfArray(c, b); - 1 !== b && c.splice(b, 1);
                                a()
                            }
                        }
                    }(),
                    c = function() {},
                    d = function(c) {
                        var d = c.http,
                            e = !1,
                            l = !1;
                        switch (d.readyState) {
                            case 4:
                                l = !0;
                                break;
                            case 3:
                                e = !0
                        }
                        var g = 200 === d.status || 304 === d.status,
                            n = c.responsePosition;
                        if (e || l && g) {
                            var k = d.responseText;
                            if (n < k.length) {
                                var n = k.substring(n, k.length),
                                    k = n.split("\x26\x26\x26"),
                                    m = n.lastIndexOf("\x26\x26\x26");
                                if (-1 === m && e) return;
                                m < n.length - 3 && e && k.pop();
                                f.each(k, function(a, b) {
                                    var d;
                                    if ("" !== f.trim(a)) try {
                                        d = f.parseJSON(a)
                                    } catch (h) {
                                        p.logError(h, "Invalid streaming ajax JSON response: " + a)
                                    } else d = a;
                                    c.callbacks.chunk(d)
                                });
                                c.responsePosition += m
                            }
                        }
                        l && (clearInterval(c.pollTimer), clearTimeout(c.timeoutTimer), a.complete(), g ? c.callbacks.success(null, d.statusText, c) : c.callbacks.failure(c, d.statusText, d.statusText), b.trigger("a:pageUpdate"), b.trigger("a:ajax:complete"))
                    },
                    e = function(c) {
                        var d = c.http;
                        if (4 === d.readyState) {
                            clearInterval(c.pollTimer);
                            clearTimeout(c.timeoutTimer);
                            a.complete();
                            var e = d.responseText;
                            try {
                                var l = f.parseJSON(e);
                                l && (e = l)
                            } catch (g) {}
                            200 !== d.status && 304 !== d.status ? c.callbacks.failure(c, d.statusText, d.statusText) : c.callbacks.success(e, d.statusText, c);
                            b.trigger("a:ajax:complete")
                        }
                    };
                return function() {
                    function b(c) {
                        4 > c.http.readyState && (clearInterval(c.pollTimer), c.callbacks.failure(c, "Request Timeout", "Request Timeout"), a.complete())
                    }

                    function g(a, c, b) {
                        b = b || {};
                        b = f.extend({}, k.all, k[c], b);
                        f.each(b, function(c, b) {
                            (c || "" === c) && a.setRequestHeader(b, c)
                        });
                        return a
                    }

                    function n(c, b, d, e, l, f, k, m, t, r) {
                        var v = c.http;
                        v.open(b, d);
                        g(v, b, t);
                        c.timeout = e;
                        c.callbacks.chunk = l || c.callbacks.chunk;
                        c.callbacks.success = f || c.callbacks.success;
                        c.callbacks.failure = k || c.callbacks.failure;
                        c.callbacks.abort = m || c.callbacks.abort;
                        r && (v.withCredentials = !0);
                        a.add(c);
                        return {
                            abort: function() {
                                c.abort()
                            }
                        }
                    }
                    var k = {
                            all: {
                                "X-Requested-With": "XMLHttpRequest"
                            },
                            get: {
                                Accept: "text/html,*/*"
                            },
                            post: {
                                Accept: "text/html,*/*",
                                "Content-Type": "application/x-www-form-urlencoded"
                            }
                        },
                        m = function() {
                            var a = new XMLHttpRequest;
                            this.pollTimer = null;
                            this.http = a;
                            this.responsePosition = 0;
                            this.buffer = "";
                            this.callbacks = {
                                success: c,
                                failure: c,
                                chunk: c,
                                abort: c
                            }
                        };
                    m.prototype = {
                        send: function() {
                            var a = this;
                            a.http.send(a.params);
                            a.pollTimer = setInterval(function() {
                                if (2 <= a.http.readyState && "unknown" !== typeof a.http.responseText) {
                                    var c = a.http.getResponseHeader("Content-Type"),
                                        c = c ? c.toLowerCase() : "";
                                    (-1 !== c.indexOf("application/json-amazonui-streaming") || -1 !== c.indexOf("application/amazonui-streaming-json") ? d : e)(a)
                                }
                            }, 25);
                            a.timeout = "undefined" ===
                                typeof a.timeout ? 2E4 : a.timeout;
                            a.timeoutTimer = f.delay(b, a.timeout, a)
                        },
                        get: function(a, c, b, d, h, e, l, g, f) {
                            if (c) {
                                var k = a.indexOf("?"),
                                    m = a.charAt(a.length - 1); - 1 < k ? "?" !== m && "\x26" !== m && (a += "\x26") : a += "?";
                                a += c
                            }
                            return n(this, "get", a, b, d, h, e, l, g, f)
                        },
                        abort: function() {
                            this.http && this.http.abort();
                            clearInterval(this.pollTimer);
                            clearTimeout(this.timeoutTimer);
                            a.abort(this);
                            this.callbacks.abort(this)
                        },
                        post: function(a, c, b, d, h, e, l, g, f) {
                            this.params = c;
                            return n(this, "post", a, b, d, h, e, l, g, f)
                        }
                    };
                    return m
                }()
            }(),
            c = {
                update: function(a,
                    c, b) {
                    k(c).html(b)
                },
                append: function(a, c, b) {
                    a = k(c);
                    a.html(a.html() + b)
                },
                prepend: function(a, c, b) {
                    a = k(c);
                    a.html(b + a.html())
                },
                state: function(a, c, b) {
                    e.state(c, b)
                },
                script: function(a, c) {
                    eval(c)
                },
                trigger: function(a, c) {
                    var d;
                    d = Array.prototype.slice.call(arguments, 1);
                    b.trigger.apply(void 0, d)
                }
            },
            a = {
                "a-ajax-update": function(a) {
                    var c = new r,
                        b = function() {
                            var a = q.ue;
                            a && a.tag && (a.tag("aui"), a.tag("aui:ajax"))
                        },
                        d = a.abort,
                        e = k(a.indicator),
                        g = e.hasClass("aok-hidden");
                    e.removeClass("aok-hidden").show();
                    var n = function(a,
                            c) {
                            e.hide();
                            g && e.addClass("aok-hidden");
                            b();
                            a && a.apply(q, c)
                        },
                        t = "string" === typeof a.method && "post" === a.method.toLowerCase() ? "post" : "get";
                    "get" === t && !1 === a.cache && (a.params += ["" === a.params ? "" : "\x26", "_\x3d", f.now()].join(""));
                    return c[t](a.url, a.params, a.timeout, function(c) {
                        b();
                        m(c, a.chunk)
                    }, function() {
                        n(a.success, arguments)
                    }, function() {
                        n(a.failure, arguments)
                    }, d, a.headers, a.withCredentials)
                }
            };
        g.declarative("a-ajax-update", function(c) {
            var d = c.$target,
                e = c.action,
                g = c.data;
            if (g || b.events.defaults[c.targetTag] ===
                c.type)
                if ("object" !== typeof g || g[c.type]) {
                    var g = g || {},
                        f = g.url || d.attr("href") || d.attr("action"),
                        k = n(g.params, g.paramsFormat),
                        m = d.attr("method") || g.method,
                        t = g.indicator,
                        g = g.timeout;
                    f || p.error("No ajax url provided.", "A.ajax", "declarativeHandler");
                    "form" === c.targetTag && c.type === b.events.defaults.form && (d = d.serialize(), k += d);
                    c.$event.preventDefault();
                    return a[e]({
                        url: f,
                        params: k,
                        method: m,
                        indicator: t,
                        operation: e,
                        timeout: g
                    })
                }
        });
        var t = function(c, b) {
            b = b || {};
            var e = b.headers || {};
            b.accepts !== u && (e.Accept = b.accepts);
            b.contentType !== u && (e["Content-Type"] = b.contentType);
            var g = n(b.params, b.paramsFormat);
            return a["a-ajax-update"](d.obj(this, {
                url: c,
                cache: b.cache,
                params: g,
                method: b.method,
                chunk: b.chunk,
                success: b.success,
                failure: b.failure || b.error,
                abort: b.abort,
                indicator: b.indicator,
                timeout: b.timeout,
                headers: e,
                withCredentials: !!b.withCredentials
            }))
        };
        return {
            ajax: t,
            get: function(a, c) {
                c = c || {};
                c.method = "get";
                return t.call(this, a, c)
            },
            post: function(a, c) {
                c = c || {};
                c.method = "post";
                return t.call(this, a, c)
            }
        }
    });
    "use strict";
    p.when("a-util",
        "p-detect", "a-prefix").register("a-animate", function(d, k, f) {
        function b(a, c, b) {
            a = a.jquery ? a[0] : a;
            c = f.prefixes.getStyle(c);
            a.style[c] = b
        }

        function g(a) {
            var c = "",
                b = k.capabilities.transform3d;
            a.top !== u && a.left !== u ? (c = "translate", b && (c += "3d"), c += "(" + a.left + ", " + a.top, b && (c += ", 0"), c += ")") : (a.top !== u ? c = "translateY(" + a.top + ")" : a.left !== u && (c = "translateX(" + a.left + ")"), b && (c += " translateZ(0)"));
            a.scale !== u && (c += " scale(" + a.scale + ")");
            return c
        }

        function e(a) {
            var c = {},
                b = !1;
            d.each(m, function(d) {
                d in a && (b = !0, c[d] =
                    a[d], delete a[d])
            });
            return b ? c : null
        }

        function n(a, c, b) {
            k.capabilities.transform ? ("string" === typeof b && (b = parseInt(b, 10)), d.isFiniteNumber(b) || (b = 0), a = parseInt(a.css(c), 10), d.isFiniteNumber(a) || (a = 0), b = b - a + "px") : d.isFiniteNumber(b) && (b += "px");
            return b
        }
        var m = ["top", "left", "scale"],
            r = {
                animate: function(a, c, b, d, e) {
                    a._a || (a._a = 0);
                    a._a++;
                    var g = function() {
                        a._a--;
                        e && e()
                    };
                    a.queue("fx", [function() {
                        a.animate(c, {
                            duration: b,
                            easing: "linear" === d ? d : "swing",
                            complete: g,
                            queue: !1
                        })
                    }])
                },
                fadeIn: function(a, c, b, d) {
                    (a.hasClass("aok-hidden") ||
                        a.hasClass("a-hidden")) && a.css("display", "none").removeClass("aok-hidden a-hidden");
                    this.stopAnimation(a, !0, !0);
                    a.fadeIn({
                        duration: c,
                        easing: "linear" === b ? b : "swing",
                        complete: d,
                        queue: !1
                    })
                },
                fadeOut: function(a, c, b, d) {
                    this.stopAnimation(a, !0, !0);
                    var e = a.css("opacity");
                    a.fadeOut({
                        duration: c,
                        easing: "linear" === b ? b : "swing",
                        complete: function() {
                            a.css("opacity", e);
                            d && d()
                        },
                        queue: !1
                    })
                },
                fadeToggle: function(a, c, b, d) {
                    a.fadeToggle({
                        duration: c,
                        easing: "linear" === b ? b : "swing",
                        complete: d,
                        queue: !1
                    })
                },
                slideUp: function(a, c,
                    b, d) {
                    a.slideUp({
                        duration: c,
                        easing: "linear" === b ? b : "swing",
                        complete: d,
                        queue: !1
                    })
                },
                slideDown: function(a, c, b, d) {
                    a.slideDown({
                        duration: c,
                        easing: "linear" === b ? b : "swing",
                        complete: d,
                        queue: !1
                    })
                },
                slideToggle: function(a, c, b, d) {
                    a.slideToggle({
                        duration: c,
                        easing: "linear" === b ? b : "swing",
                        complete: d,
                        queue: !1
                    })
                },
                isAnimated: function(a) {
                    a = a.jquery ? a[0] : a;
                    return a._a && 0 < a._a
                },
                stopAnimation: function(a, c, b) {
                    a.stop(c, b)
                }
            },
            c = {
                animate: function(a, c, h, f, m) {
                    if (a && a.length) {
                        var r = a[0];
                        c = d.copy(c);
                        h = h === u ? 250 : h;
                        f = f || "linear";
                        c.top !==
                            u && (c.top = n(a, "top", c.top));
                        c.left !== u && (c.left = n(a, "left", c.left));
                        b(a, "transition", 4 > h ? "all 0ms" : "all " + h + "ms " + f);
                        4 < h ? (r._a === u && (r._a = 0), r._a++, f = function() {
                            0 < r._a && r._a--;
                            r._a || b(a, "transition", "");
                            a.removeData("aAnimateTimeoutId").removeData("aAnimateOnComplete");
                            m && m()
                        }, a.data("aAnimateOnComplete", f).data("aAnimateTimeoutId", d.delay(f, h))) : m && d.delay(m, 0);
                        k.capabilities.transform && (h = e(c)) && b(a, "transform", g({
                            top: h.top,
                            left: h.left,
                            scale: h.scale
                        }));
                        d.objectIsEmpty(c) || a.css(c)
                    }
                },
                fadeIn: function(a,
                    c, b, e) {
                    this.stopAnimation(a, !0, !0);
                    var g;
                    a.data("aTargetOpacity") === u ? (g = a.css("opacity") || 1, a.data("aTargetOpacity", g)) : g = a.data("aTargetOpacity");
                    a.css("opacity", "0").removeClass("a-hidden aok-hidden").show();
                    d.reflowCssChanges(a);
                    this.animate(a, {
                        opacity: g
                    }, c, b, function() {
                        a.show();
                        e && e()
                    })
                },
                fadeOut: function(a, c, b, d) {
                    this.stopAnimation(a, !0, !0);
                    var e = a.css("opacity");
                    a.data("aTargetOpacity") === u && a.data("aTargetOpacity", e);
                    this.animate(a, {
                        opacity: 0
                    }, c, b, function() {
                        a.hide().css("opacity", e);
                        d && d()
                    })
                },
                fadeToggle: function(a, c, b, d) {
                    ("none" === a.css("display") || .05 > +a.css("opacity") ? this.fadeIn : this.fadeOut).call(this, a, c, b, d)
                },
                slideUp: function(a, c, b, e) {
                    var g = this.animate;
                    a.css({
                        height: a.innerHeight(),
                        overflow: "hidden"
                    });
                    d.delay(function() {
                        g(a, {
                            height: 0
                        }, c, b, function() {
                            a.hide();
                            a.css({
                                height: "",
                                overflow: ""
                            });
                            e && e()
                        })
                    }, 0)
                },
                slideDown: function(a, c, b, e) {
                    var g = a.innerHeight(),
                        f = this.animate;
                    a.css({
                        height: 0,
                        overflow: "hidden"
                    });
                    a.show();
                    d.delay(function() {
                        f(a, {
                            height: g
                        }, c, b, function() {
                            e && e();
                            a.css({
                                height: "",
                                overflow: ""
                            })
                        })
                    }, 0)
                },
                slideToggle: function(a, c, b, d) {
                    (a.is(":visible") ? this.slideUp : this.slideDown).call(this, a, c, b, d)
                },
                isAnimated: function(a) {
                    a = a.jquery ? a[0] : a;
                    return a._a && 0 < a._a
                },
                stopAnimation: function(a, c, e) {
                    if (a && a.length) {
                        var g = a[0];
                        b(a, "transition", "all " + (e ? "1" : "0") + "ms");
                        c && (g._a = 0);
                        d.reflowCssChanges(a);
                        clearTimeout(a.data("aAnimateTimeoutId"));
                        a.data("aAnimateOnComplete") && a.data("aAnimateOnComplete")()
                    }
                }
            };
        return k.capabilities.transition ? c : r
    });
    "use strict";
    p.when("A", "jQuery").register("a-image-lazy-loader",
        function(d, k) {
            function f() {
                k(".a-lazy-loaded").each(function() {
                    e.set(k(this))
                })
            }

            function b() {
                var b = [];
                k(".a-lazy-loaded").each(function() {
                    var m = k(this);
                    m.data("src") && g(m) && (m.load(function() {
                        d.trigger("a:image:lazyLoaded", m);
                        f()
                    }), b.push(m), m.removeClass("a-lazy-loaded"), e.remove(m))
                });
                d.each(b, function(b) {
                    b.attr("src", b.data("src"))
                })
            }

            function g(b) {
                e.get(b) || e.set(b);
                var d = k(q),
                    g = d.scrollTop(),
                    d = q.innerHeight ? q.innerHeight : d.height(),
                    c = g + d + 500,
                    g = g - 500,
                    a = e.get(b);
                b = a.top;
                var a = a.height,
                    f = b + a;
                return b >=
                    g && b < c || f > g && f <= c || a > d && b <= g && f >= c
            }
            var e = function() {
                var b = {},
                    d = 0;
                return {
                    get: function(d) {
                        return b[d.data("cacheKey")]
                    },
                    set: function(e) {
                        e.data("cacheKey") || (e.data("cacheKey", d), d++);
                        b[e.data("cacheKey")] = {
                            top: e.offset().top,
                            height: e.height()
                        }
                    },
                    remove: function(d) {
                        d.data("cacheKey") && delete b[d.data("cacheKey")]
                    }
                }
            }();
            f();
            b();
            d.on("scroll", function() {
                b()
            });
            d.on("scroll", d.debounce(function() {
                f();
                b()
            }, 250));
            d.on("resize", b);
            d.on("a:image:lazyLoad", b);
            d.on.ready(b)
        });
    "use strict";
    p.register("a-image-url-key-handler",
        function() {
            return {
                generate: function(d, k) {
                    return d
                },
                parse: function(d) {
                    return {
                        url: d
                    }
                }
            }
        });
    "use strict";
    p.when("jQuery", "a-util", "a-events", "a-defer", "p-detect", "a-image-url-key-handler").register("a-image", function(d, k, f, b, g, e) {
        function n(a) {
            a = d(a);
            var c = a.data("a-dynamic-image");
            if (c && "object" === typeof c) {
                var b = a.data("a-dynamic-image-container");
                "undefined" === typeof b && (b = a.closest(".a-dynamic-image-container"), 0 === b.length && (b = a.parent()), a.data("a-dynamic-image-container", b));
                var e = g.capabilities.hires &&
                    q.devicePixelRatio ? q.devicePixelRatio : 1,
                    h = b.width() * e,
                    f = b.height() * e,
                    n = Number.MAX_VALUE,
                    m = Number.MAX_VALUE,
                    r = a.attr("src") || "",
                    u, C = h / f;
                k.each(c, function(a, c) {
                    var b = parseInt(a[0], 10);
                    a = parseInt(a[1], 10);
                    b -= f;
                    a -= h;
                    b = 1 <= C ? a : b;
                    Math.abs(b) < m && 0 <= b && (m = Math.abs(b), u = c);
                    Math.abs(b) < n && (n = Math.abs(b), r = c)
                });
                u && (r = u);
                p.schedule(r, a);
                p.fill();
                return r
            }
        }

        function m() {
            d("img.a-dynamic-image").each(function() {
                d(this).data("a-manual-replacement") || n(this)
            })
        }
        var r = document.getElementsByTagName("img"),
            c = {},
            a = 0,
            p =
            function() {
                var b = [],
                    d = {};
                return {
                    schedule: function(a, g) {
                        a = e.generate(a, g.attr("crossorigin"));
                        d[a] || (b.push(a), d[a] = !0);
                        c[a] = c[a] || [];
                        for (var h = 0; h < c[a].length; h++)
                            if (g.is(c[a][h])) return;
                        c[a].push(g)
                    },
                    fill: function() {
                        for (var c = 0; c < 2 - a; c++)
                            if (0 < b.length) {
                                var e = b.shift();
                                d[e] = !1;
                                h.load(e)
                            }
                    }
                }
            }(),
            h = function() {
                function g(a) {
                    var d = c[a],
                        h = e.parse(a).url;
                    d && (k.each(d, function(a) {
                        a.data("a-image-replaced") !== h && (a.data("a-image-replaced", h), b.defer(function() {
                            a.attr("src", h);
                            f.trigger("a:image:load", {
                                $imageElement: a,
                                url: h
                            });
                            var c = a.data("a-image-name");
                            c && f.trigger("a:image:load:" + c, {
                                $imageElement: a,
                                url: h
                            })
                        }))
                    }), c[a] = [])
                }
                var h = {};
                return {
                    load: function(c) {
                        if (h[c]) g(c);
                        else if (!1 !== h[c]) {
                            var d = new Image;
                            d.onload = function() {
                                a--;
                                g(c);
                                h[c] = !0;
                                p.fill()
                            };
                            d.onerror = function() {
                                a--;
                                h[c] = !1;
                                p.fill()
                            };
                            a++;
                            b.defer(function() {
                                var a = e.parse(c),
                                    b = a.crossOrigin;
                                b && (d.crossOrigin = b);
                                d.src = a.url
                            })
                        }
                    },
                    poll: function() {
                        k.isPageHidden() || k.each(r, function(a) {
                            a = d(a);
                            !a.data("a-hires") || a.data("a-hires-loaded") || a.data("a-manual-replacement") ||
                                a.is(":hidden") || !k.onScreen(a) || (p.schedule(a.data("a-hires"), a), a.data("a-hires-loaded", !0))
                        })
                    }
                }
            }();
        g.capabilities.hires && f.on.ready(function() {
            k.interval(function() {
                h.poll();
                p.fill()
            }, 2E3)
        });
        f.on.ready(m);
        d(q).resize(m);
        return {
            loadHiResImage: function(a) {
                var c = [];
                d(a).each(function() {
                    var a = d(this),
                        b = a.data("a-hires");
                    b && (p.schedule(b, a), p.fill(), c.push(b));
                    a.data("a-hires-loaded", !0)
                });
                return c
            },
            loadDynamicImage: function(a) {
                var c = [];
                d(a).each(function() {
                    c.push(n(this))
                });
                return c
            },
            loadImageManually: function(a,
                c) {
                var b = [];
                d(a, c).each(function() {
                    var a = d(this);
                    if (!a.data("a-image-already-loaded")) {
                        a.data("a-image-already-loaded", !0);
                        var c = n(a),
                            e = d("\x3cimg\x3e").attr("src", c || a.data("a-image-source"));
                        b.push(c);
                        var c = "" + this.className,
                            g = a.data("a-extra-classes");
                        g && (c += " " + g);
                        e.attr("class", c);
                        e.attr("id", this.id);
                        e.attr("style", a.attr("style"));
                        e.attr("alt", a.attr("alt"));
                        e.attr("usemap", a.attr("usemap"));
                        e.attr("title", a.attr("title"));
                        e.attr("role", a.attr("role"));
                        (c = a.data("a-image-crossorigin")) && e.attr("crossorigin",
                            c);
                        k.each(this.attributes, function(a) {
                            a && a.name && (0 === a.name.indexOf("data-") || 0 === a.name.indexOf("aria-")) && e.attr(a.name, a.value)
                        });
                        e.data(a.data());
                        a.replaceWith(e)
                    }
                    return b
                })
            },
            loadDescendantImagesManually: function(a, c) {
                a = d(a, c).find("div.a-manually-loaded").filter(function() {
                    return !d(this).data("a-image-already-loaded")
                });
                return this.loadImageManually(a)
            }
        }
    });
    p.register("a-class", function() {
        function d() {}
        var k = /xyz/.test(function() {
            xyz
        }) ? /\b_super\b/ : /.*/;
        d.extend = function(f) {
            var b = this.prototype,
                g = Object.create ? Object.create(b) : function(b) {
                    function d() {}
                    d.prototype = b;
                    return new d
                }(b),
                e;
            for (e in f) g[e] = "function" === typeof f[e] && "function" === typeof b[e] && k.test(f[e]) ? function(d, e) {
                return function() {
                    var g = this._super;
                    this._super = b[d];
                    var c = e.apply(this, arguments);
                    this._super = g;
                    return c
                }
            }(e, f[e]) : f[e];
            f = "function" === typeof g.init ? g.hasOwnProperty("init") ? g.init : function() {
                b.init.apply(this, arguments)
            } : function() {};
            f.prototype = g;
            g.constructor = f;
            f.extend = d.extend;
            return f
        };
        return {
            createClass: function(f) {
                return d.extend(f)
            }
        }
    });
    "use strict";
    p.when("a-timing-analytics", "a-bodyBegin").execute("build-A", function(d) {
        var k = p.execute().decorate,
            f = p.when("a-util", "a-defer", "a-base", "a-events", "a-declarative", "a-state", "a-ajax", "a-animate", "a-image", "a-constants", "a-detect", "a-browser-events", "a-preload", "a-prefix", "a-request-animation-frame", "a-class", "a-draggable").register("A", function(b) {
                function g(d, g, f) {
                    this._guard = d;
                    this._logError = g;
                    b.each(e, function(c) {
                        b.extend(this, new c.constructor(d, g))
                    }, this)
                }
                var e = [];
                g.prototype = {};
                b.each(arguments, function(d) {
                    k && d.constructor !== Object ? e.push(d) : (delete d.constructor, b.extend(g.prototype, d))
                });
                d.stopWidgetLogging("A");
                return k ? g : g.prototype
            });
        k && f.decorate(function(b, d) {
            return new b(d.guard, d.logError)
        })
    });
    "use strict";
    p.register("a-constants", function() {
        return {
            constants: {
                keycodes: {
                    BACKSPACE: 8,
                    TAB: 9,
                    ENTER: 13,
                    ESCAPE: 27,
                    SPACE: 32,
                    LEFT_ARROW: 37,
                    UP_ARROW: 38,
                    RIGHT_ARROW: 39,
                    DOWN_ARROW: 40,
                    DELETE: 46
                },
                declarativeEvents: "blur click dblclick focus focusin focusout mousedown mouseup mouseenter mouseleave mousemove change submit touchstart touchend touchmove touchcancel keydown keyup keypress MSPointerDown pointerdown MSPointerUp pointerup MSPointerMove pointermove MSPointerCancel pointercancel MSPointerOver pointerenter MSPointerOut pointerleave",
                HIDE_CLASS: "aok-hidden",
                BROWSER_EVENTS: {
                    SCROLL: "scroll",
                    RESIZE: "resize",
                    ORIENTATION_CHANGE: "orientationChange"
                },
                PAGESTATE_LOADED_MODULE_PREFIX: "page-state-loaded:",
                NOOP: function() {}
            }
        }
    });
    "use strict";
    p.when("jQuery", "a-detect", "a-events", "a-util", "a-defer").register("a-browser-events", function(d, k, f, b, g) {
        function e() {
            return q.innerHeight ? q.innerHeight : document.documentElement.clientHeight
        }

        function n() {
            return q.innerWidth ? q.innerWidth : document.documentElement.clientWidth
        }

        function m() {
            return q.innerWidth ?
                Math.round(document.documentElement.clientWidth / q.innerWidth * 10) / 10 : 1
        }

        function r(a) {
            switch (a) {
                case h.ALL:
                    a = "orientation height width zoom scrollLeft scrollTop".split(" ");
                    break;
                case h.SCROLL:
                    a = ["scrollLeft", "scrollTop"];
                    break;
                case h.ZOOM:
                    a = ["height", "width", "zoom", "scrollLeft", "scrollTop"];
                    break;
                default:
                    a = ["orientation", "height", "width", "scrollLeft", "scrollTop"]
            }
            for (var c = {}, b, d;
                (d = a.pop()) !== u;) b = l[d], "orientation" === d ? l[d] = q.orientation === u ? n() > e() ? 90 : 0 : q.orientation : "height" === d ? l[d] = e() : "width" ===
                d ? l[d] = n() : "scrollTop" === d ? l[d] = q.scrollY ? q.scrollY : p.scrollTop() : "scrollLeft" === d ? l[d] = q.scrollX ? q.scrollX : p.scrollLeft() : "zoom" === d && (l[d] = m()), l[d] !== b && (c[d] = b);
            return c
        }

        function c(a) {
            if (a = w[a]) a.pollCounter = a.maxPollCount, a.intervalId || (a.intervalId = setInterval(a.handler, a.pollInterval))
        }

        function a(a) {
            (a = w[a]) && a.intervalId && (clearInterval(a.intervalId), a.intervalId = 0)
        }
        var p = d(q),
            h = {
                ORIENTATION_CHANGE: "orientationchange",
                SCROLL: "scroll",
                RESIZE: "resize",
                ZOOM: "zoom",
                ALL: "all"
            },
            l = {
                scrollLeft: 0,
                scrollTop: 0,
                height: e(),
                width: n(),
                orientation: q.orientation === u ? n() > e() ? 90 : 0 : q.orientation,
                zoom: m()
            };
        f.on("beforeReady", function() {
            r(h.ALL)
        });
        var y = {
                speed: 0,
                degree: 0,
                direction: "",
                positionX: 0,
                positionY: 0
            },
            v = [],
            x;
        p.bind("mousemove", b.throttle(function(a) {
            a = {
                x: a.clientX,
                y: a.clientY
            };
            if (x) {
                var c = x,
                    b = 0,
                    d = 0;
                v.push({
                    speed: Math.sqrt(Math.pow(a.x - c.x, 2) + Math.pow(a.y - c.y, 2)) / 50 * 10,
                    degree: Math.atan2(a.y - c.y, a.x - c.x) / (Math.PI / 180)
                });
                4 < v.length && (v = v.slice(-4));
                for (var c = v.length, e = 0; e < c; e++) b += v[e].speed, d += v[e].degree;
                b = Number((b / c).toFixed(2));
                d = Math.round(d / c);
                y = {
                    speed: b,
                    degree: d,
                    direction: 0 <= d ? 157.5 < d ? "W" : 112.5 < d ? "SW" : 67.5 < d ? "S" : 22.5 < d ? "SE" : "E" : -157.5 > d ? "W" : -112.5 > d ? "NW" : -67.5 > d ? "N" : -22.5 > d ? "NE" : "E",
                    positionX: a.x,
                    positionY: a.y
                };
                x = a
            } else a && (x = a)
        }, 50));
        p.bind(h.SCROLL, b.throttle(function() {
            var a = r(h.SCROLL);
            f.trigger(h.SCROLL, l, a)
        }, 100));
        var w = {};
        b.each([h.RESIZE, h.ZOOM], function(a) {
            w[a] = {
                handler: function() {},
                lastViewport: b.copy(l),
                maxPollCount: 5,
                pollCounter: 5,
                pollInterval: 100,
                intervalId: 0
            }
        });
        w.resize.handler =
            function() {
                var c = [],
                    d = w.resize;
                r("resize");
                var e = b.diff(l, d.lastViewport);
                e.orientation && c.push(h.ORIENTATION_CHANGE);
                e.width || e.height ? c.push(h.RESIZE) : k.capabilities.isIETouchCapable && e.scrollTop && c.push(h.RESIZE);
                c.length && (d.lastViewport = b.copy(l), b.each(c, function(a) {
                    f.trigger(a, l, e)
                }));
                0 === --d.pollCounter && a(h.RESIZE)
            };
        w.resize.pollInterval = 100;
        w.resize.maxPollCount = 10;
        p.bind(h.RESIZE, function(a) {
            c(h.RESIZE)
        });
        w.zoom.handler = function() {
            r(h.ZOOM);
            var c = w.zoom,
                d = b.diff(l, c.lastViewport);
            d.zoom &&
                (c.lastViewport = b.copy(l), f.trigger(h.ZOOM, l, d));
            0 === --c.pollCounter && a(h.ZOOM)
        };
        w.zoom.pollInterval = 200;
        k.capabilities.android && p.bind("touchcancel", function(a) {
            2 === a.originalEvent.changedTouches.length && (w.zoom.maxPollCount = 15, c(h.ZOOM))
        });
        k.capabilities.ios && p.bind("touchend", function(a) {
            1 === a.originalEvent.touches.length && (w.zoom.maxPollCount = 1, c(h.ZOOM))
        });
        k.capabilities.ios || k.capabilities.android || p.bind("resize", function(a) {
            w.zoom.maxPollCount = 5;
            c(h.ZOOM)
        });
        return {
            viewport: function(a) {
                a &&
                    r(h.ALL);
                return b.copy(l)
            },
            cursor: function() {
                return b.copy(y)
            },
            scrollBarWidth: function(a) {
                if (a || (document && document.body && document.body.scrollHeight ? document.body.scrollHeight : 0) > e()) {
                    a = document.createElement("div");
                    a.style.visibility = "hidden";
                    a.style.width = "100%";
                    a.style.overflowX = "scroll";
                    document.body.appendChild(a);
                    var c = a.offsetHeight;
                    document.body.removeChild(a);
                    return c
                }
                return 0
            }
        }
    });
    "use strict";
    p.register("a-analytics", function() {
        function d(d, b) {
            var g = q && q.ue && q.ue.count;
            if (g && d) {
                var e = "aui:" +
                    d;
                1 < arguments.length && g(e, b);
                return g(e)
            }
        }
        var k = q && q.ue && q.ue.tag;
        return {
            increment: function(f, b) {
                if (f) {
                    var g = d(f) || 0;
                    d(f, g + (b || 1))
                }
            },
            count: d,
            logError: function(d, b, g) {
                q.ueLogError && q.ueLogError({
                    message: d
                }, {
                    logLevel: b,
                    attribution: g
                })
            },
            tag: function(d) {
                k && d && k("aui:" + d)
            }
        }
    });
    "use strict";
    p.when("3p-promise", "a-analytics", "prv:a-preload-queue", "prv:a-preload-strategies").register("a-preload", function(d, k, f, b) {
        function g() {
            return new d(function(b) {
                setTimeout(b, 2500)
            })
        }

        function e(e) {
            var f = Date.now(),
                c = b.getStrategy(e)(e),
                a = d.race([c.promise, g()]).then(function() {
                    k.increment("preload_fulfilled");
                    return {
                        url: e,
                        success: !0,
                        duration: Date.now() - f
                    }
                }, function(a) {
                    return {
                        url: e,
                        success: !1,
                        reason: a
                    }
                });
            c.teardown && a.then(c.teardown);
            return a
        }

        function n(b, g) {
            if ("string" === typeof b) {
                if (!b.trim()) return d.resolve();
                k.increment("preload_asks");
                return f(g).then(function(c) {
                    return e(b).then(c)
                })
            }
            return "object" !== typeof b ? d.reject("not an URL or URL list") : d.all(b.map(function(c) {
                return n(c, g)
            }))
        }
        return {
            preload: n
        }
    });
    p.when("3p-promise").register("prv:a-preload-queue",
        function(d) {
            function k() {
                if (f) {
                    var d = (b.length ? b : e ? g : []).pop();
                    d && (f--, d())
                }
            }
            var f = "function" === typeof q.plCount ? q.plCount() : 5,
                b = [],
                g = [],
                e = !1;
            p.when("afterLoad").execute(function() {
                e = !0;
                for (var b = f; 0 < b; b--) k()
            });
            return function(e) {
                function m() {
                    m = function() {};
                    f++;
                    k()
                }
                return (new d(function(d) {
                    var c = e ? b : g;
                    c.splice(Math.round(Math.random() * c.length), 0, d);
                    k()
                })).then(function() {
                    return function(b) {
                        m();
                        return b
                    }
                })
            }
        });
    p.when("3p-promise").register("prv:a-preload-strategies", function(d) {
        function k(b) {
            return (b =
                /^(?:[^?#]+)[.]([a-z2]+)(?:[?#].*)?$/.exec(b)) && b[1] || ""
        }

        function f(b) {
            b = k(b);
            return /^gif|jpe?g|png$/.test(b)
        }

        function b(b) {
            var e = document.createElement("link");
            return {
                promise: new d(function(c, a) {
                    try {
                        e.rel = "preload";
                        var d, g = k(b);
                        d = "js" === g ? "script" : "css" === g ? "style" : f(b) ? "image" : "woff" === g || "woff2" === g ? "font" : "fetch";
                        e.as = d;
                        e.crossOrigin = "anonymous";
                        e.href = b;
                        e.onerror = e.onload = c;
                        document.head.appendChild(e)
                    } catch (n) {
                        a("failed to preload link loader")
                    }
                }),
                teardown: function() {
                    e && e.parentElement && e.parentElement.removeChild(e)
                }
            }
        }

        function g(b) {
            var e = new Image;
            return {
                promise: new d(function(c, a) {
                    try {
                        e.style.display = "none", e.crossOrigin = "anonymous", e.onerror = e.onload = c, e.src = b, document.documentElement.appendChild(e)
                    } catch (d) {
                        a("failed to preload image loader")
                    }
                }),
                teardown: function() {
                    e && e.parentElement && e.parentElement.removeChild(e)
                }
            }
        }

        function e(b) {
            return {
                promise: new d(function(d, c) {
                    try {
                        var a = new XMLHttpRequest;
                        a.open("GET", b, !0);
                        a.onreadystatechange = function() {
                            4 == this.readyState && d()
                        };
                        a.send()
                    } catch (e) {
                        c("failed to preload ajax loader")
                    }
                })
            }
        }
        var n;
        try {
            n = document.createElement("link").relList.supports("preload")
        } catch (m) {
            n = !1
        }
        return {
            getStrategy: function(d) {
                return n ? b : f(d) ? g : e
            },
            link: b,
            xhr: e,
            image: g
        }
    });
    "use strict";
    p.when("a-util").register("a-request-animation-frame", function(d) {
        for (var k = 0, f = ["ms", "moz", "webkit", "o"], b = 0; b < f.length && !q.requestAnimationFrame; ++b) q.requestAnimationFrame = q[f[b] + "RequestAnimationFrame"], q.cancelAnimationFrame = q[f[b] + "CancelAnimationFrame"] || q[f[b] + "CancelRequestAnimationFrame"];
        q.requestAnimationFrame || (q.requestAnimationFrame =
            function(b, e) {
                var f = d.now(),
                    m = Math.max(0, 16 - (f - k));
                e = q.setTimeout(function() {
                    b(f + m)
                }, m);
                k = f + m;
                return e
            });
        q.cancelAnimationFrame || (q.cancelAnimationFrame = function(b) {
            clearTimeout(b)
        });
        return {
            requestAnimationFrame: function(b, d) {
                return q.requestAnimationFrame(b, d)
            },
            cancelAnimationFrame: function(b) {
                q.cancelAnimationFrame(b)
            }
        }
    });
    "use strict";
    p.when("jQuery").register("a-form-controls-api", function(d) {
        var k = 0,
            f = function(b) {
                return b && b.jquery ? b : b && 1 === b.nodeType ? d(b) : null
            },
            b = function(b, d, k) {
                var m = f(b);
                if (!m ||
                    1 !== m.length) return !1;
                b = m.find("input").first();
                d !== u && (d = !!d, m.hasClass("a-touch-multi-select") && (m.find("i.a-icon").first().toggleClass("a-icon-touch-multi-select-active", d).toggleClass("a-icon-touch-multi-select", !d), m.attr("aria-checked", d)), b.prop("checked") !== d && b.prop("checked", d).trigger("change"));
                k !== u && (k = !!k, b.prop("disabled") !== k && b.prop("disabled", k))
            };
        return {
            findFormElementContainer: function(b) {
                if ((b = f(b)) && 1 === b.length) {
                    var e = b.closest("form");
                    0 === e.length && (e = b.closest("fieldset"),
                        0 === e.length && (e = d(document)));
                    return e
                }
            },
            toggleCheckboxState: function(d) {
                d = f(d);
                var e;
                d && 1 === d.length && (e = d.find("input").first(), b(d, !e[0].checked))
            },
            setCheckboxState: b,
            setRadioState: b,
            normalizeElement: function(d) {
                if ((d = (d = f(d)) ? d : f(this)) && 1 === d.length) {
                    var e = d.find("input").first();
                    e.attr("type");
                    var n = d.hasClass("a-touch-multi-select");
                    d.attr("id") || e.attr("id") || n && (!n || d.parent().attr("id")) || (n = "a-form-controls-autoid-" + k, d.attr("aria-labelledby", n).find(".a-checkbox-label, .a-radio-label, .a-touch-multi-select-item-label").attr("id",
                        n), k++);
                    b(d, e[0].checked, e[0].disabled)
                }
            },
            normalizeFieldsets: function(b) {
                d(b).closest("fieldset").each(function(b, g) {
                    b = d(g);
                    g = b.find("legend").first();
                    if (g.length) {
                        var f = g.attr("id");
                        f || (f = "a-form-controls-autoid-" + k, g.attr("id", f), k++);
                        b.attr("aria-describedby", f)
                    }
                })
            }
        }
    });
    "use strict";
    p.when("a-util", "a-constants").execute("prepare-a-weblab", function(d, k) {
        p.when(k.constants.PAGESTATE_LOADED_MODULE_PREFIX + "a-wlab-states").register("a-weblab", function(f) {
            function b(b) {
                m || (r[b] = n[b]);
                return m && m[b] ||
                    n[b]
            }

            function g(c) {
                return b(c) || "C"
            }

            function e(c) {
                return b(c) || "C"
            }
            var n = f || {},
                m, r = {};
            p.when(k.constants.PAGESTATE_LOADED_MODULE_PREFIX + "a-ltree-states").execute(function(b) {
                m = b || {};
                d.each(d.keys(r), function(a) {
                    (m[a] || r[a]) && m[a] !== r[a] && p.log("a-weblab returned wrong value for " + a + ". It returned " + r[a] + ". it is set as " + m[a] + " at a-ltree-states.")
                })
            });
            return {
                is: function(b, a, d) {
                    return (d ? e : g)(b) === a
                },
                isActive: function(c) {
                    return !!b(c)
                },
                noTrigger: g,
                trigger: e
            }
        })
    });
    "use strict";
    p.declare("prv:a-post-atf-catchdomready", !0);
    p.when("a-util", "a-defer", "prv:a-post-atf-catchdomready").register("prv:a-post-atf", function(d, k, f) {
        function b() {
            n || (n = !0, d.each(e, function(b) {
                k.defer(b)
            }), e = [])
        }

        function g() {
            f && b()
        }
        var e = [],
            n = !1;
        p.when("af", "cf").execute("flush_queued_functions_after_ATF", b);
        p.when("a-domready").execute("flush_queued_functions_after_domready", function() {
            d.delay(g, 500)
        });
        return {
            execute: function(b) {
                n ? k.defer(b) : e.push(b)
            }
        }
    });
    "use strict";
    p.register("prv:a-tnr", function() {
        return {
            findTnrAttribute: function(d, k, f) {
                return null
            },
            ack: function(d, k, f, b) {},
            ackDelegated: function(d) {},
            ackDeclarative: function(d) {},
            wrapJqBindArgs: function() {
                var d = arguments.length;
                if (1 >= d) return [];
                for (var k = [], f = 1; f < d; f++) k.push(arguments[f]);
                return k
            },
            wrapJqUnbindArgs: function() {
                for (var d = Array(arguments.length), k = 0; k < d.length; ++k) d[k] = arguments[k];
                return d
            },
            wrapDeclarativeActionHandler: function(d) {
                return d
            }
        }
    });
    "use strict";
    p.register("prv:a-collect-p-debug", function() {
        var d = !1;
        return function() {
            d || (d = !0, p.when("prv:p-debug", "afterLoad").execute(function(d) {
                d =
                    JSON && JSON.stringify ? JSON.stringify(d) : "{}";
                p.log(d, "WARN", "[AUI] p-debug")
            }))
        }
    });
    "use strict";
    p.when("A").register("a-component-mixins", function(d) {
        function k(g) {
            for (var e = 0; e < g.length; e++)
                if (0 > d.indexOfArray(b, g[e])) return !1;
            return !0
        }
        var f = 0,
            b = d.constants.declarativeEvents.split(" ");
        return {
            show: function() {
                this._$element.removeClass("a-hidden aok-hidden").show();
                return this
            },
            hide: function() {
                this._$element.addClass("aok-hidden");
                return this
            },
            toggle: function() {
                return this._$element.hasClass("aok-hidden") ?
                    this.show() : this.hide()
            },
            size: function() {
                return this._$element.size()
            },
            isEmpty: function() {
                return 0 === this._$element.size()
            },
            on: function(b, e) {
                var n = d.parseFunctionName(e);
                n || p.error.call({}, "Please name all asynchronous event callbacks");
                if (b = b ? b.split(" ") : u) {
                    this.fnMap = this.fnMap || {};
                    k(b) || p.error.call({}, "That event is not supported!");
                    var m = this;
                    d.each(b, function(b) {
                        this.fnMap[b] = this.fnMap[b] || [];
                        var c = this.fnMap[b][e] = "a-component-event-" + f++;
                        d.declarative(c, b, function() {
                            try {
                                e.apply(m, m.callbackArgs || [])
                            } catch (a) {
                                p.logError.call({}, a, "Error occurred in an asynchronous event callback", "FATAL", (e.caller || "") + b + "handler:" + (n || "anonymous"))
                            }
                        });
                        d.declarative.create(m._$element, c)
                    }, m)
                }
            },
            off: function(b, e) {
                b = b ? b.split(" ") : u;
                this.fnMap || p.error.call({}, "There are no callbacks assigned to this component");
                b && e ? d.each(b, function(b) {
                    try {
                        d.declarative.remove(this._$element, this.fnMap[b][e]), delete this.fnMap[b][e]
                    } catch (g) {
                        p.error.call({}, "The component is not bound to a callback with name " + d.parseFunctionName(e) ||
                            "anonymous for event " + b)
                    }
                }, this) : e || b ? !e && b ? d.each(b, function(b) {
                    for (var d in this.fnMap[b]) this.fnMap[b].hasOwnProperty(d) && this.off(b, d);
                    delete this.fnMap[b]
                }, this) : p.error.call({}, "Please provide an event associated with the callback") : (d.declarative.remove(this._$element), delete this.fnMap)
            },
            trigger: function(b, e) {
                this.callbackArgs = e || [];
                d.$.fn.trigger.call(this._$element, b)
            }
        }
    });
    "use strict";
    p.when("A", "jQuery", "a-component-mixins", "a-analytics", "prv:a-sampler").register("a-component", function(d,
        k, f, b, g) {
        var e = d.createClass({
            init: function(b, e) {
                d.contains(b, ".a-") && p.error("{API} Cannot create components using 'a-' selectors. Apply your own CSS class or ID to select this element.", "API", "component");
                this._$element = k(b, e);
                this._trackApi()
            },
            _trackApi: function() {
                this._componentName && g("AUI API Analytics") && b.increment("api:" + this._componentName)
            }
        });
        return {
            create: function(b) {
                var g = b.mixin;
                g && delete b.mixin;
                b = e.extend(b);
                g && d.mixin(b.prototype, f, g);
                return b
            }
        }
    });
    "use strict";
    p.when("A", "jQuery",
        "a-component").register("a-alert", function(d, k, f) {
        var b = ["error", "success", "warning", "info"],
            g = d.map(b, function(b) {
                return "a-alert-" + b
            }).join(" "),
            e = d.map(b, function(b) {
                return "a-alert-inline-" + b
            }).join(" "),
            n = document.createElement("h4");
        n.className = "a-alert-heading";
        var m = k(n),
            r = f.create({
                _componentName: "alert",
                init: function(b, a) {
                    this._super(b, a);
                    this._$element = this._$element.filter(".a-alert, .a-alert-inline");
                    this._$heading = this._$element.find(".a-alert-heading");
                    this._$content = this._$element.find(".a-alert-content")
                },
                mixin: ["show", "hide", "size", "isEmpty"],
                heading: function(b) {
                    if ("undefined" === typeof b) return this._$heading.text();
                    this._$heading.length ? this._$heading.text(b) : this._$heading = m.clone().text(b).insertBefore(this._$content);
                    return this
                },
                removeHeading: function() {
                    this._$heading.remove();
                    this._$heading = k();
                    return this
                },
                text: function(b) {
                    if ("undefined" === typeof b) return this._$content.text();
                    this._$content.text(b);
                    return this
                },
                html: function(b) {
                    if ("undefined" === typeof b) return this._$content.html();
                    this._$content.html(b);
                    return this
                },
                type: function(c) {
                    -1 === d.indexOfArray(b, c) && p.error("{API} Alert type must be one of [error, success, warning, info].", "API", "alert");
                    this._$element.each(function(a, b) {
                        a = k(b);
                        b = "a-alert-";
                        a.hasClass("a-alert-inline") ? (b += "inline-", a.removeClass(e)) : a.removeClass(g);
                        a.addClass(b + c)
                    });
                    return this
                }
            });
        return function(b, a) {
            return new r(b, a)
        }
    });
    "use strict";
    p.when("jQuery", "a-component", "a-form-controls-api").register("a-checkbox", function(d, k, f) {
        var b = f.setCheckboxState,
            g = k.create({
                _componentName: "checkbox",
                init: function(b, d) {
                    this._super(b, d);
                    this._$element = this._$element.closest(".a-checkbox");
                    this._$input = this._$element.find("[type\x3dcheckbox]")
                },
                mixin: ["show", "hide", "size", "isEmpty"],
                check: function(d) {
                    d = void 0 === d ? !0 : d;
                    this._$element.each(function() {
                        b(this, d)
                    });
                    return this
                },
                uncheck: function() {
                    return this.check(!1)
                },
                toggleChecked: function() {
                    this._$element.each(function() {
                        f.toggleCheckboxState(this)
                    });
                    return this
                },
                isChecked: function() {
                    for (var b = 0, d = this._$input.length; b < d; b++)
                        if (!this._$input[b].checked) return !1;
                    return !0
                },
                isUnchecked: function() {
                    for (var b = 0, d = this._$input.length; b < d; b++)
                        if (this._$input[b].checked) return !1;
                    return !0
                },
                enable: function(d) {
                    d = void 0 === d ? !0 : d;
                    this._$element.each(function() {
                        b(this, void 0, !d)
                    });
                    return this
                },
                disable: function() {
                    return this.enable(!1)
                },
                toggleEnabled: function() {
                    for (var d = 0, g = this._$input.length; d < g; d++) b(this._$element[d], void 0, !this._$input[d].disabled);
                    return this
                },
                isEnabled: function() {
                    for (var b = 0, d = this._$input.length; b < d; b++)
                        if (this._$input[b].disabled) return !1;
                    return !0
                },
                isDisabled: function() {
                    for (var b = 0, d = this._$input.length; b < d; b++)
                        if (!this._$input[b].disabled) return !1;
                    return !0
                },
                toggle: function(b) {
                    "undefined" !== typeof b && (b = !!b);
                    this._$element.each(function() {
                        d(this).toggle(b)
                    });
                    return this
                }
            });
        return function(b, d) {
            return new g(b, d)
        }
    });
    "use strict";
    p.when("A", "a-component").register("a-meter", function(d, k) {
        var f = k.create({
            _componentName: "meter",
            init: function(b, d) {
                this._super(b, d);
                this._$element = this._$element.filter(".a-meter, .a-meter-with-txt");
                this._$bar = this._$element.find(".a-meter-bar");
                this._$progressTxt = this._$element.find(".a-meter-progress-txt")
            },
            mixin: ["show", "hide", "size", "isEmpty"],
            get: function() {
                return {
                    percent: this.percent(),
                    txt: this.text()
                }
            },
            enable: function() {
                this._$element.removeClass("a-inactive");
                return this
            },
            disable: function() {
                this._$element.addClass("a-inactive");
                return this
            },
            isEnabled: function() {
                return !this._$element.hasClass("a-inactive")
            },
            percent: function(b) {
                if ("undefined" === typeof b) return b = this._$bar.get(0).style.width, parseInt(b, 10);
                d.isFiniteNumber(b) || p.error("{API}  Meter percent should be a number between 0 and 100",
                    "a-meter", "setProgress");
                b = Math.min(100, Math.max(0, b));
                b += "%";
                this._$bar.css({
                    width: b
                });
                this._$element.attr("aria-label", b);
                return this
            },
            text: function(b) {
                if ("undefined" === typeof b) return this._$progressTxt.text();
                this._$progressTxt.text(b);
                return this
            },
            set: function(b, d) {
                this.percent(b);
                d && this.text(d);
                return this
            }
        });
        return function(b, d) {
            return new f(b, d)
        }
    });
    p.when("a-component").register("a-spinner", function(d) {
        var k = d.create({
            _componentName: "spinner",
            init: function(d, b) {
                this._super(d, b);
                this._$element =
                    this._$element.filter(".a-spinner-wrapper, .a-spinner")
            },
            mixin: ["show", "hide", "isEmpty", "size"],
            remove: function() {
                this._$element.remove()
            }
        });
        return function(d, b) {
            return new k(d, b)
        }
    });
    "use strict";
    p.register("a-ua", function() {
        return {
            compareVersions: function(d, k, f) {
                var b = function(b) {
                    p.error("Versions are not comparable. " + b, "A - extras", "compareVersions")
                };
                f = f || ".";
                "string" === typeof d && "string" === typeof k && "string" === typeof f && "" !== d && "" !== k || b("Input values are not valid.");
                d = d.split(f);
                k = k.split(f);
                f = Math.max(d.length, k.length);
                for (var g = 0; g < f; g++) {
                    var e = g < d.length ? Number(d[g]) : 0,
                        n = g < k.length ? Number(k[g]) : 0;
                    !isNaN(e) && isFinite(e) && !isNaN(n) && isFinite(n) || b("Piece of one version number evaluates to NaN or +/- Infinity.");
                    if (e < n) return -1;
                    if (e > n) return 1
                }
                return 0
            }
        }
    });
    "use strict";
    p.when("a-analytics", "prv:p-debug", "ready").execute(function(d, k) {
        p.declare("prv:a-logTrigger", function(f) {
            var b = k[f] && k[f].registered || 0,
                g = 0,
                e = 0,
                n;
            for (n in k)
                if (k.hasOwnProperty(n)) {
                    var m = k[n];
                    m.end && m.end <= b && (g++, e +=
                        m.end - m.start)
                }
            d.count("blocking-count:" + f, g);
            d.count("blocking-time:" + f, Math.round(e))
        })
    });
    "use strict";
    p.when("a-analytics", "afterLoad").execute("a-doctype-test", function(d) {
        document.doctype && document.doctype.name && "html" === document.doctype.name.toLowerCase() || (p.log("Missing or Invalid HTML doctype. Please refer to http://w?AUI/LogMessages#HDOCTYPE for more details.", "WARN"), d.increment("a-doctype-issue"))
    });
    "use strict";
    p.when("jQuery", "a-analytics", "load").register("a-unicode-rupee-test", function(d,
        k) {
        var f = d("\x3cdiv/\x3e"),
            b = d("\x3cspan/\x3e").html("\x26#65534;");
        d = d("\x3cspan/\x3e").html("\x26#8377;");
        f.append(b, d);
        f.appendTo(document.body);
        d = d.width();
        b = b.width();
        d === b ? k.increment("aui-unsupported-rupee", 1) : k.increment("aui-supported-rupee", 1);
        f.remove()
    });
    "use strict";
    p.register("prv:a-sampler-inclusion", function() {
        return {
            "AUI API Analytics": .01 > Math.random()
        }
    });
    p.when("prv:a-sampler-inclusion").register("prv:a-sampler", function(d) {
        return function(k) {
            return d.hasOwnProperty(k) && d[k]
        }
    });
    "use strict";
    p.when("A", "3p-promise", "load").register("a-pcv", function(d, k) {
        var f;
        return {
            getData: function() {
                f || (f = new k(function(b, d) {
                    var e = q.pcv.AmazonUI;
                    e ? (document.documentElement.setAttribute("data-aui-version", e), b(e)) : d(Error("Package closure version of AmazonUI is not found on the page"))
                }));
                return f
            }
        }
    });
    "use strict";
    p.when("A").register("prv:a-timing-resource", function(d) {
        var k = q && q.performance && q.performance.getEntries && "function" === typeof q.performance.getEntries;
        return function(f) {
            if (!k) return [];
            var b = q.performance.getEntries({
                entryType: "resource"
            }) || [];
            return "function" === typeof f ? d.filter(b, f) : b
        }
    });
    p.when("A", "a-analytics", "prv:a-timing-resource", "ready").register("prv:a-asset-transfer", function(d, k, f) {
        function b(b, d, e) {
            return (b = b.exec(d)) && 2 <= b.length ? b[1] : e || ""
        }

        function g() {
            return f(function(b) {
                return b && ("link" === b.initiatorType || "script" === b.initiatorType || "css" === b.initiatorType) && b.name && 0 < b.name.indexOf("AUIClients/AmazonUI")
            })
        }
        var e = /AUIClients\/(.*?(?=#|$|-[a-z0-9]{40}))/;
        return function() {
            d.each(g(),
                function(d) {
                    var g;
                    g = [d.initiatorType, b(e, d.name || "")].join(":");
                    var f = d.startTime || 0,
                        c = d.responseEnd || 0,
                        a = d.transferSize || 0;
                    d = d.duration || c - f;
                    0 === a ? k.tag(g + ":cachehit") : k.count(g + ":transferSize", a);
                    k.count(g + ":startTime", f);
                    k.count(g + ":transferTime", 0 <= d ? d : 0)
                })
        }
    });
    p.when("prv:a-asset-transfer", "a-weblab").execute("a-asset-transfer-time", function(d, k) {
        k.isActive("AUI_PERF_130093") && !k.is("AUI_PERF_130093", "C") && d()
    });
    "use strict";
    p.when("A", "jQuery").register("a-touch-highlight", function(d, k) {
        var f = {
            touchstart: function(b, g) {
                var e = k(b.currentTarget);
                b = {
                    startX: g.clientX,
                    startY: g.clientY,
                    dX: 0,
                    dY: 0,
                    highlightTimer: d.delay(function() {
                        e.addClass("a-touch-press")
                    }, 110)
                };
                e.data("a-touch-track", b);
                k(".a-touch-press").removeClass("a-touch-press")
            },
            touchmove: function(b, d) {
                if (b = k(b.currentTarget).data("a-touch-track")) b.dX = d.clientX - b.startX, b.dY = d.clientY - b.startY, 7 < Math.abs(b.dX) && 7 < Math.abs(b.dY) && clearTimeout(b.highlightTimer)
            },
            touchend: function(b, d) {
                b = k(b.currentTarget);
                if (d = b.data("a-touch-track")) clearTimeout(d.highlightTimer),
                    b.removeClass("a-touch-press")
            }
        };
        f.touchcancel = f.touchend;
        p.when("ready").execute("a-touchpress-listeners", function() {
            k(document).delegate("a:not(.a-button-text), .a-button:not(.a-button-disabled), .a-accordion-row, .a-histogram-row, label, .a-touch-radio, .a-touch-checkbox", "touchstart touchmove touchend touchcancel", function(b) {
                f[b.type](b, b.originalEvent.changedTouches[0])
            });
            p.when("a-event-analytics").execute("TNR: notifyJquery for touchstart", function(b) {
                b.notifyJquery(k("a:not(.a-button-text), .a-button:not(.a-button-disabled), .a-accordion-row, .a-histogram-row, label, .a-touch-radio, .a-touch-checkbox"),
                    "touchstart")
            })
        })
    });
    "use strict";
    p.when("A").register("a-touch-recognize", function(d) {
        var k = {
                tap: function(b, d) {
                    if (b.ended && 20 > Math.abs(b.deltaX) && 20 > Math.abs(b.deltaY) && 75 < b.duration) return {
                        name: "tap",
                        touchFinished: !1
                    }
                },
                doubleTap: function(b, g) {
                    if (b.ended && g.ended && !g.wasDoubleTap) {
                        var e = 20 > b.deltaX && 20 > b.deltaY && 20 > g.deltaX && 20 > g.deltaY,
                            f = 300 > d.now() - g.startTime;
                        g = 30 > Math.abs(b.startX - g.startX) && 30 > Math.abs(b.startY - g.startY);
                        if (e && f && g) return b.wasDoubleTap = !0, {
                            name: "doubleTap",
                            touchFinished: !0
                        }
                    }
                },
                pan: function(b, d) {
                    if (1 < b.samples.length) {
                        d = Math.abs(b.deltaX);
                        var e = Math.abs(b.deltaY);
                        if ((!b.ended || 250 >= Math.abs(b.velocityX) && 250 >= Math.abs(b.velocityY)) && (5 < d || 5 < e)) return {
                            name: "pan",
                            direction: b.direction || (d > e ? "horizontal" : "vertical")
                        }
                    }
                },
                swipe: function(b, d) {
                    if (b.ended && 20 < b.duration && b.samples && 2 < b.samples.length) {
                        var e = b.samples[b.samples.length - 1],
                            f = b.samples[0];
                        d = Math.abs(e.x - f.x);
                        e = Math.abs(e.y - f.y);
                        if ((250 < Math.abs(b.velocityX) || 250 < Math.abs(b.velocityY)) && (5 < d || 5 < e)) return {
                            name: "swipe",
                            direction: b.direction || (d > e ? "horizontal" : "vertical"),
                            touchFinished: !0
                        }
                    }
                }
            },
            f = ["pan", "swipe", "doubleTap", "tap"];
        return function(b, d) {
            for (var e, n = 0, m = f.length; n < m; n++)
                if (e = k[f[n]](b, d)) return e;
            return {
                name: "touch",
                touchFinished: !1
            }
        }
    });
    "use strict";
    p.when("A", "jQuery", "a-touch-base", "a-touch-recognize", "a-util", "prv:a-tnr").register("a-touch", function(d, k, f, b, g, e) {
        function n() {
            if (h && !c.multi) {
                var e = b(c, a);
                c.finished || (f.trigger(e, c, t.target, t.currentTarget), c.finished = e.touchFinished)
            }
            h = !1;
            l && (y = d.requestAnimationFrame(n))
        }

        function m(a) {
            a.preventDefault()
        }

        function r(a, b) {
            if ("touchstart" === a.type) v[a.type](a, a.originalEvent.targetTouches[0], k(b), k(a.target));
            else v[a.type](a, a.originalEvent.targetTouches[0], b)
        }
        var c = f.touch,
            a = f.lastTouch,
            t = {},
            h = !1,
            l = !1,
            y = 0,
            v = {
                touchstart: function(a, b, e, h) {
                    var f = null;
                    e.hasClass("a-gesture-horizontal") ? f = "horizontal" : e.hasClass("a-gesture-vertical") && (f = "vertical");
                    var g = d.now();
                    c = {
                        id: a.timeStamp,
                        startTime: g,
                        startX: b.pageX,
                        startY: b.pageY,
                        deltaX: 0,
                        deltaY: 0,
                        velocityX: 0,
                        velocityY: 0,
                        duration: 0,
                        ended: !1,
                        $target: e,
                        $triggerTarget: h,
                        targetOffset: e.offset(),
                        multi: 1 < a.originalEvent.targetTouches.length,
                        direction: f,
                        capture: u,
                        samples: [{
                            x: b.pageX,
                            y: b.pageY,
                            deltaX: 0,
                            deltaY: 0,
                            elapsed: 0,
                            time: g
                        }]
                    };
                    l = !0;
                    y = d.requestAnimationFrame(n)
                },
                touchmove: function(a, b, e) {
                    if (c.samples && c.samples.length) {
                        h = !0;
                        var g = d.now(),
                            k = c.samples[c.samples.length - 1],
                            g = {
                                x: b.pageX,
                                y: b.pageY,
                                deltaX: b.pageX - k.x,
                                deltaY: b.pageY - k.y,
                                direction: f.touchDirection(b, k),
                                elapsed: g - c.startTime,
                                time: g
                            };
                        if (c.capture === u) {
                            var k = Math.abs(g.deltaX),
                                l = Math.abs(g.deltaY);
                            c.capture = !c.direction || "horizontal" === c.direction && k >= l / 1.15 || "vertical" === c.direction && l >= k / 1.15
                        }
                        c.capture && (m(a), c.samples.push(g), c.deltaX = b.pageX - c.startX, c.deltaY = b.pageY - c.startY, c.duration = g.elapsed, c.multi = c.multi || 1 < a.originalEvent.targetTouches.length, b = f.computeVelocity(c.samples), c.velocityX = b.x, c.velocityY = b.y, t = {
                            target: a.target,
                            currentTarget: e
                        })
                    }
                },
                touchend: function(b, e, g) {
                    if (c.samples && c.samples.length) {
                        h = !0;
                        g = d.now();
                        var k = c.samples[c.samples.length - 1];
                        e = {
                            x: k.x,
                            y: k.y,
                            deltaX: e && e.pageX ? e.pageX - k.deltaX : k.deltaX,
                            deltaY: e && e.pageY ? e.pageY - k.deltaY : k.deltaY,
                            direction: 1 < c.samples.length ? f.touchDirection(k, c.samples[c.samples.length - 2]) : k.direction,
                            elapsed: g - c.startTime,
                            time: g
                        };
                        c.samples.push(e);
                        c.capture && m(b);
                        c.multi = c.multi || 1 < b.originalEvent.targetTouches.length;
                        c.duration = g - c.startTime;
                        c.ended = !0;
                        e = f.computeVelocity(c.samples);
                        c.velocityX = e.x;
                        c.velocityY = e.y;
                        t = {
                            target: b.target,
                            currentTarget: b.currentTarget
                        };
                        l = !1;
                        d.cancelAnimationFrame(y);
                        n();
                        a = c
                    }
                }
            };
        v.touchcancel =
            v.touchend;
        k(document).delegate(".a-gesture", "mouseenter mouseleave", function(a) {
            m(a);
            e.ackDelegated(a)
        }).delegate(".a-gesture", "touchstart touchend touchmove touchcancel", function(a) {
            var b = k(this);
            b.data("a-touch-bound") || (b.data("a-touch-bound", !0).bind("touchstart touchend touchmove touchcancel", function(a) {
                r(a, this)
            }), r(a, this));
            e.ackDelegated(a)
        });
        p.when("a-event-analytics").execute("TNR: notifyJquery for touchstart (a-gesture)", function(a) {
            a.notifyJquery(k(".a-gesture"), "touchstart")
        });
        return {
            pauseTouchEvents: function(a) {
                k(q).bind("touchstart.a-pause touchmove.a-pause touchend.a-pause",
                    m);
                d.delay(function() {
                    k(q).unbind("touchstart.a-pause touchmove.a-pause touchend.a-pause")
                }, a)
            }
        }
    });
    "use strict";
    p.when("A", "jQuery").register("a-touch-base", function(d, k) {
        var f = {};
        return {
            touch: f,
            lastTouch: {},
            trigger: function(b, g, e, f) {
                var m;
                m = g.samples[g.samples.length - 1];
                m = {
                    x: m.x,
                    y: m.y,
                    direction: m.direction,
                    targetX: m.x - g.targetOffset.left,
                    targetY: m.y - g.targetOffset.top,
                    deltaX: m.deltaX,
                    deltaY: m.deltaY,
                    velocityX: g.velocityX,
                    velocityY: g.velocityY,
                    touchDeltaX: g.deltaX,
                    touchDeltaY: g.deltaY,
                    touchDuration: g.duration,
                    ended: g.ended
                };
                g = g.direction || b.direction;
                if (f = f ? f.id : null) g && d.trigger("a:" + b.name + "-" + g + ":" + f, m), d.trigger("a:" + b.name + ":" + f, m);
                e = k(e);
                g && e.trigger(b.name + "-" + g, m);
                e.trigger(b.name, m)
            },
            computeVelocity: function(b) {
                for (var f = d.now(), e = 0, k = b.length; e < k; e++)
                    if (150 > f - b[e].time) {
                        b.splice(0, e);
                        break
                    }
                f = b[0];
                b = b[b.length - 1];
                e = (b.time - f.time) / 1E3;
                return {
                    x: (b.x - f.x) / e,
                    y: (b.y - f.y) / e
                }
            },
            touchDirection: function(b, d) {
                var e;
                e = (b.pageX || b.x) - d.x;
                b = (b.pageY || b.y) - d.y;
                return "horizontal" === (f.direction ? f.direction :
                    Math.abs(e) > Math.abs(b) ? "horizontal" : "vertical") ? 0 < e ? "right" : "left" : 0 < b ? "down" : "up"
            }
        }
    });
    "use strict";
    p.when("A").register("a-immersive-image", function(d) {
        function k(b, c) {
            c = c ? ("transform" !== m("transform") ? "-webkit-" : "") + "transform 0.5s ease-out" : "none";
            b.css(m("transition"), c);
            b.parent().css(m("transition"), c)
        }

        function f(b, c, a, d) {
            c = "translate(" + c + "px, " + a + "px)";
            d = "scale(" + d + ")";
            b.css(m("transform"), d);
            b.parent().css(m("transform"), c)
        }

        function b(b, c, a, d, e) {
            var k = b.innerWidth() / 2,
                m = b.innerHeight() / 2;
            a = g(b, (k - a) * e, (m - d) * e, e);
            c.offsetX = a.x;
            c.offsetY = a.y;
            c.scale = e;
            f(b, c.offsetX, c.offsetY, e)
        }

        function g(b, c, a, d) {
            var e = b.innerWidth() / 4 * d;
            b = b.innerHeight() / 4 * d;
            d = c && c / Math.abs(c);
            var f = a && a / Math.abs(a);
            return {
                x: Math.abs(c) > e ? e * d : c,
                y: Math.abs(a) > b ? b * f : a,
                boundX: Math.abs(c) > e,
                boundY: Math.abs(a) > b,
                signX: d,
                signY: f
            }
        }

        function e(b, c, a, e) {
            c.zoomed && (d.trigger("a:immersiveImage:zoomOut", {
                $image: b,
                immersiveImage: c
            }), f(b, 0, 0, 1), k(b, a), c.atBounds = !1, c.zooming = !0, c.scale = 1, d.delay(function() {
                c.isPanEnabled = !1;
                b.css("-webkit-backface-visibility",
                    "hidden");
                e && (c.zooming = !1, c.zoomed = !1)
            }, 600))
        }

        function n(e, c, a, f, h) {
            c.zoomed || (d.trigger("a:immersiveImage:zoomIn", {
                $image: e,
                immersiveImage: c
            }), e.css("-webkit-backface-visibility", "visible"), k(e, !0), b(e, c, a, f, 2), c.atBounds = !1, c.zooming = !0, d.delay(function() {
                c.isPanEnabled = !0;
                h && (c.zooming = !1, c.zoomed = !0)
            }, 600))
        }
        var m = d.prefixes.getStyle;
        d.declarative("a-immersive-image", ["touchstart"], function(b) {
            var c = b.$target;
            if ("IMG" === c.prop("tagName") && !c.data("a-immersive-init")) {
                var a = {
                    zoomed: !1,
                    atBounds: !1,
                    offsetX: 0,
                    offsetY: 0,
                    scale: 1,
                    isPanEnabled: !1
                };
                c.data("a-immersive-image", a);
                c.bind("doubleTap", function(b, d) {
                    a.zooming || (a.zoomed ? e(c, a, !0, !0) : n(c, a, d.targetX, d.targetY, !0))
                });
                c.bind("pan swipe", function(b, d) {
                    if (a.zoomed && !a.zooming && a.isPanEnabled) {
                        var e = d.ended ? d.deltaX + d.velocityX / a.scale : d.deltaX,
                            m = d.ended ? d.deltaY + d.velocityY / a.scale : d.deltaY;
                        if (b = d.ended) a.atBounds = !1;
                        d = d.ended;
                        e = g(c, a.offsetX + e, a.offsetY + m, a.scale);
                        a.offsetX = e.x;
                        a.offsetY = e.y;
                        a.endedAtBounds && e.boundX && e.signX === a.signX && (a.atBounds = !0);
                        a.endedAtBounds = e.boundX && d;
                        a.signX = e.signX;
                        k(c, b);
                        f(c, a.offsetX, a.offsetY, a.scale)
                    }
                });
                (function() {
                    function b(a, c) {
                        var d = a[0].pageX - c.left,
                            e = a[0].pageY - c.top,
                            f = a[1].pageX - c.left;
                        a = a[1].pageY - c.top;
                        return {
                            midX: (d + f) / 2,
                            midY: (e + a) / 2,
                            distance: Math.sqrt(Math.pow(d - f, 2) + Math.pow(e - a, 2))
                        }
                    }
                    var d, f = 0,
                        g = !1;
                    c.bind("touchstart", function(a) {
                        var e = a.originalEvent.targetTouches;
                        2 === e.length && (d = b(e, c.offset()), a.stopImmediatePropagation(), a.preventDefault())
                    });
                    p.when("a-event-analytics").execute("TNR: notifyJquery for touchstart",
                        function(a) {
                            a.notifyJquery(c, "touchstart")
                        });
                    c.bind("touchmove", function(k) {
                        var m = k.originalEvent.targetTouches;
                        if (2 === m.length && (m = b(m, c.offset()), d)) {
                            g = !0;
                            var p = m.distance - d.distance;
                            f += Math.abs(p);
                            4 < f && !a.zooming && (0 > p ? e(c, a, !0, !1) : n(c, a, m.midX, m.midY, !1));
                            k.stopImmediatePropagation();
                            k.preventDefault()
                        }
                    });
                    c.bind("touchend touchleave touchcancel", function(b) {
                        g && 0 === b.originalEvent.targetTouches.length && (f = 0, g = !1, a.zoomed = 1 < a.scale, a.zooming = !1, b.preventDefault());
                        a.atBounds = !1
                    })
                })();
                c.data("a-immersive-init", !0)
            }
        });
        return {
            zoomOut: function(b) {
                var c = b.data("a-immersive-image");
                c && e(b, c, !1, !0)
            }
        }
    })
});
/* ******** */
(function(c) {
    var f = window.AmazonUIPageJS || window.P,
        g = f._namespace || f.attributeErrors,
        d = g ? g("AmazonUIButton@beacon", "AmazonUI") : f;
    d.guardFatal ? d.guardFatal(c)(d, window) : d.execute(function() {
        c(d, window)
    })
})(function(c, f, g) {
    c.when("A", "a-component").register("a-button", function(d, l) {
        function e(a) {
            a.preventDefault()
        }
        var h = l.create({
            _componentName: "button",
            init: function(a, b) {
                this._super(a, b);
                this._$element = this._$element.filter(".a-button");
                this._$coreFormElement = this._$element.children(".a-button-inner").children("button,input");
                this._$coreLinkElement = this._$element.children(".a-button-inner").children("a");
                this._$contentElement = this._$element.find(".a-button-text")
            },
            mixin: "show hide toggle isEmpty size on off trigger".split(" "),
            enable: function() {
                this._$element.removeClass("a-button-disabled");
                this._$coreFormElement.prop("disabled", !1);
                this._$coreLinkElement.unbind("click", e);
                return this
            },
            disable: function() {
                this._$element.addClass("a-button-disabled").removeClass("a-button-focus");
                this._$coreFormElement.prop("disabled", !0);
                this._$coreLinkElement.click(e);
                return this
            },
            isEnabled: function() {
                return !this._$element.hasClass("a-button-disabled")
            },
            setStatus: function(a) {
                var b = this._$element,
                    e = [null, "normal", "selected", "disabled", "error", "inactive"],
                    k = 0 > d.indexOfArray(e, a),
                    m = "radio" === b.attr("role");
                if (k) return c.error(a + " is not a valid status"), !1;
                d.each(e, function(a) {
                    b.removeClass("a-button-" + a)
                });
                this._$coreFormElement.prop("disabled", "disabled" === a);
                b.attr("aria-checked", function(b, k) {
                    return m ? "selected" === a : k
                });
                null !==
                    a && b.addClass("a-button-" + a);
                return this
            },
            text: function(a) {
                if (!(1 > this._$contentElement.length)) {
                    if ("undefined" === typeof a) return this._$contentElement.text();
                    this._$contentElement.text(a);
                    return this
                }
            }
        });
        return function(a, b) {
            return new h(a, b)
        }
    });
    "use strict";
    c.when("A", "a-component").register("a-toggle-button", function(d, c) {
        function e(a) {
            a.preventDefault()
        }

        function h(a) {
            d.each(b, function(b) {
                a._$element.removeClass(b)
            }, a)
        }

        function a(a) {
            return 0 === a._$element.length || 0 === a._$coreFormElement.length
        }
        var b = ["a-button-selected", "a-button-focus"],
            f = c.create({
                _componentName: "toggleButton",
                init: function(a, b) {
                    this._super(a, b);
                    this._$element = this._$element.filter(".a-button");
                    this._$coreFormElement = this._$element.find(".a-button-inner").find("button,input");
                    this._$coreLinkElement = this._$element.find(".a-button-inner a")
                },
                name: function() {
                    return this._$coreFormElement.attr("name")
                },
                enable: function() {
                    this._$element.removeClass("a-button-disabled");
                    this._$coreFormElement.prop("disabled", !1);
                    this._$coreLinkElement.unbind("click",
                        e);
                    return this
                },
                disable: function() {
                    h(this);
                    this._$element.addClass("a-button-disabled");
                    this._$coreFormElement.prop("disabled", !0);
                    this._$coreLinkElement.click(e);
                    return this
                },
                setAvailable: function() {
                    this._$element.removeClass("a-button-unavailable");
                    return this
                },
                setUnavailable: function() {
                    this._$element.addClass("a-button-unavailable");
                    return this
                },
                isEnabled: function() {
                    return !a(this) && !this._$element.hasClass("a-button-disabled")
                },
                setSelected: function() {
                    !a(this) && this.isEnabled() && this._$element.addClass("a-button-selected a-button-focus").attr("aria-checked",
                        "true");
                    return this
                },
                setUnselected: function() {
                    h(this);
                    return this
                },
                isSelected: function() {
                    return !a(this) && this._$element.hasClass("a-button-selected")
                },
                isAvailable: function() {
                    return !a(this) && !this._$element.hasClass("a-button-unavailable")
                }
            });
        return function(a, b) {
            return new f(a, b)
        }
    });
    "use strict";
    c.when("A", "a-component", "a-toggle-button").register("a-toggle-button-group", function(d, c, e) {
        var f = c.create({
            _componentName: "toggleButtonGroup",
            init: function(a, b) {
                this._super(a, b);
                this._$toggleGroupElement =
                    this._$element.filter(".a-button-group, .a-button-toggle-group").eq(0);
                this._$toggleGroupName = (a = this._$toggleGroupElement.data("a-button-group")) ? a.name : g
            },
            name: function() {
                return this._$toggleGroupName
            },
            getToggleButtonByName: function(a) {
                return this.getToggleButtonBySelector(".a-button:has([name\x3d" + a + "])")
            },
            setSelected: function(a) {
                a = this.getToggleButtonBySelector(a);
                a.isEnabled() && (this.getSelected().setUnselected(), a.setSelected());
                return this
            },
            getSelected: function() {
                return this.getToggleButtonBySelector(".a-button.a-button-selected")
            },
            getToggleButtonBySelector: function(a) {
                return e(this._$toggleGroupElement.find(a))
            }
        });
        return function(a, b) {
            return new f(a, b)
        }
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("AmazonUIMeter", "AmazonUI") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(d) {
    var g = window.AmazonUIPageJS || window.P,
        f = g._namespace || g.attributeErrors,
        a = f ? f("AmazonUIFont", "AmazonUI") : g;
    a.guardFatal ? a.guardFatal(d)(a, window) : a.execute(function() {
        d(a, window)
    })
})(function(d, g, f) {
    d.when("jQuery", "A", "3p-promise").register("a-fonts", function(a, d, k) {
        function l(a, d) {
            var b = e && e[a] ? e : d;
            return function() {
                return b[a].apply(b, arguments)
            }
        }
        var h = [],
            b = a("body"),
            f = function() {
                return new k(function(a, b) {
                    var e = g.setInterval(function() {
                        d.reduce(h, function(a, b) {
                            return a && "loaded" ===
                                b.status
                        }, !0) && (a(), clearInterval(e))
                    }, 50)
                })
            }(),
            m = {
                load: function(d) {
                    return new k(function(e, f) {
                        var c = {
                            variant: d,
                            status: "unloaded"
                        };
                        h.push(c);
                        c.$loader = a("\x3cspan\x3e.\x3c/span\x3e", {
                            "class": "aok-hidden"
                        }).css("font", c.variant).appendTo(b);
                        c.status = "loading";
                        c.$checker = a("\x3cspan\x3e.\x3c/span\x3e", {
                            "class": "aok-hidden"
                        }).appendTo(b);
                        c.intervalId = g.setInterval(function() {
                            c.$checker.css("font", c.variant + ', Consolas, "Courier New", Courier, monospace');
                            var a = c.$checker.width(),
                                b = c.$checker.height();
                            c.$checker.css("fontFamily", 'Consolas, "Courier New", Courier, monospace');
                            if (c.$checker.width() !== a || c.$checker.height() !== b) e(c.variant), c.status = "loaded", c.$loader.remove(), c.$checker.remove(), clearInterval(c.intervalId)
                        }, 50)
                    })
                },
                check: function(a) {
                    d.each(h, function(b) {
                        if (b.variant === a) return "loaded" === b.status
                    });
                    return !1
                },
                ready: f
            },
            e = document.fonts;
        e && e.ready && (f = e.ready.then ? e.ready : e.ready.apply(e));
        return {
            load: l("load", m),
            check: l("check", m),
            ready: f
        }
    });
    "use strict";
    d.when("A", "a-fonts", "prv:a-capabilities",
        "load").register("prv:a-custom-font-loader", function(a, d, f) {
        return function(g, h) {
            !f.isUCBrowser && a.localStorage && -1 === a.indexOfArray((a.localStorage.getItem("a-font-class") || "").split(" "), g) && (d.ready.then(function(b) {
                b = a.localStorage.getItem("a-font-class") || "";
                b += (b.length ? " " : "") + g;
                a.localStorage.setItem("a-font-class", b)
            }), a.each(h, function(a) {
                d.load(a)
            }))
        }
    });
    "use strict";
    d.when("prv:a-custom-font-loader").execute("a-ember-loader", function(a) {
        a("a-ember", ["1em Amazon Ember", "bold 1em Amazon Ember",
            "italic 1em Amazon Ember", "italic bold 1em Amazon Ember"
        ])
    });
    "use strict"
});
/* ******** */
(function(m) {
    var C = window.AmazonUIPageJS || window.P,
        w = C._namespace || C.attributeErrors,
        c = w ? w("AmazonUICarousel", "AmazonUI") : C;
    c.guardFatal ? c.guardFatal(m)(c, window) : c.execute(function() {
        m(c, window)
    })
})(function(m, C, w) {
    m.declare("a-carousel-constants", {
        ANIMATING: "animating",
        ANIMATION_SPEED: "animation_speed",
        AUTO_ADJUST_HEIGHT: "auto_adjust_height",
        CIRCULAR: "circular",
        CURRENT_PIXEL: "px",
        CURRENTLY_WRAPPING: "currentlyWrapping",
        DELAY_TIME: "delay_time",
        ELEMENT_CSS_CLASS: "elementCssClass",
        FETCHED_ITEMS: "fetchedItems",
        FIRST_VISIBLE_ITEM: "firstVisibleItem",
        HIDE_OFF_SCREEN: "hide_off_screen",
        INIT_EVENTS: "a:pageUpdate beforeReady",
        LOADING: "loading",
        MIN_GUTTER: "minimum_gutter_width",
        NAME: "name",
        NO_TRANSITION: "no_transition",
        PAGE_NUMBER: "pageNumber",
        PAGE_SIZE: "pageSize",
        PEEK_GRADIENT: "peek_gradient",
        PEEK_PERCENTAGE: "peek_percentage",
        PEEK_WIDTH: "peek_width",
        SET_SIZE: "set_size",
        SPRINGINESS: "springiness",
        STATIC_LOADER_CSS_CLASS: "staticLoaderCssClass",
        TOTAL_PAGES: "totalPages",
        TOUCH_EASING: "touch_easing",
        TRANSITION_STRATEGY: "transitionStrategy",
        WRAP_EASING: "wrap_easing"
    });
    "use strict";
    m.when("jQuery").register("a-carousel-utils", function(c) {
        function l(c) {
            return "string" === typeof c
        }

        function g(c) {
            return c && c.nodeType !== w
        }

        function d(c) {
            return "" === c ? "\x3cdiv\x3e\x3c/div\x3e" : c ? l(c) || g(c) ? c : d(c.content) : null
        }

        function f(c) {
            c && (l(c) || g(c) ? c = !0 : c.content = f(c.content));
            return c
        }
        return {
            addElementToDom: function(d, f) {
                f && (l(f) ? d.html(f) : g(f) && (c(f).hasClass("a-carousel-card-fragment") ? d.empty().append(c(f).contents()) : d.empty().append(f)), !0 !== f && d.removeClass("a-carousel-card-empty"))
            },
            clearElementFromItem: f,
            getElementFromItem: d,
            isElement: g,
            isString: l
        }
    });
    "use strict";
    m.register("a-carousel-circular-utils", function() {
        function c(c) {
            var d = 0 < c;
            return function(c, h, k) {
                var e = h.length;
                k = (k || 1) % e;
                c = c.get(0);
                for (var b, a = 0; a < k; a++) d ? (b = h.get(a), c.appendChild(b)) : (b = h.get(e - 1 - a), c.insertBefore(b, c.children[0]))
            }
        }

        function l(c) {
            var d = 0 < c;
            return function(c, h) {
                h = h ? h % c.length : 1;
                d ? c = c.concat(c.splice(0, h)) : c.unshift.apply(c, c.splice(c.length - h, h));
                return c
            }
        }
        return {
            rotateCW: c(1),
            rotateCCW: c(-1),
            rotateArrayCW: l(1),
            rotateArrayCCW: l(-1),
            firstCardIndexAfterRotate: function(c, d, f) {
                c = (d + c) % f;
                0 === c ? c = f : 0 > c && (c = f + c);
                return c
            },
            relativeIndexFromIndex: function(c, d, f) {
                var h = 1;
                if (0 < c && c <= f) return c > d ? h = c - d + 1 : c < d && (h = f - d + c + 1), h;
                m.error("idx should be between 1 and " + f, "a-carousel-circular-utils", "relativeIndexFromIndex")
            }
        }
    });
    "use strict";
    m.when("A", "jQuery").register("a-carousel-measure", function(c, l) {
        return function(g) {
            function d(d, f, e) {
                var b, a, x, q;
                f.jquery || (f = l(f));
                for (c.each(e, function(b) {
                        if ("top" === b || "left" === b) return a =
                            f.offset(), !1
                    }); void 0 !== (b = e.pop());) x = d[b], "left" === b || "top" === b ? d[b] = a[b] : -1 < b.indexOf("outer") ? d[b] = f[b](!0) : d[b] = f["outer" + b.charAt(0).toUpperCase() + b.substr(1)](), d[b] !== x && (void 0 === q && (q = {}), q[b] = x);
                return q
            }
            var f = {
                carousel: {
                    height: 0,
                    width: 0,
                    outerHeight: 0,
                    outerWidth: 0
                },
                viewport: {
                    height: 0,
                    width: 0,
                    outerHeight: 0,
                    outerWidth: 0
                },
                items: [],
                getFirstCardWidth: function() {
                    return void 0 === this.items[0] || !c.isFiniteNumber(this.items[0].width) || 0 >= this.items[0].width ? 160 : this.items[0].width
                }
            };
            g.measure =
                function(h) {
                    var k = this.dom.$carousel,
                        e = this.dom.$viewport,
                        b = {};
                    h && (h = h.split(" "));
                    if (!h || -1 < c.indexOfArray(h, "carousel")) b.carousel = d(f.carousel, k, "top left height width outerHeight outerWidth".split(" "));
                    if (!h || -1 < c.indexOfArray(h, "viewport")) b.viewport = d(f.viewport, e, ["height", "width", "outerHeight", "outerWidth"]);
                    if (!h || -1 < c.indexOfArray(h, "items")) f.items = [], b.items = {}, k.children("li").each(function(a, c) {
                        f.items[a] = {};
                        c = d(f.items[a], c, "top left height width outerHeight outerWidth".split(" "));
                        void 0 !== c && (b.items[a] = c)
                    });
                    return b
                };
            g.getItemOffset = function(c) {
                var d = f.items;
                c--;
                if (d && d.length) {
                    if (c < d.length) {
                        for (var e = 0, b = d[0].outerWidth, a = 0; a < c; a++) e += d[a] ? d[a].outerWidth : b;
                        0 < c && this.getAttr("first_item_flush_left") && (e += g.getAttr("currentGutter"));
                        return e
                    }
                } else return 0
            };
            g.getDimensions = function() {
                return c.copy(f)
            };
            g.updateDimensionsCache = function(d) {
                c.extend(f, d)
            };
            g.getViewportWidth = function() {
                try {
                    return f.viewport.width
                } catch (c) {}
            }
        }
    });
    "use strict";
    m.when("A", "jQuery").register("a-carousel-attributes",
        function(c, l) {
            return function(g, d) {
                var f = {},
                    h = {},
                    k = {};
                c.extend(f, d);
                g.onChange = function(e, b) {
                    e = e.split(" ");
                    for (var a = e.length, d; a--;) d = e[a], h[d] || (h[d] = []), l.isFunction(b) && -1 === c.indexOfArray(h[d], b) && h[d].push(b);
                    return this
                };
                g.unbind = function(e, b) {
                    h[e] && b && (b = c.indexOfArray(h[e], b), -1 < b && h[e].splice(b, 1));
                    return this
                };
                g.once = function(c, b) {
                    var a = function() {
                        b.apply(null, arguments);
                        g.unbind(c, a)
                    };
                    return g.onChange(c, a)
                };
                g.setAttr = function(e, b, a) {
                    var d = f[e];
                    f[e] = b;
                    if (!(a || k[e] || c.equals(b, d))) {
                        k[e] = !0;
                        b = c.copy(b);
                        d = c.copy(d);
                        if (h[e]) {
                            a = c.copy(h[e]);
                            for (var q = 0, n = a.length; q < n; q++) a[q](b, d, g, e)
                        }
                        b = {
                            newValue: b,
                            oldValue: d,
                            carousel: g
                        };
                        c.trigger("a:carousel:change:" + e, b);
                        f.name && c.trigger("a:carousel:" + f.name + ":change:" + e, b);
                        k[e] = !1
                    }
                    return this
                };
                g.getAttr = function(e) {
                    return c.copy(f[e])
                }
            }
        });
    "use strict";
    m.when("A", "jQuery", "a-carousel-measure", "a-carousel-attributes", "a-carousel-strategies", "a-carousel-constants", "a-analytics", "prv:a-capabilities", "prv:a-tnr").register("a-carousel-base", function(c,
        l, g, d, f, h, k, e, b) {
        function a(a) {
            var b = a.getAttr("set_size") <= a.getAttr("pageSize"),
                c = a.getAttr(h.NO_TRANSITION);
            1 === a.getAttr("totalPages") && 1 < a.getAttr("pageNumber") && a.gotoPage(1, {
                startover: !0,
                animationDuration: 0
            });
            a.dom.$container.find(".a-carousel-left, .a-carousel-right").css("visibility", b || c ? "hidden" : "visible")
        }

        function x(a, b) {
            return isNaN(a) ? (m.log("`set_size` should be an integer: " + a, "WARN", "aui:carousel:base"), b) : parseInt(a, 10)
        }

        function q(a) {
            a.onChange("pageSize", function(b, c) {
                var e = a.getAttr("firstVisibleItem"),
                    d = Math.ceil(e / b);
                1 === d && 1 < e ? d = 2 : 1 > d && (d = 1);
                a.setAttr("pageNumber", d);
                a.setAttr("totalPages", Math.ceil(a.getAttr("set_size") / b));
                e = a.getAttr("ajax");
                b > c && (e && e.prefetch_next_page ? a.strategies.ajax.wantNextPage(a) : a.strategies.ajax.wantCurrentPage(a))
            });
            a.onChange("set_size", function(b, c) {
                var e = a.getAttr("pageSize"),
                    d = a.getAttr("fetchedItems");
                a.setAttr("totalPages", Math.ceil(b / e));
                b < c ? (d.splice(b, Number.MAX_VALUE), a.setAttr("fetchedItems", d)) : a.strategies.ajax.wantCurrentPage && a.strategies.ajax.wantCurrentPage(a)
            });
            a.onChange("firstVisibleItem", function(b) {
                a.dom.$container.find("input.a-carousel-firstvisibleitem").val(b)
            });
            a.onChange("pageNumber", function(b) {
                0 < b && b <= a.getAttr("totalPages") && a.setAttr("currentlyWrapping", !1)
            })
        }

        function n(a, b, e) {
            if (0 !== arguments.length) {
                a.jquery || (a = l(a));
                this.dom = {
                    $container: a,
                    $viewport: a.hasClass("a-carousel-viewport") ? a : a.find(".a-carousel-viewport"),
                    $carousel: a.find(".a-carousel")
                };
                !a.length || this.dom.$viewport.length && this.dom.$carousel.length || k.logError("[AUI] CarouselContainer does not have CarouselContent.",
                    "ERROR", JSON.stringify({
                        xpath: c.xpath(a.get(0)),
                        cssSelector: c.cssSelector(a.get(0)),
                        custody: c.attributionChain(a.get(0))
                    }));
                var f = {
                    totalPages: 1E3,
                    pageNumber: 1,
                    pageSize: 0,
                    firstVisibleItem: 1,
                    maintain_state: !0,
                    px: 0,
                    auto_adjust_height: !0,
                    ajax: {}
                };
                c.extend(f, e);
                f.maintain_state = !!f.maintain_state;
                f.id_list ? f.set_size || (f.set_size = f.id_list.length) : f.id_list = [];
                var n = this.dom.$carousel.children("li");
                if (f.set_size) f.set_size = x(f.set_size, n.length);
                else {
                    var q = parseInt(n.first().attr("aria-setsize"), 10);
                    c.isFiniteNumber(q) && 0 < q ? f.set_size = q : f.set_size = n.length
                }
                var r = [];
                this.dom.$carousel.children("li").each(function(a, b) {
                    r.push(c.trim(b.innerHTML))
                });
                f.fetchedItems = r;
                g(this);
                d(this, f);
                this.strategies = b;
                return this
            }
        }
        c.each(f, function(a, b) {
            n.prototype["set" + b.charAt(0).toUpperCase() + b.slice(1) + "Strategy"] = function(a) {
                this.strategies[name] = a;
                "function" === typeof a.init && a.init(this)
            }
        });
        f = n.prototype;
        f.gotoNextPage = function(a) {
            this.getAttr("transitionPaused") || (this.strategies.transition.gotoNextPage(this,
                a), a && a.accessibleSafe && this.strategies.accessibility.nextPage(this, a.animationDuration, a.animationSpeed))
        };
        f.gotoPrevPage = function(a) {
            this.getAttr("transitionPaused") || (this.strategies.transition.gotoPrevPage(this, a), a && a.accessibleSafe && this.strategies.accessibility.prevPage(this, a.animationDuration, a.animationSpeed))
        };
        f.gotoPage = function(a, b) {
            this.getAttr("transitionPaused") || (this.strategies.transition.gotoPage(this, a, b), b && b.accessibleSafe && this.strategies.accessibility.gotoPage(this, b.animationDuration,
                b.animationSpeed))
        };
        f.gotoIndex = function(a, b) {
            (!this.getAttr("transitionPaused") || b && b.ignorePause) && this.strategies.transition.gotoIndex(this, a, b)
        };
        f.gotoPixel = function(a, b) {
            this.getAttr("transitionPaused") || this.strategies.transition.gotoPixel(this, a, b)
        };
        f.resize = function() {
            if (this.dom.$container.is(":visible")) {
                var a = this.measure("carousel viewport");
                this.strategies.display.resize(this, a)
            }
        };
        f.pause = function() {
            this.setAttr("transitionPaused", !0)
        };
        f.resume = function() {
            this.setAttr("transitionPaused", !1)
        };
        f.triggerEvent = function(a, b) {
            b = b || {};
            b.carousel = this;
            c.trigger("a:carousel:" + a, b);
            var e = this.getAttr("name");
            e && c.trigger("a:carousel:" + e + ":" + a, b)
        };
        f.getStaticLoader = function() {
            return this.getAttr(h.STATIC_LOADER_CSS_CLASS) ? '\x3cdiv class\x3d"' + this.getAttr(h.STATIC_LOADER_CSS_CLASS) + '"\x3e\x3c/div\x3e' : ""
        };
        f.getEmptyCard = function(a, b) {
            var c = "a-carousel-card a-carousel-card-empty";
            this.getAttr(h.ELEMENT_CSS_CLASS) && (c = c + " " + this.getAttr(h.ELEMENT_CSS_CLASS));
            return ['\x3cli class\x3d"', c, '" role\x3d"listitem" aria-setsize\x3d"',
                b, '" aria-posinset\x3d"', a, '"\x3e', this.getStaticLoader(), "\x3c/li\x3e"
            ].join("")
        };
        f.initTouchHandling = function() {
            var a = this,
                b = a.dom.$viewport;
            if (b.length && ((c.capabilities.touch || c.capabilities.pointerPrefix) && m.when("a-touch").execute(function(e) {
                    b.addClass("a-gesture a-gesture-horizontal").bind("pan-horizontal swipe-horizontal", function() {
                        return !1
                    });
                    c.on("a:swipe-horizontal:" + b[0].id, function(b) {
                        if (!a.getAttr("transitionPaused") && a.strategies.transition.onSwipe) a.strategies.transition.onSwipe(a,
                            b)
                    });
                    if (!a.getAttr("disable_panning")) c.on("a:pan-horizontal:" + b[0].id, function(b) {
                        if (!a.getAttr("transitionPaused") && a.strategies.transition.onPan) a.strategies.transition.onPan(a, b)
                    })
                }), e.isIE10 || e.isIE11Plus)) {
                var d = function(a) {
                    a.stopPropagation();
                    a.preventDefault();
                    document.body.removeEventListener("click", d, !0)
                };
                b.bind(c.action.start, function(a) {
                    b.bind("swipe-horizontal.a-ssiec pan-horizontal.a-ssiec", function(a) {
                        b.unbind(".a-ssiec");
                        b.bind(c.action.end + ".a-ssiec", function(a) {
                            b.unbind(".a-ssiec");
                            document.body && document.body.addEventListener("click", d, !0)
                        })
                    })
                });
                "touchstart" === c.action.start && m.when("a-event-analytics").execute(function(a) {
                    a.notifyJquery(b, c.action.start)
                })
            }
        };
        f.init = function() {
            var e = this,
                d = e.strategies,
                f = e.dom.$viewport[0];
            f && !f.id && (f.id = "anonCarousel" + e.__id);
            e.dom.$carousel.contents().not(function() {
                return this.tagName && "li" === this.tagName.toLowerCase()
            }).remove();
            c.each(e.strategies, function(a) {
                a.initAttrs && c.each(a.initAttrs, function(a, b) {
                    var c = a;
                    "function" === typeof a &&
                        (c = a(e.getAttr(b)));
                    e.setAttr(b, c)
                })
            });
            if (1 > e.getAttr("set_size")) return d.ajax.init(e), !1;
            e.measure();
            c.each(e.strategies, function(a) {
                a.init(e)
            });
            d = e.getAttr("pageSize");
            f = e.getAttr("set_size");
            e.setAttr("totalPages", Math.ceil(f / d));
            q(e);
            e.setAttr("isInTab", 0 < e.dom.$container.closest(".a-tab-content").length, !0);
            e.triggerEvent("init");
            c.each(e.strategies, function(a) {
                a.afterInit && a.afterInit(e)
            });
            e.triggerEvent("afterInit");
            d = e.getAttr("firstVisibleItem");
            1 === d && e.getAttr("maintain_state") && (d = parseInt(e.dom.$container.find("input.a-carousel-firstvisibleitem").val(),
                10), c.isFiniteNumber(d) && 0 < d && d <= f || (d = 1));
            if (1 < d) {
                for (var f = 700, x = Math.ceil(d / e.getAttr("pageSize")), n = 2; n < x; n++) f += 700 / n;
                e.gotoIndex(d, {
                    animationDuration: f,
                    easingFunction: "ease"
                })
            }
            a(this);
            e.onChange("pageSize set_size", function() {
                a(e)
            });
            d = e.dom.$container.find(".a-carousel-button");
            d.length && (f = d.eq(0).position().top + "px", d.css("top", f));
            var k = !1,
                r = function(a) {
                    a.preventDefault();
                    a = {
                        startover: !0,
                        accessibleSafe: "keydown" === a.type ? !0 : !1
                    };
                    5 < e.getAttr("pageNumber") ? a.animationDuration = 1250 : a.animationSpeed =
                        5 * e.getDimensions().viewport.width;
                    e.gotoPage(1, a)
                };
            e.dom.$container.delegate(".a-carousel-goto-nextpage", "click dblclick", function(a) {
                k || (k = !0, a.preventDefault(), e.gotoNextPage(), c.delay(function() {
                    k = !1
                }, 5));
                b.ackDelegated(a)
            }).delegate(".a-carousel-goto-prevpage", "click dblclick", function(a) {
                k || (k = !0, a.preventDefault(), e.gotoPrevPage(), c.delay(function() {
                    k = !1
                }, 5));
                b.ackDelegated(a)
            }).delegate(".a-carousel-goto-nextpage", "keydown", function(a) {
                if (a.which === c.constants.keycodes.ENTER || a.which === c.constants.keycodes.SPACE) a.preventDefault(),
                    e.gotoNextPage({
                        accessibleSafe: !0
                    });
                b.ackDelegated(a)
            }).delegate(".a-carousel-goto-prevpage", "keydown", function(a) {
                if (a.which === c.constants.keycodes.ENTER || a.which === c.constants.keycodes.SPACE) a.preventDefault(), e.gotoPrevPage({
                    accessibleSafe: !0
                });
                b.ackDelegated(a)
            }).delegate(".a-carousel-restart", "keydown", function(a) {
                a.which !== c.constants.keycodes.ENTER && a.which !== c.constants.keycodes.SPACE || r(a);
                b.ackDelegated(a)
            }).delegate(".a-carousel-restart", "click", function(a) {
                r(a);
                b.ackDelegated(a)
            });
            m.when("a-event-analytics").execute(function(a) {
                a.notifyJquery(e.dom.$container.find(".a-carousel-goto-nextpage"),
                    "click dblclick keydown");
                a.notifyJquery(e.dom.$container.find(".a-carousel-goto-prevpage"), "click dblclick keydown");
                a.notifyJquery(e.dom.$container.find(".a-carousel-goto-restart"), "keydown click")
            });
            e.dom.$container.find(".a-carousel-page-max").html(this.getAttr("totalPages"));
            return !0
        };
        return n
    });
    "use strict";
    m.when("A", "jQuery", "a-carousel-base", "a-carousel-constants").register("a-carousel-mobile", function(c, l, g, d) {
        function f(e) {
            var b = e.getAttr("loaderHeight");
            b || ((b = e.getAttr("maxHeight")) ?
                (b = Math.min(.9 * b, 90), b = Math.max(b, 120)) : b = 90, e.setAttr("loaderHeight", b));
            return b
        }

        function h(e, b, a) {
            g.call(this, e, b, a);
            if (0 !== arguments.length) return this.getAttr("circular") === k && this.setAttr("circular", !1), this.getAttr("show_partial_next") === k && this.setAttr("show_partial_next", !0), this.getAttr("hide_off_screen") === k && this.setAttr("hide_off_screen", !1), this.getAttr("springiness") === k && this.setAttr("springiness", .8), this.getAttr("touch_easing") === k && this.setAttr("touch_easing", "cubic-bezier(0.215, 0.610, 0.355, 1.000)"),
                this.init = function() {
                    return g.prototype.init.call(this) ? (this.getAttr(d.STATIC_LOADER_CSS_CLASS) || this.dom.$carousel.children("li").children(".a-loading-static").css("height", f(this) + "px"), this.getAttr(d.NO_TRANSITION) || this.initTouchHandling(), !0) : !1
                }, this
        }
        var k;
        h.prototype = new g;
        h.prototype.constructor = h;
        h.prototype.getStaticLoader = function() {
            return this.getAttr(d.STATIC_LOADER_CSS_CLASS) ? '\x3cdiv class\x3d"' + this.getAttr(d.STATIC_LOADER_CSS_CLASS) + '"\x3e\x3c/div\x3e' : '\x3cdiv class\x3d"a-loading-static" style\x3d"height:' +
                f(this) + 'px"\x3e\x3cdiv class\x3d"a-loading-static-inner"\x3e\x3c/div\x3e\x3c/div\x3e'
        };
        return h
    });
    "use strict";
    m.when("A", "jQuery", "a-carousel-base", "a-carousel-constants").register("a-carousel-desktop", function(c, l, g, d) {
        function f(e) {
            var b = e.getAttr("set_size") <= e.getAttr("pageSize"),
                a = e.getAttr(d.NO_TRANSITION);
            e.dom.$container.find(".a-carousel-pagination").css("visibility", b || a ? "hidden" : "visible")
        }

        function h(e, b, a) {
            g.call(this, e, b, a);
            if (0 !== arguments.length) {
                var c = this;
                c.getAttr("circular") ===
                    k && this.setAttr("circular", !0);
                c.getAttr("hide_off_screen") === k && this.setAttr("hide_off_screen", !0);
                c.onChange("totalPages", function(a) {
                    c.dom.$container.find(".a-carousel-page-max").html(a);
                    a < c.getAttr("pageNumber") && c.gotoPage(a)
                });
                c.onChange("pageNumber", function(a, b) {
                    b = c.dom.$container;
                    var e = b.find(".a-carousel-restart-container");
                    1 < a ? e.show() : e.hide();
                    b.find(".a-carousel-page-current").html(a)
                });
                c.init = function() {
                    var a = this;
                    return g.prototype.init.call(a) ? (f(this), a.onChange("pageSize set_size",
                        function() {
                            f(a)
                        }), 2 > a.getAttr("pageNumber") && a.dom.$container.find(".a-carousel-restart-container").hide(), a.getAttr(d.NO_TRANSITION) || a.initTouchHandling(), !0) : !1
                };
                return c
            }
        }
        var k;
        h.prototype = new g;
        return h.prototype.constructor = h
    });
    "use strict";
    m.when("A", "a-carousel-desktop", "a-carousel-mobile").register("a-carousel-classes", function(c, l, g) {
        return {
            desktop: l,
            mobile: g,
            "default": c.capabilities.mobile || c.capabilities.tablet ? "mobile" : "desktop"
        }
    });
    "use strict";
    m.when("A", "jQuery", "p-detect", "a-carousel-constants").register("a-carousel-stretchygoodness",
        function(c, l, g, d) {
            function f(a, b, e, d) {
                a.getAttr("show_partial_next") && (b -= e / 10);
                var f = a.getAttr("minimum_gutter_width");
                a.getAttr("set_size");
                a = 0;
                for (var k = !0; 0 < b;) a++, b = d && k ? b - e : b - (e + f), k = !1;
                0 > b && a--;
                return c.isFiniteNumber(a) && 0 < a ? a : 1
            }

            function h(a, b, e, d, f, k, h) {
                "stretch" === a.getAttr("single_page_align") && d > k && (d = k);
                b -= e * d;
                a.getAttr("show_partial_next") ? (a = b - f * (d + 1), h && (a += f), h = a / e, b -= e * (.5 < h ? .5 : h)) : h && (b += f);
                e = Math.ceil(b / (d + 1));
                if (!c.isFiniteNumber(e) || e < f) e = f;
                return e
            }

            function k(a) {
                if (a.getAttr("auto_adjust_height"))
                    if (a.getAttr("animating")) a.once("animating",
                        function() {
                            k(a)
                        });
                    else {
                        var b = a.getAttr("maxHeight"),
                            e = a.getDimensions();
                        b && c.isFiniteNumber(b) || (b = 1);
                        var d = b,
                            f = a.getAttr("pageSize"),
                            h = f * (a.getAttr("pageNumber") - 1),
                            f = h + f - 1,
                            e = e.items,
                            g = e.length,
                            l;
                        for (a.getAttr("show_partial_next") && f++; h <= f && h < g; h++)(l = e[h]) && l.outerHeight > d && (d = e[h].outerHeight || e[h].height);
                        d > b && (a.updateDimensionsCache({
                            viewport: {
                                height: d,
                                outerHeight: d
                            }
                        }), a.setAttr("maxHeight", d), 1 === b ? a.dom.$viewport.height(d) : c.animate(a.dom.$viewport, {
                                height: d
                            }, a.getAttr("height_animation_speed"),
                            "linear"))
                    }
                else a.dom.$viewport.css("height", "")
            }

            function e(a) {
                a.onChange("pageNumber", function() {
                    a.getAttr("hide_off_screen") && a.dom.$carousel.children("li").css("visibility", "")
                });
                a.onChange("pageSize", function(b, e) {
                    b > e && k(a)
                });
                a.onChange("loading", function(b) {
                    b || k(a)
                });
                a.onChange("firstVisibleItem", function() {
                    k(a)
                });
                a.onChange("animating", function(b) {
                    if (!b && a.getAttr("hide_off_screen")) {
                        var e = a.getAttr("firstVisibleItem") - 1,
                            c = e + a.getAttr("pageSize") - 1;
                        a.getAttr("show_partial_next") && c++;
                        a.dom.$carousel.children("li").each(function(a,
                            b) {
                            a = a >= e && a <= c;
                            l(b).css("visibility", a ? "" : "hidden")
                        })
                    }
                });
                a.onChange("single_page_align minimum_gutter_width", function() {
                    b(a)
                });
                a.onChange("minimum_gutter_width", function() {
                    b(a)
                })
            }

            function b(a) {
                var b = a.getDimensions(),
                    e = b.viewport.width,
                    b = b.getFirstCardWidth(),
                    d = a.getAttr("minimum_gutter_width"),
                    k = a.getAttr("set_size"),
                    g = a.getAttr("first_item_flush_left"),
                    l = f(a, e, b, g),
                    p = h(a, e, b, l, d, k, g);
                a.setAttr("currentGutter", p);
                a.setAttr("pageSize", l);
                var m = a.dom.$carousel,
                    u = m.children("li"),
                    d = u.length,
                    r = a.getAttr("totalPages"),
                    B = a.getAttr("pageNumber"),
                    z = a.getAttr("firstVisibleItem"),
                    G = (B - 1) * l + 1;
                B > r ? (z = (r - 1) * l + 1, a.setAttr("pageNumber", r), a.setAttr("firstVisibleItem", z)) : z !== G && (r = Math.ceil(z / l), z = (r - 1) * l + 1, a.setAttr("pageNumber", r), a.setAttr("firstVisibleItem", z));
                var A = z - 1,
                    E = A + l - 1;
                a.getAttr("show_partial_next") && E++;
                var H = a.getAttr("hide_off_screen"),
                    I = p + "px",
                    J = b + "px",
                    F;
                u.each(function(a, b) {
                    F = !H || a >= A && a <= E;
                    b.style[c.capabilities.rtl ? "marginRight" : "marginLeft"] = g && 0 === a ? 0 : I;
                    b.style.visibility = F ? "" : "hidden";
                    b.style.width =
                        J
                });
                var w;
                a.getAttr("first_item_flush_left") ? (p = u.first().outerWidth(!0), 1 < u.length && (w = u.eq(1).outerWidth(!0)), r = (d - 1) * w + p) : (p = w = u.first().outerWidth(!0), r = d * w);
                l >= k ? (r = e, B = a.getAttr("single_page_align"), m.toggleClass("a-text-right", "right" === B), m.toggleClass("a-text-center", "center" === B), "center" === B && u.first().css("margin-left", 0)) : m.removeClass("a-text-right a-text-center");
                r = l >= k ? e : r;
                m.css("width", r + "px");
                e = {
                    carousel: {
                        width: r,
                        outerWidth: m.outerWidth()
                    },
                    items: []
                };
                for (k = 0; k < d; k++) e.items.push({
                    width: b,
                    outerWidth: 0 === k ? p : w
                });
                a.updateDimensionsCache(e);
                a.gotoIndex(z, {
                    animationDuration: 0,
                    ignorePause: !0
                });
                a.triggerEvent("repaint")
            }
            return {
                repaint: b,
                init: function(a) {
                    var f = a.getAttr("minimum_gutter_width");
                    c.isFiniteNumber(f) || (f = 15, a.setAttr("minimum_gutter_width", f));
                    a.setAttr("currentGutter", f);
                    f = a.getAttr("height_animation_speed");
                    c.isFiniteNumber(f) || a.setAttr("height_animation_speed", 200);
                    a.setAttr("first_item_flush_left", !!a.getAttr("first_item_flush_left"));
                    a.setAttr("show_partial_next", !!a.getAttr("show_partial_next"));
                    b(a);
                    a.getAttr(d.NO_TRANSITION) || k(a);
                    f = a.getDimensions();
                    a.dom.$container.find(".a-carousel-left, .a-carousel-right, .a-carousel-viewport").css("height", Math.max(f.viewport.height, f.items[0] ? f.items[0].height : 0) + "px");
                    f = a.getAttr("firstVisibleItem");
                    1 < f && (a.setAttr("firstVisibleItem", f), f = Math.ceil(f / a.getAttr("pageSize")), a.gotoPage(f));
                    e(a)
                },
                resize: function(a, e) {
                    e.viewport && void 0 !== e.viewport.width && b(a)
                }
            }
        });
    "use strict";
    m.when("A", "jQuery", "p-detect", "a-carousel-utils").register("a-carousel-display-swap",
        function(c, l, g, d) {
            function f(e) {
                if (e.getAttr("auto_adjust_height")) {
                    var b = e.getAttr("maxHeight");
                    b && c.isFiniteNumber(b) || (b = 1);
                    var a = b;
                    e.dom.$carousel.children("li").not(".a-carousel-card-empty").each(function(b, e) {
                        b = l(e).outerHeight();
                        a = Math.max(b, a)
                    });
                    a > b && (e.setAttr("maxHeight", a), g.capabilities.transition ? 1 === b ? e.dom.$viewport.height(a) : c.animate(e.dom.$viewport, {
                        height: a
                    }, e.getAttr("height_animation_speed"), "linear") : e.dom.$viewport.height(a), e.updateDimensionsCache({
                        viewport: {
                            height: a,
                            outerHeight: a
                        }
                    }))
                } else e.dom.$viewport.css("height",
                    "")
            }

            function h(e) {
                e.onChange("animating", function(b) {
                    b || f(e)
                });
                e.onChange("loading", function(b) {
                    b || f(e)
                });
                e.onChange("pageSize", function(b, a) {
                    e.dom.$carousel.children("li").slice(b).remove();
                    if (b > a) {
                        a = e.getAttr("set_size");
                        var c = e.getDimensions().getFirstCardWidth(),
                            k = e.getAttr("currentGutter"),
                            n = e.getAttr("fetchedItems"),
                            h = e.getAttr("firstVisibleItem") - 1,
                            g = e.dom.$carousel.children("li"),
                            t = document.createDocumentFragment(),
                            p;
                        if (l.isArray(n)) {
                            for (var m = g.length; m < b; m++) p = m + h, g = l(['\x3cli class\x3d"a-carousel-card a-carousel-card-empty" role\x3d"listitem" aria-setsize\x3d"',
                                a, '" aria-posinset\x3d"', p + 1, '" style\x3d"width:', c, "px; margin-left:", k, 'px;"\x3e', e.getStaticLoader()
                            ].join("")), n[p] && d.addElementToDom(g, d.getElementFromItem(n[p])), p >= a && g.removeClass("a-carousel-card-empty"), t.appendChild(g[0]);
                            e.dom.$carousel.append(t)
                        }
                        f(e)
                    }
                });
                e.onChange("set_size", function(b, a) {
                    var d = e.getAttr("pageNumber"),
                        f = e.getAttr("totalPages"),
                        n = e.dom.$carousel.children("li");
                    d === f && b > a && (n.length && e.dom.$carousel.children("li").each(function(a, b) {
                        c.trim(b.innerHTML) || (b.className +=
                            " a-carousel-card-empty", b.innerHTML = e.getStaticLoader())
                    }), 0 === a && k(e))
                });
                e.onChange("single_page_align minimum_gutter_width", function() {
                    k(e)
                });
                e.onChange("minimum_gutter_width", function() {
                    k(e)
                })
            }

            function k(e) {
                var b = e.getDimensions(),
                    a = b.viewport.width,
                    d = b.getFirstCardWidth(),
                    f = e.getAttr("minimum_gutter_width"),
                    b = e.getAttr("set_size"),
                    k;
                k = e.getAttr("minimum_gutter_width");
                e.getAttr("set_size");
                k = Math.max(Math.floor(a / (d + k)), 1);
                k = c.isFiniteNumber(k) ? k : 1;
                var h, g = k;
                "stretch" === e.getAttr("single_page_align") &&
                    g > b && (g = b);
                g = Math.ceil((a - d * g) / (g + 1));
                c.isFiniteNumber(g) || (g = f);
                h = g;
                e.setAttr("currentGutter", h);
                e.setAttr("pageSize", k);
                var g = e.dom.$carousel,
                    l = g.children("li"),
                    f = l.length,
                    d = d + h,
                    p = f * d,
                    m = Math.min(k, b);
                e.dom.$carousel.children("li").slice(m).remove();
                l.css("margin-left", h + "px");
                k >= b ? (p = a, a = e.getAttr("single_page_align"), g.toggleClass("a-text-right", "right" === a), g.toggleClass("a-text-center", "center" === a), "center" === a && l.first().css("margin-left", 0)) : g.removeClass("a-text-right a-text-center");
                for (a = {
                        carousel: {
                            width: p,
                            outerWidth: g.outerWidth()
                        },
                        items: []
                    }; f--;) a.items.push({
                    outerWidth: d
                });
                e.updateDimensionsCache(a);
                e.triggerEvent("repaint")
            }
            return {
                repaint: k,
                init: function(e) {
                    var b = e.getAttr("minimum_gutter_width");
                    b || (b = 15, e.setAttr("minimum_gutter_width", b));
                    e.setAttr("currentGutter", b);
                    b = e.getAttr("height_animation_speed");
                    c.isFiniteNumber(b) || e.setAttr("height_animation_speed", 200);
                    h(e);
                    k(e);
                    b = e.getDimensions();
                    e.dom.$container.find(".a-carousel-left, .a-carousel-right, .a-carousel-viewport").css("height",
                        Math.max(b.viewport.height, b.items[0] ? b.items[0].height : 0) + "px");
                    b = e.getAttr("firstVisibleItem");
                    1 < b && (e.setAttr("firstVisibleItem", b), b = Math.ceil(b / e.getAttr("pageSize")), e.gotoPage(b))
                },
                resize: function(e, b) {
                    b.viewport && void 0 !== b.viewport.width && k(e)
                }
            }
        });
    "use strict";
    m.when("A", "jQuery").register("a-carousel-display-single", function(c, l) {
        function g(d) {
            if (d.getAttr("auto_adjust_height"))
                if (d.getAttr("animating")) d.once("animating", function() {
                    g(d)
                });
                else d.dom.$viewport.css("height", "auto"), c.delay(function() {
                        d.dom.$viewport.height(d.dom.$viewport.height())
                    },
                    0);
            else d.dom.$viewport.css("height", "")
        }

        function d(d, e) {
            var b = d.dom.$carousel.children("li"),
                a = d.getAttr("firstVisibleItem") - 1;
            d = d.getAttr("show_partial_next") ? 2 : 1;
            a = b.slice(a, a + d);
            b.not(a).css("visibility", "hidden");
            e && a.css("visibility", "")
        }

        function f(c) {
            c.getAttr("fixed_height") || (c.dom.$viewport.delegate("img", "load", function() {
                    g(c)
                }), c.onChange("loading", function(e) {
                    e || g(c)
                }), c.onChange("pageNumber", function() {
                    c.getAttr("hide_off_screen") && c.dom.$carousel.children("li").css("visibility", "")
                }),
                c.onChange("animating", function(e) {
                    !e && c.getAttr("hide_off_screen") && d(c)
                }), c.onChange("minimum_gutter_width", function() {
                    h(c)
                }))
        }

        function h(c) {
            var e = c.getDimensions(),
                b = e.viewport.width,
                a = c.getAttr("show_partial_next"),
                f = c.getAttr("minimum_gutter_width"),
                g = c.getAttr("set_size"),
                h = c.dom.$carousel.children("li"),
                b = b - 2 * f;
            a && (b -= f + e.viewport.width / 3);
            h.css({
                width: b + "px",
                margin: "0 " + f + "px"
            });
            e = b + 2 * f;
            a = e * g;
            c.dom.$carousel.width(a);
            for (a = {
                    carousel: {
                        width: a
                    },
                    items: []
                }; g--;) a.items[g] = {
                width: b,
                outerWidth: e
            };
            c.updateDimensionsCache(a);
            c.getAttr("hide_off_screen") && d(c, !0);
            c.gotoIndex(c.getAttr("firstVisibleItem"), {
                animationDuration: 0,
                ignorePause: !0
            });
            c.triggerEvent("repaint")
        }
        return {
            repaint: h,
            init: function(d) {
                var e = d.getAttr("minimum_gutter_width");
                d.setAttr("minimum_gutter_width", c.isFiniteNumber(e) ? e : 14);
                d.setAttr("show_partial_next", !!d.getAttr("show_partial_next"));
                d.setAttr("pageSize", 1);
                d.setAttr("pageSize", 1);
                e = d.getAttr("fixed_height");
                c.isFiniteNumber(e) ? d.dom.$viewport.height(e) : d.setAttr("fixed_height", !1);
                d.dom.$carousel.children("li").css("visibility", "visible");
                f(d);
                this.repaint(d);
                g(d)
            },
            resize: function(c, e) {
                e.viewport && void 0 !== e.viewport.width && (this.repaint(c), c.getAttr("fixed_height") || g(c))
            }
        }
    });
    "use strict";
    m.when("A", "jQuery", "a-carousel-constants").register("a-carousel-display-peekcircular", function(c, l, g) {
        function d(d) {
            return function(g) {
                return c.isFiniteNumber(g) ? g : d
            }
        }
        l = {};
        l[g.PAGE_SIZE] = 1;
        l[g.MIN_GUTTER] = d(14);
        l[g.PEEK_PERCENTAGE] = d(10);
        return {
            initAttrs: l,
            init: function(c) {
                var d = this;
                c.onChange(g.PEEK_PERCENTAGE, function(g, e) {
                    d.repaint(c)
                });
                c.dom.$carousel.children("li").css("visibility", "visible");
                d.repaint(c)
            },
            repaint: function(d) {
                var h = d.getAttr(g.MIN_GUTTER),
                    k = d.getAttr(g.SET_SIZE),
                    e = d.getAttr(g.PEEK_PERCENTAGE),
                    b = d.getDimensions().viewport.width,
                    a = d.dom.$carousel,
                    x = a.children("li"),
                    e = e / 100 * b,
                    q = b - 2 * e - h,
                    n = q + 2 * h,
                    b = n * k;
                a.width(b);
                x.css({
                    width: q + "px",
                    "margin-left": h + "px",
                    "margin-right": h + "px"
                });
                d.updateDimensionsCache({
                    carousel: {
                        width: b
                    },
                    items: c.map(c.range(k), function() {
                        return {
                            width: q,
                            outerWidth: n
                        }
                    })
                });
                d.setAttr(g.PEEK_WIDTH, e, !1);
                d.triggerEvent("repaint")
            },
            resize: function(d, c) {
                c.viewport && c.viewport.width !== w && this.repaint(d)
            }
        }
    });
    "use strict";
    m.when("A").register("a-carousel-display-variablewidth", function(c) {
        return {
            init: c.constants.NOOP,
            resize: c.constants.NOOP,
            repaint: c.constants.NOOP
        }
    });
    "use strict";
    m.when("a-carousel-stretchygoodness", "a-carousel-display-swap", "a-carousel-display-single", "a-carousel-display-peekcircular", "a-carousel-display-variablewidth").register("a-carousel-strategies-display",
        function(c, l, g, d, f) {
            return {
                swap: l,
                single: g,
                peekCircular: d,
                stretchyGoodness: c,
                variableWidth: f,
                "default": "stretchyGoodness"
            }
        });
    "use strict";
    m.when("A", "jQuery", "a-carousel-utils").register("a-carousel-transition-swap", function(c, l, g) {
        function d(d, b) {
            var a = d.getAttr("preloadedImages");
            a || (a = []);
            for (var f = [], h = b.length - 1; 0 <= h; h--)
                if (b[h] && !a[h]) {
                    var n = g.getElementFromItem(b[h]);
                    n && l("img", n).each(function() {
                        f.push(this.src)
                    });
                    a[h] = !0
                }
            c.preload(f);
            d.setAttr("preloadedImages", a)
        }

        function f(d) {
            return "number" ===
                typeof d ? d ? 0 > d ? -1 : 1 : isNaN(d) ? NaN : 0 : NaN
        }

        function h(d, b) {
            d.getAttr("pageNumber");
            d.getAttr("pageSize");
            var a = d.getAttr("firstVisibleItem"),
                f = d.getAttr("delay_time"),
                h = d.dom.$carousel.children("li"),
                n = h.filter(".a-carousel-card-empty");
            n.length && d.setAttr("loading", !0);
            n.each(function(k, v) {
                var t = l(v);
                v = h.index(v) + a - 1;
                var p = b[v];
                p && c.delay(function() {
                    g.addElementToDom(t, g.getElementFromItem(p));
                    k === n.length - 1 && d.setAttr("loading", !1)
                }, 0 + f)
            })
        }

        function k(d, b, a) {
            a = a || {};
            var h = d.getAttr("pageNumber");
            if (b !==
                h) {
                var k = d.getAttr("set_size"),
                    n = d.getAttr("totalPages"),
                    l = d.getAttr("circular"),
                    v = d.getAttr("pageSize"),
                    t = a.delayTime || d.getAttr("delay_time"),
                    p = f(a.direction) || NaN;
                !l && 1 > b ? b = 1 : !l && b > n ? b = n : l && 1 > b ? b = n : l && b > n && (b = 1);
                p || (p = h < b ? 1 : -1);
                a.startover && (p = t = 1);
                var m = v * (b - 1),
                    u = 1 === p ? 0 : v - 1;
                d.setAttr("pageNumber", b);
                d.setAttr("firstVisibleItem", m + 1);
                d.setAttr("animating", !0);
                var r = c.interval(function() {
                    var a = m + u;
                    if (r !== d.getAttr("responsiveTimerId")) clearInterval(r);
                    else if (-1 === p && 0 > u || 1 === p && u >= v) d.setAttr("responsiveTimerId",
                        w), d.setAttr("animating", !1);
                    else {
                        var b = d.dom.$carousel.children("li").eq(u),
                            c = d.getAttr("fetchedItems")[a];
                        c ? g.addElementToDom(b, g.getElementFromItem(c)) : a < k ? b.html(d.getStaticLoader()).addClass("a-carousel-card-empty") : b.empty().removeClass("a-carousel-card-empty");
                        u += p
                    }
                }, t);
                d.setAttr("responsiveTimerId", r)
            }
        }
        return {
            init: function(e) {
                var b = e.getAttr("delay_time");
                c.isFiniteNumber(b) || e.setAttr("delay_time", 30);
                e.onChange("responsiveTimerId", function(a, b) {
                    b !== a && clearInterval(b)
                });
                e.onChange("fetchedItems",
                    function(a, b) {
                        h(e, a);
                        d(e, a)
                    });
                d(e, e.getAttr("fetchedItems"))
            },
            gotoIndex: function(d, b, a) {
                a = a || {};
                var c = d.getAttr("pageSize");
                k(d, Math.ceil(b / c), a)
            },
            gotoNextPage: function(d, b) {
                b = b || {};
                var a = d.getAttr("pageNumber");
                b.direction = -1;
                k(d, ++a, b)
            },
            gotoPrevPage: function(d, b) {
                b = b || {};
                var a = d.getAttr("pageNumber");
                b.direction = 1;
                k(d, --a, b)
            },
            gotoPage: k
        }
    });
    "use strict";
    m.when("A", "jQuery", "a-carousel-utils", "a-carousel-constants").register("a-carousel-transition-slide", function(c, l, g, d) {
        function f(b) {
            var a = b.dom.$carousel.children("li").length,
                c = a + 1,
                e = b.getAttr(d.SET_SIZE),
                f = e - a;
            if (0 < f) {
                for (var f = c + f - 1, h = []; c <= f; c++) h.push(b.getEmptyCard(c, e));
                b.dom.$carousel.append(h.join(""));
                b.setAttr(d.LOADING, !0);
                for (var f = b.getAttr(d.FETCHED_ITEMS), h = b.dom.$carousel.children("li"), k, c = a; c < e; c++)
                    if (k = f[c]) {
                        var l = g.getElementFromItem(k),
                            a = h.eq(c);
                        g.addElementToDom(a, l);
                        f[c] = g.clearElementFromItem(k)
                    }
                b.strategies.display.repaint && b.strategies.display.repaint(b);
                b.setAttr(d.FETCHED_ITEMS, f, !0);
                b.setAttr(d.LOADING, !1)
            }
        }

        function h(b, a, e) {
            if (b.getAttr(d.ANIMATING)) b.once(d.ANIMATING,
                function() {
                    h(b, a, e)
                });
            else {
                var f = b.getDimensions().items;
                if (!e || a.length >= e.length) {
                    b.setAttr(d.LOADING, !0);
                    for (var n = b.dom.$carousel.children("li"), k = a.length, l, m; k--;)
                        if ((m = a[k]) && !c.equals(m, e[k]) && !0 !== m && !0 !== m.content) {
                            var p = g.getElementFromItem(m);
                            l = n.eq(k);
                            l.length && (g.addElementToDom(l, p), f[k] = {
                                width: l.outerWidth(),
                                outerWidth: l.outerWidth(!0),
                                height: l.outerHeight(),
                                outerHeight: l.outerHeight(!0)
                            }, a[k] = g.clearElementFromItem(m))
                        }
                }
                b.setAttr(d.FETCHED_ITEMS, a);
                b.updateDimensionsCache({
                    items: f
                });
                b.setAttr(d.LOADING, !1)
            }
        }
        var k = c.capabilities.touch ? 2E3 : 3E3,
            e = c.capabilities.rtl ? -1 : 1;
        return {
            wrapToFirst: function(b) {
                var a = b.getAttr(d.PAGE_SIZE),
                    c = b.getDimensions().getFirstCardWidth(),
                    e = this;
                b.gotoPixel(a * c * -1, {
                    animationDuration: 0,
                    callback: function() {
                        b.setAttr(d.CURRENTLY_WRAPPING, !1);
                        e.gotoPage(b, 1)
                    }
                })
            },
            wrapToLast: function(b) {
                b.getAttr(d.PAGE_SIZE);
                var a = b.getAttr(d.TOTAL_PAGES),
                    c = this,
                    e = b.getDimensions().carousel.width;
                b.gotoPixel(e, {
                    animationDuration: 0,
                    callback: function() {
                        b.setAttr(d.CURRENTLY_WRAPPING, !1);
                        c.gotoPage(b, a)
                    }
                })
            },
            gotoPage: function(b, a, c) {
                c = c || {};
                (void 0 === c.animationDuration || 0 < c.animationDuration) && !c.silent && b.setAttr(d.ANIMATING, !0);
                var e = b.getAttr(d.TOTAL_PAGES);
                0 < a && a <= e && b.setAttr(d.PAGE_NUMBER, a);
                var f = b.getAttr(d.CIRCULAR);
                !f && 1 > a ? (a = 1, c.animationDuration = Math.pow(b.getAttr(d.ANIMATION_SPEED) * b.getAttr(d.SPRINGINESS))) : !f && a > e && (a = e, c.animationDuration = Math.pow(b.getAttr(d.ANIMATION_SPEED), b.getAttr(d.SPRINGINESS)));
                this.gotoIndex(b, b.getAttr(d.PAGE_SIZE) * (a - 1) + 1, c)
            },
            gotoIndex: function(b,
                a, e) {
                e = e || {};
                (void 0 === e.animationDuration || 0 < e.animationDuration) && !e.silent && b.setAttr(d.ANIMATING, !0);
                var f = b.getAttr(d.CIRCULAR) && !b.getAttr(d.CURRENTLY_WRAPPING),
                    h = e.callback,
                    g = this,
                    k = !1,
                    l = b.getViewportWidth(),
                    m = Math.ceil(a / b.getAttr(d.PAGE_SIZE)),
                    y;
                m !== b.getAttr(d.PAGE_NUMBER) && 0 < m && m <= b.getAttr(d.TOTAL_PAGES) && b.setAttr(d.PAGE_NUMBER, m);
                b.setAttr(d.FIRST_VISIBLE_ITEM, a);
                1 > a ? f && (k = -1 * l, y = function() {
                    h && h();
                    g.wrapToLast(b)
                }) : a > b.getAttr(d.SET_SIZE) ? f && (k = b.getAttr(d.CURRENT_PIXEL) + l, y = function() {
                    h &&
                        h();
                    g.wrapToFirst(b)
                }) : k = b.getItemOffset(a);
                y ? (b.setAttr(d.CURRENTLY_WRAPPING, !0), e.callback = y, e.easingFunction = e.easingFunction || b.getAttr(d.WRAP_EASING), e.animationSpeed = 1.3 * (c.isFiniteNumber(e.animationSpeed) ? e.animationSpeed : b.getAttr(d.ANIMATION_SPEED))) : e.callback = h;
                !1 !== k && this.gotoPixel(b, k, e)
            },
            gotoPixel: function(b, a, e) {
                var f = b.getAttr(d.CURRENT_PIXEL);
                if (a !== f) {
                    e = e || {};
                    var h = e.easingFunction || "ease-out",
                        g = e.callback;
                    b.getViewportWidth();
                    var k;
                    void 0 !== e.animationDuration ? k = e.animationDuration :
                        (k = c.isFiniteNumber(e.animationSpeed) ? e.animationSpeed : b.getAttr(d.ANIMATION_SPEED), f = Math.abs(a - f), k = 0 === k ? 0 : Math.floor(f / k * 1E3));
                    0 < k && !e.silent && b.setAttr(d.ANIMATING, !0);
                    if (c.isFiniteNumber(a)) {
                        var f = 0 < k ? function() {
                                g && g();
                                b.getAttr(d.CURRENTLY_WRAPPING) || b.setAttr(d.ANIMATING, c.isAnimated(b.dom.$carousel), e.silent)
                            } : g,
                            l = c.capabilities.rtl ? 1 : -1;
                        b.setAttr(d.CURRENT_PIXEL, a);
                        c.animate(b.dom.$carousel, {
                            left: a * l
                        }, k, h, f)
                    } else m.error("Target pixel is not a finite number", "a-carousel-transition-slide",
                        "gotoPixel")
                }
            },
            gotoNextPage: function(b, a) {
                var c = b.getAttr(d.PAGE_NUMBER);
                this.gotoPage(b, ++c, a)
            },
            gotoPrevPage: function(b, a) {
                var c = b.getAttr(d.PAGE_NUMBER);
                this.gotoPage(b, --c, a)
            },
            onSwipe: function(b, a) {
                if (!b.getAttr(d.CURRENTLY_WRAPPING)) {
                    var f = b.getAttr(d.FIRST_VISIBLE_ITEM),
                        h = b.getAttr(d.PAGE_SIZE),
                        g = b.getAttr(d.PAGE_NUMBER),
                        k = 0 > e * a.velocityX,
                        l = f;
                    k && g < b.getAttr(d.TOTAL_PAGES) ? l = f + h : !k && 1 < g && (l = f - h);
                    h = b.getAttr(d.CURRENT_PIXEL);
                    g = b.getItemOffset(l);
                    a = Math.abs(1E3 * (k ? h - g : h + g) / a.velocityX);
                    a = Math.max(a,
                        300);
                    a = Math.min(a, 1.2 * c.viewport().width);
                    a = {
                        animationDuration: a,
                        easingFunction: b.getAttr(d.TOUCH_EASING)
                    };
                    l !== f || b.getAttr("circular") ? k ? b.gotoNextPage(a) : b.gotoPrevPage(a) : (a.animationSpeed = .95 * c.viewport().width, delete a.animationDuration, b.gotoIndex(l, a))
                }
            },
            onPan: function(b, a) {
                if (!b.getAttr(d.CURRENTLY_WRAPPING)) {
                    b.setAttr(d.ANIMATING, !0);
                    var f = b.getItemOffset(b.getAttr(d.FIRST_VISIBLE_ITEM)),
                        h = f - e * a.touchDeltaX,
                        g = b.getAttr(d.CIRCULAR),
                        k = b.getAttr(d.PAGE_NUMBER),
                        l = b.getAttr(d.TOTAL_PAGES);
                    a.ended ?
                        (f = {
                            easingFunction: b.getAttr(d.TOUCH_EASING),
                            animationSpeed: .95 * c.viewport().width,
                            silent: !0
                        }, a = e * a.touchDeltaX, h = Math.abs(a) < .4 * b.getViewportWidth(), !g && (0 > a && l === k || 0 < a && 1 === k) || h ? b.gotoPage(k, f) : 0 > a ? b.gotoNextPage(f) : b.gotoPrevPage(f)) : (!g && (g = b.getAttr(d.SPRINGINESS), 0 > h && 0 < a.touchDeltaX || k === l && 0 > a.touchDeltaX) && (k = Math.pow(Math.abs(a.touchDeltaX), g), h = 0 >= h ? -1 * k : f + k), b.gotoPixel(h, {
                            easingFunction: b.getAttr(d.TOUCH_EASING),
                            animationDuration: 0,
                            silent: !0
                        }))
                }
            },
            init: function(b) {
                var a = b.getAttr(d.ANIMATION_SPEED);
                c.isFiniteNumber(a) || b.setAttr(d.ANIMATION_SPEED, k);
                void 0 === b.getAttr(d.WRAP_EASING) && b.setAttr(d.WRAP_EASING, "linear");
                f(b);
                b.onChange(d.FETCHED_ITEMS, function(a, d) {
                    h(b, a, d)
                });
                b.onChange(d.SET_SIZE, function(a, d) {
                    a > d && f(b)
                })
            }
        }
    });
    "use strict";
    m.when("A", "a-carousel-utils", "a-carousel-circular-utils", "a-carousel-constants").register("a-carousel-transition-slidecircular", function(c, l, g, d) {
        function f(a) {
            var b = a.dom.$carousel.children("li").length,
                f = a.getAttr(d.SET_SIZE),
                h = f - b,
                g = e(a, b);
            0 < h && (b += 1, h = c.map(c.range(b,
                b + h), function(b) {
                return a.getEmptyCard(b, f)
            }), g.after(h.join("")), a.measure("items"))
        }

        function h(c, e) {
            var f = c.getAttr(d.SET_SIZE);
            if (2 < c.getAttr(d.SET_SIZE)) {
                var h = a(c, c.getAttr(d.FIRST_VISIBLE_ITEM)),
                    g = Math.round(c.getAttr(d.SET_SIZE) / 2),
                    f = k(g, h, f);
                0 !== f.quantity && (D(c, f.direction, f.quantity), h = f.direction === t.CLOCKWISE ? h - f.quantity : h + f.quantity, e.gotoPixel(c, b(c, h), {
                    animationDuration: 0
                }))
            }
        }

        function k(a, b, d) {
            var c = {};
            a === b ? a = b = 0 : a > b ? (b = a - b, a = d - b) : (a = b - a, b = d - a);
            c.direction = a <= b ? t.CLOCKWISE : t.COUNTER_CLOCKWISE;
            c.quantity = Math.min(a, b);
            return c
        }

        function e(b, d) {
            return b.dom.$carousel.children("li").eq(a(b, d) - 1)
        }

        function b(a, b) {
            var c = Math.floor(a.getAttr(d.PEEK_WIDTH) || 0);
            return a.getItemOffset(b) - c
        }

        function a(a, b) {
            b = b || 1;
            var c = a.getAttr("transitionSlideCircularFirstCardIndex");
            a = a.getAttr(d.SET_SIZE);
            return g.relativeIndexFromIndex(b, c, a)
        }

        function x(b, f, h) {
            if (b.getAttr(d.ANIMATING)) b.once(d.ANIMATING, function() {
                x(b, f, h)
            });
            else {
                var g = b.getDimensions().items,
                    k = Math.min(f.length, b.getAttr(d.SET_SIZE));
                if (!h ||
                    f.length >= h.length) b.setAttr(d.LOADING, !0), c.each(c.range(k), function(d) {
                    var k = d + 1,
                        n = f[d],
                        A = e(b, k),
                        m = n && !(!0 === n || !0 === n.content);
                    n && !c.equals(n, h[d]) && A.length && m && (k = a(b, k), g[k] = {
                        width: A.outerWidth(),
                        outerWidth: A.outerWidth(!0),
                        height: A.outerHeight(),
                        outerHeight: A.outerHeight(!0)
                    }, l.addElementToDom(A, l.getElementFromItem(n)), f[d] = l.clearElementFromItem(n))
                }), b.setAttr(d.LOADING, !1);
                b.setAttr(d.FETCHED_ITEMS, f);
                b.updateDimensionsCache({
                    items: g
                })
            }
        }

        function q(a) {
            var b = {
                reached: !1,
                left: !1,
                right: !1
            };
            if (!(2 < a.getAttr(d.SET_SIZE))) {
                var c = a.getAttr(d.PAGE_NUMBER);
                a = a.getAttr(d.SET_SIZE);
                1 === c && (b.reached = !0, b.left = !0);
                c === a && (b.reached = !0, b.right = !0)
            }
            return b
        }

        function n(a, b, c) {
            var e = q(a),
                f = a.getAttr(d.PAGE_NUMBER);
            e.reached && e[b] ? a.gotoPage(f) : ("right" === b ? a.gotoNextPage : a.gotoPrevPage).call(a, c)
        }

        function D(a, b, c) {
            var e = a.getAttr("transitionSlideCircularFirstCardIndex") || 1,
                f = a.getAttr(d.SET_SIZE),
                h = a.dom.$carousel.children("li"),
                k = a.dom.$carousel;
            b === t.CLOCKWISE ? (g.rotateCW(k, h, c), e = g.firstCardIndexAfterRotate(c,
                e, f)) : (g.rotateCCW(a.dom.$carousel, a.dom.$carousel.children("li"), c), e = g.firstCardIndexAfterRotate(-1 * c, e, f));
            a.setAttr("transitionSlideCircularFirstCardIndex", e);
            c = c || 1;
            b = b || t.CLOCKWISE;
            e = a.getDimensions().items;
            e = b === t.CLOCKWISE ? g.rotateArrayCW(e, c) : g.rotateArrayCCW(e, c);
            a.updateDimensionsCache({
                items: e
            })
        }

        function v(e, f, g, k, l) {
            var n = l.callback,
                m = a(e, e.getAttr(d.FIRST_VISIBLE_ITEM)),
                q = e.getAttr(d.CURRENT_PIXEL) - b(e, m);
            c.sequence(function(a) {
                D(e, f, k);
                a()
            }, function(a) {
                g.gotoPixel(e, b(e, f === t.CLOCKWISE ?
                    m - k : m + k) + q, {
                    animationDuration: 0,
                    callback: a
                })
            }, function(a) {
                l.callback = a;
                g.gotoPixel(e, b(e, m), l)
            }, function(a) {
                h(e, g);
                a()
            }, function(a) {
                n && n();
                a()
            })()
        }
        var t = {
                CLOCKWISE: 1,
                COUNTER_CLOCKWISE: -1
            },
            p = c.capabilities.rtl ? -1 : 1,
            y = c.capabilities.touch ? 2E3 : 3E3,
            u = {};
        u[d.HIDE_OFF_SCREEN] = !1;
        u[d.ANIMATION_SPEED] = function(a) {
            return function(b) {
                return c.isFiniteNumber(b) ? b : a
            }
        }(y);
        u.transitionSlideCircularFirstCardIndex = 1;
        return {
            initAttrs: u,
            init: function(a) {
                f(a);
                a.onChange(d.FETCHED_ITEMS, function(b, c) {
                    x(a, b, c);
                    a.strategies.display.repaint(a)
                });
                a.onChange(d.SET_SIZE, function(b, c) {
                    b > c && f(a)
                });
                a.onChange(d.PEEK_WIDTH, function(b, c) {
                    b !== c && (b = a.getAttr(d.FIRST_VISIBLE_ITEM), a.gotoIndex(b))
                })
            },
            afterInit: function(a) {
                h(a, this);
                a.strategies.display.repaint(a);
                a.gotoPage(a.getAttr(d.PAGE_NUMBER))
            },
            gotoPage: function(a, b, c) {
                c = c || {};
                var e = a.getAttr(d.TOTAL_PAGES);
                0 < b && b <= e && (a.setAttr(d.PAGE_NUMBER, b), this.gotoIndex(a, a.getAttr(d.PAGE_SIZE) * (b - 1) + 1, c))
            },
            gotoIndex: function(c, e, f) {
                var h = c.getAttr(d.SET_SIZE),
                    g = a(c, c.getAttr(d.FIRST_VISIBLE_ITEM)),
                    l = a(c,
                        e);
                g === l ? this.gotoPixel(c, b(c, g), f) : (2 < c.getAttr(d.SET_SIZE) ? (h = k(g, l, h), f.startover && (5 < h.quantity ? f.animationDuration = 1250 : (delete f.animationDuration, f.animationSpeed = 5 * c.getDimensions().viewport.width)), v(c, h.direction, this, h.quantity, f)) : this.gotoPixel(c, b(c, e), f), c.setAttr(d.FIRST_VISIBLE_ITEM, e))
            },
            gotoPixel: function(a, b, e) {
                var f = a.getAttr(d.CURRENT_PIXEL);
                if (b !== f) {
                    c.isFiniteNumber(b) || m.error("Target pixel is not a finite number", "a-carousel-transition-slide-circular", "gotoPixel");
                    e = e || {};
                    var h = e.easingFunction || "ease-out",
                        g = e.callback,
                        k;
                    e.animationDuration !== w ? k = e.animationDuration : (k = c.isFiniteNumber(e.animationSpeed) ? e.animationSpeed : a.getAttr(d.ANIMATION_SPEED), f = Math.abs(b - f), k = 0 === k ? 0 : Math.floor(f / k * 1E3));
                    0 < k && (!e.silent && a.setAttr(d.ANIMATING, !0), g = function() {
                        e.callback && e.callback();
                        a.setAttr(d.ANIMATING, c.isAnimated(a.dom.$carousel), e.silent)
                    });
                    f = c.capabilities.rtl ? t.CLOCKWISE : t.COUNTER_CLOCKWISE;
                    a.setAttr(d.CURRENT_PIXEL, b);
                    c.animate(a.dom.$carousel, {
                        left: b * f
                    }, k, h, g)
                }
            },
            gotoNextPage: function(a,
                b) {
                var c = a.getAttr(d.PAGE_NUMBER),
                    c = c === a.getAttr(d.TOTAL_PAGES) ? 1 : c + 1;
                this.gotoPage(a, c, b)
            },
            gotoPrevPage: function(a, b) {
                var c = a.getAttr(d.PAGE_NUMBER),
                    c = 1 === c ? a.getAttr(d.TOTAL_PAGES) : c - 1;
                this.gotoPage(a, c, b)
            },
            onSwipe: function(e, f) {
                var h = e.getAttr(d.CURRENT_PIXEL),
                    g = e.getAttr(d.PAGE_SIZE),
                    k = a(e, e.getAttr(d.FIRST_VISIBLE_ITEM)),
                    l = 0 > p * f.velocityX,
                    g = b(e, l ? k + g : k - g),
                    h = Math.abs(1E3 * (l ? h - g : h + g) / f.velocityX),
                    l = 1.2 * c.viewport().width;
                n(e, 0 > p * f.touchDeltaX ? "right" : "left", {
                    animationDuration: Math.min(Math.max(h,
                        300), l),
                    easingFunction: e.getAttr(d.TOUCH_EASING)
                })
            },
            onPan: function(e, f) {
                e.setAttr(d.ANIMATING, !0);
                var h = e.getAttr(d.PAGE_NUMBER),
                    g = a(e, e.getAttr(d.FIRST_VISIBLE_ITEM)),
                    g = b(e, g),
                    g = q(e).reached ? g - p * f.touchDeltaX * .4 : g - p * f.touchDeltaX;
                f.ended ? (g = {
                    easingFunction: e.getAttr(d.TOUCH_EASING),
                    animationSpeed: .95 * c.viewport().width,
                    silent: !0
                }, Math.abs(f.touchDeltaX) >= .4 * e.getViewportWidth() ? n(e, 0 > p * f.touchDeltaX ? "right" : "left", g) : e.gotoPage(h, g)) : e.gotoPixel(g, {
                    easingFunction: e.getAttr(d.TOUCH_EASING),
                    animationDuration: 0,
                    silent: !0
                })
            }
        }
    });
    "use strict";
    m.when("A", "a-carousel-utils", "a-carousel-constants").register("a-carousel-transition-freescroll", function(c, l, g) {
        function d(b) {
            a[b.__id] || (a[b.__id] = new m(b));
            return a[b.__id]
        }

        function f(a) {
            for (var b = a.countItems(), c = [], e = 0; e < b; e++) c.push(!0);
            a.setAttr(g.FETCHED_ITEMS, c)
        }

        function h(a) {
            var b = a.countItems(),
                c = a.getAttr(g.SET_SIZE),
                e = [],
                d;
            if (c > b) {
                for (var f = 0; f < c - b; f++) d = b + f + 1, e.push(a.getEmptyCard(d, c));
                a.appendItems(e)
            }
        }

        function k(a, b, e) {
            if (!e || b.length >= e.length)
                for (var d =
                        a.getItems(), f = b.length, h; f--;)(h = b[f]) && !c.equals(h, e[f]) && !0 !== h && !0 !== h.content && a.hasItem(d, f) && (b[f] = a.insertFetchedItem(h, d, f));
            a.setAttr(g.FETCHED_ITEMS, b)
        }

        function e(a) {
            a.hasEmptyCard() && a.attachScrollListener(function() {
                a.throttle("detect", b)
            })
        }

        function b(a) {
            var c = a.getAttr("loading_threshold_pixels"),
                e = a.measureWidth(),
                d = a.getFirstEmptyDetails(); - 1 !== d.index && d.left < e + c ? a.wantNext(d.index, a.getAttr("next_request_size")) : (a.previousCardLeft && a.previousCardLeft !== d.left && a.throttle("detect",
                b), a.previousCardLeft = d.left)
        }
        var a = {},
            m = function(a) {
                this.carousel = a
            };
        c.extend(m.prototype, {
            setAttr: function(a, b) {
                return this.carousel.setAttr(a, b)
            },
            getAttr: function(a) {
                return this.carousel.getAttr(a)
            },
            onChange: function(a, b) {
                this.carousel.onChange(a, b)
            },
            getItems: function() {
                return this.carousel.dom.$carousel.children("li")
            },
            countItems: function() {
                return this.getItems().length
            },
            showItems: function() {
                return this.getItems().css("visibility", "").attr("aria-hidden", "false")
            },
            getEmptyCard: function(a, b) {
                return this.carousel.getEmptyCard(a,
                    b)
            },
            getEmptyCards: function() {
                return this.carousel.dom.$carousel.children(".a-carousel-card-empty")
            },
            hasEmptyCard: function() {
                return 0 < this.getEmptyCards().length
            },
            getFirstEmptyDetails: function() {
                var a = this.getEmptyCards();
                return 0 < a.length ? (a = a.first(), {
                    index: a.index(),
                    left: a.position().left
                }) : {
                    index: -1,
                    left: -1
                }
            },
            appendItems: function(a) {
                this.carousel.dom.$carousel.append(a.join(""))
            },
            hasItem: function(a, b) {
                return 0 < a.eq(b).length
            },
            insertFetchedItem: function(a, b, c) {
                l.addElementToDom(b.eq(c), l.getElementFromItem(a));
                return l.clearElementFromItem(a)
            },
            attachScrollListener: function(a) {
                this.carousel.dom.$carousel.bind(c.action.move + ".a-carousel-freeScroll scroll.a-carousel-freeScroll", a)
            },
            detachScrollListener: function(a) {
                this.carousel.dom.$carousel.unbind(".a-carousel-freeScroll")
            },
            measureWidth: function() {
                return this.carousel.dom.$carousel.outerWidth()
            },
            wantNext: function(a, b) {
                this.carousel.strategies.ajax.want(this.carousel, a, b)
            },
            throttle: function(a, b) {
                var c = this;
                clearTimeout(c[a]);
                c[a] = setTimeout(function() {
                        b(c)
                    },
                    100)
            }
        });
        var q = {
            ajaxLock: !0
        };
        q[g.NO_TRANSITION] = !0;
        q[g.HIDE_OFF_SCREEN] = !1;
        q[g.AUTO_ADJUST_HEIGHT] = !1;
        q.next_request_size = 10;
        q.loading_threshold_pixels = 400;
        return {
            gotoIndex: c.constants.NOOP,
            gotoNextpage: c.constants.NOOP,
            gotoPrevPage: c.constants.NOOP,
            gotoPage: c.constants.NOOP,
            initAttrs: q,
            init: function(a) {
                var l = d(a);
                l.showItems();
                f(l);
                h(l);
                e(l);
                l.onChange(g.FETCHED_ITEMS, function(a, c) {
                    b(l);
                    k(l, a, c);
                    l.hasEmptyCard() || l.detachScrollListener()
                });
                c.on.resize(function() {
                    b(l)
                })
            },
            afterInit: function(a) {
                var e =
                    d(a);
                c.delay(function() {
                    e.setAttr("ajaxLock", !1);
                    b(e)
                })
            },
            prepareFetchedItems: f,
            addEmptyCards: h,
            handleItemChanges: k,
            detectEmptyCardsLoadingThreshold: b,
            ATTR: {
                NEXT_REQUEST_SIZE: "next_request_size",
                LOADING_THRESHOLD_PIXELS: "loading_threshold_pixels"
            }
        }
    });
    "use strict";
    m.when("A", "jQuery", "a-carousel-transition-slide", "a-carousel-transition-swap", "a-carousel-transition-freescroll", "a-carousel-transition-slidecircular", "a-carousel-constants").register("a-carousel-strategies-transition", function(c, l, g, d, f,
        h, k) {
        l = {};
        l[k.NO_TRANSITION] = !0;
        l[k.HIDE_OFF_SCREEN] = !1;
        l[k.AUTO_ADJUST_HEIGHT] = !1;
        return {
            slideHorizontal: g,
            swap: d,
            freeScroll: f,
            slideCircular: h,
            none: {
                gotoIndex: c.constants.NOOP,
                gotoNextPage: c.constants.NOOP,
                gotoPrevPage: c.constants.NOOP,
                gotoPage: c.constants.NOOP,
                initAttrs: l,
                init: function(c) {
                    c.dom.$carousel.children("li").css("visibility", "").attr("aria-hidden", "false")
                }
            },
            "default": "slideHorizontal"
        }
    });
    "use strict";
    m.when("A").register("a-carousel-ajax-standard", function(c) {
        function l(f, h, g) {
            f.triggerEvent("beforeAjax", {
                url: h,
                params: g
            });
            c.get(h, {
                cache: !1,
                success: function(e) {
                    e = c.isArray(e) ? e : e !== d && null !== e && !c.objectIsEmpty(e) && e.hasOwnProperty("data") && c.isArray(e.data) ? e.data : null;
                    if (null === e) m.error("Invalid JSON returned to carousel from " + h + " - see http://tiny/c1mr5h0u for details.", "a-carousel-ajax-standard", "sendRequest");
                    else {
                        g.needSetSize && (e && e.length || m.error("Carousel requires a set_size and none was returned by the fallback AJAX request at: " + h, "a-carousel-ajax-standard", "sendRequest"), f.setAttr("set_size",
                            e[0].setSize ? e[0].setSize : e.length));
                        for (var b = f.getAttr("fetchedItems"), a;
                            (a = e.pop()) !== d;) a && (a.content || "" === a.content ? a.content = c.trim(a.content) : a = c.trim(a)), b[g.offset + e.length] = a;
                        g.needSetSize && f.init();
                        f.setAttr("fetchedItems", b);
                        f.setAttr("ajaxLock", !1);
                        g.needSetSize && f.getAttr("pageSize") >= b.length && f.strategies.ajax.wantCurrentPage(f);
                        f.triggerEvent("ajaxSuccess", {
                            url: h,
                            params: g
                        })
                    }
                },
                params: g
            })
        }

        function g(c) {
            var d = c.getAttr("requestTimer");
            d && (clearTimeout(d), c.setAttr("requestTimer", null))
        }
        var d;
        return {
            getItems: function(d, g, k) {
                var e = d.getAttr("ajax");
                d.setAttr("requestTimer", c.delay(l, e.fetch_delay, d, g, k))
            },
            wantNextPage: function(c) {
                g(c);
                if (c.getAttr("ajax").prefetch_next_page) {
                    var d = c.getAttr("pageSize"),
                        k = 2 * d;
                    c.getAttr("show_partial_next") && k++;
                    this.want(c, (c.getAttr("pageNumber") - 1) * d, k)
                } else this.wantCurrentPage(c)
            },
            wantPrevPage: function(c) {
                g(c);
                if (c.getAttr("ajax").prefetch_next_page) {
                    var d = c.getAttr("pageSize"),
                        k = 2 * d;
                    c.getAttr("show_partial_next") && k++;
                    this.want(c, (c.getAttr("pageNumber") -
                        2) * d, k)
                } else this.wantCurrentPage(c)
            },
            wantCurrentPage: function(c) {
                g(c);
                var d = c.getAttr("pageSize"),
                    k = c.getAttr("show_partial_next") ? d + 1 : d;
                this.want(c, (c.getAttr("pageNumber") - 1) * d, k)
            },
            want: function(c, d, k) {
                if (!c.getAttr("ajaxLock")) {
                    g(c);
                    var e = c.getAttr("ajax"),
                        b = c.getAttr("set_size");
                    if (e.url) {
                        var a = c.getAttr("fetchedItems"),
                            l = e.id_list;
                        l || (l = []);
                        var m = -1 < d ? d : 0;
                        d = d + k - 1;
                        var n = e.params || {},
                            D = [],
                            v = [];
                        0 === b && (l.length && (b = l), n.needSetSize = "true", c.setAttr("ajaxLock", !0));
                        for (-1 === k && b && (d = b); m <= d && m <
                            b;) a[m] || ((k = l[m]) && D.push(k), v.push(m), a[m] = !1), m++;
                        c.setAttr("fetchedItems", a, {
                            silent: !0
                        });
                        n.count = v.length;
                        n.offset = v[0] || 0;
                        0 < D.length && (n[e.id_param_name] = D.join(","));
                        (0 < v.length || n.needSetSize) && this.getItems(c, e.url, n)
                    }
                }
            },
            init: function(f) {
                var g = f.getAttr("ajax");
                c.isFiniteNumber(g.fetch_delay) || (g.fetch_delay = 500);
                g.id_param_name = g.id_param_name || "ids";
                g.prefetch_next_page = g.prefetch_next_page === d ? !0 : !!g.prefetch_next_page;
                f.setAttr("ajax", g);
                f.getAttr("set_size") || this.want(f, 0, -1)
            },
            afterInit: function(c) {
                c.strategies.ajax.wantCurrentPage(c);
                c.onChange("pageNumber", function(d, g) {
                    d > g ? c.strategies.ajax.wantNextPage(c) : c.strategies.ajax.wantPrevPage(c)
                })
            }
        }
    });
    "use strict";
    m.when("a-util").register("a-carousel-ajax-promise", function(c) {
        function l(g, d) {
            var f = g.getAttr("requestTimer");
            f && clearTimeout(f);
            g.setAttr("requestTimer", c.delay(d, 500))
        }
        return {
            getItems: function(g, d, f) {
                l(g, function() {
                    var h = g.getAttr("async_provider");
                    h && h(d, f).then(function(f) {
                        var e = g.getAttr("fetchedItems");
                        c.each(f, function(b, a) {
                            e[d[a]] = b
                        });
                        g.setAttr("fetchedItems",
                            e)
                    })
                })
            },
            wantNextPage: function(c) {
                var d = c.getAttr("pageSize"),
                    f = (c.getAttr("pageNumber") - 1) * d;
                this.want(c, f, 2 * d)
            },
            wantPrevPage: function(c) {
                var d = c.getAttr("pageSize"),
                    f = (c.getAttr("pageNumber") - 2) * d;
                this.want(c, f, 2 * d)
            },
            wantCurrentPage: function(c) {
                var d = c.getAttr("pageSize"),
                    f = (c.getAttr("pageNumber") - 1) * d;
                this.want(c, f, d)
            },
            want: function(g, d, f) {
                d = Math.max(0, d);
                f = Math.min(d + f, g.getAttr("set_size"));
                for (var h = g.getAttr("fetchedItems"), k = []; d < f; d++) h[d] || (k.push(d), h[d] = !1);
                if (k.length) {
                    var e, b = g.getAttr("ajax").id_list;
                    b && (e = c.map(k, function(a) {
                        return b[a]
                    }));
                    g.setAttr("fetchedItems", h, {
                        silent: !0
                    });
                    this.getItems(g, k, e)
                }
            },
            init: function(c) {},
            afterInit: function(g) {
                g.strategies.ajax.wantCurrentPage(g);
                g.onChange("async_provider", c.once(function() {
                    g.strategies.ajax.wantCurrentPage(g)
                }));
                g.onChange("pageNumber", function(c, f) {
                    c > f ? g.strategies.ajax.wantNextPage(g) : g.strategies.ajax.wantPrevPage(g)
                })
            }
        }
    });
    "use strict";
    m.when("A", "a-carousel-ajax-standard", "a-carousel-ajax-promise").register("a-carousel-strategies-ajax", function(c,
        l, g) {
        return {
            standard: l,
            promise: g,
            none: {
                wantNextPage: c.constants.NOOP,
                wantPrevPage: c.constants.NOOP,
                wantCurrentPage: c.constants.NOOP,
                want: c.constants.NOOP,
                init: c.constants.NOOP
            },
            "default": "standard"
        }
    });
    "use strict";
    m.when("A", "a-carousel-constants").register("a-carousel-accessibility-standard-desktop", function(c, l) {
        function g(a) {
            var b = a.dom.$carousel,
                c = b.children("li"),
                d = a.getAttr(l.PAGE_SIZE),
                e = a.getAttr(l.FIRST_VISIBLE_ITEM) - 1;
            return a.getAttr(l.NO_TRANSITION) ? c : c.length <= d ? b.children("li:not(:empty), li.a-carousel-card-empty") :
                c.slice(e, e + d)
        }

        function d(a, b, d, e) {
            var f = function() {
                var d = g(a);
                (b ? d.first() : d.last()).find("a, button, input, select, textarea, [tabindex]:not([tabindex\x3d'-1'])").not(":disabled").first().focus();
                c.delay(function() {
                    h(a)
                }, a.getAttr(l.PAGE_SIZE) * a.getAttr(l.DELAY_TIME) + 50)
            };
            if (0 === d || 0 === e) c.delay(f, 0);
            else a.once(l.ANIMATING, function(a) {
                a || f()
            })
        }

        function f(a) {
            var c = a.dom.$carousel.children("li"),
                d = a.getAttr(l.TRANSITION_STRATEGY),
                e = a.getAttr(l.SET_SIZE),
                f = e ? {
                    "aria-setsize": e
                } : {};
            if ("swap" === d) {
                var g =
                    a.getAttr(l.FIRST_VISIBLE_ITEM);
                c.each(function(a) {
                    var c = b(this);
                    g + a > e ? (c.removeAttr("aria-setsize"), c.removeAttr("aria-posinset")) : (f["aria-posinset"] = g + a, c.attr(f))
                })
            } else c.each(function(a) {
                f["aria-posinset"] = a + 1;
                b(this).attr(f)
            })
        }

        function h(a) {
            a = a.dom.$container;
            a.find(".a-carousel-accessibility-page-info").html(a.find(".a-carousel-page-count").text())
        }

        function k(a) {
            a.getAttr(l.TRANSITION_STRATEGY);
            if (!a.getAttr(l.NO_TRANSITION)) {
                var b = a.dom.$carousel.children("li");
                a = g(a);
                b = b.not(a);
                a.attr("aria-hidden", !1);
                b.attr("aria-hidden", !0)
            }
        }

        function e(a, b) {
            if (!a.getAttr(l.CIRCULAR)) {
                var c = a.dom.$container;
                c.find(".a-carousel-goto-prevpage").attr("aria-disabled", 1 === b ? "true" : "false");
                c.find(".a-carousel-goto-nextpage").attr("aria-disabled", b === a.getAttr(l.TOTAL_PAGES) ? "true" : "false")
            }
        }
        var b = c.$;
        return {
            init: function(a) {
                var b = a.getAttr(l.NAME);
                f(a);
                k(a);
                e(a, 1);
                c.on("a:carousel" + (b ? ":" + name : "") + ":repaint", function() {
                    k(a)
                });
                a.onChange(l.SET_SIZE, function(b, c) {
                    f(a)
                });
                a.onChange(l.LOADING, function(b) {
                    a.getAttr(l.ANIMATING) ||
                        a.dom.$carousel.attr("aria-busy", (!!b).toString())
                });
                a.onChange(l.ANIMATING, function(b) {
                    a.getAttr(l.LOADING) || a.dom.$carousel.attr("aria-busy", (!!b).toString());
                    !b && a.getAttr(l.SET_SIZE) > a.getAttr(l.PAGE_SIZE) && (b = a.getAttr(l.TRANSITION_STRATEGY), k(a), "slide" !== b && f(a))
                });
                a.onChange(l.PAGE_NUMBER, function(b) {
                    e(a, b)
                })
            },
            afterInit: function(a) {
                h(a)
            },
            gotoPage: function(a, b, c) {
                a.getAttr(l.NO_TRANSITION) || d(a, !0, b, c)
            },
            nextPage: function(a, b, c) {
                a.getAttr(l.NO_TRANSITION) || d(a, !0, b, c)
            },
            prevPage: function(a, b,
                c) {
                a.getAttr(l.NO_TRANSITION) || d(a, !1, b, c)
            }
        }
    });
    "use strict";
    m.when("A", "a-carousel-constants").register("a-carousel-accessibility-standard-mobile", function(c, l) {
        function g(c) {
            var g = c.dom.$carousel;
            c = g.children(".a-carousel-card-empty");
            var g = g.children("li").not(c),
                k = g.length,
                e = k ? {
                    "aria-setsize": k
                } : {};
            c.attr("aria-hidden", "true").removeAttr("aria-setsize").removeAttr("aria-posinset");
            g.each(function(b) {
                e["aria-posinset"] = b + 1;
                e["aria-hidden"] = "false";
                d(this).attr(e)
            })
        }
        var d = c.$;
        c = c.constants.NOOP;
        return {
            init: function(c) {
                g(c);
                c.onChange(l.SET_SIZE, function() {
                    g(c)
                });
                c.onChange(l.LOADING, function(d) {
                    c.dom.$carousel.attr("aria-busy", (!!d).toString());
                    d || g(c)
                })
            },
            gotoPage: c,
            nextPage: c,
            prevPage: c
        }
    });
    "use strict";
    m.when("A", "a-carousel-accessibility-standard-desktop", "a-carousel-accessibility-standard-mobile").register("a-carousel-strategies-accessibility", function(c, l, g) {
        return {
            standardDesktop: l,
            standardMobile: g,
            none: {
                init: c.constants.NOOP,
                gotoPage: c.constants.NOOP,
                nextPage: c.constants.NOOP,
                prevPage: c.constants.NOOP
            },
            "default": c.capabilities.mobile || c.capabilities.tablet ? "standardMobile" : "standardDesktop"
        }
    });
    "use strict";
    m.when("a-carousel-strategies-display", "a-carousel-strategies-transition", "a-carousel-strategies-ajax", "a-carousel-strategies-accessibility").register("a-carousel-strategies", function(c, l, g, d) {
        return {
            display: c,
            transition: l,
            ajax: g,
            accessibility: d
        }
    });
    "use strict";
    m.when("A", "jQuery", "a-timing-analytics", "a-carousel-classes", "a-carousel-strategies", "a-carousel-constants").register("a-carousel-framework",
        function(c, l, g, d, f, h) {
            function k(a, b, d, f) {
                b = new b(a, d, f);
                b.__id = ++C;
                a.data("a-carousel", b);
                a.removeClass("a-carousel-static");
                n(a) ? c.delay(e, 10, b) : y.push(b);
                f.name && (r[f.name] = b);
                return b
            }

            function e(a) {
                a.init();
                p.push(a);
                a.__initialized = !0;
                a.dom.$container.addClass("a-carousel-initialized");
                var b = a.getAttr("name");
                b && z[b] && c.each(z[b], function(b) {
                    b(a)
                })
            }

            function b(a, b) {
                (b = b[a + "Strategy"]) || (b = f[a]["default"]);
                return f[a][b]
            }

            function a(a) {
                for (var b = a.length, c; b--;) c = a[b], c.dom.$container.length && B.find(c.dom.$container).length ||
                    ((c = c.getAttr("name")) && delete r[c], a.splice(b, 1))
            }

            function x() {
                a(y);
                a(p)
            }

            function q(a) {
                var c = a.data("a-carousel-options") || {};
                c.displayStrategy = a.data("a-display-strategy");
                c.transitionStrategy = a.data("a-transition-strategy");
                c.ajaxStrategy = a.data("a-ajax-strategy");
                c.accessibilityStrategy = a.data("a-accessibility-strategy");
                c.carouselClass = a.data("a-class");
                a = b("display", c);
                var e = b("transition", c),
                    f = b("ajax", c),
                    g = b("accessibility", c),
                    h = c.carouselClass;
                h || (h = d["default"]);
                h = d[h];
                if (h !== t && a !== t &&
                    e !== t && f !== t && g !== t) return {
                    carouselClass: h,
                    strategies: {
                        display: a,
                        transition: e,
                        ajax: f,
                        accessibility: g
                    },
                    opts: c
                }
            }

            function n(a) {
                return a.hasClass("a-begin") && 0 === a.children(".a-end").length ? !1 : c.onScreen(a)
            }

            function w() {
                l(".a-carousel-static").each(function() {
                    var a = l(this),
                        b = q(a);
                    b && k(a, b.carouselClass, b.strategies, b.opts)
                })
            }

            function v() {
                for (var a = y.length; a--;) {
                    var b = y[a];
                    n(b.dom.$container) && (y.splice(a, 1), e(b))
                }
            }
            var t, p = [],
                y = [],
                u = !1,
                r = {},
                B = l(document),
                z = {},
                C = 0;
            c.on("resize orientationchange", function(a,
                b) {
                x();
                (b.height || b.width) && c.delay(function() {
                    c.each(p, function(a) {
                        a.resize()
                    })
                }, c.capabilities.mobile || c.capabilities.tablet ? 100 : 0)
            });
            c.on("a:popover:afterSlideOut", function() {
                c.each(p, function(a) {
                    a.resize()
                })
            });
            c.on("a:carousel:change:name", function(a) {
                a.newValue && (r[a.newValue] = a.carousel);
                a.oldValue && delete r[a.oldValue]
            });
            c.on(h.INIT_EVENTS, function() {
                v();
                w();
                c.once(function() {
                    g.stopWidgetLogging("carousel")
                })()
            });
            c.on("a:pageUpdate", x);
            c.on("scroll", function() {
                v();
                w()
            });
            c.declarative("a-tabs",
                "click",
                function(a) {
                    c.delay(function() {
                        v();
                        c.each(p, function(a) {
                            a.getAttr("isInTab") && a.resize()
                        })
                    }, 50)
                });
            c.on("a:popover:afterShow", function() {
                c.delay(v, 50)
            });
            c.on("a:popover:ajaxContentLoaded", function() {
                c.delay(function() {
                    x();
                    w()
                }, 50)
            });
            c.on.ready(function() {
                u = !0
            });
            h = {
                getCarousel: function(a) {
                    a.jquery || (a = l(a));
                    var b = a.closest(".a-carousel-container").data("a-carousel");
                    if (!b) {
                        var c = q(a);
                        c && (b = k(a, c.carouselClass, c.strategies, c.opts))
                    }
                    return b
                },
                getCarouselByName: function(a) {
                    return r[a]
                },
                createAll: function() {
                    x();
                    w()
                },
                initializeAll: function() {
                    x();
                    v()
                },
                kill: function(a) {
                    a.jquery || (a = l(a));
                    if (a.length && (a = a.closest(".a-carousel-container"), a.length)) {
                        var b = a.data("a-carousel");
                        if (b) {
                            var d = c.indexOfArray(p, b); - 1 < d ? (p[d].name && delete r[p[d].name], p.splice(d, 1)) : (d = c.indexOfArray(y, b), -1 < d && (y[d].name && delete r[y[d].name], y.splice(d, 1)))
                        }
                        a.remove()
                    }
                },
                registerStrategy: function(a, b, c) {
                    f[a] || (f.type = {});
                    f[a][b] && m.error("Attempted to register a " + a + " strategy which already exists: " + b, "a-carousel-framework", "registerStrategy");
                    f[a][b] = c;
                    u && w()
                },
                registerCarouselClass: function(a, b) {
                    d[a] && m.error("Attempted to register a carousel class which already exists: " + a, "a-carousel-framework", "registerCarouselClass");
                    l.isFunction(b) || m.error("Attempted to register carousel class " + a + " without a constructor function.", "a-carousel-framework", "registerCarouselClass");
                    d[a] = b;
                    u && w()
                },
                getAllCarousels: function() {
                    return p.concat(y)
                },
                onInit: function(a, b) {
                    a && (z[a] || (z[a] = []), l.isFunction(b) && (z[a].push(b), (a = r[a]) && a.__initialized && b(a)))
                }
            };
            Object.freeze !== t && Object.freeze(h);
            return h
        })
});
/* ******** */
(function(e) {
    var g = window.AmazonUIPageJS || window.P,
        k = g._namespace || g.attributeErrors,
        a = k ? k("AmazonUIComponents", "AmazonUI") : g;
    a.guardFatal ? a.guardFatal(e)(a, window) : a.execute(function() {
        e(a, window)
    })
})(function(e, g, k) {
    e.when("A", "a-form-controls-api").register("a-form-controls-handlers", function(a, b) {
        var f = a.$,
            d = function() {
                f(this).removeClass("a-hover-disable")
            },
            h = function(c, d) {
                var h = b.findFormElementContainer(c);
                a.delay(function() {
                    h.find(d).each(b.normalizeElement)
                }, 0)
            };
        return {
            handleBoxInputMobileFocus: function() {
                f(this).addClass("a-form-focus")
            },
            handleBoxInputMobileBlur: function() {
                f(this).removeClass("a-form-focus")
            },
            accessibilityKeyPress: function(c) {
                c.keyCode === a.constants.keycodes.SPACE && (c.preventDefault(), c.stopPropagation())
            },
            formReset: h,
            handleCheckboxClick: function() {
                if (!a.capabilities.mobile && !a.capabilities.tablet) f(this).addClass("a-hover-disable").one("mouseleave", d)
            },
            normalizeFormControls: function() {
                f("form").unbind("reset.a-form-controls-reset").bind("reset.a-form-controls-reset", function(c) {
                    h(c.currentTarget, "li .a-touch-multi-select")
                })
            },
            touchMultiSelectHandler: function(c) {
                b.toggleCheckboxState(c.currentTarget)
            }
        }
    });
    "use strict";
    e.when("A", "a-form-controls-handlers", "ready").register("a-form-controls", function(a, b) {
        function f(a) {
            var c = d(this),
                b = c.siblings("a.a-placeholder"),
                c = c.find(":selected").text();
            b.html(c);
            a && a.preventDefault && a.preventDefault()
        }
        var d = a.$;
        d(document).delegate(".a-select-multiple, .a-input-text, .a-input-text-wrapper", "focusin", b.handleBoxInputMobileFocus).delegate(".a-select-multiple, .a-input-text, .a-input-text-wrapper",
            "focusout", b.handleBoxInputMobileBlur).delegate(".a-touch-radio, .a-touch-checkbox", "keypress", b.accessibilityKeyPress).delegate("li .a-touch-multi-select", "click", b.touchMultiSelectHandler).delegate("select.a-touch-select-input", "change", f);
        a.on("a:pageUpdate beforeReady", function() {
            d("body").find("select.a-touch-select-input").each(f);
            b.normalizeFormControls()
        })
    });
    "use strict";
    e.when("A").register("a-buttons", function(a) {
        var b = a.$,
            f = 0;
        a.declarative("a-button-group", ["click"], function(d) {
            var b = d.$target,
                c = b.closest(".a-button:not(.a-button-disabled)");
            if (c.length) {
                var f = d.$declarativeParent.find(".a-button");
                d = d.data && d.data.name ? d.data.name : !1;
                b = b.closest("input[type\x3dsubmit], button").attr("name") || b.find("input[type\x3dsubmit], button").attr("name");
                f.removeClass("a-button-selected").attr("aria-checked", "false");
                c.addClass("a-button-selected").attr("aria-checked", "true");
                if (b || d) c = {
                    $button: c,
                    buttonName: b,
                    buttonGroupName: d
                }, d && (a.trigger("a:button-group:" + d + ":toggle", {
                    selectedButton: c
                }), b && a.trigger("a:button-group:" +
                    d + ":" + b + ":toggle", {
                        selectedButton: c
                    }))
            }
        });
        a.on("a:pageUpdate beforeReady", function() {
            var a = b(".a-button:not([id])"),
                e = b(".a-button-group,.a-button-toggle-group");
            a.each(function() {
                var c = b(this),
                    a = c.find(".a-button-text"),
                    d = c.find(".a-button-input"),
                    e = "a-autoid-" + f++;
                c.attr("id", e);
                a.length && (e = (c = a.attr("id")) ? c : e + "-announce", d.attr("aria-labelledby", e), a.attr("id", e))
            });
            e.each(function() {
                var a = b(this).find(".a-button[role\x3d'radio']"),
                    d = a.length,
                    e = 1;
                a.each(function() {
                    b(this).attr({
                        "aria-posinset": e++,
                        "aria-setsize": d
                    })
                })
            })
        });
        b(document).delegate(".a-button-input, .a-button-text", "focusin", function() {
            var a = b(this).closest(".a-button");
            a.hasClass("a-button-disabled") || a.addClass("a-button-focus")
        }).delegate(".a-button-input, .a-button-text", "focusout " + a.action.cancel, function() {
            b(this).closest(".a-button").removeClass("a-button-focus")
        })
    })
});
/* ******** */
(function(c) {
    var a = window.AmazonUIPageJS || window.P,
        e = a._namespace || a.attributeErrors,
        b = e ? e("AmazonUITabs", "AmazonUI") : a;
    b.guardFatal ? b.guardFatal(c)(b, window) : b.execute(function() {
        c(b, window)
    })
})(function(c, a, e) {
    c.when("A").register("a-tabs", function(b) {
        var c = b.$;
        b.declarative("a-tabs", ["click"], function(a) {
            var d = a.$target.closest("li"),
                h = a.data.name,
                f = d.data("a-tab-name"),
                g = d.closest(".a-tab-container"),
                g = g.find(".a-box-tab").not(g.find(".a-box-tab .a-box-tab"));
            f !== e && (c("li.a-active", d.closest(".a-tabs")).removeClass("a-active"),
                d.addClass("a-active"), c.each(g, function(b, a) {
                    c(a).toggleClass("a-hidden", c(a).data("a-name") !== f)
                }), d = {
                    $tab: d,
                    tabName: f,
                    tabSetName: h
                }, b.trigger("a:tabs:" + h + ":select", {
                    selectedTab: d
                }), b.trigger("a:tabs:" + h + ":" + f + ":select", {
                    selectedTab: d
                }), a.$event.preventDefault())
        })
    })
});
/* ******** */
(function(d) {
    var f = window.AmazonUIPageJS || window.P,
        k = f._namespace || f.attributeErrors,
        a = k ? k("AmazonUIAccordion", "AmazonUI") : f;
    a.guardFatal ? a.guardFatal(d)(a, window) : a.execute(function() {
        d(a, window)
    })
})(function(d, f, k) {
    d.when("A").register("a-accordion-a11y", function(a) {
        var d = a.$,
            b;
        return {
            refreshFocus: function(e, g) {
                g = g || 600;
                b || (b = d("\x3cb /\x3e", {
                    "class": "a-accordion-a11y",
                    tabIndex: -1,
                    style: "position: absolute"
                }).appendTo("body"));
                b.css({
                    display: "block"
                }).offset(e.offset());
                a.delay(function() {
                        b.focus()
                    },
                    50);
                a.delay(function() {
                    e.focus();
                    b.css({
                        display: "none"
                    })
                }, g)
            }
        }
    });
    d.when("A", "a-accordion-a11y", "prv:a-capabilities").register("a-accordion", function(a, d, b) {
        function e(b) {
            var h = b.$target.closest(".a-accordion"),
                c = b.$target.closest(".a-box"),
                e = h.find(".a-box").not(c),
                l = c.find(".a-accordion-row"),
                n = h.data("a-accordion-name"),
                p = c.data("a-accordion-row-name"),
                u = h.hasClass("a-accordion-collapse"),
                v = c.find("a.a-accordion-row"),
                q = b.$target.closest(".a-accordion-row-a11y"),
                h = h.find(".a-accordion-row-a11y").not(q);
            if (p) {
                var t = c.find(".a-accordion-inner"),
                    r = !0;
                if (c.hasClass("a-accordion-active"))
                    if (u) t[f]({
                        duration: m,
                        complete: function() {
                            c.removeClass("a-accordion-active");
                            c.find(".a-icon.a-accordion-radio").removeClass("a-icon-radio-active").addClass("a-icon-radio-inactive");
                            q.attr("aria-checked", "false").attr("aria-expanded", "false")
                        }
                    });
                    else r = !1;
                else e.find(".a-accordion-inner")[f]({
                    duration: m,
                    complete: function() {
                        e.removeClass("a-accordion-active")
                    }
                }), t[g]({
                    duration: m,
                    complete: function() {
                        c.addClass("a-accordion-active");
                        e.find(".a-icon.a-accordion-radio").removeClass("a-icon-radio-active").addClass("a-icon-radio-inactive");
                        c.find(".a-icon.a-accordion-radio").removeClass("a-icon-radio-inactive").addClass("a-icon-radio-active")
                    }
                }), h.attr("aria-checked", "false").attr("aria-expanded", "false"), q.attr("aria-checked", "true").attr("aria-expanded", "true");
                r && k && d.refreshFocus(l);
                r && (l = {
                    $row: c,
                    rowName: p,
                    accordionName: n
                }, a.trigger("a:accordion:select", {
                    selectedRow: l
                }), a.trigger("a:accordion:" + n + ":select", {
                    selectedRow: l
                }), a.trigger("a:accordion:" +
                    n + ":" + p + ":select", {
                        selectedRow: l
                    }))
            }
            v.length && b.$event.preventDefault()
        }
        var g = "slideDown",
            f = "slideUp",
            m = 300;
        if (a.capabilities.mobile || a.capabilities.tablet) g = "show", f = "hide", m = 0;
        var k = !a.capabilities.touch && b.isFirefox;
        a.declarative("a-accordion", ["click"], e);
        a.declarative("a-accordion", ["keypress"], function(b) {
            var d = a.constants.keycodes,
                c = b.$event.which;
            c !== d.ENTER && c !== d.SPACE || e(b)
        })
    })
});
/* ******** */
(function(c) {
    var e = window.AmazonUIPageJS || window.P,
        n = e._namespace || e.attributeErrors,
        a = n ? n("AmazonUIExpander", "AmazonUI") : e;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, e, n) {
    c.declare("prv:a-expander-constants", {
        classNames: {
            inline: {
                expand: "a-icon-expand",
                collapse: "a-icon-collapse"
            },
            section: {
                expand: "a-icon-section-expand",
                collapse: "a-icon-section-collapse"
            },
            extender: {
                expand: "a-icon-extender-expand",
                collapse: "a-icon-extender-collapse"
            }
        },
        elementClasses: {
            container: "a-expander-container",
            content: "a-expander-content",
            header: "a-expander-header",
            fadeDiv: "a-expander-content-fade"
        }
    });
    c.when("A", "jQuery", "prv:a-expander-constants").register("a-partial-expander", function(a, c, e) {
        function l() {
            c(".a-expander-partial-collapse-container").each(function() {
                var a = c(this),
                    d = a.children("." + m.content),
                    f = a.data("a-expander-collapsed-height"),
                    b = a.children("." + m.header);
                d.height() <= f ? b.css({
                    opacity: "0",
                    display: "none"
                }) : (b.css({
                        opacity: "1",
                        display: "block"
                    }), d.css("padding-bottom", b.height()), "true" !==
                    d.attr("aria-expanded") && a.css({
                        height: f,
                        "max-height": "none"
                    }))
            })
        }
        var m = e.elementClasses;
        a.on("load ready resize orientationchange a:popover:afterShow a:popover:ajaxContentLoaded", l);
        return l
    });
    "use strict";
    c.when("A", "jQuery", "prv:a-expander-constants", "a-partial-expander").register("a-expander", function(a, c, e, l) {
        function m(b, a) {
            var d = b.closest("." + g.container),
                f = d.data("a-expander-collapsed-height"),
                c = "true" === b.attr("aria-expanded"),
                e = function() {
                    b.toggleClass(g.content + "-expanded");
                    b.attr("aria-expanded",
                        c ? "false" : "true");
                    a()
                };
            f ? (d.css("height", c ? f : "auto"), e()) : b.toggle(0, function() {
                e()
            })
        }
        var g = e.elementClasses,
            d = e.classNames,
            f = {};
        a.each(d, function(b, d) {
            f[d] = {};
            a.each(b, function(a, b) {
                f[d][b] = new RegExp("\\b" + a + "\\b", "g")
            })
        });
        a.declarative("a-expander-toggle", "click", function(b) {
            var c = b.$target.closest("." + g.container),
                e = c.find("." + g.container),
                l = c.data("a-expander-name"),
                p;
            p = b.$currentTarget.hasClass(g.header) ? b.$currentTarget : c.find("." + g.header).not(e.find("." + g.header));
            var n = c.find("." + g.content).not(e.find("." +
                g.content));
            m(n, function() {
                var h = p.find(".a-icon")[0],
                    k = null,
                    m = p.children("." + g.fadeDiv);
                "false" === n.attr("aria-expanded") ? (h && (h.className = h.className.replace(f.inline.collapse, d.inline.expand).replace(f.section.collapse, d.section.expand).replace(f.extender.collapse, d.extender.expand)), b.data && b.data.expand_prompt && (k = b.data.expand_prompt), m.show(), h = "collapse") : (h && (h.className = h.className.replace(f.inline.expand, d.inline.collapse).replace(f.section.expand, d.section.collapse).replace(f.extender.expand,
                    d.extender.collapse)), b.data && b.data.collapse_prompt && (k = b.data.collapse_prompt), m.hide(), h = "expand");
                k && "" !== k && p.find(".a-expander-prompt").not(e.find(".a-expander-prompt")).html(k);
                k = {
                    expander: {
                        $expander: c,
                        expanderName: l
                    }
                };
                a.trigger("a:expander:toggle", k);
                a.trigger("a:expander:toggle:" + h, k);
                l && (a.trigger("a:expander:" + l + ":toggle", k), a.trigger("a:expander:" + l + ":toggle:" + h, k))
            })
        });
        return {
            initializeExpanders: l
        }
    })
});
/* ******** */
(function(h) {
    var e = window.AmazonUIPageJS || window.P,
        l = e._namespace || e.attributeErrors,
        d = l ? l("AmazonUISwitch", "AmazonUI") : e;
    d.guardFatal ? d.guardFatal(h)(d, window) : d.execute(function() {
        h(d, window)
    })
})(function(h, e, l) {
    h.when("a-switch-framework", "jQuery").register("a-switch", function(d, k) {
        var g = d.SWITCH_STATE,
            h = d.SWITCH_CONTAINER_CLASS,
            v = d.SWITCH_CLASS;
        return {
            getSwitch: function(c) {
                function m(c) {
                    var n = f.data(g);
                    if (c === l) return n.isOn;
                    if (!n.isEnabled || e(f)) return !1;
                    d.setOnState(f, c);
                    return !0
                }

                function e() {
                    return f.data(g).isDragging
                }
                c.jquery || (c = k(c));
                if (0 === c.length) return null;
                c = c.eq(0);
                c = c.closest("." + h);
                if (0 === c.length) return null;
                var f = c.find("." + v);
                d.ensureInitialized(f);
                return {
                    toggle: function() {
                        return m(!f.data(g).isOn)
                    },
                    isOn: m,
                    enabled: function(c) {
                        var n = f.data(g);
                        if (c === l) return n.isEnabled;
                        if (n.isEnabled === c) return !1;
                        d.setEnabled(f, c);
                        return !0
                    },
                    isDragging: e,
                    label: function(d) {
                        var c = f.data(g).label,
                            h = c[0].childNodes[0];
                        if (d === l) return c.text();
                        3 === h.nodeType && (h.textContent = d)
                    }
                }
            }
        }
    });
    "use strict";
    h.when("A", "jQuery").register("a-switch-framework",
        function(d, k) {
            function g(a) {
                a.preventDefault();
                var b = a.data.$switch.data("a-switch-state"),
                    c = b.control;
                if (!d.isAnimated(c)) {
                    a = p(a) - b.initialX;
                    b.isOn && (a += b.rightBoundary);
                    var e = b.leftBoundary,
                        u = b.rightBoundary;
                    a = a < e ? e : a > u ? u : a;
                    a !== b.leftOffset && (d.animate(c, {
                        left: a
                    }, 0), b.leftOffset = a, b.isDragging = !0, b.dragCount++)
                }
            }

            function e(a) {
                a.preventDefault();
                if (d.capabilities.touch || 1 === a.which) {
                    a = a.data.$switch;
                    var b = a.data("a-switch-state");
                    m(a, b.isDragging && 1 < b.dragCount ? b.leftOffset > b.midPoint : !b.isOn);
                    b.isDragging = !1;
                    r(a)
                }
            }

            function l(a, b, c) {
                c = {
                    switchState: a,
                    previousState: c
                };
                d.trigger("a:switch:" + b, c);
                a.name && d.trigger("a:switch:" + a.name + ":" + b, c)
            }

            function c(a) {
                if (!a.data("a-switch-state")) {
                    var b = a.closest(".a-switch-row"),
                        c = a.children(".a-switch-control"),
                        d = b.find(".a-switch-label"),
                        e = d.siblings("input"),
                        h = e.attr("name"),
                        f = b.hasClass("a-active"),
                        l = !b.hasClass("a-disabled"),
                        g = q.left,
                        k = (a.width() - c.width() + q.right) * z;
                    a.data("a-switch-state", {
                        input: e,
                        container: b,
                        control: c,
                        label: d,
                        isDragging: !1,
                        rightBoundary: k,
                        leftBoundary: g,
                        midPoint: k / 2,
                        initialX: null,
                        leftOffset: f ? k : g,
                        maxLeftOffset: q.maxLeftOffset,
                        isOn: f,
                        isEnabled: l,
                        name: h,
                        dragCount: 0,
                        clicked: !1
                    })
                }
            }

            function m(a, b) {
                c(a);
                a = a.data("a-switch-state");
                var e = a.isOn,
                    h = b !== a.isOn;
                a.isOn = b;
                var f = a.control,
                    k = a.maxLeftOffset,
                    g = a.isOn ? a.rightBoundary : a.leftBoundary,
                    g = k && g > k ? k : g;
                d.animate(f, {
                    left: g
                }, 300, "ease-out");
                a.leftOffset = g;
                f = a.container;
                a.isOn ? f.addClass("a-active") : f.removeClass("a-active");
                f = a.input;
                a.isOn ? f.attr("checked", "checked") : f.removeAttr("checked");
                h && l(a, "flip", e);
                b ? l(a, "on", e) : l(a, "off", e)
            }
            var x = function(a) {
                    a.bind("touchmove.a-switch-component", {
                        $switch: a
                    }, g);
                    a.bind("touchend.a-switch-component", {
                        $switch: a
                    }, e);
                    a.bind("touchcancel.a-switch-component", {
                        $switch: a
                    }, e);
                    a.bind("mouseup.a-switch-component", {
                        $switch: a
                    }, e)
                },
                f = function(a) {
                    a.unbind("touchmove.a-switch-component");
                    a.unbind("touchend.a-switch-component");
                    a.unbind("touchcancel.a-switch-component");
                    a.unbind("mouseup.a-switch-component")
                },
                w = function(a) {
                    return (a.originalEvent.touches[0] ||
                        a.originalEvent.changedTouches[0]).pageX
                },
                n = function(a) {
                    k("body").bind("mousemove.a-switch-component", {
                        $switch: a
                    }, g);
                    k("body").bind("mouseup.a-switch-component", {
                        $switch: a
                    }, e)
                },
                y = function(a) {
                    k("body").unbind("mousemove.a-switch-component", g);
                    k("body").unbind("mouseup.a-switch-component", e)
                },
                A = function(a) {
                    return a.pageX
                },
                q = {
                    left: d.capabilities.rtl ? 1 : -1,
                    right: -1
                },
                z = d.capabilities.rtl ? -1 : 1;
            h.when("prv:skin-vars").execute(function(a) {
                q = a.toggle.bounds
            });
            var t = null,
                r = null,
                p = null;
            d.capabilities.touch ? (t =
                x, r = f, p = w) : (t = n, r = y, p = A);
            d.declarative("a-switch", d.capabilities.touch ? "touchstart" : "mousedown", function(a) {
                var b = a.$event;
                b.preventDefault();
                if (d.capabilities.touch || 1 === b.which) {
                    a = a.$declarativeParent;
                    c(a);
                    var e = a.data("a-switch-state");
                    e.dragCount = 0;
                    e.clicked = !0;
                    e.isDragging = !1;
                    e.isEnabled && (e.initialX = p(b), t(a))
                }
            });
            d.declarative("a-switch-input", "change", function(a) {
                a.$event.preventDefault();
                a = a.$target.closest(".a-switch-row").find(".a-switch");
                c(a);
                var b = a.data("a-switch-state");
                m(a, !b.isOn)
            });
            d.declarative("a-switch-label", "click", function(a) {
                a.$event.preventDefault();
                a = a.$target.closest(".a-switch-row").find(".a-switch");
                c(a);
                var b = a.data("a-switch-state");
                b.clicked ? b.clicked = !1 : b.isEnabled && m(a, !b.isOn)
            });
            h.when("ready").execute("a-switch-normalization", function() {
                k(".a-switch-input").each(function() {
                    var a = k(this),
                        b = a.next().children(".a-switch");
                    m(b, a.prop("checked"))
                })
            });
            return {
                ensureInitialized: c,
                setOnState: m,
                setEnabled: function(a, b) {
                    c(a);
                    a = a.data("a-switch-state");
                    var d = a.container;
                    b ? d.removeClass("a-disabled") : d.addClass("a-disabled");
                    a.isEnabled = b
                },
                SWITCH_STATE: "a-switch-state",
                SWITCH_CONTAINER_CLASS: "a-switch-row",
                SWITCH_CLASS: "a-switch"
            }
        })
});
/* ******** */
(function(b) {
    var a = window.AmazonUIPageJS || window.P,
        g = a._namespace || a.attributeErrors,
        e = g ? g("AmazonUIProgressBar", "AmazonUI") : a;
    e.guardFatal ? e.guardFatal(b)(e, window) : e.execute(function() {
        b(e, window)
    })
})(function(b, a, g) {
    b.when("A", "ready").register("a-progress", function(e) {
        function b(a) {
            (a ? f(a) : f(".a-js-progress-bar")).each(function() {
                var b = f(this);
                if (e.onScreen(b, 0)) {
                    var a, h, c, g;
                    a = +b.attr("data-progress-percentage");
                    h = -(a - 100);
                    c = b.width();
                    g = h / 100 * c;
                    var d = b.find(".a-js-progress-tooltip"),
                        k = d.width();
                    d.find(".a-js-tooltip-arrow");
                    a = (a + h / 2) / 100 * c - k / 2;
                    h = k + a;
                    (k = h < c) || (a -= h - c);
                    c = a;
                    f(d).css("left", c + 0);
                    c = d.width();
                    d = d.find(".a-js-tooltip-arrow");
                    d.removeClass("aok-hidden");
                    k ? (c /= 2, f(d).css("left", c + -9)) : f(d).css("left", c + -27);
                    12 > g && d.addClass("aok-hidden");
                    f(b.find(".a-js-progress-tooltip")).removeClass("a-progress-tooltip-hidden").addClass("a-progress-tooltip-revealed")
                }
            })
        }
        var f = e.$;
        b();
        e.on("resize scroll", function(a) {
            b()
        });
        return {
            init: b
        }
    })
});
/* ******** */
(function(m) {
    var t = window.AmazonUIPageJS || window.P,
        C = t._namespace || t.attributeErrors,
        b = C ? C("AmazonUIPopover", "AmazonUI") : t;
    b.guardFatal ? b.guardFatal(m)(b, window) : b.execute(function() {
        m(b, window)
    })
})(function(m, t, C) {
    m.when("A", "a-popover-base-factory").register("a-popover-base-apis", function(b, h) {
        return {
            show: function(b) {
                var c = h.get(b.$trigger ? b.$trigger : b);
                if (c) return c.show.apply(c, arguments)
            },
            hide: function(b) {
                var c = h.get(b);
                if (c) return c.unlock(1), c.hide.apply(c, arguments)
            },
            get: function(b) {
                return h.get(b)
            },
            remove: function(b) {
                return h.remove(b)
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-util", "a-popover-objectclass", "a-popover-data").register("a-popover-base-factory", function(b, h, f, c) {
        function d(a) {
            return k[a] ? k[a] : null
        }

        function g(a, b) {
            return new f.PopoverClass(a, b)
        }

        function a(a, b) {
            var e = null;
            if ("number" === typeof a) e = d(a);
            else if ("string" === typeof a)(e = u[a] ? u[a] : null) || (e = d(a));
            else if ("object" === typeof a)
                if (a.$popover) e = a;
                else if (a = l(a), e = a.data("a-popover-id"), e || (e = a.find(".a-declarative").eq(0), e = e.length ?
                    e.data("a-popover-id") : null), e = d(e), !e) {
                var k = a.data("action");
                (k = k ? a.data(k) : null) && k.name && (e = k.name, e = u[e] ? u[e] : null, !e || b && e.type !== b ? e = null : (b = (b = e.attrs("currentDataStrategy")) ? c.getStrategyByName(b) : c.guessStrategyByAttrs(e.attrs())) && b.reusePopover ? e.$trigger[0] !== a[0] && (e.$trigger.data("a-popover-id", null), e.$trigger = a) : e = null)
            }
            return e
        }

        function p() {
            v || (v = g({
                id: -1,
                $popover: n,
                $trigger: n,
                immersive: !0
            }, {
                isActive: function() {
                    return !0
                },
                hideMethod: function() {
                    this.hideChildren()
                },
                showMethod: b.constants.NOOP
            }));
            return v
        }
        var l = b.$,
            e = 1,
            u = {},
            k = {},
            n = l("\x3cdiv id\x3d'a-popover-root' style\x3d'z-index:-1;position:absolute;' /\x3e").appendTo("body"),
            v;
        return {
            getRoot: p,
            get: function(e, b) {
                b = b ? b : this ? this.type : null;
                return (e = a(e, b)) && b && e.type !== b ? null : e
            },
            create: function(c, n) {
                var f = l(c),
                    h = n.attributes || {},
                    v = n.typeSpecificFunctions || n.variant || {};
                n = n.actionCheck || !1;
                f.data("a-popover-id");
                var x = h.type,
                    m = null;
                !x || f.hasClass("a-declarative") && f.data("action") && -1 !== f.data("action").indexOf(x) || (f = b.declarative.create(f,
                    "a-" + x), c = f[0]);
                if (n && f.data("action") && -1 === f.data("action").indexOf(x)) return null;
                x && f && (m = a(f));
                if (m) return m.type !== x ? null : m;
                f = h;
                c = l(c);
                f.type ? c && c.length ? (f = b.extend({
                    id: e++,
                    $trigger: c,
                    $triggerWrapper: null
                }, f), v = b.copy(v), v = g(f, v), k[v.id] = v, v.name && (u[v.name] = v), c.data("a-popover-id", v.id), c = v.$trigger.closest(".a-popover"), c = !v.attrs("immersive") && c.length ? d(c.data("a-popover-id")) || p() : p(), v.parent = c, c.children.push(v)) : v = null : v = null;
                return v
            },
            remove: function(a, e) {
                a = this.get(a);
                var l = !1;
                if (a) {
                    l =
                        a.id;
                    if (a && -1 < l) {
                        var c = b.indexOfArray(a.parent.children, a),
                            n = a.$container,
                            f = a.$trigger;
                        a.parent.children.splice(c, 1);
                        a.unlock().hide();
                        a.update({
                            content: ""
                        });
                        n && a.$container.remove();
                        f.data("a-popover-id", "");
                        a.name && delete u[a.name];
                        delete k[l];
                        l = !0
                    } else l = !1;
                    e && b.declarative.remove(a.$trigger[0], "a-" + e)
                }
                return l
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-util", "a-popover-base-factory", "prv:a-capabilities").register("a-popover-base-handlers", function(b, h, f, c) {
        function d(a) {
            for (var e; a.length && !(e = a.data("a-popover-id"));) a =
                a.parent();
            return f.get(e)
        }
        var g = b.$;
        g(document).bind("click " + b.action.start, function(a) {
            var e = g(a.target),
                c = a.originalEvent;
            if (!(c && c.pointerType && c.pointerType === b.pointerType.touch && "click" === c.type || e.hasClass("a-modal-scroller") || "a-popover-lgtbox" === e[0].id || "html" === e[0].nodeName.toLowerCase())) {
                var k = function(e) {
                    return h.eventOccursWithin(a, e)
                };
                b.each(f.getRoot().children, function(a) {
                    if (a.isVisible() || a.isContentLoaded()) {
                        var e = h.search(a, k);
                        e ? e.hideChildren() : null !== a.attrs("lightboxOptions") ||
                            a.attrs("immersive") || a.unlock(1).hide()
                    }
                })
            }
        });
        m.when("a-event-analytics").execute(function(a) {
            a.notifyJquery(g(document), "click " + b.action.start)
        });
        b.declarative("a-popover-close", ["click", b.action.end], function(a) {
            var e = d(a.$target);
            e && (e.unlock().hide(), h.trigger("dismiss", e));
            a.$event.preventDefault()
        });
        var a = null,
            p = null;
        b.declarative("a-popover-a11y", "focusout", function(c) {
            var e = d(c.$target);
            e && c.$target.length && e.$firstTabbable.length && c.$target[0] === e.$firstTabbable[0] && !(a && 100 > b.now() - a) &&
                (a = b.now(), b.delay(function() {
                    g(document.activeElement).hasClass("a-popover-start") && e.$lastTabbable.focus()
                }, 0))
        });
        b.declarative("a-popover-a11y", "focusin", function(a) {
            var e = d(a.$target);
            e && a.$target.length && a.$target.hasClass("a-popover-end") && !(p && 100 > b.now() - p) && (p = b.now(), b.delay(function() {
                e.$firstTabbable.focus()
            }, 0))
        });
        b.declarative("a-popover-a11y", "keydown", function(a) {
            var e = a.$event;
            e.keyCode === b.constants.keycodes.ESCAPE && (a = d(a.$target), e.preventDefault(), a && a.hide())
        });
        b.on("resize zoom",
            function() {
                f.getRoot().updatePosition()
            });
        if (c.isSafari && b.capabilities.ios) b.on("a:popover:refresh", function(a) {
            a = a.popover;
            a.$popover && a.$popover.undelegate('input[type\x3d"date"]', "blur").delegate('input[type\x3d"date"]', "blur", function() {
                var a = b.$(t);
                a.scrollTop(a.scrollTop() + 1)
            })
        })
    });
    "use strict";
    m.when("A", "a-popover-base-apis", "a-popover-base-handlers").register("a-popover-base", function(b, h, f) {
        return h
    });
    "use strict";
    m.when("A", "a-popover-util", "a-popover-data", "a-popover-position", "a-popover-lightbox",
        "a-popover-animate", "prv:a-capabilities").register("a-popover-objectclass", function(b, h, f, c, d, g, a) {
        function p(a, c) {
            var n = -1,
                f = [1],
                p = -2;
            this.parent = null;
            this.children = [];
            this.typeSpecificFunctions = {};
            this.attributes = {
                position: "triggerVertical",
                alone: !1,
                immersive: !1,
                restoreFocusOnHide: !0
            };
            var r = function() {
                    this.isActive() ? this._willTriggerEvents && h.trigger("visible", this) : h.trigger("invisible", this);
                    return this
                },
                t = function(a, c) {
                    var n = this.isActive(),
                        g = this.getDataStrategy(),
                        u = !this.$popover,
                        d = c || u;
                    c = !1;
                    a = a || d;
                    if (!d)
                        for (var p = f.length; p-- && !d;) d = !k[f[p]];
                    d && (d = m.apply(this), d = e(d), u || (g.unloadContent(this), this.$container.remove(), c = !0), e("body").append(d), this.$container = d, this.$popover = this.$container.hasClass("a-popover") ? this.$container : this.$container.find(".a-popover"), this.$startAnchor = this.$popover.hasClass("a-popover-start") ? this.$popover : this.$popover.find(".a-popover-start"), this.$endAnchor = this.$popover.find(".a-popover-end"), this.$popover.attr("id", "a-popover-" + this.id).data("a-popover-id",
                        this.id));
                    this.attrs("immersive") || (d = parseInt(this.parent.$popover.css("z-index"), 10), b.isFiniteNumber(d) || (d = this.parent.attrs("immersive") ? 1010 : 0), "dropdown" === this.type && 599 != l && (d = Math.max(599, d)), this.$popover.css("z-index", Math.max(299, 100 + d)));
                    if (g.shouldRefreshContent(this) || a) c || g.unloadContent(this), g.loadContent(this, u);
                    this.typeSpecificFunctions.updateDimensions !== l && this.typeSpecificFunctions.updateDimensions.apply(this);
                    f = [];
                    n && D.call(this, [], !1);
                    a = this.$popover.find(".a-popover-inner").find("a, button, input, select, textarea, [tabindex]:not([tabindex\x3d'-1'])");
                    a = a.not(".a-dropdown-link");
                    this.$firstTabbable = this.$popover.find('[data-action\x3d"a-popover-close"]');
                    this.$firstTabbable = this.$firstTabbable.length ? this.$firstTabbable : a.first();
                    this.$lastTabbable = 0 === a.length ? this.$firstTabbable : a.last();
                    return this
                },
                D = function(a, e) {
                    function c() {
                        k.updatePosition();
                        var b = k.attrs("navigate");
                        !e && b && k.attrs("navigate", !1);
                        f.call(k, r, a);
                        e && h.trigger("show", k);
                        d && d.apply(k, a);
                        e && h.trigger("afterShow", k);
                        k.$popover.attr("aria-hidden", "false");
                        u.attr("aria-hidden",
                            "true");
                        !e && b && k.attrs("navigate", b);
                        p = 2
                    }
                    var k = this;
                    e = !!e;
                    var n = k.typeSpecificFunctions,
                        f = n.showMethod !== l ? n.showMethod : q,
                        g = n.beforeShowMethod !== l ? n.beforeShowMethod : null,
                        d = n.afterShowMethod !== l ? n.afterShowMethod : null;
                    p = 1;
                    k._willTriggerEvents = e;
                    k.attrs("originalFocus", document.activeElement);
                    k.$popover.css("visibility", "hidden").addClass("a-popover-hidden").show();
                    g && g.apply(k, a);
                    k.attrs("synchronous") ? c() : b.delay(function() {
                        c()
                    }, 0)
                };
            this.show = function() {
                var a = this,
                    e = a.attrs("lightboxOptions") || null;
                if (a.isActive() || g.isAnimating(a)) return this;
                a.lock(1);
                e && d.lock(1);
                a.attrs("alone") && b.each(a.parent.children, function(e) {
                    e.isActive() && e.id !== a.id && !e.attrs("modeless") && e.unlock().hide()
                });
                h.trigger("beforeShow", a);
                if (!a.$container || a.isDirty() || a.getDataStrategy().shouldRefreshContent(a)) h.trigger("refresh", a), t.call(a);
                if (a.draggable) {
                    var c = a.$container;
                    b.draggable(c, {
                        handle: c.find(".a-popover-draggable-handle")
                    })
                }
                e && d.show(b.extend({
                    popover: a
                }, e));
                D.call(a, arguments, !0);
                b.delay(function() {
                    a.unlock(1);
                    e && d.unlock(1)
                }, 0);
                return this
            };
            this.hide = function() {
                var a = this,
                    c = a.typeSpecificFunctions,
                    k = c.hideMethod !== l ? c.hideMethod : w,
                    n = c.beforeHideMethod !== l ? c.beforeHideMethod : null,
                    f = c.afterHideMethod !== l ? c.afterHideMethod : null,
                    q = a.attrs("lightboxOptions") || null;
                if (!a.isActive() || a.isLocked() || g.isAnimating(a)) return this;
                p = -1;
                a.hideChildren();
                h.trigger("beforeHide", a);
                n && n.apply(a, arguments);
                k.call(a, r, arguments);
                h.trigger("hide", a);
                b.delay(function() {
                    f && f.apply(a, arguments);
                    a.$popover.attr("aria-hidden",
                        "true");
                    u.attr("aria-hidden", "false");
                    q && (a.parent.attrs("lightboxOptions") ? d.show(b.extend({
                        popover: a.parent
                    }, q)) : d.hide(q));
                    h.trigger("afterHide", a);
                    p = -2;
                    if (a.attrs("restoreFocusOnHide")) {
                        var c = null;
                        "dropdown" === a.type ? c = a.$trigger : a.$trigger && e(a.$trigger).length && (c = a.$trigger.is("a, input, button") ? a.$trigger : a.$trigger.find("a, input, button"));
                        c && c.length || (c = e(a.attrs("originalFocus")));
                        !c.length || v && !c.is(":visible") || b.delay(function() {
                                ("secondary-view" === a.type || b.onScreen(c, 0)) && c.focus()
                            },
                            400)
                    }
                }, 0);
                return this
            };
            this.update = function(a) {
                var e = "string" === typeof a ? {
                        content: a
                    } : b.copy(a),
                    c = this.attrs();
                a = this.getDataStrategy();
                b.each(e, function(a, e) {
                    (a && !c[e] || c[e] && c[e] !== a) && f.push(e)
                });
                this.isDirty() && (e = b.extend({}, c, e), this.attrs(e), this.getDataStrategy(e), this.$popover && a.unloadContent(this), this.isActive() && (t.call(this, !0), this.focus()));
                return this
            };
            this.refresh = function(a, e) {
                return t.call(this, a || !0, e || !1)
            };
            this.isActive = function() {
                return 1 <= p
            };
            this.isVisible = function() {
                return 2 ===
                    p
            };
            this.isContentLoading = function() {
                return 3 === p
            };
            this.setContentLoading = function() {
                p = 3
            };
            this.isContentLoaded = function() {
                return 4 === p
            };
            this.setContentLoaded = function() {
                p = 4
            };
            this.isDirty = function() {
                return 0 < f.length
            };
            this.lock = function(a) {
                a || (a = 10);
                n < a && (n = a);
                return this
            };
            this.unlock = function(a) {
                a || (a = 10);
                n <= a && (n = -1);
                return this
            };
            this.isLocked = function() {
                return -1 !== n
            };
            this.typeSpecificFunctions = c;
            this.attrs(a);
            b.extend(this, this.attributes)
        }
        var l, e = b.$,
            u = e("#a-page"),
            k = {
                name: !0,
                url: !0,
                content: !0,
                width: !0,
                height: !0,
                "max-width": !0,
                "max-height": !0,
                "min-width": !0,
                "min-height": !0
            },
            n = b.capabilities.mobile && a.isIE10Plus,
            v = e("html").hasClass("a-lt-ie9"),
            q = function(a) {
                this.$popover.css({
                    visibility: "visible"
                }).removeClass("a-popover-hidden");
                this.attrs("focusWhenShown") && "ajax" !== this.attrs("currentDataStrategy") && this.focus();
                a.call(this)
            },
            w = function(a) {
                this.$popover.hide().find(".a-lgtbox-vertical-scroll").removeClass("a-lgtbox-vertical-scroll");
                a.call(this)
            },
            m = function() {
                var a = this.typeSpecificFunctions;
                return a.skin !== l ? a.skin(this) : ""
            },
            r = p.prototype;
        r.getDataStrategy = function(a) {
            var e = this.typeSpecificFunctions;
            a || this.attrs("currentDataStrategy") || (a = this.attrs());
            a && (a = a.dataStrategy ? f.getStrategyByName(a.dataStrategy) : f.guessStrategyByAttrs(a)) && (e.dataStrategy = a, this.attrs("currentDataStrategy", a.name));
            return e.dataStrategy
        };
        r.getContent = function() {
            return this.typeSpecificFunctions.getContent !== l ? this.typeSpecificFunctions.getContent.apply(this, arguments) : null
        };
        r.updateContent = function(a) {
            this.typeSpecificFunctions.updateContent !==
                l && this.typeSpecificFunctions.updateContent.apply(this, arguments);
            return this
        };
        r.setAriaBusy = function(a) {
            this.typeSpecificFunctions.setAriaBusy !== l && this.typeSpecificFunctions.setAriaBusy.apply(this, arguments);
            return this
        };
        r.ajax = function(a) {
            return this.update({
                url: a
            })
        };
        r.updateChildrenPosition = function() {
            b.each(this.children, function(a) {
                a.isActive() && a.updatePosition()
            });
            return this
        };
        r.updatePosition = function() {
            var k = this;
            if (-1 === k.id) b.each(k.children, function(a) {
                a.isActive() && a.updatePosition()
            });
            else {
                if (this.typeSpecificFunctions.updatePosition !== l) return this.typeSpecificFunctions.updatePosition.apply(this, arguments), k;
                var n = k.$popover;
                a.isMetroIEGuess && a.isIETouchCapable ? n.css("opacity", .01) : n.css("visibility", "hidden");
                var f = function() {
                    var l = n.find(".a-popover-inner").css({
                            height: "auto",
                            "overflow-y": "auto"
                        }),
                        f = k.attrs("position"),
                        g = {},
                        u, g = k.typeSpecificFunctions.positionStrategy ? c.customPosition(k, k.typeSpecificFunctions.positionStrategy) : c[f](k);
                    h.trigger("beforeUpdatePosition", k);
                    u = {
                        top: g.top + "px",
                        left: g.left + "px"
                    };
                    a.isMetroIEGuess && a.isIETouchCapable ? u.opacity = 1 : u.visibility = "visible";
                    e.withoutRtl(function() {
                        n.css(u)
                    });
                    k.isContentLoaded() && 0 === e(document.activeElement).closest(k.$popover).length && !0 === k.attrs("focusWhenShown") && k.focus();
                    if (l.length && (!l[0].style.height || "auto" === l[0].style.height)) {
                        var g = n.outerHeight() || 0,
                            d = n.find(".a-popover-header, .a-modal-close-nohead-top").outerHeight(!0) || 0,
                            p = n.find(".a-popover-footer").outerHeight(!0) || 0,
                            f = l.outerHeight() || 0,
                            g = g - d -
                            p;
                        f > g && l.css({
                            height: g + "px",
                            "overflow-y": "scroll"
                        })
                    }
                    h.trigger("afterUpdatePosition", k);
                    h.trigger("positionUpdated", k);
                    b.each(k.children, function(a) {
                        a.isActive() && a.updatePosition()
                    })
                };
                k.attrs("immersive") && (b.capabilities.mobile || b.capabilities.tablet) ? (n.css({
                    top: 0,
                    left: 0
                }), b.delay(function() {
                    f()
                }, 0)) : f()
            }
            return k
        };
        r.attrs = function(a, e) {
            var c = this;
            if (e === l && "object" !== typeof a) return a ? "string" === typeof a ? this.attributes[a] !== l ? this.attributes[a] : null : null : this.attributes;
            "object" === typeof a ? b.each(a,
                function(a, e) {
                    c.attrs(e, a)
                }) : "string" === typeof a && (this.attributes[a] = e, c[a] = e);
            return this
        };
        r.hideChildren = function() {
            b.each(this.children, function(a) {
                a.unlock(1);
                a.hide()
            });
            return this
        };
        r.focus = function() {
            var a = this,
                c = e(t),
                k = c.scrollTop(),
                l = a.$popover.offset().top;
            n && k > l && c.scrollTop(l);
            b.delay(function() {
                a.$firstTabbable.focus()
            }, 0);
            return this
        };
        return {
            PopoverClass: p
        }
    });
    "use strict";
    m.when("jQuery", "prv:a-tnr", "ready").register("a-changeover", function(b, h) {
        b(document).delegate(".a-changeover:not(.a-changeover-manual)",
            "webkitAnimationEnd animationend click touchstart",
            function(b) {
                h.ackDelegated(b);
                this.style.display = "none"
            })
    });
    "use strict";
    m.when("A", "a-popover-util").register("a-popover-ajax-strategy", function(b, h) {
        return {
            name: "ajax",
            reusePopover: !1,
            loadContent: function(f, c) {
                f.setContentLoading();
                var d = f.attrs("url"),
                    g = f.attrs("timeout") || 1E4,
                    a = f.attrs("ajaxFailMsg") || "Sorry, content is not available.",
                    p = !!f.attrs("cache"),
                    l = f.attrs("spinnerTimer"),
                    e = f.attrs("ajaxHandler"),
                    u = f.attrs("content");
                f.attrs("content",
                    null);
                if (u && !c) f.updateContent(u), l && clearTimeout(l), e && e.abort && e.abort();
                else {
                    var k = function() {
                            return !f.attrs("content") && "ajax" === f.attrs("currentDataStrategy") && (f.isVisible() || f.isActive())
                        },
                        l = b.delay(function() {
                            k() && (h.showSpinner(f), f.setAriaBusy(!0))
                        }, 100),
                        n = function(a, e, c) {
                            k() && (clearTimeout(l), f.setContentLoaded(), h.trigger(e, f), f.setAriaBusy(!1), f.update({
                                content: a
                            }), f.isActive() && f.updatePosition(), c && h.trigger("ajaxContentLoaded", f))
                        },
                        e = b.ajax(d, {
                            type: "GET",
                            timeout: g,
                            cache: p,
                            success: function(a) {
                                n(a,
                                    "ajaxSuccess", !0)
                            },
                            error: function() {
                                n(a, "ajaxFail", !1)
                            }
                        });
                    f.attrs({
                        spinnerTimer: l,
                        ajaxHandler: e
                    })
                }
                return this
            },
            unloadContent: function(b) {
                h.clearContent(b);
                return this
            },
            shouldRefreshContent: function(b) {
                return !b.attrs("manualRefresh")
            },
            isValidStrategy: function(b) {
                return !!b.url
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-util").register("a-popover-inline-strategy", function(b, h) {
        return {
            name: "inline",
            reusePopover: !1,
            loadContent: function(b) {
                b.setContentLoading();
                var c = b.attrs("content");
                c && b.attrs("content",
                    null);
                if (!c) var c = b.$trigger,
                    d = c.data("action"),
                    c = c.data(d) || {},
                    c = c.inlineContent ? c.inlineContent : null;
                c || (c = b.attrs("inlineContent"));
                b.updateContent(c);
                b.setContentLoaded();
                return this
            },
            unloadContent: function(b) {
                var c = b.getContent(),
                    c = c && 0 < c.length ? c.html() : b.attrs("inlineContent"),
                    d = b.$trigger,
                    g = d.data("action"),
                    a = d.data(g) || {};
                a.inlineContent = c;
                d.data(g, a);
                h.clearContent(b);
                return this
            },
            shouldRefreshContent: function(b) {
                return b.isDirty()
            },
            isValidStrategy: function(b) {
                return !0
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-util").register("a-popover-preload-strategy", function(b, h) {
        var f = b.$;
        return {
            name: "preload",
            reusePopover: !0,
            loadContent: function(b) {
                b.setContentLoading();
                var d = b.attrs("name"),
                    g = b.attrs("content");
                b.attrs("content", null);
                var a;
                a = f("#a-popover-" + d);
                a.detach();
                if (a.length) {
                    a = a[0];
                    for (var p = document.createDocumentFragment(); a.firstChild;) p.appendChild(a.firstChild);
                    a = p
                } else a = !1;
                g ? b.updateContent(g) : d && b.updateContent(a);
                b.setContentLoaded();
                return this
            },
            unloadContent: function(c) {
                var d =
                    c.attrs("name");
                if (d) {
                    var g = c.getContent();
                    if (g && g.html()) {
                        var d = "a-popover-" + d,
                            a = f("#" + d);
                        a.length ? a = a[0] : (a = document.createElement("div"), a.id = d, a.className = "a-popover-preload", document.body.appendChild(a));
                        d = a;
                        if (!b.trim(d.innerHTML))
                            if (g = g[0], "string" === typeof g) f(d).html(g);
                            else {
                                for (a = document.createDocumentFragment(); g.firstChild;) a.appendChild(g.firstChild);
                                d.appendChild(a)
                            }
                        h.clearContent(c)
                    }
                }
                return this
            },
            shouldRefreshContent: function(b) {
                b = (b = b.attrs("name")) ? f("#a-popover-" + b) : null;
                return !(!b ||
                    !b.length || "" === b.html())
            },
            isValidStrategy: function(b) {
                return b.name ? "preload" === b.currentDataStrategy ? !0 : !!f("#a-popover-" + b.name).length : !1
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-lightbox", "a-popover-optional-helpers", "prv:a-capabilities").register("a-dropdown-base-positions", function(b, h, f, c) {
        function d(a) {
            a = a.popover;
            if (a.isVisible() && p) {
                var c = document.body,
                    k = Math.abs(parseInt(c.style.top, 10));
                if (k) {
                    var c = c.clientHeight,
                        n = b.viewport().height,
                        l = a.attrs("initialBodyTop");
                    k > c - n ? (a.attrs("initialBodyTop",
                        k), document.body.style.top = -(c - n) + "px") : l && (document.body.style.top = l)
                }
            }
        }

        function g(a) {
            var b = a.$popover;
            b.find(".a-popover-inner").css("height", "auto");
            d(a);
            b.css({
                width: "auto",
                position: "absolute",
                display: "inline-block"
            });
            var b = a.measure(b, a.$trigger),
                c = .1 * b.windowHeight;
            a = f.getOffsetTopDelta(a, c, l);
            return {
                top: t.scrollY + (c + a),
                left: (b.windowWidth - b.popoverWidth) / 2
            }
        }

        function a(a) {
            var c = a.$popover,
                k = c.find(".a-popover-inner").css("height", "auto"),
                n = c.find(".a-popover-header");
            d(a);
            c.css({
                width: "auto",
                display: "inline-block"
            });
            var c = a.measure(c, a.$trigger),
                g, n = .8 * (b.viewport().height - n.outerHeight());
            g = k.outerHeight();
            f.evaluateActualHeight(a, g, l) > n ? (g = .1 * b.viewport().height, a = f.getOffsetTopDelta(a, g, l), g += a, k.css("height", n - a + "px").addClass("a-lgtbox-vertical-scroll")) : (g = (c.windowHeight - c.popoverHeight) / 2, k.removeClass("a-lgtbox-vertical-scroll"));
            return {
                top: g,
                left: (c.windowWidth - c.popoverWidth) / 2
            }
        }
        h = b.capabilities.isGen5App || c.isAndroidStockGuess && b.capabilities.androidVersion && "4.1" > b.capabilities.androidVersion;
        var p = /Silk|Chrome|(?:UCBrowser\/(?:9|1\d+))/i.test(navigator.userAgent),
            l = 0;
        m.when("prv:skin-vars").execute(function(a) {
            l = a.popover.optionalButtonHeight
        });
        return {
            positionStrategy: h ? g : a
        }
    });
    "use strict";
    m.when("A", "a-dropdown-base-positions").register("a-dropdown-base-view-base", function(b, h) {
        return b.extend(h, {
            updateContent: function(b) {
                "string" === typeof b ? this.$popover.find(".a-popover-inner").html(b) : b && this.$popover.find(".a-popover-inner").html("").append(b)
            },
            beforeShowMethod: function() {
                this.parent.lock(1);
                this.$trigger.attr("aria-pressed", !0)
            },
            afterShowMethod: function() {
                var f = this.$popover,
                    c = f.find(".a-active");
                b.delay(function() {
                    c.length ? c.closest("li").focus() : c = f.find("li").first().focus()
                }, 0)
            },
            beforeHideMethod: function() {
                this.parent.unlock(1)
            },
            afterHideMethod: function() {
                this.$trigger.attr("aria-pressed", !1);
                this.$popover.css("width", "auto")
            }
        })
    });
    "use strict";
    m.when("A", "a-ua", "a-popover-base-factory", "a-dropdown-base-positions", "a-dropdown-base-view-base", "a-popover-animate", "prv:a-capabilities").register("a-dropdown-base-view",
        function(b, h, f, c, d, g, a) {
            function p(a, e) {
                a.$popover.css({
                    opacity: 0,
                    visibility: "visible"
                }).removeClass("a-popover-hidden");
                b.delay(function() {
                    g.animate(a, {
                        opacity: 1
                    }, 500, "linear", function() {
                        e.call(a)
                    })
                }, 0)
            }

            function l(a, e) {
                var c = a.$popover;
                b.delay(function() {
                    z && v.hide();
                    c.css({
                        visibility: "visible"
                    }).removeClass("a-popover-hidden");
                    e.call(a)
                }, 0)
            }

            function e(a, b) {
                var e = a.$popover.find(".a-lgtbox-vertical-scroll");
                a.scrollable = !!e.length;
                a.scrollable || x || e.addClass("a-gesture").bind("tap.a-dropdown", function(a) {
                    n(a.target).trigger("click")
                });
                a.scrollY = t.scrollY;
                a.scrollX = t.scrollX;
                a.scrollY === C && (a.scrollY = t.pageYOffset, a.scrollX = t.pageXOffset);
                A && a.parent && "secondary-view" !== a.parent.type && (n("html, body").css({
                    position: "fixed",
                    overflow: "hidden"
                }), document.body.style.top = -1 * a.scrollY + "px");
                a.$popover.css("visibility", "visible").removeClass("a-popover-hidden");
                x && n(t).bind("scroll.dropdown", function() {
                    var b = parseInt(a.$popover[0].style.top, 10) || 0,
                        e = b + a.$popover.height();
                    t.scrollY + t.innerHeight < b + 50 ? t.scrollTo(a.scrollX, b - 20) : t.scrollY >
                        e - 50 && t.scrollTo(a.scrollX, e - .8 * t.innerHeight)
                });
                b.call(a)
            }

            function u() {
                this.$trigger.attr("aria-pressed", !1);
                this.$popover.css("width", "auto")
            }

            function k() {
                this.$trigger.attr("aria-pressed", !1);
                var a = this.$popover;
                a.css("width", "auto");
                a.find(".a-popover-inner").removeClass("a-gesture").unbind("tap.a-dropdown");
                A && (n("html, body").css({
                    position: "",
                    overflow: ""
                }), document.body.style.top = "0", this.attrs("initialBodyTop", 0));
                (A || q.android && q.isAmazonApp && q.androidVersion && -1 === w(q.androidVersion, "4.4")) &&
                t.scrollTo(this.scrollX, this.scrollY);
                x && n(t).unbind("scroll.dropdown")
            }
            var n = b.$,
                v = n("#a-page"),
                q = b.capabilities,
                w = h.compareVersions,
                m = f.getRoot().id,
                r = a.isIE10Plus && q.mobile,
                z = q.mobile && a.isIE10,
                x = q.isGen5App || a.isAndroidStockGuess && q.androidVersion && -1 === w(q.androidVersion, "4.1"),
                A = a.isChrome || q.tablet && q.ieIE10Plus || q.isAmazonApp && q.androidVersion && -1 < w(q.androidVersion, "4.4");
            return b.extend(c, d, {
                showMethod: function(a) {
                    b.capabilities.ios ? p(this, a) : r ? l(this, a) : e(this, a)
                },
                afterShowMethod: function() {
                    var a =
                        this.$popover,
                        e = a.find(".a-active");
                    b.delay(function() {
                        e.length ? e.closest("li").focus() : (e = a.find("li").first().focus(), q.android && q.isAmazonApp && q.androidVersion && -1 === w(q.androidVersion, "4.4") && e[0].scrollIntoView())
                    }, 25)
                },
                beforeHideMethod: function() {
                    this.parent.unlock(1);
                    if (z) {
                        for (var a = !0, b = this.parent; a && b.id !== m;) b.attrs("lightboxOptions") && (a = !1), b = b.parent;
                        a && v.show()
                    }
                },
                afterHideMethod: q.ios ? u : k
            })
        });
    "use strict";
    m.when("A", "a-popover-base-factory", "a-dropdown-base-view").register("a-dropdown-base-factory",
        function(b, h, f) {
            function c(c, e, g) {
                var k = ['\x3cli tabindex\x3d"0" role\x3d"option"'],
                    n = c.data("aCssClass"),
                    f = c.data("aId"),
                    d = c.data("aHtmlContent"),
                    p = c.data("aImageSource"),
                    h = JSON.stringify({
                        stringVal: c.val()
                    }),
                    h = ['\x3ca tabindex\x3d"-1" href\x3d"javascript:void(0)" data-value\x3d"', b.escapeHtml(h), '"'],
                    r = ["a-dropdown-link"],
                    m = ["a-dropdown-item"];
                e && (r.push("a-active"), k.push(' aria-checked\x3d"true"'));
                a && (b.capabilities.mobile || b.capabilities.tablet) && r.push("a-list-link-after-group");
                a = !1;
                n && m.push(n);
                f && k.push(' id\x3d"' + f + '"');
                k.push('aria-labelledby\x3d"');
                k.push(g);
                k.push('"');
                h.push(' id\x3d"');
                h.push(g);
                h.push('"');
                k.push(' class\x3d"' + m.join(" ") + '"');
                k.push("\x3e");
                d ? e = d : (e = [], p && (r.push("a-option-has-image"), e.push('\x3cimg src\x3d"' + p + '" class\x3d"a-rich-option-image" /\x3e')), e.push(c.html()), e = e.join(""));
                h.push(' class\x3d"');
                h.push(r.join(" "));
                h.push('"\x3e');
                h.push(e);
                h.push("\x3c/a\x3e");
                k.push(h.join(""));
                k.push("\x3c/li\x3e");
                return k.join("")
            }

            function d(b) {
                b.jquery || (b = g(b));
                var e = b.children("optgroup,option:not(.a-prompt)"),
                    f = !1,
                    k = b[0],
                    n = b.attr("id") ? b.attr("id") : "dropdown" + p++,
                    d, h; - 1 < k.selectedIndex && (d = k.options[k.selectedIndex].value);
                h = ['\x3cul tabindex\x3d"-1" class\x3d"a-nostyle a-list-link', b.data("a-has-images") ? " a-box-list" : "", '" role\x3d"listbox" aria-multiselectable\x3d"false"\x3e'];
                var w = 0;
                e.each(function() {
                    var b = g(this);
                    b.is("optgroup") ? (b.children().each(function(a) {
                            h.push(c(g(this), d === this.value, n + "_" + w++))
                        }), h.push('\x3cli tabindex\x3d"-1" class\x3d"divider"\x3e\x3chr /\x3e\x3c/li\x3e'),
                        f = a = !0) : (h.push(c(b, d === this.value, n + "_" + w++)), f = !1)
                });
                f && h.pop();
                h.push("\x3c/ul\x3e");
                return h.join("")
            }
            var g = b.$,
                a = !1,
                p = 1;
            return b.extend({
                create: h.create,
                remove: h.remove,
                get: h.get
            }, {
                type: "dropdown",
                create: function(a, e, c) {
                    var k = e.$button,
                        n = e.$sourceSelect,
                        g = n[0],
                        p = k.find(".a-dropdown-label"),
                        w = n.data("aTouchHeader");
                    if (!w || !w.length && p.length) w = p.text();
                    return h.create(a, {
                        attributes: {
                            type: "dropdown",
                            header: w,
                            closeButtonLabel: e.closeButtonLabel ? e.closeButtonLabel : "Close",
                            inlineContent: n,
                            position: e.position,
                            alone: !0,
                            sourceSelect: n,
                            sourceButton: k,
                            name: n[0].name,
                            preventNameReuse: !0,
                            lightboxOptions: b.capabilities.mobile || b.capabilities.tablet ? {
                                showDuration: b.capabilities.ios ? null : 0,
                                hideDuration: 0
                            } : null
                        },
                        typeSpecificFunctions: b.extend({}, f, c, {
                            skin: function(a) {
                                var b = c.subskin ? c.subskin(g) : d(g);
                                a.attrs("inlineContent", b);
                                return c.skin(a)
                            }
                        }),
                        actionCheck: !1
                    })
                }
            })
        });
    "use strict";
    m.when("A", "prv:a-capabilities").execute("a-dropdown-base-handlers", function(b, h) {
        var f = b.capabilities.tablet && h.isIE10Plus;
        b.declarative("a-popover-scroll",
            b.action.start,
            function(b) {
                b = b.$target.closest(".a-popover-inner")[0];
                if (!f) {
                    var d = b.scrollTop + b.offsetHeight;
                    0 >= b.scrollTop ? b.scrollTop = 1 : b.scrollHeight <= d && --b.scrollTop
                }
            });
        b.declarative("a-popover-header", b.action.move, function(b) {
            b.$event.originalEvent.preventDefault()
        });
        b.declarative("a-popover-scroll", b.action.move, function(b) {
            var f = b.$target.closest(".a-popover-inner");
            b = b.$event.originalEvent;
            f.hasClass("a-lgtbox-vertical-scroll") || b.preventDefault()
        })
    });
    "use strict";
    m.when("A", "a-dropdown-base-factory").register("a-dropdown-keyboard-handlers",
        function(b, h) {
            function f(a) {
                a.removeData("a-user-navigated-text").removeData("a-user-navigated-idx")
            }

            function c(a, b) {
                a.removeAttr("aria-selected");
                "option" === b.attr("role") && b.attr("aria-selected", "true");
                b.focus()
            }

            function d(a) {
                var b = a.parent("ul");
                a = b.find("li");
                var c = b.find(":focus");
                1 > c.length && (c = b.find('[aria-checked\x3d"true"]'));
                b = c;
                return {
                    index: 0 < b.length ? b.index() : 0,
                    $options: a
                }
            }

            function g(a, b, c) {
                a.preventDefault();
                b.find("a").eq(0).trigger("click");
                f(c)
            }

            function a(a) {
                var c = a.data("a-user-navigated-debouncer");
                c || (c = b.debounce(function() {
                    f(a)
                }, 1E3), a.data("a-user-navigated-debouncer", c));
                c()
            }
            var p = b.$,
                l = b.constants.keycodes;
            return {
                keyDown: function(a) {
                    var b = p(this),
                        k = b.parent();
                    switch (a.which) {
                        case l.UP_ARROW:
                            a.preventDefault();
                            f(k);
                            0 < d(b).index && c(b, b.prev());
                            break;
                        case l.DOWN_ARROW:
                            a.preventDefault();
                            f(k);
                            k = d(b);
                            a = k.index;
                            0 <= a && a + 1 < k.$options.length && c(b, b.next());
                            break;
                        case l.ENTER:
                            g(a, b, k);
                            break;
                        case l.ESCAPE:
                            a.preventDefault();
                            b = h.get(b.closest(".a-popover"));
                            b.sourceButton.find(".a-button-text").focus();
                            b.hide();
                            f(k);
                            break;
                        case l.SPACE:
                            k.data("a-user-navigated-text") || g(a, b, k);
                            break;
                        case l.TAB:
                            f(k);
                            break;
                        case l.BACKSPACE:
                            a.preventDefault()
                    }
                },
                keyPress: function(c) {
                    var f = p(this),
                        k = f.parent(),
                        n = h.get(f.closest(".a-popover")),
                        d = c.which;
                    if (n && n.isActive() && d !== l.TAB && 0 !== d) {
                        a(k);
                        var q = k.data("a-user-navigated-idx") || 0;
                        if (!(0 > q)) {
                            n = (k.data("a-user-navigated-text") || "") + String.fromCharCode(d).toLocaleLowerCase();
                            k.data("a-user-navigated-text", n);
                            for (var w = k.children(); q < w.length; q++) {
                                var m = w.eq(q);
                                if (0 ===
                                    b.trim(m.text().toLocaleLowerCase()).indexOf(n)) {
                                    m.focus();
                                    k.data("a-user-navigated-idx", q);
                                    return
                                }
                            }
                            k.data("a-user-navigated-idx", -1);
                            d === l.SPACE && g(c, f, k)
                        }
                    }
                }
            }
        });
    "use strict";
    m.when("A", "a-dropdown-select-apis", "a-dropdown-base-factory", "a-popover-base").register("a-dropdown-base", function(b, h, f, c) {
        function d(c, g, k) {
            try {
                var n = c.$event || c;
                n.preventDefault ? n.preventDefault() : n.returnValue = !1
            } catch (d) {}
            var h = c.$declarativeParent ? c.$declarativeParent : l(c.currentTarget);
            b.delay(function() {
                var n = g.$button ?
                    g.$button : g.getButtonFromEvent(c),
                    d = g.$select ? g.$select : g.getSelectFromEvent(c);
                if (!n.hasClass("a-button-disabled")) {
                    p(d, g).isSynced() || a(l.extend({
                        $button: n,
                        $select: d
                    }, g));
                    var d = b.extend({}, g, {
                            $button: n,
                            $sourceSelect: d
                        }),
                        m = f.create(h, d, k);
                    if (m && (m.show(), n.data("a-popover-id", m.id).data("popover", m).data("isPressed", !0), !m.hasOnLoad)) {
                        m.hasOnLoad = !0;
                        var r = [],
                            n = m.$popover.find("img");
                        n.length && (n.each(function(a, b) {
                            if (!b.complete || !b.naturalWidth) {
                                var c = l.Deferred();
                                r.push(c);
                                l(b).bind("load error",
                                    function() {
                                        c.resolve()
                                    })
                            }
                        }), r.length ? l.when.apply(l, r).done(function() {
                            m.updatePosition()
                        }) : m.updatePosition())
                    }
                }
            })
        }

        function g(a) {
            var b = a.$button;
            a = a.$select;
            b || (b = a.nextAll(".a-button-dropdown"));
            return a.length ? ((b = f.get(b)) && b.hide(), !0) : !1
        }

        function a(a) {
            var b = a.$button;
            a = a.$select;
            b || (b = a.nextAll(".a-button-dropdown"));
            return a.length ? ((b = f.get(b)) && f.remove(b.id), a.data("a-info", null), !0) : !1
        }

        function p(c, f) {
            var k;
            c = f.$select ? f.$select : "string" === typeof c ? l("select#" + c) : c.jquery ? c : l(c);
            if (!c.length) return null;
            k = f.$button ? f.$button : f.getButtonFromSelect(c);
            c.data("a-select") ? f = c.data("a-select") : (f = b.extend({
                hidePopover: g,
                refreshPopover: a,
                options: b.extend({
                    $select: c,
                    $button: k
                }, f)
            }, h), c.data("a-select", f));
            return f
        }
        var l = b.$;
        return {
            toggleDropdown: function(a, b) {
                var c = (b.$button ? b.$button : b.getButtonFromEvent(a)).data("popover");
                c && c.$popover.is(":visible") ? c.hide() : d(a, b)
            },
            showDropdown: d,
            getSelect: p
        }
    });
    "use strict";
    m.when("A", "jQuery").register("a-dropdown-options-apis", function(b, h) {
        return {
            update: function(b) {
                "object" !==
                typeof b && m.error("input of options.update() function must be a hash");
                this.hidePopover(this.options);
                for (var c = 0, d = this.size(); c < d; c++) {
                    var g = this.options.elements[c],
                        a = g[0];
                    b.value && g.val(b.value);
                    void 0 !== b.selected && (!a.selected && b.selected ? this.options.$select.val(a.value) : a.selected && !b.selected && this.options.$select.val(""));
                    b.html_content && g.data("a-html-content", b.html_content);
                    b.image_source && g.data("a-image-source", b.image_source);
                    b.native_css_class && (a.className = b.native_css_class);
                    b.css_class &&
                        g.data("a-css-class", b.css_class);
                    b.native_id && (a.id = b.native_id);
                    b.id && g.data("a-id", b.id);
                    b.text && (g.text(b.text), a.selected && this.setSelectValue(a.value))
                }
                this.refreshPopover(this.options);
                return this
            },
            remove: function() {
                this.hidePopover(this.options);
                for (var b = 0, c = this.size(); b < c; b++) {
                    var d = this.options.elements[b];
                    d.is(":selected") && this.setSelectValue("");
                    d.remove()
                }
                this.refreshPopover(this.options);
                return !0
            },
            info: function() {
                for (var b = [], c = 0, d = this.size(); c < d; c++) {
                    var g = this.options.elements[c];
                    b.push({
                        value: g[0].value,
                        text: g.text(),
                        selected: g[0].selected,
                        html_content: g.data("a-html-content"),
                        image_source: g.data("a-image-source"),
                        native_css_class: g[0].className,
                        css_class: g.data("a-css-class"),
                        native_id: g[0].id,
                        id: g.data("a-id")
                    })
                }
                return b
            },
            size: function() {
                return this.options.elements.length
            }
        }
    });
    "use strict";
    m.when("A", "jQuery", "a-dropdown-options-apis").register("a-dropdown-select-apis", function(b, h, f) {
        function c(a) {
            var b = this.options.$select,
                c = this.options.$button,
                e = b[0];
            "number" === typeof a &&
                (a = a.toString());
            for (var d = 0, k = e.options.length; d < k && e.options[d].value !== a; d++);
            d === k && "" === a && (d = 0);
            d < k && (c.find(".a-dropdown-prompt").html(e.options[d].innerHTML), c.css("min-width", d / e.options.length + "%"), b.val() !== a && (b.val(a), b.trigger("change", [g, !0])));
            return this
        }

        function d(a) {
            if (a === g) return this.options.$select.val();
            this.setValue = c;
            return this.setValue(a)
        }
        var g;
        return {
            isSynced: function() {
                var a = this.options.$select,
                    c = a.data("a-info"),
                    g = this.getOptions().info();
                a.data("a-info", g);
                return c ?
                    b.equals(c, g) : !0
            },
            update: function(a) {
                "object" !== typeof a && m.error("input of select.update() function must be an object");
                this.hidePopover(this.options);
                var b = {
                        none: !0,
                        micro: !0,
                        mini: !0,
                        small: !0,
                        base: !0,
                        medium: !0,
                        large: !0,
                        "extra-large": !0,
                        "double-large": !0,
                        block: !0
                    },
                    c = this.options.$select,
                    e = c[0],
                    d = this.options.$button,
                    k = d[0],
                    n = c.siblings("label");
                a.name && (e.name = a.name);
                if (a.option_prompt) {
                    var f = c.find(".a-prompt");
                    f.length ? (f.text(a.option_prompt), f.prop("selected") && d.find(".a-dropdown-prompt").text(a.option_prompt)) :
                        (c.prepend(h("\x3coption class\x3d'a-prompt' /\x3e").text(a.option_prompt)), d.find(".a-dropdown-prompt").text(a.option_prompt))
                }
                a.has_images !== g && c.data("a-has-images", !!a.has_images);
                a.button_size !== g && d.length && ("small" === a.button_size ? d.addClass("a-button-small") : d.removeClass("a-button-small"));
                a.spacing !== g && b.hasOwnProperty(a.spacing) && (b = /\ba-spacing-[a-z]+\b/g, e.className = e.className.replace(b, ""), k.className = k.className.replace(b, ""), c.addClass("a-spacing-" + a.spacing), d.addClass("a-spacing-" +
                    a.spacing));
                a.grid_units !== g && (b = /\ba-button-span\d{1,2}\b/g, e.className = e.className.replace(b, ""), k.className = k.className.replace(b, ""), isFinite(a.grid_units) && 0 < a.grid_units && 13 > a.grid_units && (c.addClass("a-button-span" + a.grid_units), d.addClass("a-button-span" + a.grid_units)));
                a.width_name && ("base" === a.width_named ? d.addClass("a-button-width-normal") : d.removeClass("a-button-width-normal"));
                if (a.status) {
                    var q = a.status,
                        b = d.closest(".a-dropdown-container, .a-splitdropdown-container").find(".a-button"),
                        f = "error" === q,
                        q = "disabled" === q;
                    e.disabled = q;
                    b.toggleClass("a-button-disabled", q);
                    q ? b.attr("aria-disabled", "true") : b.removeAttr("aria-disabled");
                    b.toggleClass("a-button-error", f)
                }
                a.native_id && (e.id = a.native_id, n.length && (n[0].htmlFor = a.native_id));
                a.id && (k.id = a.id);
                a.native_css_class && ((k = c.data("a-native-class")) && c.removeClass(k), c.addClass(a.native_css_class).data("a-native-class", a.native_css_class));
                a.css_class && ((k = d.data("a-class")) && d.removeClass(k), d.addClass(a.css_class).data("a-class", a.css_class));
                a.label_text !== g && ("" === a.label_text ? (d.find(".a-dropdown-label").remove(), c.siblings("label").remove()) : (k = d.find(".a-dropdown-label"), k.length ? k.text(a.label_text) : d.find(".a-dropdown-prompt").before(h("\x3cspan class\x3d'a-dropdown-label' /\x3e").text(a.label_text)), n.length ? n.text(a.label_text) : c.before(h("\x3clabel for\x3d'" + e.id + "' class\x3d'a-native-dropdown' /\x3e").text(a.label_text))), d.css("min-width", "" === a.label_text ? "0.1%" : "0%"));
                this.refreshPopover(this.options);
                return this
            },
            setValue: c,
            val: d,
            getOptions: function(a) {
                var c = this.options.$select,
                    l = [];
                a = a === g ? c.children("optgroup, option:not(.a-prompt)") : h.isArray(a) ? a : [a];
                for (var e = 0, m = a.length; e < m; e++) {
                    var k = a[e],
                        n = [];
                    b.isFiniteNumber(k) ? n = c.children("optgroup, option:not(.a-prompt)").eq(k) : "string" === typeof k ? n = c.children("option#" + k) : "object" === typeof k && (n = k.jquery ? k : h(k));
                    n.length && l.push(n)
                }
                return b.extend({
                        hidePopover: this.hidePopover,
                        refreshPopover: this.refreshPopover,
                        setSelectValue: d,
                        options: b.extend({
                            elements: l
                        }, this.options)
                    },
                    f)
            },
            getOption: function(a) {
                return this.getOptions(a)
            },
            addOptions: function(a, b) {
                h.isArray(a) || (a = [a]);
                for (var c = a.length; c--;) this.addOption(a[c], b);
                return this
            },
            addOption: function(a, b) {
                var c = this.options.$select;
                if (!a.native_id || !c.find("option#" + a.native_id).length) {
                    var e = c.children("optgroup, option:not(.a-prompt)"),
                        g = document.createElement("option");
                    b = b && 0 < b && b <= e.length ? b : 0;
                    a.native_id && (g.id = a.native_id);
                    0 === e.length || b === e.length ? c[0].appendChild(g) : e.eq(b).before(g);
                    this.getOption(g).update(a)
                }
                return this
            },
            removeOptions: function(a) {
                this.getOptions(a).remove();
                return this
            },
            removeOption: function(a) {
                return this.removeOptions(a)
            },
            appendOption: function(a) {
                return this.addOption(a, this.options.$select.children("optgroup, option:not(.a-prompt)").length)
            },
            appendOptions: function(a) {
                if (h.isArray(a))
                    for (var b = 0, c = a.length; b < c; b++) this.addOption(a[b]);
                return this
            }
        }
    });
    "use strict";
    m.when("A", "a-dropdown-options", "a-dropdown-apis", "a-dropdown-keyboard-handlers", "a-analytics").register("a-dropdown", function(b, h, f,
        c, d) {
        var g = b.$,
            a = g(document);
        b.on("beforeReady a:pageUpdate a:ajax:complete", function() {
            var b = a.find("select.a-native-dropdown").not("[tabindex\x3d0]"),
                c = b.length;
            c && (a.find(".a-button-dropdown").attr("aria-hidden", !0).find(".a-button-text").removeAttr("tabindex"), d.count("dropdown:usage", c), b.attr("tabindex", 0))
        });
        a.delegate(".a-native-dropdown", "change", function(a, c, e) {
            var d = h.getButtonFromEvent(a),
                k = "",
                n = -1 < this.selectedIndex ? this.options[this.selectedIndex].value : "",
                v = d.data("popover");
            a = !1;
            var q;
            if (d.length) {
                for (var d = d.eq(0), m = this.length; m--;)
                    if (q = this.options[m], q.value === n) {
                        k = q.innerHTML;
                        break
                    }
                v && v.$popover && (v.$popover.find(".a-active").removeClass("a-active").closest("li").attr("aria-checked", !1), void 0 === c && (c = JSON.stringify({
                    stringVal: n
                }), c = v.$popover.find('a[data-value\x3d"' + b.escapeJquerySelector(c) + '"]')));
                c && c.length && (a = !0, c.addClass("a-active").closest("li").attr("aria-checked", !0));
                d.find(".a-dropdown-prompt").html(k);
                d.css("min-width", this.selectedIndex / this.options.length +
                    "%");
                v && (v.hide(), (d = f.getSelect(this)) && g(this).data("a-info", d.getOptions().info()));
                e || (e = this.name, d = this.id, c = {
                    auiItemNode: a ? c[0] : null,
                    nativeItemNode: this.options[this.selectedIndex],
                    selectNode: this,
                    id: d,
                    name: e,
                    value: this.value
                }, e && "" !== e && (b.trigger("a:dropdown:" + e + ":select", c), b.trigger("a:dropdown:selected:" + e, c)), d && "" !== d && b.trigger("a:dropdown:" + d + ":select", c), b.trigger("a:dropdown:select", c))
            }
        });
        a.delegate(".a-button-dropdown:not(.a-button-disabled)", "focusin", function() {
            g(this).find(".a-button-text").focus()
        });
        a.delegate("select.a-native-dropdown", "focusin", function() {
            var a = g(this).closest(".a-dropdown-container").find(".a-button-dropdown");
            a.hasClass("a-button-disabled") || a.addClass("a-button-focus")
        }).delegate("select.a-native-dropdown", "focusout", function() {
            g(this).closest(".a-dropdown-container").find(".a-button-dropdown").removeClass("a-button-focus")
        });
        return f
    });
    "use strict";
    m.when("A", "a-dropdown-base", "a-dropdown-options").register("a-dropdown-apis", function(b, h, f) {
        function c(b) {
            return h.getSelect(b,
                f)
        }
        var d = b.$;
        b.on("beforeReady", function() {
            d(".a-dropdown-container select").each(function() {
                var b = c(this);
                b && b.val(b.val())
            })
        });
        return {
            getSelect: c,
            updateOption: function(b, a) {
                var f = d("option#" + b).closest("select");
                c(f).getOption(b).update(a)
            },
            updateSelect: function(b, a) {
                c(b).update(a)
            },
            setValue: function(b, a) {
                c(b).setValue(a)
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-accessibility", "a-ua", "prv:a-capabilities").register("a-dropdown-view", function(b, h, f, c) {
        b = b.capabilities;
        f = b.isGen5App || c.isAndroidStockGuess &&
            b.androidVersion && -1 === f.compareVersions(b.androidVersion, "4.1");
        var d = b.isAndroid ? "a-scrollbar-fix" : "",
            g, a;
        f ? (g = function() {
            return '\x3cdiv class\x3d"a-popover-header"\x3e'
        }, a = function() {
            return '\x3cdiv class\x3d"a-popover-inner ' + d + '"\x3e'
        }) : (g = function() {
            return '\x3cdiv data-action\x3d"a-popover-header" class\x3d"a-popover-header a-declarative"\x3e'
        }, a = function() {
            return '\x3cdiv data-action\x3d"a-popover-scroll" class\x3d"a-popover-inner a-declarative ' + d + '"\x3e'
        });
        return {
            skin: function(b) {
                var c = b.attrs("header") ||
                    "",
                    e = b.attrs("closeButtonLabel");
                b = b.id;
                var d = {
                    id: b,
                    header_str: c,
                    needs_declarative: !1
                };
                return ['\x3cdiv class\x3d"a-popover a-dropdown a-dropdown-common a-declarative" data-action\x3d"a-popover-a11y"\x3e', h.getStartAnchorHtml(d), '\x3cdiv class\x3d"a-popover-wrapper"\x3e', g(), '\x3ch4 id\x3d"a-popover-header-', b, '" class\x3d"a-popover-header-content"\x3e', c, '\x3c/h4\x3e\x3cbutton data-action\x3d"a-popover-close" class\x3d"a-button-close a-declarative" aria-label\x3d"', e + '"\x3e', '\x3ci class\x3d"a-icon a-icon-close"\x3e\x3c/i\x3e\x3c/button\x3e\x3c/div\x3e',
                    a(), "\x3c/div\x3e\x3c/div\x3e", h.getEndAnchorHtml(d), "\x3c/div\x3e"
                ].join("")
            }
        }
    });
    "use strict";
    m.when("A", "a-dropdown-base", "a-dropdown-view", "a-dropdown-options", "a-dropdown-apis", "a-dropdown-base-factory", "a-dropdown-keyboard-handlers").register("a-dropdown-handlers", function(b, h, f, c, d, g, a) {
        var p = b.$;
        d = p(document);
        b.declarative("a-dropdown-button", "click", function(a) {
            c.getSelectFromButton(a.$target).trigger("click")
        });
        d.delegate("select.a-native-dropdown", "keydown", function(a) {
            var e = b.constants.keycodes,
                d = a.which,
                k = p(a.target).nextAll(".a-button-dropdown").eq(0);
            if (b.onScreen(k) && (d === e.UP_ARROW || d === e.DOWN_ARROW || d === e.ENTER || d === e.SPACE)) {
                var n = p(a.target);
                n.prop("disabled", !0);
                b.delay(function() {
                    n.prop("disabled", !1)
                }, 0);
                a.preventDefault ? a.preventDefault() : a.returnValue = !1;
                h.showDropdown(a, b.extend({
                    $button: k
                }, c), f)
            }
        });
        d.delegate("select.a-native-dropdown", "click", function(a) {
            a.preventDefault ? a.preventDefault() : a.returnValue = !1;
            var e = p(a.target).nextAll(".a-button-dropdown").eq(0);
            b.onScreen(e) &&
                h.showDropdown(a, b.extend({
                    $button: e
                }, c), f)
        });
        d.delegate(".a-popover.a-dropdown a", "click", function(a) {
            a.preventDefault();
            a = p(this);
            var b = g.get(a.closest(".a-popover"));
            if (a.hasClass("a-active")) b.hide();
            else {
                var c = a.data("value").stringVal;
                b.sourceSelect.val(c).trigger("change", [a])
            }
        });
        a && (a.keyDown && d.delegate(".a-dropdown li", "keydown", a.keyDown), a.keyPress && d.delegate(".a-dropdown li", "keypress", a.keyPress))
    });
    "use strict";
    m.when("A").register("a-dropdown-options", function(b) {
        function h(b) {
            return b.nextAll(".a-button-dropdown")
        }
        var f = b.$;
        return {
            getSelectFromButton: function(b) {
                return b.closest(".a-button-dropdown").prevAll("select.a-native-dropdown")
            },
            getButtonFromEvent: function(b) {
                return b.popover ? b.popover.$trigger.nextAll(".a-button-dropdown") : b.$target ? h(b.$target) : f(b.target).nextAll(".a-button-dropdown")
            },
            getButtonFromSelect: h,
            getSelectFromEvent: function(b) {
                b = f(b.target);
                b.length || m.error("Cannot locate the \x3cselect\x3e of dropdown");
                return b
            },
            triggerSelector: ".a-button-dropdown"
        }
    });
    "use strict";
    m.when("A", "a-popover-accessibility").register("a-dropdown-split-view",
        function(b, h) {
            return {
                skin: function(b) {
                    var c = b.attrs("header") || "";
                    b = {
                        id: b.id,
                        label_str: c,
                        needs_declarative: !1
                    };
                    return ['\x3cdiv class\x3d"a-popover a-splitdropdown a-dropdown-common a-declarative" data-action\x3d"a-popover-a11y"\x3e', h.getStartAnchorHtml(b), '\x3cdiv class\x3d"a-popover-wrapper"\x3e\n\x3cdiv data-action\x3d"a-popover-scroll" class\x3d"a-popover-inner a-declarative"\x3e\x3c/div\x3e\n\x3c/div\x3e', h.getEndAnchorHtml(b), "\x3c/div\x3e"].join("\n")
                }
            }
        });
    "use strict";
    m.when("A", "a-dropdown-base",
        "a-dropdown-split-utils", "a-dropdown-split-view", "a-dropdown-split-options", "a-dropdown-base-factory", "a-dropdown-keyboard-handlers", "prv:a-tnr").register("a-dropdown-split-handlers", function(b, h, f, c, d, g, a, p) {
        var l = b.$;
        b.declarative("a-splitdropdown-button", "click", function(a) {
            p.ackDeclarative(a);
            var g = d.getButtonFromEvent(a);
            h.showDropdown(a, b.extend({
                $button: g
            }, d), c)
        });
        b.declarative("a-splitdropdown-main", "click", function(a) {
            p.ackDeclarative(a);
            var b = a.$target.closest(".a-splitdropdown-container").find("select"),
                c = b.attr("id"),
                n = b.val();
            f.triggerEvent(c, b, n);
            a.$event.preventDefault()
        });
        b.declarative("a-splitdropdown-button", "keydown", function(a) {
            p.ackDeclarative(a);
            var g = d.getButtonFromEvent(a),
                k = b.constants.keycodes,
                n = a.$event.which;
            n !== k.DOWN_ARROW && n !== k.ENTER && n !== k.SPACE || h.showDropdown(a, l.extend({
                $button: g
            }, d), c)
        });
        l(document).delegate(".a-popover.a-splitdropdown a", "click", function(a) {
            p.ackDelegated(a);
            var b = l(this),
                c = b.data("value").stringVal,
                b = g.get(b.closest(".a-popover")),
                n = b.sourceSelect,
                d = n.attr("id");
            b.hide();
            f.triggerEvent(d, n, c);
            a.preventDefault()
        }).delegate(".a-splitdropdown li", "keydown", a.keyDown).delegate(".a-splitdropdown li", "keypress", a.keyPress)
    });
    "use strict";
    m.when("A").register("a-dropdown-split-options", function(b) {
        function h(b) {
            return b.popover ? b.popover.$trigger.closest(".a-button-splitdropdown") : b.$target ? b.$target.closest(".a-button-splitdropdown") : f(b.target).nextAll(".a-button-splitdropdown")
        }
        var f = b.$;
        return {
            getButtonFromEvent: h,
            getButtonFromSelect: function(b) {
                return b.next(".a-button-group-splitdropdown").find(".a-button-splitdropdown")
            },
            getSelectFromEvent: function(b) {
                b = h(b).closest(".a-splitdropdown-container").find("select");
                b.length || m.error("cannot locate the \x3cselect\x3e of the split dropdown");
                return b
            }
        }
    });
    "use strict";
    m.when("A").register("a-dropdown-split-utils", function(b) {
        return {
            triggerEvent: function(h, f, c) {
                f = {
                    $select: f,
                    value: c,
                    id: h
                };
                b.trigger("a:splitdropdown:" + h + ":select", f);
                b.trigger("a:splitdropdown:select", f)
            }
        }
    });
    "use strict";
    m.when("A", "a-dropdown-base", "a-dropdown-split-options", "a-dropdown-split-utils", "a-dropdown-split-handlers",
        "a-analytics").register("a-splitdropdown", function(b, h, f, c, d, g) {
        var a = b.$,
            p = a(document);
        b.on("a:pageUpdate beforeReady", function() {
            if ((b.capabilities.mobile || b.capabilities.tablet) && !b.capabilities.touchScrolling) {
                p.find("select.a-native-splitdropdown").removeAttr("tabindex").removeAttr("aria-hidden");
                var c = p.find(".a-splitdropdown-container label.a-native-dropdown");
                b.each(c, function(b) {
                    a(b).attr("for", a(b).nextAll("select.a-native-splitdropdown").attr("id") || "")
                })
            }
        });
        p.delegate(".a-native-splitdropdown",
            "change",
            function(b, d, g) {
                b = a(this);
                d = b.val();
                var k = b.attr("id");
                g || c.triggerEvent(k, b, d)
            }).delegate(".a-button-splitdropdown:not(.a-button-disabled)", "focusin", function() {
            a(this).find(".a-button-text").focus()
        });
        return {
            getSelect: function(a) {
                return h.getSelect(a, f)
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-accessibility-templates").register("a-popover-accessibility", function(b, h) {
        var f = h.startAnchorTemplate,
            c = h.startAnchorDeclarativeTemplate,
            d = h.endAnchorTemplate,
            g = h.descriptionTemplate,
            a = h.offscreenDescriptionTemplate,
            p = h.labelTemplate,
            l = h.offscreenStartTemplate,
            e = function(a, b) {
                var c = {
                    "{{DESCRIPTION}}": b,
                    "{{DESCRIPTION_ID}}": a
                };
                return g.replace(/\{\{[\w_]*\}\}/g, function(a) {
                    return c[a]
                })
            },
            m = function(a) {
                var b = a.id,
                    c = a.header_str;
                return (a = a.label_str) ? 'aria-label\x3d"' + a + '"' : c ? 'aria-labelledby\x3d"a-popover-header-' + b + '"' : ""
            },
            k = function(b, c) {
                var k = {
                    "{{DESCRIPTION}}": c,
                    "{{DESCRIPTION_ID}}": b
                };
                return a.replace(/\{\{[\w_]*\}\}/g, function(a) {
                    return k[a]
                })
            };
        return {
            getAriaLabelledByDescribedby: function(a) {
                var b = a.id,
                    c =
                    a.header_str,
                    k = a.aria_description,
                    d = "";
                a.label_str ? d = 'aria-labelledby\x3d"a-popover-label-' + b + '"' : c && (d = 'aria-labelledby\x3d"a-popover-header-' + b + '"');
                k && (d += ' aria-describedby\x3d"a-popover-aria-description-' + b + '"');
                return d
            },
            getPopoverLabelHtml: function(a) {
                var b = "",
                    c = a.id;
                if (a = a.label_str) var k = {
                        "{{LABEL}}": a,
                        "{{LABEL_ID}}": "a-popover-label-" + c
                    },
                    b = p.replace(/\{\{[\w_]*\}\}/g, function(a) {
                        return k[a]
                    });
                return b
            },
            getStartAnchorHtml: function(a) {
                var k = a.id,
                    d = a.label_str,
                    g = a.aria_description,
                    h = "";
                if (!k) return "";
                var l = {
                    "{{ROLE}}": 'role\x3d"dialog"',
                    "{{ANCHOR_NAME}}": "a-popover-start",
                    "{{ARIA_LABEL}}": m(a),
                    "{{LABEL_STR}}": d || "",
                    "{{ARIA_DESCRIBEDBY}}": ""
                };
                a = a.needs_declarative ? c : f;
                g && (k = "a-popover-aria-description-" + k, l["{{ARIA_DESCRIBEDBY}}"] = 'aria-describedby\x3d"' + k + '"', h = e(k, g));
                b.capabilities.ios && (l["{{ROLE}}"] = "");
                a = a.replace(/\{\{[\w_]*\}\}/g, function(a) {
                    return l[a]
                }) + h;
                b.capabilities.ios && (a = a.replace(/span/g, "button"));
                return a.replace(/\s\s>|\s>/g, "\x3e")
            },
            getEndAnchorHtml: function(a) {
                a = d;
                b.capabilities.ios &&
                    (a = a.replace(/span/g, "button"));
                return a
            },
            getDescription: function(a) {
                var b = "",
                    c = a.id;
                (a = a.aria_description) && (b = k("a-popover-aria-description-" + c, a));
                return b
            },
            getStartAnchorSimplifiedHtml: function() {
                var a = l;
                b.capabilities.ios && (a = a.replace(/span/g, "button"));
                return a
            }
        }
    });
    "use strict";
    m.declare("a-popover-accessibility-templates", {
        startAnchorTemplate: '\x3cspan tabindex\x3d"0" {{ROLE}} class\x3d"{{ANCHOR_NAME}} a-popover-a11y-offscreen" {{ARIA_LABEL}} {{ARIA_DESCRIBEDBY}}\x3e{{LABEL_STR}}\x3c/span\x3e',
        startAnchorDeclarativeTemplate: '\x3cspan tabindex\x3d"0" {{ROLE}} data-action\x3d"a-popover-a11y" class\x3d"{{ANCHOR_NAME}} a-popover-a11y-offscreen a-declarative" {{ARIA_LABEL}} {{ARIA_DESCRIBEDBY}}\x3e{{LABEL_STR}}\x3c/span\x3e',
        endAnchorTemplate: '\x3cspan tabindex\x3d"0" class\x3d"a-popover-end a-popover-a11y-offscreen"\x3e\x3c/span\x3e',
        descriptionTemplate: '\x3cspan id\x3d"{{DESCRIPTION_ID}}" class\x3d"a-popover-a11y-offscreen"\x3e{{DESCRIPTION}}\x3c/span\x3e',
        offscreenDescriptionTemplate: '\x3cspan id\x3d"{{DESCRIPTION_ID}}" class\x3d"a-popover-a11y-offscreen" aria-hidden\x3d"true"\x3e{{DESCRIPTION}}\x3c/span\x3e',
        labelTemplate: '\x3cspan id\x3d"{{LABEL_ID}}" class\x3d"a-popover-a11y-offscreen" aria-hidden\x3d"true"\x3e{{LABEL}}\x3c/span\x3e',
        offscreenStartTemplate: '\x3cspan tabindex\x3d"0" class\x3d"a-popover-start a-popover-a11y-offscreen"\x3e\x3c/span\x3e'
    });
    "use strict";
    m.when("A", "a-popover-util").register("a-popover-ajax", function(b, h) {
        return {
            update: function(b, c, d) {
                var g = {};
                g.url = c;
                d.timeout && (g.timeout = d.timeout);
                d.ajaxFailMsg && (g.ajaxFailMsg = d.ajaxFailMsg);
                d.cache && (g.cache = d.cache);
                b.update(g)
            },
            showSpinner: function(b) {
                return h.showSpinner(b)
            }
        }
    });
    "use strict";
    m.when("A").register("a-popover-animate", function(b) {
        function h(c, d) {
            return function() {
                b[c].apply(b, d)
            }
        }

        function f(b, d) {
            return function() {
                b._isAnimating = !1;
                d && d()
            }
        }
        return {
            isAnimating: function(b) {
                return b._isAnimating
            },
            animate: function(c, d, g, a, p) {
                c._isAnimating = 0 < g;
                b.animationFrameDelay(h("animate", [c.$popover, d, g, a, f(c, p)]))
            },
            fadeOut: function(c, d, g, a) {
                c._isAnimating = 0 < d;
                b.animationFrameDelay(h("fadeOut", [c.$popover, d, g, f(c, a)]))
            },
            fadeIn: function(c, d, g, a) {
                c._isAnimating = 0 < d;
                b.animationFrameDelay(h("fadeIn", [c.$popover, d, g, f(c, a)]))
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-util", "a-popover-inline-strategy", "a-popover-preload-strategy", "a-popover-ajax-strategy").register("a-popover-data", function(b, h, f, c, d) {
        var g = [d, c, f];
        return {
            guessStrategyByAttrs: function(a) {
                for (var b = 0, c = g.length; b < c; b++) {
                    var d = g[b];
                    if (d.isValidStrategy(a)) return d
                }
            },
            getStrategyByName: function(a) {
                for (var b = 0, c = g.length; b < c; b++) {
                    var d = g[b];
                    if (d.name === a) return d
                }
                return null
            },
            showSpinner: h.showSpinner
        }
    });
    "use strict";
    m.when("A", "a-popover-lightbox-markup",
        "a-timing-analytics", "prv:a-capabilities", "ready").register("a-popover-lightbox", function(b, h, f, c) {
        function d(a) {
            a.preventDefault();
            a.stopPropagation();
            a.stopImmediatePropagation();
            return !1
        }

        function g() {
            B.bind("click", d);
            m.when("a-event-analytics").execute(function(a) {
                a.notifyJquery(B, "click")
            });
            w = !0
        }

        function a() {
            B.unbind("click", d);
            w = !1
        }

        function p(c) {
            var k = l(t); - 1 < z || !r || (c = c || {}, g(), "number" !== typeof c.hideDuration && (c.hideDuration = 250), 0 < c.hideDuration ? b.fadeOut(r, c.duration, "linear", function() {
                c.lockScroll &&
                    (l("html, body").css("overflow", ""), l("body").css("margin-right", ""), b.delay(function() {
                        0 < x && (k.scrollTop(x), x = -1);
                        0 < A && (k.scrollLeft(A), A = -1)
                    }, 100));
                y = null
            }) : (r.css("display", "none"), c.lockScroll && (l("html, body").css("overflow", ""), l("body").css("margin-right", ""), 0 < x && (k.scrollTop(x), x = -1)), y = null), r.css({
                height: "",
                width: ""
            }), b.delay(a, c.hideDuration + 350), l("#a-page").removeAttr("aria-hidden"))
        }
        var l = b.$,
            e = -1 < document.documentElement.className.indexOf("-ie"),
            u = c.isIE10Plus && b.capabilities.mobile,
            k = 0 === (b.capabilities.androidVersion + "").indexOf("4."),
            n = c.isUCBrowser,
            v = h.id,
            q = h.div,
            w = !1,
            B = l("body"),
            r = null,
            z = -1,
            x = -1,
            A = -1,
            y = null;
        l(document).delegate("#" + v, "click " + b.action.start + " " + b.action.move, function(a) {
            a.preventDefault()
        });
        b.declarative("a-popover-floating-close", b.capabilities.touch ? b.action.end : "click", function(a) {
            !w && a.$target.data("action") && -1 < a.$target.data("action").indexOf("a-popover-floating-close") && (y && y.isActive() ? (y.unlock().hide(), a.$event.preventDefault()) : p())
        });
        if (c.isiOS8) b.on("a:popover:afterUpdatePosition",
            function(a) {
                a = a.popover;
                var b = l("#" + v),
                    c = b.length ? b.offset().top : -1,
                    k = l(t),
                    d, g;
                a.isActive() && a.attrs("lightboxOptions") && c && (d = 0, g = setInterval(function() {
                    k.scrollTop(c);
                    5 < ++d && clearInterval(g)
                }, 200))
            });
        f.stopWidgetLogging("dropdown");
        return {
            show: function(c) {
                l("#a-page").attr("aria-hidden", "true");
                var d = l(t);
                r || (l("body").append(q), r = l("#" + v));
                c = c || {};
                g();
                c.lockScroll && (-1 === x && (x = d.scrollTop(), A = d.scrollLeft()), b.setCssImportant(l("body"), "margin-right", b.scrollBarWidth() + "px"), u || (e ? l("html, body").css("overflow",
                    "hidden") : l("body").css("overflow", "hidden")));
                var f = (y = c.popover || null) ? y.$popover.css("z-index") - 2 : -1;
                0 < f && (r.css("z-index", f), k && d.width());
                "number" !== typeof c.showDuration && (c.showDuration = 200);
                n && y.$popover.css("overflow", "auto");
                0 < c.showDuration ? b.fadeIn(r, c.showDuration) : r.css("display", "block");
                b.delay(a, c.showDuration + 300)
            },
            hide: p,
            lock: function(a) {
                a || (a = 10);
                z < a && (z = a)
            },
            unlock: function(a) {
                a || (a = 10);
                z <= a && (z = -1)
            },
            LIGHTBOX_ID: v
        }
    });
    m.declare("a-popover-lightbox-markup", {
        id: "a-popover-lgtbox",
        div: '\x3cdiv id\x3d"a-popover-lgtbox" class\x3d"a-declarative" data-action\x3d"a-popover-floating-close" /\x3e'
    });
    "use strict";
    m.when("A", "ready").register("a-popover-navigate", function(b) {
        function h(a) {
            "string" === typeof a && (g = !0, t.location.hash = a);
            return t.location.hash || ""
        }
        var f = b.$,
            f = f(t),
            c = [],
            d = [],
            g = !1,
            a = {},
            p = !1;
        d.push(h());
        f.bind("hashchange", function(c) {
            c.preventDefault();
            p ? p = !1 : d.push(h());
            32 <= d.length && d.shift();
            g ? g = !1 : b.trigger("a:popover:navigate", a[d[d.length - 1]])
        });
        b.on("a:popover:navigate",
            function(a) {
                a ? a.show({
                    preventNavigate: !0
                }) : (a = 0 <= c.length - 1 ? c[c.length - 1] : null) && a.unlock().hide({
                    preventNavigate: !0
                })
            });
        b.on("a:popover:showNavigable a:popover:showNavigableLegacy", function(a) {
            c.push(a.popover)
        });
        b.on("a:popover:hideNavigable a:popover:hideNavigableLegacy", function(a) {
            c.pop()
        });
        return {
            forward: function(c) {
                var d = c.name + "_" + b.now();
                a["#" + d] = c;
                h(d)
            },
            back: function() {
                0 < d.length && d.pop();
                p = !0;
                t.history.back()
            }
        }
    });
    "use strict";
    m.when("A", "prv:a-capabilities").register("a-popover-position",
        function(b, h) {
            function f() {
                if (1 === b.viewport().zoom) return {
                    top: 0,
                    left: 0
                };
                l || (l = p('\x3cspan id\x3d"a-popover-offset-tracker"\x3e\x3c/span\x3e'), p("body").prepend(l));
                var a;
                p.withoutRtl(function() {
                    a = l.offset()
                });
                return a
            }

            function c(a, c) {
                var d = b.viewport(),
                    g = f(),
                    h, l;
                p.withoutRtl(function() {
                    h = c.offset();
                    l = a.offset()
                });
                if (u) {
                    var r = t.pageYOffset - document.documentElement.scrollTop;
                    h.top -= r;
                    l.top -= r
                }
                h.top -= g.top;
                h.left -= g.left;
                l.top -= g.top;
                l.left -= g.left;
                var r = c[0].getBoundingClientRect(),
                    r = r.right - r.left,
                    m = c.outerHeight(),
                    x = a.outerWidth(!0),
                    A = a.outerHeight(!0),
                    y = a.find(".a-popover-header"),
                    y = y.length ? y.outerHeight(!0) : 0;
                return {
                    windowWidth: d.width,
                    windowHeight: d.height,
                    windowTop: d.scrollTop,
                    windowLeft: d.scrollLeft,
                    windowRight: d.scrollLeft + d.width,
                    windowBottom: d.scrollTop + d.height,
                    zoomTop: g.top,
                    zoomLeft: g.left,
                    triggerWidth: r + 1,
                    triggerHeight: m,
                    triggerTop: h.top - e,
                    triggerLeft: h.left - e,
                    triggerRight: h.left + r + e,
                    triggerBottom: h.top + m + e,
                    triggerVerticalCenter: h.top + m / 2,
                    triggerHorizontalCenter: h.left + r / 2,
                    popoverWidth: x,
                    popoverHeight: A,
                    popoverTop: l.top,
                    popoverLeft: l.left,
                    popoverRight: l.left + x,
                    popoverBottom: l.top + A,
                    popoverVerticalCenter: l.top + A / 2,
                    popoverHorizontalCenter: l.left + x / 2,
                    headerHeight: y
                }
            }

            function d(a) {
                return a.removeClass("a-arrow-top a-arrow-bottom a-arrow-left a-arrow-right")
            }

            function g(a) {
                var b = {
                        deltaTop: 0
                    },
                    c;
                b.top = a.triggerVerticalCenter - a.popoverHeight / 2;
                b.top < a.windowTop + 20 ? (c = Math.min(a.windowTop + 20, a.triggerTop - 20), b.deltaTop = b.top - c, b.top = c) : b.top + a.popoverHeight > a.windowBottom - 20 && (c = Math.min(20,
                    a.windowBottom - a.triggerBottom + 20), b.deltaTop = b.top + a.popoverHeight - (a.windowBottom - c), b.top = a.windowBottom - c - a.popoverHeight);
                return b
            }

            function a(a) {
                var b = {
                        deltaLeft: 0
                    },
                    c;
                b.left = a.triggerHorizontalCenter - a.popoverWidth / 2;
                20 > b.left ? (c = Math.min(20, a.triggerLeft - 20), b.deltaLeft = b.left - c, b.left = c) : b.left + a.popoverWidth > a.windowRight - 20 && (c = Math.min(20, a.windowRight - a.triggerRight + 20), b.deltaLeft = b.left + a.popoverWidth - (a.windowRight - c), b.left = a.windowRight - c - a.popoverWidth);
                return b
            }
            var p = b.$;
            p(t);
            var l =
                null,
                e = 1,
                u = b.capabilities.mobile && h.isIE10Plus;
            m.when("prv:skin-vars-desktop").execute(function(a) {
                e = a.popover.POPOVER_SPACING ? a.popover.POPOVER_SPACING : e
            });
            return {
                windowCenter: function(a) {
                    a = c(a.$popover, a.$trigger);
                    var b = {};
                    b.top = (a.windowHeight - a.popoverHeight) / 2;
                    b.left = (a.windowWidth - a.popoverWidth) / 2;
                    0 > b.top && (b.top = 0);
                    return b
                },
                windowTop: function(a) {
                    a = c(a.$popover, a.$trigger);
                    var b = {
                        top: 0
                    };
                    b.left = a.windowWidth / 2 - a.popoverWidth / 2;
                    return b
                },
                windowFullWidth: function(a) {
                    return {
                        top: 0,
                        left: 0
                    }
                },
                triggerRight: function(a,
                    b) {
                    var e = a.$popover,
                        f = a.$trigger;
                    b || (b = c(e, f));
                    f = g(b);
                    f.left = b.triggerRight;
                    a.attrs("popoverArrow") && (d(e).addClass("a-arrow-right"), e.find(".a-arrow-border").css("top", b.popoverHeight / 2 + f.deltaTop));
                    return f
                },
                triggerLeft: function(a, b) {
                    var e = a.$popover,
                        f = a.$trigger;
                    b || (b = c(e, f));
                    f = g(b);
                    f.left = b.triggerLeft - b.popoverWidth;
                    f.left = 0 < f.left ? f.left : 0;
                    a.attrs("popoverArrow") && (d(e).addClass("a-arrow-left"), e.find(".a-arrow-border").css("top", b.popoverHeight / 2 + f.deltaTop));
                    return f
                },
                triggerTop: function(b,
                    g) {
                    var e = b.$popover,
                        f = b.$trigger;
                    g || (g = c(e, f));
                    f = a(g);
                    f.top = g.triggerTop - g.popoverHeight;
                    b.attrs("popoverArrow") && (d(e).addClass("a-arrow-top"), e.find(".a-arrow-border").css("left", g.popoverWidth / 2 + f.deltaLeft));
                    return f
                },
                triggerBottom: function(b, g) {
                    var e = b.$popover,
                        f = b.$trigger;
                    g || (g = c(e, f));
                    f = a(g);
                    f.top = g.triggerBottom;
                    b.attrs("popoverArrow") && (d(e).addClass("a-arrow-bottom"), e.find(".a-arrow-border").css("left", g.popoverWidth / 2 + f.deltaLeft));
                    return f
                },
                triggerHorizontal: function(a, b) {
                    var d = a.$popover,
                        g = a.$trigger;
                    b || (b = c(d, g));
                    return b.triggerLeft - b.windowLeft > b.windowRight - b.triggerRight ? this.triggerLeft(a, b) : this.triggerRight(a, b)
                },
                triggerVertical: function(a, b) {
                    var d = a.$popover,
                        g = a.$trigger;
                    b = b ? b : c(d, g);
                    return b.triggerTop - b.windowTop > b.popoverHeight + 20 ? this.triggerTop(a, b) : this.triggerBottom(a, b)
                },
                triggerVerticalAlignLeft: function(a, b) {
                    var g = a.$popover,
                        e = a.$trigger;
                    b || (b = c(g, e));
                    var e = {},
                        f = 0,
                        h = 0,
                        l = b.windowBottom - b.triggerBottom;
                    e.left = b.triggerLeft;
                    e.top = l > b.popoverHeight ? b.triggerBottom + 3 :
                        b.triggerTop - b.popoverHeight - 3;
                    20 > e.left ? (h = Math.min(20, b.triggerLeft - 20), f = e.left - h, e.left = h) : e.left + b.popoverWidth > b.windowRight - 20 && (h = Math.min(20, b.windowRight - b.triggerRight + 20), f = e.left + b.popoverWidth - (b.windowRight - h), e.left = b.windowRight - h - b.popoverWidth);
                    a.attrs("popoverArrow") && (d(g).addClass(l > b.popoverHeight ? "a-arrow-bottom" : "a-arrow-top"), p.withoutRtl(function() {
                        g.find(".a-arrow-border").css("left", b.triggerWidth / 2 + f)
                    }));
                    return e
                },
                customPosition: function(a, b) {
                    return b.call(this, {
                        popover: a,
                        $popover: a.$popover,
                        $trigger: a.$trigger,
                        measure: c
                    })
                }
            }
        });
    "use strict";
    m.when("A").register("a-popover-util", function(b) {
        function h(b, c) {
            for (var a = b.children.length; a--;) {
                var f = h(b.children[a], c);
                if (f) return f
            }
            if (c(b)) return b
        }
        var f = b.$,
            c = /^-?\d+(?:\.\d+)?$/;
        return {
            trigger: function(c, g) {
                b.trigger("a:popover:" + c, {
                    popover: g
                });
                g.name && b.trigger("a:popover:" + c + ":" + g.name, {
                    popover: g
                })
            },
            extractDeclarativeParams: function(c, g) {
                c = f(c);
                c = c.hasClass("a-declarative") ? c : c.find(".a-declarative").eq(0);
                g = "a-" + g;
                var a =
                    c.data("action");
                return a && b.contains(a, g) ? {
                    attributes: c.data(g) || null,
                    $trigger: c
                } : null
            },
            eventOccursWithin: function(b, c) {
                b = f(b.target);
                return 0 < b.closest(c.$trigger).length || 0 < b.closest(c.$popover).length
            },
            search: h,
            getCSSHash: function(d) {
                var g = {};
                b.each("height width max-height max-width min-height min-width".split(" "), function(a) {
                    if (d[a]) {
                        var f = d[a];
                        if (b.isFiniteNumber(f) || c.test(f)) f += "px";
                        g[a] = f
                    }
                });
                g.height && !g["max-height"] && (g["max-height"] = "none");
                g.width && !g["max-width"] && (g["max-width"] =
                    "none");
                return g
            },
            clearContent: function(b) {
                (b = b.getContent()) && b.empty()
            },
            showSpinner: function(b) {
                b.updateContent('\x3cdiv class\x3d"a-popover-loading-wrapper a-text-center"\x3e\x3cdiv class\x3d"a-box a-color-base-background a-popover-loading"\x3e\x3c/div\x3e\x3c/div\x3e');
                b.updatePosition();
                return b
            },
            getBool: function(b, c) {
                return void 0 !== b ? !0 === b || "true" === b : !0 === c
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-util", "a-popover-animate").register("a-modal-view-base", function(b, h, f) {
        var c = b.$,
            d = c("html").hasClass("a-lt-ie9");
        return {
            setAriaBusy: function(b) {
                this.$popover.find(".a-popover-wrapper").attr("aria-busy", b)
            },
            updateContent: function(b) {
                "string" === typeof b ? this.$popover.find(".a-popover-inner").html(b) : b && this.$popover.find(".a-popover-inner").html("").append(b)
            },
            updateDimensions: function() {
                var b = this.$popover,
                    a = h.getCSSHash(this.attrs());
                !this.draggable || a.width && "auto" !== a.width || (a.width = b.width() + "px");
                b.css(a);
                a.height ? b.addClass("a-popover-modal-fixed-height") : b.removeClass("a-popover-modal-fixed-height");
                this.isActive() && this.updatePosition();
                return this
            },
            getContent: function() {
                return this.$popover ? this.$popover.find(".a-popover-inner") : null
            },
            showMethod: function(c) {
                var a = this,
                    p = a.$popover;
                p.css({
                    visibility: "visible"
                }).removeClass("a-popover-hidden");
                d || "ajax" === a.attrs("currentDataStrategy") ? c.call(a) : (p.css({
                    opacity: 0
                }), f.animate(a, {
                    opacity: 1
                }, 500, "linear", function() {
                    c.call(a)
                }));
                b.animationFrameDelay(function() {
                    a.focus()
                });
                a.attrs("legacyNavigable") && h.trigger("showNavigableLegacy", a)
            },
            hideMethod: function(b) {
                var a =
                    this;
                d ? (a.$popover.hide().css("visibility", "hidden").find(".a-lgtbox-vertical-scroll").removeClass("a-lgtbox-vertical-scroll"), b.call(a)) : f.fadeOut(a, 250, "linear", function() {
                    b.call(a)
                });
                a.attrs("legacyNavigable") && h.trigger("hideNavigableLegacy", a)
            }
        }
    });
    "use strict";
    m.when("A", "a-modal-view-base", "a-modal-positions", "a-popover-accessibility").register("a-modal-view", function(b, h, f, c) {
        var d = b.$,
            d = d("html").hasClass("a-lt-ie9");
        return b.extend(h, b.capabilities.touch || b.capabilities.mobile || b.capabilities.tablet ||
            d ? f.innerScroll : f.modalScroll, {
                skin: function(d) {
                    var a = d.attrs("id"),
                        f = d.attrs("header") || "",
                        h = d.attrs("hideHeader") || !1,
                        e = d.attrs("footer"),
                        m = d.attrs("modeless") || !1,
                        k = d.attrs("closeButton"),
                        n = d.attrs("closeButtonLabel") || "",
                        v = d.attrs("hideHeaderCloseButtonLayout") || "",
                        q = d.attrs("popoverLabel") || "",
                        w = d.attrs("padding");
                    d = d.attrs("ariaDescription");
                    d = {
                        id: a,
                        header_str: f,
                        label_str: q,
                        aria_description: d
                    };
                    var q = c.getDescription(d),
                        t = c.getPopoverLabelHtml(d),
                        k = '\x3cbutton data-action\x3d"a-popover-close" class\x3d"' +
                        (k ? "" : " a-button-close-a11y") + " a-button-close a-declarative" + (h ? k ? "top" === v ? " a-modal-close-nohead-top" : " a-button-top-right" : " a-button-a11y-top-right" : "") + '" aria-label\x3d"' + n + '"\x3e\x3ci class\x3d"a-icon a-icon-close"\x3e\x3c/i\x3e\x3c/button\x3e',
                        f = !h || t ? "\x3cheader" + (h ? "" : ' class\x3d"a-popover-header"') + "\x3e" + (h ? "" : '\x3ch4 class\x3d"a-popover-header-content' + (m ? " a-popover-draggable-handle" : "") + '" id\x3d"a-popover-header-' + a + '"\x3e' + f + "\x3c/h4\x3e") + k + t + "\x3c/header\x3e" : k,
                        e = e ? '\x3cdiv class\x3d"a-popover-footer"\x3e' +
                        e + "\x3c/div\x3e" : "",
                        w = "none" === w ? " a-padding-none" : "",
                        h = b.capabilities.isAndroid ? "" : c.getStartAnchorSimplifiedHtml(),
                        k = b.capabilities.isAndroid ? "" : c.getEndAnchorHtml(d),
                        n = m ? "" : '\x3cdiv class\x3d"a-modal-scroller a-declarative" data-action\x3d"a-popover-floating-close"\x3e';
                    d = '\x3cdiv class\x3d"a-popover a-popover-modal a-declarative' + (m ? " a-modal-modeless" : " ") + '" data-action\x3d"a-popover-a11y" role\x3d"dialog"' + c.getAriaLabelledByDescribedby(d) + "\x3e";
                    return n + d + h + q + '\x3cdiv class\x3d"a-popover-wrapper"\x3e' +
                        f + ('\x3cdiv class\x3d"a-popover-inner' + w + '" id\x3d"a-popover-content-' + a + '"\x3e\x3c/div\x3e') + e + "\x3c/div\x3e" + k + "\x3c/div\x3e" + (m ? "" : "\x3c/div\x3e")
                }
            })
    });
    "use strict";
    m.when("A", "a-popover-lightbox", "a-popover-optional-helpers", "prv:a-capabilities").register("a-modal-positions", function(b, h, f, c) {
        function d(a) {
            var b = a.$popover.closest(".a-modal-scroller");
            b.scrollTop(0).css("visibility", "visible");
            b.bind("scroll", function() {
                a.updateChildrenPosition()
            })
        }

        function g() {
            var a = b.viewport();
            2 < a.width / a.height &&
                b.delay(function() {
                    document.activeElement.scrollIntoView();
                    t.scrollTo(t.pageXOffset, 0)
                }, 0)
        }

        function a(a, b, c) {
            if (0 > a) return c({
                "padding-right": b + "px",
                "box-sizing": "content-box"
            }), !0;
            c({
                "padding-right": "",
                "box-sizing": ""
            });
            return !1
        }

        function p(a) {
            return function(b) {
                a.css(b)
            }
        }
        var l = b.$,
            e = c.isIE10Plus && b.capabilities.mobile,
            u = 0;
        m.when("prv:skin-vars").execute(function(a) {
            u = a.popover.optionalButtonHeight
        });
        m.declare("prv:a-model-applyHorizonalScrollStyles", a);
        return {
            innerScroll: {
                positionStrategy: function(d) {
                    var n =
                        d.popover,
                        m = d.$popover,
                        q = d.$trigger,
                        w = m.find(".a-popover-inner").css("height", "auto"),
                        B = m.closest(".a-modal-scroller"),
                        r = {},
                        z = b.viewport(!0),
                        x = .1 * z.height,
                        A = .05 * z.width,
                        z = .8 * z.height,
                        y = n.attrs("height"),
                        n = n.attrs("min-height");
                    m.css({
                        height: y ? y : "",
                        "min-height": n ? n : ""
                    });
                    q = d.measure(m, q);
                    r.left = (q.windowWidth - q.popoverWidth) / 2;
                    a(r.left, A, p(m)) && (r.left = A);
                    f.evaluateActualHeight(d, q.popoverHeight, u) > z ? (n = m.find(".a-popover-header, .a-modal-close-nohead-top").outerHeight(!0) || 0, y = m.find(".a-popover-footer").outerHeight(!0) ||
                        0, d = f.getOffsetTopDelta(d, x, u), z -= d, x += d, w.css({
                            height: z - n - y + "px",
                            "overflow-y": "auto"
                        }), m.css({
                            height: z,
                            "min-height": 0
                        }), r.top = x) : (r.top = (q.windowHeight - q.popoverHeight) / 2, w.css("height", "auto"));
                    r.left += q.zoomLeft;
                    r.top += q.zoomTop;
                    e && (B.css("top", l(t).scrollTop()), m.removeClass("a-popover-pan-y").addClass("a-popover-pan-x"), m = l(document).height(), w = l(document).width(), l("#" + h.LIGHTBOX_ID).css({
                        height: m,
                        width: w > q.popoverWidth ? w : q.popoverWidth + A
                    }));
                    c.isMetroIEGuess && c.isIETouchCapable && g();
                    return r
                },
                beforeShowMethod: b.constants.NOOP,
                beforeHideMethod: b.constants.NOOP
            },
            modalScroll: {
                positionStrategy: function(d) {
                    var e = d.$popover,
                        f = d.$trigger,
                        h = e.closest(".a-modal-scroller"),
                        l = e.find(".a-popover-inner").css("height", "auto");
                    if (e.hasClass("a-popover-modal-fixed-height")) {
                        var m = e.find(".a-popover-footer");
                        l.css("padding-bottom", m.height() + 15)
                    }
                    var l = {},
                        r = b.viewport(!0),
                        u = r.height,
                        m = .1 * u,
                        r = .05 * r.width,
                        u = .8 * u,
                        x = e.height(),
                        t = e.width();
                    d = d.measure(e, f);
                    l.left = (d.windowWidth - t) / 2;
                    l.top = (d.windowHeight - x) /
                        2;
                    a(l.left, r, p(e)) && (l.left = r);
                    x > u ? h.length ? (l.top = 0, e.css({
                        position: "relative",
                        margin: d.zoomTop + m + "px 0 " + m + "px " + (d.zoomLeft + l.left) + "px"
                    }), l.left = 0, h.css("padding-bottom", "1px")) : x > u && (l.top = padding) : h.length && (e.css({
                        position: "absolute",
                        margin: "0px"
                    }), h.css("padding-bottom", "0px"));
                    l.left += d.zoomLeft;
                    l.top += d.zoomTop;
                    c.isMetroIEGuess && c.isIETouchCapable && g();
                    return l
                },
                beforeShowMethod: function() {
                    d(this)
                },
                beforeHideMethod: function() {
                    this.$popover.closest(".a-modal-scroller").css("visibility", "hidden").unbind("scroll")
                }
            },
            util: {
                determineMaximumInnerHeight: function(a) {
                    var c = a.$popover;
                    a = .8 * b.viewport().height;
                    var d = c.find(".a-popover-header, .a-modal-close-nohead-top").outerHeight(!0) || 0,
                        c = c.find(".a-popover-footer").outerHeight(!0) || 0;
                    return a - d - c
                },
                determineInnerVerticalPadding: function(a) {
                    a = a.$popover.find(".a-popover-inner");
                    return a.outerHeight() - a.height()
                }
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-base-factory", "a-modal-view", "a-popover-util", "prv:a-capabilities").register("a-modal-factory", function(b, h, f, c, d) {
        function g(d,
            e) {
            var g = !1,
                k = !1;
            b.capabilities.mobile || b.capabilities.tablet || (g = c.getBool(e.modeless), k = c.getBool(e.draggable));
            e = {
                modeless: g,
                draggable: k,
                type: "modal",
                alone: !0,
                immersive: !0,
                position: "windowCenter",
                header: e.header,
                hideHeader: e.hideHeader,
                footer: e.footer,
                padding: e.padding,
                width: e.width,
                height: e.height,
                "max-width": e["max-width"],
                "max-height": e["max-height"],
                "min-width": e["min-width"],
                "min-height": e["min-height"],
                closeButton: c.getBool(e.closeButton, !0),
                timeout: e.timeout,
                lightboxOptions: g ? C : {
                    lockScroll: !0,
                    showDuration: a || m ? 0 : null
                },
                data: e.data || {},
                dataStrategy: e.dataStrategy,
                url: e.url,
                manualRefresh: !!e.manualRefresh,
                ajaxFailMsg: e.ajaxFailMsg,
                cache: c.getBool(e.cache, !0),
                inlineContent: e.inlineContent ? e.inlineContent : e.content,
                name: e.name,
                closeButtonLabel: e.closeButtonLabel ? e.closeButtonLabel : "Close",
                hideHeaderCloseButtonLayout: e.hideHeaderCloseButtonLayout,
                popoverLabel: e.popoverLabel,
                ariaDescription: e.ariaDescription,
                legacyNavigable: c.getBool(e.legacyNavigable, !0)
            };
            return h.create(d, {
                attributes: e,
                typeSpecificFunctions: f,
                actionCheck: !0
            })
        }
        var a = -1 < document.documentElement.className.indexOf("a-lt-ie9"),
            m = b.capabilities.mobile && d.isIE10Plus;
        return {
            type: "modal",
            create: g,
            get: function(a) {
                var b = h.get(a, "modal");
                b || "object" !== typeof a || (a = c.extractDeclarativeParams(a, "modal")) && (b = g(a.$trigger, a.attributes || {}));
                return b
            },
            remove: function(a) {
                return h.remove(a, "modal")
            }
        }
    });
    "use strict";
    m.when("A", "a-modal-factory").register("a-modal-handlers", function(b, h) {
        var f = b.$;
        b.declarative("a-modal", "click", function(b) {
            h.get(b.$declarativeParent).show();
            b.$event.preventDefault()
        });
        f(document).delegate(".a-modal-scroller", "click " + b.action.start + " " + b.action.move, function(b) {
            b.target === this && b.preventDefault()
        })
    });
    "use strict";
    m.when("A", "a-modal-factory", "a-popover-base", "a-modal-handlers").register("a-modal", function(b, h) {
        return h
    });
    "use strict";
    m.when("A", "a-popover-util", "a-popover-animate").register("a-popover-view-base", function(b, h, f) {
        return {
            setAriaBusy: function(b) {
                this.$popover.find(".a-popover-wrapper").attr("aria-busy", b)
            },
            updateContent: function(b) {
                "string" ===
                typeof b ? this.$popover.find(".a-popover-content").html(b) : b && this.$popover.find(".a-popover-content").html("").append(b)
            },
            updateDimensions: function() {
                this.$popover.css(h.getCSSHash(this.attrs()));
                this.isActive() && this.updatePosition();
                return this
            },
            getContent: function() {
                return this.$popover ? this.$popover.find(".a-popover-content") : null
            },
            hideMethod: function(b) {
                var d = this;
                f.fadeOut(d, 250, "linear", function() {
                    d.$popover.css({
                        top: "auto",
                        left: "auto"
                    });
                    b.call(d)
                })
            }
        }
    });
    m.when("a-util").register("a-popover-optional-helpers",
        function(b) {
            return {
                getOffsetTopDelta: function(h, f, c) {
                    c = parseFloat(c);
                    var d = b.isFiniteNumber(c) && 0 < c;
                    h = h.$popover.find(".a-button-close").length && !h.$popover.find(".a-button-close-a11y").length;
                    return d && h && 0 > f - c ? c - f : 0
                },
                evaluateActualHeight: function(b, f, c) {
                    return b.$popover.find(".a-button-close").length && !b.$popover.find(".a-button-close-a11y").length ? f + c : f
                }
            }
        });
    "use strict";
    m.when("A", "a-popover-view-base", "a-popover-util", "a-popover-accessibility").register("a-popover-view", function(b, h, f, c) {
        var d = !0;
        m.when("prv:skin-vars").execute(function(b) {
            d = b.popover.closeButtonEnabled
        });
        return b.extend(h, {
            skin: function(f) {
                var a = f.attrs("id"),
                    h = f.attrs("header"),
                    l = d && f.attrs("closeButton"),
                    e = f.attrs("closeButtonLabel") || "",
                    m = f.attrs("popoverLabel") || "",
                    k = f.attrs("ariaDescription"),
                    n = f.attrs("padding");
                f = f.attrs("popoverArrow");
                k = {
                    id: a,
                    header_str: h,
                    label_str: m,
                    aria_description: k
                };
                b.capabilities.isAndroid && (e = (m || h) + " " + e);
                var l = '\x3cbutton data-action\x3d"a-popover-close" class\x3d"a-button-close ' + (l ?
                        "" : "a-button-close-a11y") + ' a-declarative" aria-label\x3d"' + e + '"\x3e\x3ci class\x3d"a-icon a-icon-close"\x3e\x3c/i\x3e\x3c/button\x3e',
                    v = (e = !!h) ? "a-popover-has-header" : "a-popover-no-header",
                    n = "none" === n ? " a-padding-none" : "";
                f = f ? '\x3cdiv class\x3d"a-arrow-border"\x3e\x3cdiv class\x3d"a-arrow"\x3e\x3c/div\x3e\x3c/div\x3e' : "";
                var m = b.capabilities.isAndroid ? "" : c.getStartAnchorSimplifiedHtml(),
                    q = b.capabilities.isAndroid ? "" : c.getEndAnchorHtml(k),
                    h = h ? '\x3ch4 class\x3d"a-popover-header-content" id\x3d"a-popover-header-' +
                    a + '"\x3e' + h + "\x3c/h4\x3e" : "",
                    v = '\x3cdiv class\x3d"a-popover ' + v + ' a-declarative" data-action\x3d"a-popover-container a-popover-a11y" role\x3d"dialog"' + c.getAriaLabelledByDescribedby(k) + "\x3e",
                    t = c.getDescription(k),
                    k = c.getPopoverLabelHtml(k);
                return v + m + t + '\x3cdiv class\x3d"a-popover-wrapper"\x3e' + (e ? '\x3cheader class\x3d"a-popover-header"\x3e' + h + l + k + "\x3c/header\x3e" : "") + ('\x3cdiv class\x3d"a-popover-inner' + n + '"\x3e') + (e ? "" : k ? "\x3cheader\x3e" + l + k + "\x3c/header\x3e" : l) + ('\x3cdiv class\x3d"a-popover-content" id\x3d"a-popover-content-' +
                    a + '"\x3e\x3c/div\x3e') + "\x3c/div\x3e" + f + "\x3c/div\x3e" + q + "\x3c/div\x3e"
            }
        })
    });
    "use strict";
    m.when("A", "a-popover-base-factory", "a-popover-view", "a-popover-util").register("a-popover-factory", function(b, h, f, c) {
        function d(b, a) {
            a = {
                type: "popover",
                alone: !0,
                header: a.header,
                width: a.width,
                height: a.height,
                "max-width": a["max-width"],
                "max-height": a["max-height"],
                "min-width": a["min-width"],
                "min-height": a["min-height"],
                padding: a.padding,
                closeButton: c.getBool(a.closeButton, !0),
                position: a.position || "triggerVertical",
                activate: a.activate || "onmouseover",
                timeout: a.timeout,
                data: a.data || {},
                dataStrategy: a.dataStrategy,
                url: a.url,
                manualRefresh: !!a.manualRefresh,
                ajaxFailMsg: a.ajaxFailMsg,
                cache: c.getBool(a.cache, !0),
                inlineContent: a.inlineContent ? a.inlineContent : a.content,
                name: a.name,
                closeButtonLabel: a.closeButtonLabel ? a.closeButtonLabel : "Close",
                popoverLabel: a.popoverLabel,
                ariaDescription: a.ariaDescription,
                focusWhenShown: c.getBool(a.focusWhenShown, !0),
                popoverArrow: c.getBool(a.popoverArrow, !0),
                restoreFocusOnHide: c.getBool(a.restoreFocusOnHide, !0)
            };
            return h.create(b, {
                attributes: a,
                typeSpecificFunctions: f,
                actionCheck: !0
            })
        }
        return {
            type: "popover",
            create: d,
            get: function(b) {
                var a = h.get(b, "popover");
                a || "object" !== typeof b || (b = c.extractDeclarativeParams(b, "popover")) && (a = d(b.$trigger, b.attributes || {}));
                return a
            },
            remove: function(b) {
                return h.remove(b, "popover")
            }
        }
    });
    "use strict";
    m.when("A", "a-popover-factory").register("a-popover-handlers", function(b, h) {
        b.declarative("a-popover", "click", function(b) {
            h.get(b.$declarativeParent).show();
            b.$event.preventDefault()
        })
    });
    "use strict";
    m.when("A", "a-popover-factory", "a-popover-base", "a-popover-handlers").register("a-popover", function(b, h) {
        return h
    });
    "use strict";
    m.when("A", "a-popover-util", "a-popover-navigate", "a-touch", "a-detect", "a-popover-accessibility", "prv:a-capabilities").register("a-secondary-view-view", function(b, h, f, c, d, g, a) {
        function p() {
            w.show();
            b.delay(function() {
                w.css("opacity", 1)
            }, 0)
        }

        function l(a) {
            b.delay(function() {
                w.css("opacity", 0)
            }, 0);
            b.delay(function() {
                w.hide()
            }, a)
        }

        function e() {
            k.unbind(q);
            k.bind(q,
                function(a) {
                    0 === u(a.target).closest("a").length && a.preventDefault()
                });
            m.when("a-event-analytics").execute(function(a) {
                a.notifyJquery(w, B)
            })
        }
        var u = b.$,
            k = u(t),
            n = u("body"),
            v = u("#a-page"),
            q = d.action.start + ".a-secondary-view " + d.action.move + ".a-secondary-view " + d.action.end + ".a-secondary-view",
            w = u("\x3cdiv id\x3d'a-white'/\x3e");
        n.append(w);
        w.bind(d.action.start + " " + d.action.move + " " + d.action.end + " click", function(a) {
            a.stopImmediatePropagation();
            a.preventDefault()
        });
        var B = "touchstart" === d.action.start ?
            "touchstart click" : "click";
        m.when("a-event-analytics").execute(function(a) {
            a.notifyJquery(w, B)
        });
        return {
            skin: function(a) {
                var b = a.attrs("id"),
                    c = a.attrs("header"),
                    d = a.attrs("backButtonText") || "Back",
                    e = a.attrs("alternateBackground"),
                    f = a.attrs("hideHeader"),
                    h = a.attrs("popoverLabel") ? a.attrs("popoverLabel") : "",
                    k = a.attrs("padding");
                a = a.attrs("ariaDescription");
                h = {
                    id: b,
                    header_str: c,
                    label_str: h,
                    aria_description: a
                };
                a = c ? ['\x3cdiv class\x3d"a-span8 a-column a-span-last a-text-right"\x3e', '\x3ch4 id\x3d"a-popover-header-' +
                    b + '"\x3e', c, "\x3c/h4\x3e\n\x3c/div\x3e"
                ].join("\n") : "";
                k = "none" === k ? " a-padding-none" : "";
                return ['\x3cdiv class\x3d"a-popover a-popover-secondary a-declarative" data-action\x3d"a-popover-a11y"\x3e', g.getStartAnchorHtml(h), '\x3cdiv class\x3d"a-popover-wrapper"\x3e', '\x3cdiv class\x3d"a-popover-header-secondary' + (f ? " a-popover-no-header" : "") + '"\x3e', '\x3cdiv class\x3d"a-row"\x3e', '\x3cdiv class\x3d"' + (c ? "a-span4" : "a-span12 a-span-last") + ' a-column"\x3e', '\x3ca class\x3d"a-declarative" data-action\x3d"a-popover-close" href\x3d"#"\x3e\n\x3ci class\x3d"a-icon a-icon-page-back"\x3e\x3c/i\x3e\n\x3ch4\x3e',
                    d ? d : "Back", "\x3c/h4\x3e\n\x3c/a\x3e\n\x3c/div\x3e", a, "\x3c/div\x3e\n\x3c/div\x3e", '\x3cdiv class\x3d"a-popover-inner' + (e ? " a-color-alternate-background" : "") + '"\x3e', '\x3cdiv class\x3d"a-popover-header-spacing' + (f ? " a-popover-no-header" : "") + '"\x3e\x3c/div\x3e', '\x3cdiv class\x3d"a-container a-secondary-view-inner' + k + '" id\x3d"a-popover-content-' + b + '"\x3e\x3c/div\x3e', "\x3c/div\x3e\n\x3c/div\x3e", g.getEndAnchorHtml(h), "\x3c/div\x3e"
                ].join("\n")
            },
            setAriaBusy: function(a) {
                this.$popover.find(".a-popover-wrapper").attr("aria-busy",
                    a)
            },
            updateContent: function(a) {
                var b = this;
                if (b.attrs("animating")) var c = setInterval(function() {
                    b.attrs("animating") || (clearInterval(c), k.scrollTop(1))
                }, 50);
                var d = u(".a-secondary-view-inner", b.$popover);
                "string" === typeof a ? d.html(a) : a && d.html("").append(a)
            },
            getContent: function() {
                return this.$popover ? this.$popover.find(".a-secondary-view-inner") : null
            },
            beforeShowMethod: function(a) {
                a = a && a.preventNavigate ? a.preventNavigate : !1;
                this.attrs("navigate", this.name && !a)
            },
            showMethod: function(a) {
                function d() {
                    function c() {
                        h.trigger("afterSlide",
                            g);
                        a.call(g)
                    }
                    u && f.forward(g);
                    h.trigger("showNavigable", g);
                    b.delay(function() {
                        k.scrollTop(1)
                    }, 0);
                    m.show().css("visibility", "visible").removeClass("a-popover-hidden");
                    g.focus();
                    v.hide();
                    q || l(n);
                    q ? c() : b.delay(c, n)
                }
                var g = this,
                    m = g.$popover,
                    n = g.attrs("animationLength"),
                    q = g.attrs("synchronous") || g.attrs("disableAnimation"),
                    t = g.attrs("scrollable"),
                    u = g.attrs("navigate"),
                    w = function() {
                        var a = b.viewport();
                        m.width(a.width);
                        m.css("min-height", a.height);
                        m.find(".a-popover-wrapper, .a-popover-inner").css("min-height",
                            a.height)
                    };
                g.attrs("resizeHandle", b.on("resize", w));
                w();
                c.pauseTouchEvents(n);
                h.trigger("beforeSlide", g);
                t || e();
                q || p();
                g.attrs("scrollTop", k.scrollTop());
                q ? d() : b.delay(d, n + 50)
            },
            beforeHideMethod: function(a) {
                a = a && a.preventNavigate ? a.preventNavigate : !1;
                this.attrs("navigate", this.name && !a)
            },
            hideMethod: function(d) {
                function e() {
                    function a() {
                        h.trigger("afterSlideOut", g);
                        m.hide().css("visibility", "hidden");
                        d.call(g)
                    }
                    w && f.back();
                    h.trigger("hideNavigable", g);
                    B || v.show();
                    m.hide().css("visibility", "hidden");
                    t || l(n);
                    b.delay(function() {
                        k.scrollTop(u)
                    }, C);
                    t ? a() : b.delay(a, n)
                }
                var g = this,
                    m = g.$popover,
                    n = g.attrs("animationLength"),
                    t = g.attrs("disableAnimation"),
                    u = g.attrs("scrollTop"),
                    w = g.attrs("navigate"),
                    B = !1,
                    C = a.isIE10 ? 200 : 0;
                b.each(g.parent.children, function(a) {
                    B = B || a.type === g.type && a.isVisible()
                });
                c.pauseTouchEvents(g.animationLength);
                b.off("resize", g.attrs("resizeHandle"));
                B || k.unbind(q);
                h.trigger("beforeSlideOut", g);
                t || p();
                t ? e() : b.delay(e, n + 50)
            },
            updatePosition: function() {}
        }
    });
    "use strict";
    m.when("A", "a-popover-base-factory",
        "a-secondary-view-view", "a-popover-util").register("a-secondary-view-factory", function(b, h, f, c) {
        function d(c, d) {
            d.disableAnimation = d.disableAnimation || b.capabilities.isOldAndroid;
            return h.create(c, {
                attributes: {
                    type: "secondary-view",
                    immersive: !0,
                    disableAnimation: a || d.disableAnimation,
                    synchronous: !!(a || d.synchronous && "false" !== d.synchronous),
                    animationLength: d.disableAnimation ? 0 : 300,
                    alternateBackground: d.alternateBackground || !1,
                    hideHeader: a || d.hideHeader || !1,
                    scrollable: d.scrollable || !0,
                    header: d.header,
                    backButtonText: d.backButtonText,
                    position: "windowFullWidth",
                    timeout: d.timeout,
                    dataStrategy: d.dataStrategy,
                    inlineContent: d.inlineContent ? d.inlineContent : d.content,
                    url: d.url,
                    manualRefresh: !!d.manualRefresh,
                    name: d.name,
                    cache: "false" === d.cache || !1 === d.cache ? !1 : !0,
                    data: d.data || {},
                    popoverLabel: d.popoverLabel,
                    padding: d.padding,
                    ariaDescription: d.ariaDescription,
                    historyApi: "true" === d.historyApi || !0 === d.historyApi
                },
                typeSpecificFunctions: f,
                actionCheck: !0
            })
        }
        var g = b.$,
            a = !1;
        m.when("mash-will-load").execute(function() {
            a = !0
        });
        return {
            type: "secondary-view",
            create: d,
            get: function(a) {
                var b = h.get(a, "secondary-view");
                if (!b && "object" === typeof a) {
                    var e = c.extractDeclarativeParams(a, "secondary-view");
                    e && (b = d(e.$trigger, e.attributes || {}))
                }
                b && "object" === typeof a && (a = g(a), a = (a = a.hasClass("a-declarative") ? a : a.find(".a-declarative").eq(0)) ? a.data("a-secondary-view") : null, b.data = a.data);
                return b
            },
            remove: function(a) {
                return h.remove(a, "secondary-view")
            }
        }
    });
    "use strict";
    m.when("A", "a-secondary-view-factory", "a-popover-util").register("a-secondary-view-handlers",
        function(b, h, f) {
            var c = !1,
                d = null;
            m.when("mash-will-load").execute(function() {
                c = !0
            });
            m.when("mash").execute(function(a) {
                d = a
            });
            var g = function(a) {
                var b = h.get(a.$declarativeParent);
                d && d.navigate && d.navigate({
                    successCallback: function() {
                        b.show({
                            preventNavigate: !1
                        })
                    }
                })
            };
            b.declarative("a-secondary-view", "click", function(a) {
                c ? g(a) : h.get(a.$declarativeParent).show();
                a.$event.preventDefault()
            })
        });
    "use strict";
    m.when("A", "a-secondary-view-factory", "a-popover-base", "a-secondary-view-handlers").register("a-secondary-view",
        function(b, h) {
            return h
        });
    "use strict";
    m.when("A", "a-popover-animate").register("a-tooltip-view-base", function(b, h) {
        return {
            updateContent: function(b) {
                this.$popover.find(".a-tooltip-inner").html(b)
            },
            getContent: function() {
                return this.$popover ? this.$popover.find(".a-tooltip-inner") : null
            },
            hideMethod: function(b) {
                var c = this;
                h.fadeOut(c, 250, "linear", function() {
                    b.call(c)
                })
            }
        }
    });
    "use strict";
    m.when("A", "a-tooltip-view-base").register("a-tooltip-view", function(b, h) {
        return b.extend(h, {
            skin: function(b) {
                return ['\x3cdiv role\x3d"tooltip" class\x3d"a-popover a-tooltip a-declarative" data-action\x3d"a-popover-close"\x3e\x3cdiv class\x3d"a-tooltip-inner"\x3e\x3c/div\x3e',
                    b.attrs("popoverArrow") ? '\x3cdiv class\x3d"a-arrow-border"\x3e\x3cdiv class\x3d"a-arrow"\x3e\x3c/div\x3e\x3c/div\x3e' : "", "\x3c/div\x3e"
                ].join("")
            }
        })
    });
    "use strict";
    m.when("A", "a-popover-base-factory", "a-tooltip-view", "a-popover-util").register("a-tooltip-factory", function(b, h, f, c) {
        function d(b, a) {
            a = {
                type: "tooltip",
                name: a.name,
                inlineContent: a.inlineContent ? a.inlineContent : a.content,
                position: a.position || "triggerVertical",
                activate: a.activate || "onmouseover",
                popoverArrow: c.getBool(a.popoverArrow, !0),
                restoreFocusOnHide: !1
            };
            a = h.create(b, {
                attributes: a,
                typeSpecificFunctions: f,
                actionCheck: !0
            });
            b.add(b.children()).filter("a, input").attr("aria-describedby", "a-popover-" + b.data("a-popover-id"));
            return a
        }
        return {
            type: "tooltip",
            create: d,
            get: function(b) {
                var a = h.get(b, "tooltip");
                a || "object" !== typeof b || (b = c.extractDeclarativeParams(b, "tooltip")) && (a = d(b.$trigger, b.attributes || {}));
                return a
            },
            remove: function(b) {
                return h.remove(b, "tooltip")
            }
        }
    });
    "use strict";
    m.when("A", "a-tooltip-factory").register("a-tooltip-handlers", function(b,
        h) {
        b.declarative("a-tooltip", "click", function(b) {
            h.get(b.$declarativeParent).show();
            b.$target.is("input, button") || b.$event.preventDefault()
        });
        b.declarative("a-tooltip", "focus focusin", function(b) {
            (b = h.get(b.$declarativeParent)) && b.show()
        });
        b.declarative("a-tooltip", "blur focusout", function(b) {
            (b = h.get(b.$declarativeParent)) && b.hide()
        })
    });
    "use strict";
    m.when("A", "a-tooltip-factory", "a-popover-base", "a-tooltip-handlers").register("a-tooltip", function(b, h) {
        return h
    })
});
/* ******** */
(function(e) {
    var h = window.AmazonUIPageJS || window.P,
        r = h._namespace || h.attributeErrors,
        a = r ? r("AmazonUIBottomSheet@v2", "AmazonUI") : h;
    a.guardFatal ? a.guardFatal(e)(a, window) : a.execute(function() {
        e(a, window)
    })
})(function(e, h, r) {
    e.when("A", "a-analytics", "a-sheet-web", "a-sheet-capabilities", "prv:a-sheet-constants", "prv:a-sheet-web-private", "prv:a-sheet-lightbox", "prv:a-sheet-history-manager", "prv:a-sheet-orientation-change").register("a-sheet", function(a, d, g, q, f, b, c, p, l) {
        var k = null,
            m = {};
        a.on("a:sheet:private:beforeShow",
            function(a) {
                h(a.sheet)
            });
        a.on("a:sheet:private:beforeHide", function(a) {
            n(a.sheet)
        });
        a.on("a:sheet:lightbox:private:click", function(a) {
            k && n(k) && (k = null)
        });
        a.on("a:sheet:history:private:pop", function(a) {
            k === m[a.sheetName] && b.hide(k) && (k = null)
        });
        a.on("a:sheet:private:destroy", function(a) {
            delete m[a.sheet._name]
        });
        a.on("orientationchange", function(b) {
            if (k) {
                var c = k;
                l.handleScrollerOrientation(c);
                l.resetSheetHeight(c);
                a.capabilities.ios && (c.$sheetOuterContainer.css("WebkitOverflowScrolling", "auto"), a.delay(function() {
                    c.$sheetOuterContainer.css("WebkitOverflowScrolling",
                        "")
                }, 1E3))
            }
        });
        a.on("a:popover:beforeShow", function(a) {
            k && "secondary-view" === a.popover.type && (b.unlockPageScroll(), b.turnOffExperimentalScrolling(k))
        });
        a.on("a:popover:afterHide", function(a) {
            k && "secondary-view" === a.popover.type && (b.lockPageScroll(), b.turnOnExperimentalScrolling(k))
        });
        if (a.capabilities.isAndroid) a.on("resize", function(a) {
            k && k.updatePosition()
        });
        var h = function(a) {
                a || e.error("Invalid sheet object passed in to .showSheet()", "AmazonUIBottomSheet", "BottomSheet");
                return k ? !1 : b.show(a) ? (k =
                    a, a._historySupportEnabled && p.push(a), !0) : !1
            },
            n = function(a) {
                a || e.error("Invalid sheet object passed in to .hideSheet()", "AmazonUIBottomSheet", "BottomSheet");
                return b.hide(a) ? (k = null, a._historySupportEnabled && p.goBack(), !0) : !1
            };
        return {
            showSheet: h,
            hideSheet: n,
            create: function(a) {
                var b = new c;
                d.increment("bottomsheet-web");
                var u = new g.Sheet(a);
                m[a.name] = u;
                u._lightbox = b;
                return u
            },
            get: function(a) {
                return m[a]
            }
        }
    });
    "use strict";
    e.when("A", "a-component", "prv:a-sheet-constants").register("a-sheet-base", function(a,
        d, g) {
        return d.create({
            _componentName: "sheet",
            init: function(d) {
                this._preloadDomId = d.preloadDomId;
                this._inlineContent = d.inlineContent;
                this._name = d.name;
                this._a11y = {
                    label: d.sheetLabel,
                    description: d.sheetDescription
                };
                var f = d.closeMessage && a.trim(d.closeMessage);
                this._closeEnabled = d.closeType === g.closeButtonType.icon || d.closeType === g.closeButtonType.message && !!f;
                this._closeMessage = f;
                var b = parseFloat(d.duration);
                this._duration = a.isFiniteNumber(b) ? 1E3 * b : g.defaults.animationDurationInMS;
                this._height = parseInt(d.height,
                    10) || g.defaults.sheetHeightInPx;
                this._autoHeight = !1;
                this._scrollPosition;
                this._historySupportEnabled = !1 !== d.historySupportEnabled;
                d.closeType !== g.closeButtonType.message && f ? e.log("closeType is " + d.closeType + " but closeMessage is set.", "WARN", "AmazonUIBottomsheet") : d.closeType !== g.closeButtonType.message || f || e.log("closeType is " + d.closeType + " but closeMessage is not set", "WARN", "AmazonUIBottomsheet");
                this._trackApi()
            }
        })
    });
    "use strict";
    e.when("A", "a-sheet", "a-sheet-accessibility").register("a-sheet-handlers",
        function(a, d, g) {
            a.declarative("a-sheet", "click", function(b) {
                var c = d.get(b.data.name);
                a.debounce(function() {
                    c ? d.showSheet(c) : d.showSheet(d.create(b.data))
                }, 250, !0)()
            });
            a.declarative("a-sheet-close", "click", function(a) {
                a = d.get(a.data.name);
                d.hideSheet(a)
            });
            var e = null,
                f = null;
            a.declarative("a-sheet-a11y", "focusout", function(b) {
                if (!(e && 100 > a.now() - e)) {
                    e = a.now();
                    var c = d.get(b.data.name);
                    c && a.delay(function() {
                            a.$(document.activeElement).hasClass("a-sheet-start") && g.getTabbableElements(c.$container).last().focus()
                        },
                        0)
                }
            });
            a.declarative("a-sheet-a11y", "focusin", function(b) {
                if (!(f && 100 > a.now() - f) && (f = a.now(), b.$target.hasClass("a-sheet-end"))) {
                    var c = d.get(b.data.name);
                    c && a.delay(function() {
                        g.getTabbableElements(c.$container).first().focus()
                    }, 0)
                }
            })
        });
    "use strict";
    e.when("A", "a-sheet-util", "a-sheet-accessibility", "prv:a-sheet-dimensions", "prv:a-capabilities", "prv:a-sheet-constants").register("prv:a-sheet-web-private", function(a, d, g, q, f, b) {
        var c = a.$,
            p = a.constants.HIDE_CLASS,
            l = c("#a-page"),
            k = c("body"),
            m = function(b) {
                var f =
                    c('\x3cdiv class\x3d"a-sheet-content-container"\x3e\x3c/div\x3e'),
                    l = c('\x3cdiv class\x3d"a-sheet-web"\x3e\x3c/div\x3e').append(f),
                    m = c('\x3cdiv class\x3d"a-sheet-web-container"\x3e\x3c/div\x3e').append(l),
                    k;
                b._preloadDomId ? (k = c("#" + b._preloadDomId), k.show().removeClass(p), f.append(k)) : b._inlineContent && f.append(c(b._inlineContent));
                k = "";
                a.capabilities.ios && b._a11y.label && (k += b._a11y.label + ", ");
                k += b._closeMessage || "close";
                var n = c(a.capabilities.ios ? "\x3cbutton/\x3e" : "\x3cspan/\x3e", {
                    "class": "a-sheet-close visually-hidden",
                    "aria-label": k,
                    tabindex: "0"
                }).prependTo(l).bind("click", d.handleHidingClick);
                e.when("a-event-analytics").execute("TNR: notifyJquery for click", function(a) {
                    a.notifyJquery(n, "click")
                });
                b._closeEnabled && (n.removeClass("visually-hidden"), b._closeMessage ? n.html(b._closeMessage) : n.addClass("a-icon a-icon-close-white"));
                "undefined" !== typeof h.orientation && (n.addClass("a-focus-hidden"), l.addClass("a-focus-hidden"));
                g.addA11yMarkup(l, b);
                b.$contentContainer = f;
                b.$sheetOuterContainer = m;
                b.$container = l;
                b.$sheetOuterContainer.bind("click",
                    d.guardedHandler(b.$sheetOuterContainer[0], d.handleHidingClick));
                e.when("a-event-analytics").execute("TNR: notifyJquery for click (sheetOuterContainer)", function(a) {
                    a.notifyJquery(b.$sheetOuterContainer, "click")
                });
                f = "100%";
                m && (f = b._height + "px");
                m = "translateY(" + f + ")";
                b.$sheetOuterContainer.addClass(p).css({
                    transform: m,
                    WebkitTransform: m
                })
            },
            v = function() {
                l.addClass("a-scroll-disabled")
            },
            n = function() {
                l.removeClass("a-scroll-disabled")
            },
            t = function(a) {
                a.$sheetOuterContainer.removeClass("a-experimental-ios-scrolling")
            },
            w = function(a) {
                a.$sheetOuterContainer.addClass("a-experimental-ios-scrolling")
            };
        return {
            lockPageScroll: v,
            unlockPageScroll: n,
            turnOffExperimentalScrolling: t,
            turnOnExperimentalScrolling: w,
            hide: function(c) {
                var f = c.$container,
                    l = c._duration,
                    m = c.$sheetOuterContainer;
                c._animating && a.stopAnimation(f, !0, !0);
                var g = function() {
                    c._active = !1;
                    c._animating = !1;
                    n();
                    c._initialScrollPosition && (k.scrollTop(c._initialScrollPosition), delete c._initialScrollPosition);
                    t(c);
                    m.addClass(p);
                    c._blurSheet && c._blurSheet();
                    d.triggerEvent(b.events.afterHide,
                        c)
                };
                d.triggerEvent(b.events.beforeHide, c);
                0 < l && (c._animating = !0);
                a.animationFrameDelay(function() {
                    var b = "translateY(" + (m.height() + "px") + ")";
                    a.animate(m, {
                        transform: b,
                        WebkitTransform: b
                    }, l, "ease-in", g);
                    c._lightbox.hide(l)
                });
                return !0
            },
            show: function(c) {
                var l = c.$container,
                    e = c.$sheetOuterContainer,
                    n = c._duration,
                    h = d.getWindowHeight(),
                    t = q.getContainerHeight(c._height, c._autoHeight, h);
                c._animating && a.stopAnimation(l, !0, !0);
                l || (m(c), l = c.$container, e = c.$sheetOuterContainer, e.appendTo("body"));
                c._active = !0;
                l.css({
                    height: t,
                    maxHeight: d.getMaxHeight(h)
                });
                v();
                f.isSafari && (c._initialScrollPosition = k.scrollTop());
                var r = function() {
                    c._animating = !1;
                    w(c);
                    d.triggerEvent(b.events.afterShow, c);
                    c._blurSheet = g.focusComponent(l, event && event.$target)
                };
                d.triggerEvent(b.events.beforeShow, c);
                0 < n && (c._animating = !0);
                a.requestAnimationFrame(function() {
                    e.removeClass(p);
                    c.updatePosition();
                    c.$contentContainer.css({
                        height: "100%",
                        overflowY: "auto"
                    });
                    c._lightbox.show(n);
                    a.animate(e, {
                            transform: "translateY(0)",
                            WebkitTransform: "translateY(0)"
                        }, n,
                        "ease-out", r)
                });
                return !0
            }
        }
    });
    e.when("A", "a-sheet-base", "a-sheet-util", "prv:a-sheet-web-private", "prv:a-sheet-constants", "prv:a-sheet-dimensions", "a-sheet-capabilities").register("a-sheet-web", function(a, d, g, h, f, b, c) {
        return {
            Sheet: d.extend({
                init: function(a) {
                    this._super(a)
                },
                _componentName: "sheet-web",
                show: function() {
                    if (this._animating || this._active) return !1;
                    g.triggerEvent("private:beforeShow", this);
                    return !0
                },
                hide: function() {
                    if (this._animating || !this._active) return e.log("Failed to hide bottom sheet: bottom sheet is " +
                        (this._animating ? "animating" : "not active"), "WARN", "hide"), !1;
                    g.triggerEvent("private:beforeHide", this);
                    return !0
                },
                changeHeight: function(c) {
                    var b = this,
                        d = !1 !== c.persist,
                        m = 1E3 * parseFloat(c.duration);
                    c = c.height;
                    var h = Math.min(Math.max(c, 0), g.getMaxHeight()),
                        n = b.$container;
                    if (b._animating || !a.isFiniteNumber(h)) return e.log("Failed to change bottom sheet height: " + (b._animating ? "bottom sheet is animating" : "height is not finite"), "WARN", "changeHeight"), !1;
                    d && (b._height = c);
                    if (!b._active || h === n.height()) return g.triggerEvent(f.events.changeHeight,
                        b), !0;
                    a.isFiniteNumber(m) || (m = b._duration);
                    var q = function() {
                        b._animating = !1;
                        g.triggerEvent(f.events.changeHeight, b)
                    };
                    0 < m && (b._animating = !0, b._autoHeight && n.css("height", n.height() + "px"));
                    b.updatePosition();
                    a.animationFrameDelay(function() {
                        a.animate(n, {
                            height: h + "px"
                        }, m, "ease-out", q)
                    });
                    return !0
                },
                updatePosition: function() {
                    var c = this,
                        d = g.getWindowHeight(),
                        f = c.$contentContainer.height(),
                        m = c.$sheetOuterContainer,
                        d = b.getSheetOuterContainerDimensions(d, f);
                    m.css({
                        height: d.height + "px"
                    });
                    a.capabilities.ios &&
                        (h.turnOffExperimentalScrolling(c), a.delay(function() {
                            h.turnOnExperimentalScrolling(c)
                        }, 500))
                },
                getContentContainer: function() {
                    return this.$contentContainer
                },
                destroy: function() {
                    if (this._active) e.log("Cannot destroy Bottomsheet as Bottomsheet is currently open", "WARN", "AmazonUIBottomsheet");
                    else {
                        for (var c in f.events) a.off("a:sheet:" + f.events[c] + ":" + this._name);
                        this.$sheetOuterContainer.remove();
                        a.trigger("a:sheet:private:destroy", {
                            sheet: this
                        })
                    }
                }
            })
        }
    });
    "use strict";
    e.when("A", "prv:a-sheet-constants",
        "a-sheet-util", "prv:a-sheet-dimensions").register("prv:a-sheet-orientation-change", function(a, d, g, e) {
        return {
            resetSheetHeight: function(a) {
                var b = a.$container.height(),
                    c = g.getMaxHeight(),
                    d = {
                        duration: 0,
                        persist: !1
                    };
                b > c ? d.height = c : b !== a._height && (d.height = a._autoHeight ? "auto" : a._height);
                "height" in d && a.changeHeight(d)
            },
            handleScrollerOrientation: function(a) {
                var b = g.getWindowHeight();
                a.$container.css({
                    top: "",
                    height: e.getContainerHeight(a._height, a._autoHeight, b),
                    maxHeight: g.getMaxHeight()
                });
                a.updatePosition()
            }
        }
    });
    "use strict";
    e.when("A", "a-component", "a-sheet-util").register("prv:a-sheet-lightbox", function(a, d, g) {
        var h = a.$,
            f = '\x3cdiv class\x3d"a-sheet-lightbox ' + a.constants.HIDE_CLASS + '" /\x3e';
        return d.create({
            _componentName: "sheet-lightbox",
            init: function(a) {
                this.$container = h(f);
                this.$container.bind("click", g.handleHidingClick).bind("touchmove", g.handleLightboxTouchmove);
                var c = this.$container;
                e.when("a-event-analytics").execute(function(a) {
                    a.notifyJquery(c, "click")
                });
                this._animating = this._active = !1;
                this._trackApi()
            },
            show: function(b) {
                var c = this;
                b = b || 0;
                c._duration = b;
                var d = c.$container;
                d.appendTo("body");
                var e = function() {
                    c._active = !0;
                    c._animating = !1
                };
                0 < b && (c._animating = !0);
                a.requestAnimationFrame(function() {
                    a.fadeIn(d, b, null, e)
                })
            },
            hide: function(b) {
                var c = this;
                b = a.isFiniteNumber(b) ? b : c._duration;
                var d = c.$container,
                    e = function() {
                        c._active = !1;
                        c._animating = !1
                    };
                0 < b && (c._animating = !0);
                a.requestAnimationFrame(function() {
                    a.fadeOut(d, b, null, e)
                })
            }
        })
    });
    "use strict";
    e.when("A", "a-sheet-accessibility-templates").register("a-sheet-accessibility",
        function(a, d) {
            var e = a.$,
                h = d.startAnchorTemplate,
                f = d.endAnchorTemplate,
                b = d.descriptionTemplate,
                c = function(a, c) {
                    var d = {
                        "{{DESCRIPTION}}": c,
                        "{{DESCRIPTION_ID}}": a
                    };
                    return b.replace(/\{\{[\w_]*\}\}/g, function(a) {
                        return d[a]
                    })
                },
                p = function(c) {
                    c = h;
                    a.capabilities.ios && (c = c.replace(/span/g, "button"));
                    return c
                },
                l = function() {
                    var c = f;
                    a.capabilities.ios && (c = c.replace(/span/g, "button"));
                    return c
                },
                k = function(a) {
                    a = a.find("a, button, input, select, textarea, [tabindex]");
                    a = a.not("[tabindex\x3d'-1']");
                    return a.not(".a-sheet-start, .a-sheet-end")
                };
            return {
                getStartAnchorHtml: p,
                getEndAnchorHtml: l,
                getTabbableElements: k,
                addA11yMarkup: function(b, d) {
                    var e = d._a11y;
                    a.declarative.create(b, "a-sheet-a11y", {
                        name: d._name
                    });
                    var f = {
                        role: "dialog",
                        tabindex: "0"
                    };
                    a.capabilities.ios && delete f.role;
                    e.label && (0 === e.label.indexOf("#") ? f["aria-labelledby"] = e.label.substring(1) : f["aria-label"] = e.label);
                    e.description && (0 === e.label.indexOf("#") ? f["aria-describedby"] = e.description.substring(1) : (d = d._name + "-description", f["aria-describedby"] = d, b.prepend(c(d, e.description))));
                    for (var g in f) f[g] !== r && b.attr(g, f[g]);
                    b.prepend(p(e));
                    b.append(l(e))
                },
                focusComponent: function(c, b) {
                    var d = b || e(document.activeElement);
                    a.capabilities.ios ? k(c).first().focus() : c.focus();
                    e("#a-page").attr("aria-hidden", "true");
                    return function() {
                        e("#a-page").removeAttr("aria-hidden");
                        a.delay(function() {
                            d.focus()
                        }, 0)
                    }
                }
            }
        });
    "use strict";
    e.declare("a-sheet-accessibility-templates", {
        startAnchorTemplate: '\x3cspan tabindex\x3d"0" class\x3d"a-sheet-start a-sheet-a11y-offscreen"\x3e\x3c/span\x3e',
        endAnchorTemplate: '\x3cspan tabindex\x3d"0" class\x3d"a-sheet-end a-sheet-a11y-offscreen"\x3e\x3c/span\x3e',
        descriptionTemplate: '\x3cspan id\x3d"{{DESCRIPTION_ID}}" class\x3d"a-sheet-a11y-offscreen a-hidden"\x3e{{DESCRIPTION}}\x3c/span\x3e'
    });
    e.declare("prv:a-sheet-constants", {
        closeButtonAreaHeightInPx: 40,
        defaultSheetHeaderHeightInPx: 50,
        maxHeightOffsetInPx: {
            mshop: {
                portrait: 80,
                landscape: 80
            },
            web: {
                portrait: 160,
                landscape: 120
            }
        },
        defaults: {
            animationDurationInMS: 300,
            sheetHeightInPx: 300
        },
        headerAnimationFunction: "cubic-bezier(0.4, 0, 0.6, 0.95)",
        logPrefix: "AmazonUIBottomSheet: ",
        closeButtonType: {
            icon: "icon",
            message: "message"
        },
        events: {
            afterHide: "afterHide",
            beforeHide: "beforeHide",
            afterShow: "afterShow",
            beforeShow: "beforeShow",
            changeHeight: "changeHeight"
        }
    });
    "use strict";
    e.when("A", "prv:a-sheet-constants").register("a-sheet-util", function(a, d) {
        var g, q = d.maxHeightOffsetInPx;
        e.when("mash").execute(function(a) {
            g = !0
        });
        var f = function() {
                return h.innerHeight
            },
            b = function(c, b) {
                a.trigger("a:sheet:" + c, {
                    sheet: b
                });
                b && b._name && a.trigger("a:sheet:" + c + ":" + b._name, {
                    sheet: b
                })
            };
        return {
            getWindowHeight: f,
            getMaxHeight: function(a) {
                var b = q[g ? "mshop" :
                    "web"][90 === Math.abs(h.orientation) ? "landscape" : "portrait"];
                return (a || f()) - b
            },
            guardedHandler: function(a, b) {
                return function(d) {
                    d.target === a && b(d)
                }
            },
            triggerEvent: b,
            handleLightboxTouchmove: function(a) {
                a.preventDefault();
                a.stopPropagation()
            },
            handleHidingClick: function(a) {
                a.preventDefault();
                a.stopPropagation();
                b("lightbox:private:click")
            },
            triggerEventDeferred: function(c, d) {
                a.delay(function() {
                    b(c, d)
                })
            }
        }
    });
    "use strict";
    e.when("A", "a-util", "a-ua", "prv:a-capabilities").register("a-sheet-capabilities", function(a,
        d, g, h) {
        function f(a) {
            if (c) return c[a];
            var e = d.cookies.get("amzn-app-ctxt");
            if (e) {
                var e = decodeURIComponent(e),
                    f = e.indexOf(" ");
                e.substring(0, f);
                e = e.substring(f);
                c = b.parseJSON(e);
                return c[a]
            }
        }
        var b = a.$,
            c;
        return {
            isAndroidApp: function() {
                return "Android" === f("os")
            },
            isIOSApp: function() {
                return "iOS" === f("os")
            },
            shouldShowHybridBottomSheet: function() {
                e.log("Hybrid Bottomsheets have been deprecated in AUI v3.19.3 and only Web Bottomsheets are vended. Please stop using this API immediately.", "WARN", "aSheetCapabilities");
                return !1
            }
        }
    });
    e.when("A", "a-sheet-util", "prv:a-sheet-constants").register("prv:a-sheet-dimensions", function(a, d, e) {
        return {
            getSheetOuterContainerDimensions: function(a, d) {
                var b = a - d - e.closeButtonAreaHeightInPx;
                return {
                    top: 0 < b ? b : 0,
                    height: 0 < b ? d + e.closeButtonAreaHeightInPx : a
                }
            },
            getContainerHeight: function(a, e, b) {
                a = Math.min(a, d.getMaxHeight(b));
                return e ? "auto" : a + "px"
            }
        }
    });
    "use strict";
    e.when("A").register("prv:a-sheet-history-manager", function(a) {
        var d = 0,
            g = !1;
        e.when("mash").execute(function(a) {
            g = !0
        });
        e.when("a-sheet-history-support").execute(function(a) {
            a.hasHistorySupport() ?
                (d = 2, h.addEventListener("popstate", q)) : (d = 1, h.addEventListener("hashchange", f))
        });
        var q = function(b) {
                var c = b.state;
                c && "a-sheet-web" === c.component && "hide" === c.action && (b.preventDefault(), h.history.replaceState(c.oldState, "", null), a.trigger("a:sheet:history:private:pop", {
                    sheetName: c.sheetName
                }))
            },
            f = function(b) {
                g || (b = b.oldURL, (b = 1 < b.split("#").length && b.split("#")[1]) && 0 === b.indexOf("a-sheet-web-") && (b = b.split("a-sheet-web-")[1], a.trigger("a:sheet:history:private:pop", {
                    sheetName: b
                })))
            };
        return {
            push: function(a) {
                2 ===
                    d ? (h.history.replaceState({
                        oldState: h.history.state,
                        component: "a-sheet-web",
                        action: "hide",
                        sheetName: a._name
                    }, "", null), h.history.pushState(null, "", null)) : 1 === d && (h.location.hash = "#a-sheet-web-" + a._name)
            },
            goBack: function() {
                0 !== d && h.history.back()
            }
        }
    });
    "use strict";
    e.when("A").execute("a-sheet-history-support-detection", function(a) {
        var d = function() {
            e.declare("a-sheet-history-support-ready", {})
        };
        if (h.navigator && h.navigator.userAgent && h.navigator.userAgent.match("CriOS")) a.$(document).one("touchstart",
            d);
        else d();
        e.when("a-sheet-history-support-ready").register("a-sheet-history-support", function() {
            return {
                hasHistorySupport: function() {
                    return h.history && "function" === typeof h.history.pushState
                }
            }
        })
    })
});
/* ******** */
(function(c) {
    var f = window.AmazonUIPageJS || window.P,
        e = f._namespace || f.attributeErrors,
        d = e ? e("AmazonUITruncate", "AmazonUI") : f;
    d.guardFatal ? d.guardFatal(c)(d, window) : d.execute(function() {
        c(d, window)
    })
})(function(c, f, e) {
    c.when("A", "a-component", "prv:a-truncate-util").register("a-truncate", function(d, c, f) {
        function e(a) {
            var b = a._$fullText,
                d = Math.round(parseFloat(a._$element.css("max-height"))),
                c = a.getOverflowMarker(),
                p = a.getSpecialCharacterList(),
                h = a._$offscreenTextHolder;
            a._$element.append(h);
            if (!(parseFloat(h.html(b).css("height")) <=
                    d)) {
                a = 0;
                for (var k = b.length, l, g; k > a;) l = Math.floor((a + k) / 2), g = b.substring(0, l + 1) + c, parseFloat(h.html(g).css("height")) > d ? k = l : a = l + 1;
                b = f.trimSpecialChars(b.substring(0, k), p) + c
            }
            h.remove();
            return b
        }

        function m() {
            g('.a-truncate:not([data-a-manual-update\x3d"true"])').attr("data-a-recalculate", !0);
            q()
        }
        var g = d.$,
            n = c.create({
                _componentName: "truncate",
                init: function(a, b) {
                    this._super(a, b);
                    this._$full = this._$element.find(".a-truncate-full");
                    this._$cut = this._$element.find(".a-truncate-cut");
                    this._$fullText = this.getFullText();
                    this._$offscreenTextHolder = g('\x3cspan class\x3d"a-truncate-calc a-offscreen"/\x3e')
                },
                update: function(a) {
                    var b = this._$cut.html(),
                        c = e(this);
                    this._$fullText !== c ? this._$cut.height(this.getMaxHeight()) : this._$cut.height("auto");
                    this._$cut.html(c);
                    this._$element.attr("data-a-updated", !0);
                    this._$full.addClass("a-offscreen");
                    this._$cut.removeClass("a-hidden");
                    c = {
                        truncateContainer: this._$element,
                        truncateInstance: this
                    };
                    a && a.silent || (a = this.getTruncatedText(), b !== a && (d.trigger("a:truncate:updated", c), (b = this._$element.data("a-truncate-name")) &&
                        d.trigger("a:truncate:" + b + ":updated", c)))
                },
                getFullText: function() {
                    return this._$full.html()
                },
                getTruncatedText: function() {
                    return this.getIsUpdated() ? this._$cut.html() : e(this)
                },
                getIsUpdated: function() {
                    return this._$element.is("[data-a-updated]")
                },
                getOverflowMarker: function() {
                    return this._$element.data("a-overflow-marker") || ""
                },
                getSpecialCharacterList: function() {
                    return this._$element.data("a-special-character-list") || ""
                },
                getLineHeight: function() {
                    return this._$element[0].style.lineHeight
                },
                getMaxHeight: function() {
                    return this._$element[0].style.maxHeight
                },
                getIfTextFits: function() {
                    return this._$fullText === e(this)
                }
            }),
            q = function(a) {
                function b() {
                    (c = a()) && d.delay(b, 0)
                }
                var c = !1;
                return function() {
                    c || b()
                }
            }(function() {
                var a = g('.a-truncate[data-a-recalculate\x3d"true"]').first(),
                    b = !!a.length;
                b && ((new n(a)).update(), a.attr("data-a-recalculate", !1));
                return b
            });
        d.on("ready orientationchange", m);
        d.on("resize", function(a, b) {
            b.width && m()
        });
        return {
            get: function(a, b) {
                return new n(a, b)
            }
        }
    });
    c.declare("prv:a-truncate-util", {
        trimSpecialChars: function(c, e) {
            e = new RegExp("[" +
                e.replace(/[.\\+*?[^\]$(){}=!<>|:-]/g, "\\$\x26") + "\\s]+$");
            return c.replace(e, "")
        }
    })
});
/* ******** */
(function(h) {
    var m = window.AmazonUIPageJS || window.P,
        n = m._namespace || m.attributeErrors,
        d = n ? n("AmazonUICardUI", "AmazonUI") : m;
    d.guardFatal ? d.guardFatal(h)(d, window) : d.execute(function() {
        h(d, window)
    })
})(function(h, m, n) {
    h.when("A", "a-component", "prv:a-cardui-peek-toggle", "prv:a-cardui-peek-expand").register("a-cardui", function(d, e, g, c) {
        var b = d.$,
            f = e.create({
                _componentName: "cardui",
                init: function(a, b) {
                    this._super(a, b);
                    this.metadata = {
                        interactedOnce: !1,
                        describedByIds: this._$element.data("describedByIds"),
                        cardExpanded: this.isExpanded(),
                        cardName: this.getName()
                    }
                },
                getCardType: function() {
                    return b(this._$element).data("a-card-type")
                },
                isExpanded: function() {},
                getName: function() {
                    return this._$element.attr("name")
                },
                getId: function() {
                    return this._$element.attr("id")
                },
                toggle: function() {}
            });
        return {
            get: function(a, k) {
                var l;
                if (!(l = b(a).data("cardInstance"))) {
                    switch (b(a).data("a-card-type")) {
                        case "peekToggle":
                            l = f.extend(g);
                            break;
                        case "peekExpand":
                            l = f.extend(c);
                            break;
                        default:
                            l = f
                    }
                    k = new l(a, k);
                    b(a).data("cardInstance", k);
                    d.trigger("a:card:initialized",
                        k);
                    b(a).attr("id") && d.trigger("a:card:" + b(a).attr("id") + ":initialized", k);
                    l = k
                }
                return l
            }
        }
    });
    "use strict";
    h.when("A", "a-component").register("prv:a-cardui-content", function(d, e) {
        var g = e.create({
            _componentName: "carduiContent",
            init: function(c, b) {
                this._super(c, b)
            },
            getHeight: function() {
                return this._$element[0].scrollHeight
            },
            getMaxHeightDataAttribute: function() {
                return this._$element.data("a-max-height")
            }
        });
        return {
            get: function(c, b) {
                return new g(c, b)
            }
        }
    });
    "use strict";
    h.when("A", "a-component", "a-cardui").register("a-cardui-deck",
        function(d, e, g) {
            function c(a, b) {
                f(a).data("cardInstance") || (f(a).attr("name", b.deckName + "-card" + b.cardCount++), f(a).data("describedByIds", b.describedByIds));
                return g.get(a)
            }

            function b(a, b) {
                b = new k(a, b);
                f(a).data("deckInstance", b);
                return b
            }
            var f = d.$,
                a = 0,
                k = e.create({
                    _componentName: "carduiDeck",
                    init: function(b, c) {
                        this._super(b, c);
                        c = this._$element;
                        b = "a-cardui-deck-autoname-" + a++;
                        f(c).attr("name", b);
                        c = this._$element;
                        var d = b + "-teaser-describedby-collapsed",
                            k = b + "-teaser-describedby-expanded";
                        f(c).find(".a-teaser-describedby-collapsed").attr("id",
                            d);
                        f(c).find(".a-teaser-describedby-expanded").attr("id", k);
                        this.metadata = {
                            cardCount: 0,
                            deckName: b,
                            describedByIds: {
                                collapsed: d,
                                expanded: k
                            }
                        };
                        this.initializeAllCards()
                    },
                    initializeCard: function(a, b) {
                        return c(a, this.metadata)
                    },
                    initializeAllCards: function() {
                        var a = this;
                        f(this._$element).find(".a-cardui").each(function() {
                            return c(this, a.metadata)
                        })
                    }
                });
            d.on("ready", function() {
                f(".a-cardui-deck").each(function() {
                    b(this)
                })
            });
            return {
                get: function(a, c) {
                    return f(a).data("deckInstance") || b(a, c)
                }
            }
        });
    "use strict";
    h.when("A", "a-component", "prv:a-see-more", "prv:a-expander-icon", "p-detect").register("prv:a-cardui-expand-control-footer", function(d, e, g, c, b) {
        function f(a, b) {
            a._$seeMore.toggleSeeMore(b.cardExpanded);
            a._$expanderIcon.toggleExpanderIcon(b.cardExpanded)
        }
        var a = e.create({
            _componentName: "carduiExpandControlFooter",
            init: function(a, b) {
                this._super(a, b);
                this._$expanderIcon = c.get(this._$element.find(".a-expander-icon"));
                this._$seeMore = g.get(this._$element.find(".a-see-more"));
                this._$button = this._$element.find('span[role\x3d"button"]')
            },
            toggleExpansion: function(a) {
                var c = this;
                b.capabilities.transition && a.interactedOnce ? d.fadeOut(c._$element, 200, "linear", function() {
                    f(c, a);
                    d.fadeIn(c._$element, 200)
                }) : f(c, a)
            },
            getName: function() {
                return this._$element.attr("name")
            },
            getId: function() {
                return this._$element.attr("id")
            },
            addTrigger: function(a) {
                this._$element.click(function() {
                    d.trigger("a:card:" + a + ":toggle", this)
                });
                this._$element.keypress(function(b) {
                    var c = d.constants.keycodes;
                    b = b.which;
                    b !== c.ENTER && b !== c.SPACE || d.trigger("a:card:" + a + ":toggle",
                        this)
                })
            }
        });
        return {
            get: function(b, c) {
                return new a(b, c)
            }
        }
    });
    "use strict";
    h.when("A", "a-component").register("prv:a-cardui-expand-control-title", function(d, e) {
        var g = e.create({
            _componentName: "carduiExpandControlTitle",
            init: function(c, b) {
                this._super(c, b);
                this._$button = this._$element.find('span[role\x3d"button"]');
                this._$header = this._$element.find("h3")
            },
            getName: function() {
                return this._$element.attr("name")
            },
            getId: function() {
                return this._$element.attr("id")
            },
            addTrigger: function(c) {
                this._$element.click(function() {
                    d.trigger("a:card:" +
                        c + ":toggle", this)
                });
                this._$element.keypress(function(b) {
                    var e = d.constants.keycodes;
                    b = b.which;
                    b !== e.ENTER && b !== e.SPACE || d.trigger("a:card:" + c + ":toggle", this)
                })
            }
        });
        return {
            get: function(c, b) {
                return new g(c, b)
            }
        }
    });
    "use strict";
    h.when("A", "a-component").register("prv:a-cardui-teaser", function(d, e) {
        var g = e.create({
            _componentName: "carduiTeaser",
            init: function(c, b) {
                this._super(c, b)
            },
            getHeight: function() {
                return this._$element[0].scrollHeight
            }
        });
        return {
            get: function(c, b) {
                return new g(c, b)
            }
        }
    });
    "use strict";
    h.when("A",
        "a-component").register("prv:a-expander-icon", function(d, e) {
        var g = e.create({
            _componentName: "expanderIcon",
            init: function(c, b) {
                this._super(c, b);
                this._$icon = this._$element.find(".a-css-icon")
            },
            toggleExpanderIcon: function(c) {
                var b = c ? "a-css-icon-expand" : "a-css-icon-collapse";
                c = c ? "a-css-icon-collapse" : "a-css-icon-expand";
                this._$icon.addClass("a-css-icon-draw");
                this._$icon.removeClass(b).addClass(c)
            }
        });
        return {
            get: function(c, b) {
                return new g(c, b)
            }
        }
    });
    "use strict";
    h.when("A", "a-component", "prv:a-cardui-scroll-viewport").register("a-reactive-container",
        function(d, e, g) {
            var c = e.create({
                _componentName: "reactiveContainer",
                init: function(b, c) {
                    this._super(b, c);
                    this._$measured = !1;
                    this._$element.addClass("a-reactive-container-transition")
                },
                setHeight: function(b) {
                    this._$element.css("height", b + "px");
                    this._$measured ? g.adjustScroll(this, parseFloat(b)) : this._$measured = !0
                },
                resetInitialization: function() {
                    this._$measured = !1
                },
                getHeight: function() {
                    return this._$element.css("height")
                }
            });
            return {
                get: function(b, d) {
                    return new c(b, d)
                }
            }
        });
    "use strict";
    h.when("A", "a-component").register("prv:a-see-more",
        function(d, e) {
            var g = e.create({
                _componentName: "seeMore",
                init: function(c, b) {
                    this._super(c, b);
                    this._$seeMoreText = this._$element.find(".a-see-more-text");
                    this._$seeLessText = this._$element.find(".a-see-less-text")
                },
                toggleSeeMore: function(c) {
                    c ? (this._$seeMoreText.hide(), this._$seeLessText.show()) : (this._$seeMoreText.show(), this._$seeLessText.hide())
                }
            });
            return {
                get: function(c, b) {
                    return new g(c, b)
                }
            }
        });
    "use strict";
    h.when("A").register("prv:a-cardui-scroll-viewport", function(d) {
        var e = d.$;
        return {
            adjustScroll: function(d,
                c) {
                d = d._$element.offset().top;
                var b = e(document).scrollTop(),
                    f = e(m).height();
                b > d + c && e("html,body").animate({
                    scrollTop: d - 100
                }, 400);
                b + f < d + c && e("html,body").animate({
                    scrollTop: b + 100
                }, 400)
            }
        }
    });
    "use strict";
    h.when("A", "prv:a-cardui-expand-control-title", "prv:a-cardui-expand-control-footer", "prv:a-cardui-teaser", "prv:a-cardui-content", "prv:a-reactive-container").register("prv:a-cardui-type-utility", function(d, e, g, c, b, f) {
        return {
            getExpandControlTitle: function(a) {
                return e.get(a._$element.find(".a-cardui-expand-control-title"))
            },
            getExpandControlFooter: function(a) {
                return g.get(a._$element.find(".a-cardui-expand-control-footer"))
            },
            getTeaser: function(a) {
                return c.get(a._$element.find(".a-cardui-teaser"))
            },
            getContent: function(a) {
                return b.get(a._$element.find(".a-cardui-content"))
            },
            getReactiveContainer: function(a) {
                a = a._$element.find(".a-reactive-container");
                return 0 < a.length ? f.get(a) : null
            },
            getEventName: function(a) {
                return "a:card:" + a.getName() + ":toggle"
            }
        }
    });
    "use strict";
    h.when("A", "prv:a-cardui-type-utility").register("prv:a-cardui-peek-expand",
        function(d, e) {
            function g(a) {
                var b = a._$header,
                    c = a._$footer;
                a.metadata.interactedOnce && d.delay(function() {
                    var a = f(document).scrollTop();
                    b._$header.focus();
                    f("html,body").scrollTop(a)
                }, 50);
                c._$element.attr("aria-hidden", !0)
            }

            function c(a) {
                var c = e.getEventName(a);
                d.on(c, function(c) {
                    if (!a.metadata.interactedOnce) {
                        a.metadata.interactedOnce = !0;
                        var e = a._$content;
                        a._$teaser._$element.removeClass("a-cardui-uninitialized");
                        e._$element.removeClass("a-cardui-uninitialized");
                        e._$element.css("max-height", "none");
                        b(a)
                    }
                    e = !a.isExpanded();
                    a._$element.attr("data-a-expanded", e);
                    a.metadata.cardExpanded = e;
                    a._$footer.toggleExpansion(a.metadata);
                    b(a);
                    g(a);
                    c = {
                        carduiInstance: a,
                        triggerElement: c
                    };
                    d.trigger("a:card:toggled", c);
                    a.getId() && d.trigger("a:card:" + a.getId() + ":toggled", c)
                })
            }

            function b(a) {
                var b = a._$teaser,
                    c = a._$content,
                    d = a._$reactiveContainer,
                    e = a.metadata;
                c.getMaxHeightDataAttribute() ? (b = c.getHeight(), b <= c.getMaxHeightDataAttribute() ? (a._$element.attr("data-a-card-type", "basic"), a._$element.find(".a-cardui-footer").addClass("a-hidden"),
                    d.setHeight(b)) : (a._$element.attr("data-a-card-type", "peekExpand"), a._$element.find(".a-cardui-footer").removeClass("a-hidden"), a = c.getMaxHeightDataAttribute(), d.setHeight(e.cardExpanded ? c.getHeight() : a))) : d.setHeight(e.cardExpanded ? b.getHeight() + c.getHeight() : b.getHeight())
            }
            var f = d.$;
            return {
                init: function(a, f) {
                    this._super(a, f);
                    this._$content = e.getContent(this);
                    this._$reactiveContainer = e.getReactiveContainer(this);
                    this._$footer = e.getExpandControlFooter(this);
                    var l = this;
                    d.on("orientationchange", function() {
                        l._$reactiveContainer.resetInitialization();
                        b(l)
                    });
                    this._$header = e.getExpandControlTitle(this);
                    this._$teaser = e.getTeaser(this);
                    this._$header.addTrigger(this.metadata.cardName);
                    this._$footer.addTrigger(this.metadata.cardName);
                    this._$footer.toggleExpansion(this.metadata);
                    g(this);
                    c(this);
                    this._$content.getHeight() <= this._$content.getMaxHeightDataAttribute() && (this._$reactiveContainer.setHeight(this._$content.getHeight()), this._$element.attr("data-a-card-type", "basic"), this._$element.find(".a-cardui-footer").addClass("a-hidden"))
                },
                isExpanded: function() {
                    return "true" ===
                        this._$element.attr("data-a-expanded")
                },
                toggle: function(a) {
                    d.trigger("a:card:" + this.getName() + ":toggle", a)
                }
            }
        });
    "use strict";
    h.when("A", "prv:a-cardui-type-utility").register("prv:a-cardui-peek-toggle", function(d, e) {
        function g(a) {
            var b = a._$header,
                c = a._$footer,
                e = a._$teaser,
                g = a._$content;
            a = a.metadata;
            a.interactedOnce && d.delay(function() {
                var a = f(document).scrollTop();
                b._$header.focus();
                f("html,body").scrollTop(a)
            }, 50);
            b._$button.attr("aria-expanded", a.cardExpanded);
            b._$header.attr("aria-describedby", a.cardExpanded ?
                a.describedByIds.expanded : a.describedByIds.collapsed);
            c._$button.attr("aria-expanded", a.cardExpanded);
            c._$element.attr("aria-describedby", a.cardExpanded ? a.describedByIds.expanded : a.describedByIds.collapsed);
            e._$element.attr("aria-hidden", a.cardExpanded);
            g._$element.attr("aria-hidden", !a.cardExpanded)
        }

        function c(a) {
            var c = e.getEventName(a);
            d.on(c, function(c) {
                if (!a.metadata.interactedOnce) {
                    a.metadata.interactedOnce = !0;
                    var e = a._$content;
                    a._$teaser._$element.removeClass("a-cardui-uninitialized");
                    e._$element.removeClass("a-cardui-uninitialized");
                    a._$reactiveContainer && b(a)
                }
                var e = !a.isExpanded(),
                    f = a._$teaser,
                    h = a._$content;
                a._$element.attr("data-a-expanded", e);
                (a.metadata.cardExpanded = e) ? (f._$element.addClass("a-cardui-absolute-position"), h._$element.removeClass("a-cardui-absolute-position")) : (h._$element.addClass("a-cardui-absolute-position"), f._$element.removeClass("a-cardui-absolute-position"));
                a._$footer.toggleExpansion(a.metadata);
                a._$reactiveContainer && b(a);
                g(a);
                c = {
                    carduiInstance: a,
                    triggerElement: c
                };
                d.trigger("a:card:toggled", c);
                a.getId() &&
                    d.trigger("a:card:" + a.getId() + ":toggled", c)
            })
        }

        function b(a) {
            var b = a._$teaser,
                c = a._$content,
                d = a._$reactiveContainer;
            a.metadata.cardExpanded ? d.setHeight(c.getHeight()) : d.setHeight(b.getHeight())
        }
        var f = d.$;
        return {
            init: function(a, f) {
                this._super(a, f);
                this._$header = e.getExpandControlTitle(this);
                this._$content = e.getContent(this);
                this._$footer = e.getExpandControlFooter(this);
                this._$teaser = e.getTeaser(this);
                this._$reactiveContainer = e.getReactiveContainer(this);
                this._$header.addTrigger(this.metadata.cardName);
                this._$footer.addTrigger(this.metadata.cardName);
                this._$footer.toggleExpansion(this.metadata);
                g(this);
                c(this);
                var h = this;
                if (h._$reactiveContainer) d.on("orientationchange", function() {
                    h.metadata.interactedOnce && (h._$reactiveContainer.resetInitialization(), b(h))
                })
            },
            isExpanded: function() {
                return "true" === this._$element.attr("data-a-expanded")
            },
            toggle: function(a) {
                d.trigger("a:card:" + this.getName() + ":toggle", a)
            }
        }
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("AmazonUICompatJS", "AmazonUI") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {
    c.when("A").register("a-ios-bug-fixes", function(a) {
        var e = a.$;
        a.capabilities.ios && a.on.load(function() {
            a.delay(function() {
                0 !== b.scrollY || e("body").hasClass("a-suppress-ios-scroll") || e('meta[name\x3d"apple-itunes-app"]').length || b.speechSynthesis || b.scrollTo(0, 1)
            }, 10)
        })
    });
    "use strict";
    c.when("A").register("a-orientation-change",
        function(a) {
            a.capabilities.touch && a.on.ready(function() {
                a.on("orientationchange", function() {
                    var a = document,
                        b = a.activeElement;
                    b && b !== a.body && (a = b.tagName.toLowerCase(), "input" !== a && "textArea" !== a && "select" !== a || b.scrollIntoView())
                })
            })
        })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("AmazonUIErrata", "AmazonUI") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(c) {
    var a = window.AmazonUIPageJS || window.P,
        d = a._namespace || a.attributeErrors,
        b = d ? d("AmazonUI", "AmazonUI") : a;
    b.guardFatal ? b.guardFatal(c)(b, window) : b.execute(function() {
        c(b, window)
    })
})(function(c, a, d) {
    a.pcv = a.pcv || {};
    a.pcv.AmazonUI = "3dee07c8bdc10e425e68d60fa32953e37707ee9a"
});
/* ******** */