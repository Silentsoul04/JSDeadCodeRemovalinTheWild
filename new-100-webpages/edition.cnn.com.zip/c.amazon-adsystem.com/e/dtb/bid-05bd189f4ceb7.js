/* aax response */
apstag.bids({
    "slots": [{
        "targeting": ["amzniid", "amznp", "amznsz", "amznbid"],
        "amzniid": "Iu25e1WVugkcRZYSMPUpKasAAAFttWdrEgMAAAzYAYdwVU8",
        "size": "300x250",
        "crid": "185300229",
        "meta": ["slotID", "mediaType", "size"],
        "amznsz": "300x250",
        "slotID": "ad_rect_atf_01",
        "amznp": "1ujtiww",
        "mediaType": "d",
        "amznbid": "f0ey2o"
    }, {
        "targeting": ["amzniid", "amznp", "amznsz", "amznbid"],
        "amzniid": "IjB79V5XIw77ohVdTXGw4ykAAAFttWdrEwMAAAzYAZQPKJw",
        "size": "300x250",
        "crid": "185300229",
        "meta": ["slotID", "mediaType", "size"],
        "amznsz": "300x250",
        "slotID": "ad_rect_btf_02",
        "amznp": "1ujtiww",
        "mediaType": "d",
        "amznbid": "jg8g74"
    }],
    "host": "https://aax-eu.amazon-adsystem.com",
    "cfe": true,
    "ev": true,
    "cfn": "bao-csm/direct/csm_others.js",
    "status": "ok",
    "cb": "6114944446931570706516128"
})