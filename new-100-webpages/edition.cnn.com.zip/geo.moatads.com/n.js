MoatSuperV26.gna909329({
    "nu": 640366,
    "nm": 549245
})