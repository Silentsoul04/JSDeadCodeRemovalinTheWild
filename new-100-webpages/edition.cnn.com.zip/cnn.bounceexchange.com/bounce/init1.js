//<script>
bouncex.init1Response({
    "brand_styles": false,
    "webfonts": false,
    "cookie": {
        "v": {
            "completed_signup": false,
            "last_session_vid": false,
            "session_count": 0,
            "submitted_underscored": false,
            "submitted_thepoint": false,
            "submitted_fareedsglobalbriefing": false,
            "submitted_resultsarein": false,
            "submitted_fivethings": false,
            "submitted_reliablesources": false,
            "submitted_provokepersuade": false,
            "submitted_goodstuff": false,
            "submitted_5cosas": false,
            "submitted_livevideo": false,
            "submitted_indiaalerts": false,
            "submitted_beforethebell": false,
            "submitted_impeachment": false
        },
        "fvt": 1570706518,
        "vid": 1570706518919441,
        "ao": 0,
        "lp": "https%3A%2F%2Fedition.cnn.com%2F",
        "as": 0,
        "vpv": 1,
        "d": "p",
        "r": "",
        "cvt": 1570706518,
        "sid": -1,
        "gcr": 32,
        "m": 0,
        "did": "6990678118507840132",
        "lvt": 1570706518
    },
    "debug": false,
    "testmode": {
        "bxtest": false,
        "office": false,
        "bxdev": false
    },
    "state": {
        "newvid": true,
        "iol": true,
        "tn": 1570706518,
        "pvid": 1,
        "gdpr": true,
        "casl": false,
        "device": {
            "browser": "Chrome",
            "version": "77.0.3865.90",
            "platform": "Android",
            "device_type": "phone"
        },
        "no_kinesis": true,
        "request_token": "a787be4e06a4ccbe66457bb6e03e8194293367b7e32a8db3f3e5a897494e28d6",
        "rc": false,
        "mobile": true,
        "vip": "80.113.225.15",
        "geo": {
            "country_code": "NL",
            "country_code3": "NLD",
            "country_name": "Netherlands",
            "region": "07",
            "city": "Amsterdam",
            "postal_code": "1083",
            "area_code": null,
            "dma_code": null,
            "metro_code": null,
            "continent_code": "EU",
            "zip": "1083",
            "country": "NL",
            "region_name": "Noord-Holland"
        }
    },
    "gbi_stacks": false,
    "creatives": false,
    "campaigns": false,
    "gbi2_enabled": true,
    "ssp_config": {
        "index": {
            "s": "185860",
            "qa_site_id": "167884",
            "reload": 50000,
            "stackWeight": 0,
            "timeout": 2000,
            "production": true,
            "jsonp": true
        },
        "pbm": {
            "desktop_id": "410931",
            "mobile_id": "410932",
            "publisher_id": "156512",
            "qa_site_id": "248764",
            "reload": 50000,
            "timeout": 2000,
            "endpoint": "hbopenbid.pubmatic.com\/translator?",
            "user_sync_endpoint": "ads.pubmatic.com\/AdServer\/js\/user_sync.html"
        }
    },
    "push_filepath": "\/",
    "sms_enabled": false,
    "sms_terms_conditions_link": "",
    "brand_name": "",
    "ads_config": {
        "freqCapEnabled": false,
        "freqCapImpressions": ""
    }
});