processGoogleToken({
    "newToken": "ChAI8K377AUQ2M__gqiooptUEi8AnMhKYXH6hCJEYYSfkPYrt0aA9WRdCQk-wf4FWd4D9o8o24OaD6XTgjL8sGP1cA",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-10-11",
    "pucrd": ""
});