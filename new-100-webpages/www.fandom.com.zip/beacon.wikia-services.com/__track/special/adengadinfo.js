var beacon_id = "VrdwK5mExw";
var session_id = "5Zusg4jXKy";
var varnishTime = "Thu, 10 Oct 2019 11:02:57 GMT";