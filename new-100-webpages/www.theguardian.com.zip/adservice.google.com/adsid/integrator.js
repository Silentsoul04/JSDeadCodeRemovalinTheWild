processGoogleToken({
    "newToken": "NT",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-10-11",
    "pucrd": ""
});