(window.webpackJsonp = window.webpackJsonp || []).push([
    [15], {
        327: function(e, t, n) {
            "use strict";
            n.d(t, "a", function() {
                return fe
            });
            var a = n(360),
                i = n.n(a),
                o = n(70),
                s = n.n(o),
                c = n(361),
                r = n.n(c),
                l = n(362),
                u = n.n(l),
                d = n(363),
                m = n.n(d),
                h = n(364),
                g = n.n(h),
                f = n(240),
                p = n.n(f),
                v = n(178),
                b = n.n(v),
                w = n(209),
                y = n.n(w),
                k = n(365),
                j = n.n(k),
                _ = n(336),
                O = n.n(_),
                C = n(57),
                M = n.n(C),
                x = n(71),
                E = n.n(x),
                T = n(357),
                A = n.n(T),
                S = n(366),
                L = n.n(S),
                N = n(367),
                B = n.n(N),
                I = n(368),
                P = n.n(I),
                D = n(369),
                z = n.n(D),
                U = n(370),
                R = n.n(U),
                H = n(371),
                q = n.n(H),
                G = n(358),
                F = n.n(G),
                V = n(372),
                $ = n.n(V),
                J = n(373),
                W = n.n(J),
                Y = n(374),
                K = n.n(Y),
                Q = n(375),
                X = n.n(Q),
                Z = n(376),
                ee = n.n(Z),
                te = n(241),
                ne = n.n(te),
                ae = n(331),
                ie = n.n(ae),
                oe = n(377),
                se = n.n(oe),
                ce = n(378),
                re = n.n(ce),
                le = n(379),
                ue = n.n(le),
                de = n(380),
                me = n.n(de),
                he = n(196),
                ge = {
                    commentCount16icon: i.a,
                    marque36icon: s.a,
                    marque54icon: r.a,
                    marketDownIcon: u.a,
                    marketUpIcon: m.a,
                    marketSameIcon: g.a,
                    arrowicon: p.a,
                    arrowdownicon: b.a,
                    crossIcon: y.a,
                    quoteIcon: j.a,
                    paidContent: O.a,
                    closeCentralIcon: M.a,
                    arrowWhiteRight: E.a,
                    arrowRight: A.a,
                    bookmark: L.a,
                    dropdownMask: B.a,
                    commentAnchor: P.a,
                    reply: z.a,
                    expandImage: R.a,
                    cursor: q.a,
                    plus: F.a,
                    share: $.a,
                    shareTwitter: W.a,
                    shareEmail: K.a,
                    shareFacebook: X.a,
                    sharePinterest: ee.a,
                    externalLink: ne.a,
                    tick: ie.a,
                    glabsLogoSmall: se.a,
                    logomembership: re.a,
                    star: ue.a,
                    chevronRight: me.a
                },
                fe = function(e, t, n) {
                    return Object(he.a)(ge[e].markup, t, n)
                }
        },
        331: function(e, t) {
            e.exports = {
                markup: '<span class="inline-tick inline-icon"><svg width="10.79" height="8.608" viewBox="0 0 10.79 8.608"><path d="M2.987 6.575L10.244 0l.546.532-7.803 8.076h-.26L0 4.788l.545-.546 2.442 2.333z"/></svg></span>'
            }
        },
        336: function(e, t) {
            e.exports = {
                markup: '<span class="inline-paid-content inline-commercial"><svg viewBox="0 0 351 227" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><path id="0" d="m0 31.6h123v-15.7-15.7h-123v31.4"/><mask id="1" fill="#fff"><use xlink:href="#0"/></mask></defs><g fill="none" fill-rule="evenodd"><path fill="#005689" d="m0 0h351v52h-351z"/><g transform="translate(174 14)"><path d="m4.2 26.8c.1-.8.6-1.8 1.9-1.9h4.5c1.3 0 1.9 1.1 1.9 1.9 0 1.7-1.1 2.3-4.4 2.3-2.9 0-4.1-1.2-4-2.3m6-14.2c0 3-.7 3.4-1.8 3.4-1.2 0-2.1-.4-2.1-3.4 0-3.1.9-3.9 2.1-3.9 1.2 0 1.8 1.1 1.8 3.9m-3.9 7.4c-.6 0-1.3-.4-1.3-1 0-.4.3-.9.7-1.2.8.3 1.6.3 2.6.3 4.1 0 6.9-1.9 6.9-5.5 0-1.6-.7-2.4-1.7-3.4l2.7.7v-3.2l-4.3.8c-1-.4-2.4-.8-3.7-.8-4.1 0-6.9 2.2-6.9 5.7 0 2.2 1.1 3.7 2.6 4.6l.1.1c-.9.6-2.8 2.1-2.8 3.8 0 1.3.8 2.5 2.5 2.9-1.8.4-3.8 1.3-3.8 3.4 0 2.2 3.1 4.2 8.1 4.2 6.2 0 8.7-3 8.7-6.8 0-3.2-1.5-4.7-5-4.7h-5.5m17 4.1c.2 0 .5 0 .7-.1 1.8-.2 3.5-1.1 4.4-2.2v2.2l6.3-.8v-1.1l-1.6-1.1v-14.2h-.5l-6.3 1.2v1.4l2.1.9v9.6c-.6.4-1.3.7-2.2.7-1.3 0-2.5-.4-2.5-2.3v-11.6h-.5l-6.3 1.3v1.4l2.1.8v8.6c0 2.8 1.2 5.1 4.4 5.1m72.8-2.9c-1 0-2.1-.6-2.1-2.4 0-1.3 1.3-2.5 2.5-2.6l1.2-.3v4.5c0 0-1 .8-1.6.8m-1.2-12c2 0 2.8 1.1 2.8 3.1v1.8l-3.2.6c-3.1.6-5.5 1.5-5.5 4.9 0 2.7 1.8 4.6 4.4 4.6 2 0 3.9-.9 4.6-2.3h.2c.3 1.7 1.7 2.3 3.4 2.3 1.3 0 2.5-.3 3-.8v-1.1l-1.5-.8v-9.5c0-3.7-2.7-4.9-7-4.9-2.8 0-4.5.7-6 1.4v4.1h2.5l1.1-3.2c.6-.2 1.2-.2 1.4-.2m-52.9 12c-1 0-2.1-.6-2.1-2.4 0-1.3 1.3-2.5 2.5-2.6l1.2-.3v4.5c0 0-1 .8-1.6.8m-1.2-12c2 0 2.8 1.1 2.8 3.1v1.8l-3.2.6c-3.1.6-5.5 1.5-5.5 4.9 0 2.7 1.8 4.6 4.4 4.6 2 0 3.9-.9 4.6-2.3h.2c.3 1.7 1.7 2.3 3.4 2.3 1.3 0 2.5-.3 3-.8v-1.1l-1.5-.8v-9.5c0-3.7-2.7-4.9-7-4.9-2.8 0-4.5.7-6 1.4v4.1h2.5l1.1-3.2c.6-.2 1.2-.2 1.4-.2m10 .4l1.6.8v11l-1.6.8v1.6h8.9v-1.6l-2.1-.8v-8.6c.9-.7 2.2-1 3.6-1 .5 0 .8.1 1.2.2v-4.7c-.2-.1-.4-.1-.6-.1-1.7 0-3.2 1.2-4.1 3.3v-3.4h-.5l-6.3 1.1v1.6m22-1.8c-.6-.5-1.7-.7-2.6-.7-3.9 0-7.6 2.3-7.6 8.8 0 6.3 3.7 8.3 6.2 8.3 2 0 3.4-.9 4-1.8h.2v1.7h.5l6.2-.7v-1.2l-1.6-.9v-20.8h-.5l-6.6 1.1v1.5l1.9.8v4.1m0 12.8c-.4.3-.9.6-1.7.6-2.1 0-3.1-1.7-3.1-5.7 0-4.6 1.3-6.1 2.9-6.1.9 0 1.5.3 1.8.7v10.5m7.4-12.6v1.5l1.6.8v11l-1.6.8v1.6h8.4v-1.6l-1.6-.8v-14.4h-.5l-6.3 1.1m4.4-7.7c-1.6 0-2.8 1.3-2.8 2.9 0 1.6 1.3 2.8 2.8 2.8 1.5 0 2.8-1.3 2.8-2.8-.1-1.6-1.3-2.9-2.8-2.9m20.3 23.5h8.4v-1.6l-1.6-.8v-10.5c.6-.5 1.5-.6 2.3-.6 1.5 0 1.9.5 1.9 2.2v8.9l-1.6.8v1.6h8.4v-1.6l-1.6-.8v-10c0-3-1.1-4.4-3.7-4.4-2.2 0-4.3.8-5.7 2.1v-2.2h-.5l-6.5 1.2v1.4l1.7.8v11l-1.6.8v1.6" fill="#fff" mask="url(#1)" transform="translate(44)"/><path d="m2.1 19c0 3 1.5 4.9 4.7 4.9 1.6 0 3.3-.4 4.3-1.2v-2c-.4.2-1 .3-1.5.3-1.5 0-2.2-.8-2.2-2.4v-8.7h3.7v-2.6h-3.7v-3.9l-5.3.8v3.2l-2.1.5v2.1h2.1v9.2m17.3 4.5v-1.6l-1.6-.8v-10.3c.6-.5 1.7-.9 2.5-.9 1.5 0 2.3.8 2.2 2.2v8.9l-1.6.8v1.6h8.4v-1.6l-1.6-.8v-10c0-3-1.7-4.4-4-4.4-2.2 0-4.5.7-5.9 2v-8.9h-.5l-6.3 1.1v1.6l2.1.8v17.9l-1.6.8v1.6h7.9m17.3-15c1.3 0 2 .9 2 5l-4.4.4c.1-4.2.9-5.4 2.4-5.4m6.9 7c0-6.8-2.7-8.9-6.8-8.9-4.7 0-7.9 3.3-7.9 8.6 0 5.5 2.9 8.5 8.3 8.5 2.9 0 5.1-1.4 5.9-2.5v-1.6c-1.1.4-2 .6-4 .6-2.9 0-4.9-1.7-4.9-4.8h9.5" fill="#aadce6"/></g><path fill="#fff" d="m0 50h351v177h-351z"/><g fill="#d8d8d8"><path d="m54 58h187v72h-187z"/><path d="m6 58h42v7h-42z"/><path d="m248 58h42v72h-42z"/><path d="m150 136h42v72h-42z"/></g><path fill="#f6a623" d="m248 136h91v72h-91z"/><g fill="#d8d8d8"><path d="m54 136h91v72h-91z"/><path d="m297 58h42v72h-42z"/><path d="m199 136h42v72h-42z"/></g></g></svg></span>'
            }
        },
        357: function(e, t) {
            e.exports = {
                markup: '<span class="inline-arrow-right inline-icon"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30"><path d="M22.8 14.6l-7.6-7.6-.7.7 5.5 6.6h-14v1.5h14l-5.5 6.6.7.7 7.6-7.6v-.9"/></svg></span>'
            }
        },
        358: function(e, t) {
            e.exports = {
                markup: '<span class="inline-plus inline-icon"><svg width="18" height="18" viewBox="0 0 18 18"><path d="M8.2 0h1.6l.4 7.8 7.8.4v1.6l-7.8.4-.4 7.8H8.2l-.4-7.8L0 9.8V8.2l7.8-.4.4-7.8z"/></svg></span>'
            }
        },
        360: function(e, t) {
            e.exports = {
                markup: '<span class="inline-comment-16 inline-icon"><svg width="16" height="16" viewBox="0 0 16 16"><path d="M13 0l1 1v7l-1 1h-6l-2 3h-1v-3h-2l-1-1v-7l1-1h11z"/></svg></span>'
            }
        },
        361: function(e, t) {
            e.exports = {
                markup: '<span class="inline-marque-54 inline-icon"><svg xmlns="http://www.w3.org/2000/svg" width="54" height="54" viewBox="0 0 36 36><path fill="#000" d="M18 0a18 18 0 1 0 0 36 18 18 0 0 0 0-36"/><path fill="#FFF" d="M21.2 4.4c2.3.4 5.3 2 6.3 3.1v5.2H27L21.2 5v-.6zm-2.2.4c-4 0-6.3 5.6-6.3 13.2 0 7.7 2.2 13.3 6.3 13.3v.6c-6 .4-14.4-4.2-14-13.8A13.3 13.3 0 0 1 19 4v.7zm10.4 14.4l-1.9.9v8.6c-1 1-3.8 2.6-6.3 3.1V19.9l-2.2-.7v-.6h10.4v.6z"/></svg></span>'
            }
        },
        362: function(e, t) {
            e.exports = {
                markup: '<span class="inline-market-down inline-icon"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="11" viewBox="0 0 15 11"><path fill="#B51800" d="M15 1.03L13.97 0H1L0 1l7 10h.958L15 1.016z"/></svg></span>'
            }
        },
        363: function(e, t) {
            e.exports = {
                markup: '<span class="inline-market-up inline-icon"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="11" viewBox="0 0 15 11"><path fill="#298422" d="M0 9.97L1.03 11H14l1-1L8 0h-.958L0 9.984z"/></svg></span>'
            }
        },
        364: function(e, t) {
            e.exports = {
                markup: '<span class="inline-market-same inline-icon"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="11" viewBox="0 0 15 11"><g fill="#333"><path d="M15 1.03L13.97 0H1L0 1l7 4h.958L15 1.016zM0 9.97L1.03 11H14l1-1-7-4h-.958L0 9.984z"/></g></svg></span>'
            }
        },
        365: function(e, t) {
            e.exports = {
                markup: '<span class="inline-quote inline-icon"><svg width="30" height="21" viewBox="0 0 30 21"><path d="M29.8.4a313 313 0 0 0-2 20.6h-12A61 61 0 0 1 23.5.4h6.4zM14.1.4c-.9 6.7-1.7 13.4-2 20.6H0C1.3 13.8 3.7 7 7.5.4h6.6z"/></svg></span>'
            }
        },
        366: function(e, t) {
            e.exports = {
                markup: '<span class="inline-bookmark inline-icon"><svg width="8.6" height="16" viewBox="0 0 8.6 16">     <path d="M0 15.7V1l1-1h6.5l1 1v14.7l-.2.3-4-2.2-4 2.2"/> </svg></span>'
            }
        },
        367: function(e, t) {
            e.exports = {
                markup: '<span class="inline-dropdown-mask inline-icon"><svg width="32" height="32"><path d="M0 0v32h32v-32h-32zm16.2 22.9l-12.4-9.8.6-.7 11.8 6.6 11.8-6.6.6.7-12.4 9.8z"/></svg></span>'
            }
        },
        368: function(e, t) {
            e.exports = {
                markup: '<span class="inline-comment-anchor inline-icon"><svg version="1.1" id="Layer_1" x="0px" y="0px" width="15px" height="15px" viewBox="0 0 15 15" enable-background="new 0 0 15 15">     <path fill="#898989" d="M5.725,13.348c-0.979,1.021-2.6,1.055-3.623,0.076c-1.02-0.979-1.055-2.602-0.076-3.623l8.424-8.79 \tc0.732-0.766,1.95-0.792,2.717-0.057c0.768,0.734,0.791,1.949,0.059,2.715l-6.894,7.193C5.84,11.375,5.03,11.393,4.52,10.9 \tc-0.511-0.488-0.528-1.299-0.04-1.81l5.324-5.553l0.337,0.321L4.816,9.413c-0.311,0.325-0.3,0.84,0.025,1.152 \tc0.326,0.312,0.841,0.301,1.15-0.024l6.896-7.193c0.557-0.581,0.536-1.501-0.043-2.058c-0.581-0.557-1.504-0.537-2.058,0.043 \tl-8.427,8.79c-0.798,0.837-0.771,2.163,0.063,2.965c0.836,0.802,2.164,0.772,2.965-0.062l6.853-7.152l0.338,0.323L5.725,13.348z"/> </svg></span>'
            }
        },
        369: function(e, t) {
            e.exports = {
                markup: '<span class="inline-reply inline-icon"><svg width="18" height="18"><path d="M10.1 5l.9-1 4 4.5v1l-4 4.5-.9-1 2.5-3h-8.6l-1-1v-2.5h2v1.5h7.6l-2.5-3z"/></svg></span>'
            }
        },
        370: function(e, t) {
            e.exports = {
                markup: '<span class="inline-expand-image inline-icon"><svg width="22" height="22" viewBox="0 0 22 22"><path d="M3.4 20.2l5.6-5.7-1.5-1.5-5.7 5.6-.8-4.6h-1v7.5l.5.5h7.5v-1l-4.6-.8m15.3-18.3l-5.7 5.7 1.4 1.4 5.7-5.7.5 4.7h1.2v-7.4l-.5-.5h-7.3v1.2l4.7.6"/></svg></span>'
            }
        },
        371: function(e, t) {
            e.exports = {
                markup: '<span class="inline-cursor inline-icon"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 95.828 95.828" enable-background="new 0 0 95.828 95.828"><path fill="#fff" d="m71 27.4l-18 41-1.7-.1-4-13.7-15.8 15.8-6-6 15.8-15.8-13.7-4-.1-1.7 41-18 2.3 2.3m25 20.5c0-26.5-21.5-47.9-47.9-47.9s-47.9 21.5-47.9 47.9 21.5 47.9 47.9 47.9 47.9-21.5 47.9-47.9"/></svg></span>'
            }
        },
        372: function(e, t) {
            e.exports = {
                markup: '<span class="inline-share inline-icon"><svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><path d="M10.073 8.4c-.475 0-.906.19-1.225.497l-5.308-2.676.015-.221-.015-.221 5.308-2.676c.319.308.75.497 1.225.497.982 0 1.778-.806 1.778-1.8s-.796-1.8-1.778-1.8-1.778.806-1.778 1.8l.016.233-5.299 2.675c-.32-.313-.755-.507-1.236-.507-.982 0-1.778.806-1.778 1.8s.796 1.8 1.778 1.8c.48 0 .915-.194 1.236-.507l5.299 2.675-.016.233c0 .994.796 1.8 1.778 1.8s1.778-.806 1.778-1.8-.796-1.8-1.778-1.8zm0-7.68c.588 0 1.067.484 1.067 1.08 0 .596-.479 1.08-1.067 1.08s-1.067-.484-1.067-1.08c0-.596.479-1.08 1.067-1.08zm0 10.56c-.588 0-1.067-.484-1.067-1.08 0-.596.479-1.08 1.067-1.08s1.067.484 1.067 1.08c0 .596-.479 1.08-1.067 1.08z"/></svg></span>'
            }
        },
        373: function(e, t) {
            e.exports = {
                markup: '<span class="inline-share-twitter inline-icon"><svg width="32" height="32" viewBox="-2 -2 32 32"><path d="M21.3 10.5v.5c0 4.7-3.5 10.1-9.9 10.1-2 0-3.8-.6-5.3-1.6.3 0 .6.1.8.1 1.6 0 3.1-.6 4.3-1.5-1.5 0-2.8-1-3.3-2.4.2 0 .4.1.7.1l.9-.1c-1.6-.3-2.8-1.8-2.8-3.5.5.3 1 .4 1.6.4-.9-.6-1.6-1.7-1.6-2.9 0-.6.2-1.3.5-1.8 1.7 2.1 4.3 3.6 7.2 3.7-.1-.3-.1-.5-.1-.8 0-2 1.6-3.5 3.5-3.5 1 0 1.9.4 2.5 1.1.8-.1 1.5-.4 2.2-.8-.3.8-.8 1.5-1.5 1.9.7-.1 1.4-.3 2-.5-.4.4-1 1-1.7 1.5z"/></svg></span>'
            }
        },
        374: function(e, t) {
            e.exports = {
                markup: '<span class="inline-share-email inline-icon"><svg width="32" height="32" viewBox="0 0 32 32"><path d="M23.363 20.875H8.637v-8.938l6.545 5.687h1.637l6.544-5.687v8.938zm-1.635-9.75L16 16l-5.728-4.875h11.456zM23.363 9.5H8.637L7 11.125v9.75L8.637 22.5h14.727L25 20.875v-9.75L23.363 9.5z"/></svg></span>'
            }
        },
        375: function(e, t) {
            e.exports = {
                markup: '<span class="inline-share-facebook inline-icon"><svg width="32" height="32" viewBox="-2 -2 32 32"><path d="M17.9 14h-3v8h-2.9v-8h-2v-2.9h2v-2.4c0-1.9 1.1-3.7 4-3.7 1.2 0 2 .1 2 .1v3h-1.8c-1 0-1.2.5-1.2 1.3v1.8h3l-.1 2.8z"/></svg></span>'
            }
        },
        376: function(e, t) {
            e.exports = {
                markup: '<span class="inline-share-pinterest inline-icon"><svg viewBox="0 0 32 32" width="32" height="32"><path d="M16.363 8C12.133 8 10 11.13 10 13.74c0 1.582.58 2.988 1.823 3.512.204.086.387.003.446-.23.04-.16.137-.568.18-.737.06-.23.037-.312-.127-.513-.36-.436-.588-1-.588-1.802 0-2.322 1.684-4.402 4.384-4.402 2.39 0 3.703 1.508 3.703 3.522 0 2.65-1.136 4.887-2.822 4.887-.93 0-1.628-.795-1.405-1.77.268-1.165.786-2.42.786-3.262 0-.752-.39-1.38-1.2-1.38-.952 0-1.716 1.017-1.716 2.38 0 .867.284 1.454.284 1.454l-1.146 5.006c-.34 1.487-.05 3.31-.026 3.493.014.108.15.134.21.05.09-.117 1.223-1.562 1.61-3.006.108-.41.625-2.526.625-2.526.31.61 1.215 1.145 2.176 1.145 2.862 0 4.804-2.693 4.804-6.298C22 10.54 19.763 8 16.363 8"/></svg></span>'
            }
        },
        377: function(e, t) {
            e.exports = {
                markup: '<span class="inline-glabs-logo-small inline-logo"><svg xmlns="http://www.w3.org/2000/svg"  width="88.9" height="47"><path d="M20.2 15.6l1.5-.8V2.6h-1.2l-2.9 3.8h-.3l.2-4.2H30l.2 4.2h-.3l-2.8-3.8h-1.2v12.2l1.6.8v.4h-7.2v-.4zm11.2-.6V1.5L30.2 1V.8l4.4-.8h.4v6.4l.1-.1a6 6 0 0 1 3.7-1.4c1.9 0 2.7 1.1 2.7 3.1v7l1 .6v.4h-5.7v-.4l1-.6V8c0-1.1-.5-1.5-1.4-1.5-.6 0-1.1.2-1.5.5v8l1 .6v.4h-5.7v-.4l1.2-.6zm14.3-4.1c.1 2.2 1.1 4 3.5 4 1.1 0 2-.5 2.7-.9v.4c-.6.8-2.1 1.9-4.2 1.9-3.7 0-5.5-2-5.5-5.6 0-3.5 2.1-5.6 5.4-5.6 3.1 0 4.7 1.6 4.7 5.7v.1h-6.6zm0-.5l3.2-.2c0-2.8-.5-4.6-1.4-4.6-1 0-1.8 2.1-1.8 4.8zM0 21.4c0-5.9 3.9-8 8.2-8 1.8 0 3.6.3 4.5.7l.1 4.1h-.4l-2.5-4C9.5 14 9 14 8.3 14c-2.3 0-3.5 2.7-3.4 7 0 5.2 1 7.6 3.1 7.6l1.3-.2v-5.6L7.8 22v-.5h6.7v.5l-1.4.8v5.5c-1.1.4-3.1.9-5.1.9-4.9 0-8-2.3-8-7.8z"/><path d="M13.9 18.6v-.3l4.5-.8h.5v8.9c0 1.1.5 1.4 1.4 1.4.6 0 1.1-.2 1.5-.7v-8l-1.2-.5v-.4l4.5-.8h.5v10.2l1.2.5v.3l-4.5.6h-.5v-1.3h-.1c-.8.8-2 1.4-3.4 1.4-2.2 0-3.2-1.3-3.2-3.2v-6.8l-1.2-.5zm28.5-1.1h.4v3.3h.1c.5-2.4 1.6-3.3 2.9-3.3l.6.1V21l-.9-.1c-1 0-1.8.2-2.5.5v6.5l1 .6v.4h-6v-.4l1.1-.6V19l-1.2-.4v-.3l4.5-.8zm11.3.2v-3.5l-1.2-.4v-.3l4.6-.8.4.1v15l1.3.5v.4l-4.5.6h-.4v-1.2h-.1a4 4 0 0 1-3 1.3c-2.5 0-4.3-1.9-4.3-5.7 0-4.1 2.1-6.1 5.3-6.1.9-.2 1.6 0 1.9.1zm0 9.6v-9c-.3-.2-.5-.4-1.3-.4-1.2 0-2 1.9-2 5.2 0 3 .5 4.6 2.2 4.6.5 0 .9-.1 1.1-.4zm10-9.8h.4v10.4l1 .6v.4h-5.9v-.4l1.1-.6v-8.8l-1.3-.5v-.3l4.7-.8zm.4-2.9c0 1.1-.9 1.9-2 1.9s-2-.8-2-1.9c0-1.1.9-1.9 2-1.9s2 .8 2 1.9zm13.2 13.3V19l-1.2-.4v-.4l4.5-.8h.5v1.3h.1c1-.9 2.4-1.4 3.9-1.4 2 0 2.8.9 2.8 3v7.6l1.1.6v.4h-6v-.4l1.1-.6v-7.4c0-1.1-.5-1.6-1.4-1.6a3 3 0 0 0-1.6.5v8.5l1 .6v.4h-5.9v-.4l1.1-.6zm-6.4-5.6v-1.5c0-2.2-.5-3-1.9-3h-.5L66 21.1h-.3V18c1.1-.3 2.4-.7 4.1-.7 3 0 4.8.8 4.8 3.4v7.2l1.1.3v.3c-.4.3-1.3.5-2.2.5-1.5 0-2.2-.5-2.5-1.3h-.1c-.6.9-1.5 1.3-2.9 1.3-1.8 0-3-1.1-3-3.1 0-1.9 1.2-2.9 3.5-3.3l2.4-.3zm0 5v-4.5l-.8.1c-1.2.1-1.6.9-1.6 2.5 0 1.8.6 2.3 1.4 2.3.6 0 .8-.1 1-.4zm-38.1-5v-1.5c0-2.2-.5-3-1.9-3h-.5L28 21.3h-.3v-3.1c1.1-.3 2.4-.7 4.1-.7 3 0 4.8.8 4.8 3.4v7.2l1.1.3v.3c-.4.3-1.3.5-2.2.5-1.5 0-2.2-.5-2.5-1.3h-.1c-.6.9-1.5 1.3-2.9 1.3-1.8 0-3-1.1-3-3.1 0-1.9 1.2-2.9 3.5-3.3l2.3-.5zm0 5v-4.5l-.8.1c-1.2.1-1.6.9-1.6 2.5 0 1.8.6 2.3 1.4 2.3.5 0 .8-.1 1-.4zm-12.7 19l1.4-.3V32.4l-1.4-.3v-.4h7.2v.4l-1.5.3v13.9h2.4l3.4-5.3h.4l-.3 5.7H20.1v-.4zM38.6 40v-1.5c0-2.3-.5-3-1.8-3h-.4l-2.8 3.8h-.4l.1-3.5c1.1-.3 2.4-.7 4.2-.7 3.1 0 4.8.8 4.8 3.4v7.4l1.1.3v.3c-.4.3-1.3.5-2.3.5-1.5 0-2.2-.5-2.6-1.3h-.1c-.6.9-1.6 1.4-3 1.4-1.8 0-3.1-1.1-3.1-3.1 0-1.9 1.2-2.9 3.6-3.4l2.7-.6zm0 5.1v-4.6l-.8.1c-1.2.1-1.6.9-1.6 2.6 0 1.8.6 2.3 1.4 2.3.6 0 .8-.1 1-.4zm16.6-4.4c0 4.4-2.5 6.3-6.2 6.3-1.9 0-3.8-.4-4.8-1V31.8l-1.3-.5V31l4.5-.7.5.1v6.1h.1c.6-.7 1.7-1.4 3.3-1.4 2.1 0 3.9 1.5 3.9 5.6zm-4 .4c0-3.4-.7-4.4-2-4.4l-1.2.2v9.3c.3.3.7.4 1.2.4 1.2 0 2-1.4 2-5.5zm13.3 2.1c0 2.3-1.6 3.7-4.7 3.7-1.4 0-2.8-.2-3.9-.6l-.1-3.3h.4l3 3.5.6.1c1.3 0 1.8-.7 1.8-1.7 0-.9-.5-1.3-1.8-1.9l-.7-.3c-2.1-1-3.3-2-3.3-3.9 0-2.3 1.6-3.7 4.4-3.7 1.1 0 2.4.1 3.3.4l.1 3.1h-.4l-2.3-3-.7-.1c-1.1 0-1.6.6-1.6 1.6s.5 1.3 1.9 2l.6.3c2.3.9 3.4 1.7 3.4 3.8z"/></svg></span>'
            }
        },
        378: function(e, t) {
            e.exports = {
                markup: '<span class="inline-logo-membership inline-commercial"><svg xmlns="http://www.w3.org/2000/svg" width="171.9" height="74" viewBox="0 0 171.9 74"><path fill="#FBBB00" d="M171.9 74V0h-3.7L0 30.5 6.7 74"/><path fill="#483E37" d="M26.5 74h145.4V26.8L33.8 8.9" opacity=".5"/><g fill="#FFF"><path d="M97.64 30.37c-.75 0-1.3.6-1.3 1.3 0 .7.6 1.3 1.3 1.3.7 0 1.3-.6 1.3-1.3 0-.7-.6-1.3-1.3-1.3M107.1 41.07h4.04v-.7l-.8-.35v-4.8c.3-.2.65-.3 1-.3.7 0 1 .3 1 1.05v4.05l-.8.35v.7h4.05v-.7l-.8-.35v-4.6c0-1.35-.6-2-1.86-2-1 0-2 .35-2.65.95v-.9h-.2l-3.1.5v.65l.84.4v5.05l-.8.35.05.65zM95.6 33.92v.7l.84.35v5.05l-.8.35v.7h4.05v-.7l-.76-.35v-6.6h-.2M92.14 39.67c-.2.15-.4.25-.75.25-1 0-1.46-.8-1.46-2.65 0-2.1.6-2.8 1.35-2.8.44 0 .64.15.84.35v4.85zm0-5.85c-.3-.2-.8-.35-1.2-.35-1.85 0-3.55 1.05-3.55 4.05 0 2.85 1.74 3.75 2.9 3.75.94 0 1.54-.4 1.84-.8h.1v.8h.2l2.95-.35v-.55l-.8-.45v-9.5h-.2l-3.1.5v.7l.8.35.04 1.85zM81.94 33.92v.7l.8.4v5.05l-.8.35v.7h4.25v-.7l-1-.35v-3.95c.44-.35 1-.45 1.64-.45.2 0 .5.05.6.05v-2.2c-.1-.05-.25-.05-.35-.05-.8 0-1.56.55-2 1.5v-1.55h-.2l-2.96.5zM76.64 34.52c.2-.1.55-.1.65-.1.94 0 1.24.5 1.24 1.4v.85l-1.4.25c-1.45.25-2.55.7-2.55 2.25 0 1.25.84 2.1 2.04 2.1.95 0 1.8-.4 2.15-1.05h.04c.1.8.8 1.05 1.6 1.05.6 0 1.15-.2 1.4-.45v-.45l-.8-.35v-4.3c0-1.65-1.2-2.3-3.2-2.3-1.3 0-2.15.3-2.85.65v1.9h1.14l.5-1.45zm1.85 5.1c-.16.2-.4.3-.7.3-.5 0-.96-.25-.96-1.1 0-.6.55-1.15 1.1-1.2l.5-.1v2.1zM101.7 34.52c.14-.1.54-.1.64-.1.95 0 1.25.5 1.25 1.4v.85l-1.4.25c-1.46.25-2.56.7-2.56 2.25 0 1.25.85 2.1 2.05 2.1.94 0 1.8-.4 2.14-1.05h.05c.1.8.8 1.05 1.6 1.05.6 0 1.14-.2 1.4-.45v-.45l-.8-.35v-4.3c0-1.65-1.2-2.3-3.2-2.3-1.3 0-2.16.3-2.86.65v1.9h1.15l.5-1.45zm1.9 5.1c-.16.2-.4.3-.7.3-.5 0-.96-.25-.96-1.1 0-.6.55-1.15 1.1-1.2l.5-.1v2.1zM66.94 38.92c0 1.3.65 2.35 2.15 2.35 1 0 1.84-.45 2.34-1v1h.2l3-.35v-.55l-.85-.45v-6.45h-.2l-3.1.5v.7l.8.4v4.45c-.26.2-.46.25-.9.25-.6 0-1-.2-1-1.05v-5.25h-.2l-3.1.5v.7l.84.4v3.85zM63.8 39.47h-2.66c-.3 0-.55-.2-.55-.5 0-.2.14-.4.34-.55.4.1.75.15 1.2.15 1.9 0 3.2-.85 3.2-2.5 0-.75-.3-1.15-.75-1.55l1.24.4v-1.5l-2 .35c-.45-.15-1.1-.4-1.7-.4-1.9 0-3.25 1-3.25 2.6 0 1 .5 1.7 1.24 2.1l.1.1c-.4.3-1.3.95-1.3 1.75 0 .6.4 1.15 1.2 1.35-.85.15-1.8.55-1.8 1.5 0 1 1.45 2 3.75 2 2.9 0 4.14-1.35 4.14-3.15 0-1.5-.8-2.15-2.45-2.15m-1.6-5.15c.54 0 .9.4.9 1.7 0 1.35-.4 1.65-.9 1.65-.56 0-.9-.3-.9-1.65 0-1.4.34-1.7.9-1.7m-.06 9.25c-1.35 0-1.85-.55-1.8-1.05 0-.35.2-.8.85-.85h2.1c.6 0 1 .4 1 .8 0 .8-.6 1.1-2.16 1.1M58.44 37.57c0-3.1-1.4-4.15-3.3-4.15-2.2 0-3.65 1.45-3.65 3.9 0 2.5 1.3 3.9 3.84 3.9 1.35 0 2.45-.7 2.8-1.2l.05-.6c-.5.15-1.06.25-2 .25-1.36 0-2.16-.7-2.16-2.15h4.4zm-3.3-3.3c.6 0 .95.45.95 2.3l-2.06.1c0-1.85.4-2.4 1.1-2.4"/><path d="M43.44 41.07h4.05v-.7l-.76-.35v-4.8c.3-.2.65-.3 1-.3.7 0 1 .45 1 1.05v4.05l-.8.35v.7H52v-.7l-.8-.35v-4.6c0-1.35-.8-2-1.86-2-1 0-2 .35-2.65.95v-4.1h-.2l-3.1.5v.65l.84.4v8.2l-.8.35v.7zM39 39.07c0 1.35.64 2.25 2.1 2.25.74 0 1.6-.2 2.04-.55v-.9c-.2.05-.55.1-.8.1-.7 0-.9-.35-.9-1.1v-3.95h1.6v-1.25h-1.6v-1.75l-2.45.35v1.4l-1.16.2v1.05H39v4.15z"/></g><path fill="#FFF" d="M55.9 64c-.2 0-.4-.1-.6-.2l-.1-.1c-.4-.3-.8-.6-.6-1.4.3-.9 2.1-6.7 2.1-6.8-.2.4-3.3 3-5.8 4.5-.2.1-1 .6-1.3.5-1.7-.4-1.1-2.2-.7-2.6 0 0 .2-.1.3-.2.9-.4 3.3-1.6 5.9-4.1 1.7-1.6 4.4-5.1 4.6-5.5 0-.1.1-.2.1-.3.1-.3.4-.9 1.1-.9.1 0 .3 0 .4.1.8.4 1.1 1 .9 1.7-.2.5-.4.9-.7 1.3-.2.3-.4.6-.5.9-.5 1.1-1.1 2.3-1.6 3.7l-.9 2.4c0 .1-.1.3-.1.4l.1-.1c.4-.6 1.8-2.6 3.3-4.6 1.6-2 4.4-5.6 4.9-6 .7-.5 1.6.3 1.8.8.2.5.3 1 .1 1.4l-2.1 5.7-.5 1.6c-.1.2-.2.5-.3.7.1-.1.3-.2.4-.2 1.1-1.1 3.4-3.7 3.4-3.7 2-2.1 3.9-4.2 5.9-6.3.3-.4.7-.5 1-.5.2 0 .3.1.5.2.4.2 1 .6.8 1.5-.1.3-2.4 7.8-2.5 8.2-.3.8-.5 1.6-.7 2.4-.1.3-.1.9.1 1.3.7-.2 3.7-2.1 3.7-2.1s-.1-.4 0-1.4c.2-2.9 1.5-5.2 2.8-6.8 1.2-1.4 2.9-2.5 3.9-2.4.9.1 1.8.8 1.7 2-.1.9-.4 1.9-.9 2.9-1.3 2.7-2.6 4.6-4.3 6.1-.2.2-.3.3-.6.5 0 0 .1.3.5.3.8.1 1.5-.2 2-.5 1.9-.9 3.6-2.4 5.3-4.5.9-1.1 1.5-2 2-2.8.4-.7.8-1.6 1.1-2.3.1-.3.3-.7.4-1 .2-.3.4-1 1.1-.9.1 0 .3.1.4.1.4.2.7.5.8.9.1.4.1.8-.2 1.2-.6 1.2-2.7 6.1-2.7 6.1-.1.3-.1.5 0 .5s3.3-3.7 4.9-5.4c0 0 2.6-2.8 2.7-3 .3-.4 1-.9 1.6-.5.6.4.9 1.4.7 2-.6 1.7-1.2 3.4-1.8 5l-.6 1.6.5-.5c2.4-3.3 7.7-8.4 9-8.3.6 0 .9.5 1.3 1.1.2.3.3.6 0 1.1-.6.9-2.4 5.7-2.5 6-.2.5-1.1 3.2-1.1 3.3 0 .1-.1.3-.1.4 0 0 4.4-3.4 5.9-5.2 2.6-3.1 6.6-13 6.8-13.4.4-.7 1.1-1.1 1.8-1.1.8.1 1 .6 1 1.1.1 1.7-5.6 11.6-5.5 11.7.2-.2 4.4-3.8 6.7-3.1 1 .3 1 1 1.2 1.9.4 1.7-1.8 11.8-9.5 12.1-1 0-2.4-.7-2.9-2.1 0 0-.2.2-.4 0-.4-.2-.7-.5-.8-.8-.1-.2 0-.5.1-.9.1-.6 2.1-2.8-.4-.5-2.1 2-4.2 3.4-4.5 3.6-.3.2-.7.4-1.1.4-.4 0-.9-.3-1.2-.6-.4-.5-.2-1.2.2-2 .3-.6.7-2.4.8-2.7l.6-1.8c.5-1.4.9-2.8 1.4-4.2.1-.2.2-.5.1-.6 0 0-2.2 2.4-2.9 3.3l-5.2 6.3c-.3.3-.6.5-.9.4-.3 0-.6-.2-.8-.3-.6-.3-.8-.8-.6-1.4.3-.8.5-1.6.7-2.4.1-.5.2-1 .4-1.5.2-.7.4-1.3.7-2l.3-.9c0-.1.1-.2.1-.4-.1.1-6.4 7.5-7.3 8.3-.2.2-.6.4-.9.4-.2 0-.9-.4-1.4-.9-.2-.3-.4-.5.1-1.4.1-.2.3-.6.3-.8 0-.1 0-.1-.1-.2-.1 0-2.3 2.5-5.2 3.7-.8.3-1.5.5-2.2.4-1.7-.2-2.6-1.3-2.6-1.3s-3.6 2.6-5.9 3c-.5.1-1.1-.2-1.4-.6-.3-.4 0-2.1.3-3.3.4-1.9 1.5-5.1 1.7-5.7.2-.7.5-1.3.7-2-.1 0-.2 0-.2.1-.3.3-3.6 3.9-3.6 3.9-1.3 1.4-2.5 2.8-3.8 4.2-.7.7-1.2 1.4-1.8 2-.2.3-.6.5-.9.4-.8-.2-1.3-1-1.3-1.5.1-1 .4-2.2.7-3.5.3-1 1.4-4.5 1.5-4.8v-.1c-.1 0-.1 0-.1.1-.6.9-5.8 8.3-7.1 10.1-.3.5-.6.8-.9 1.1-.4.9-.7 1-1 1m28.2-13.9c-1.4.5-3.2 3.1-3.8 6.2 1.1-1.2 3.7-5.1 3.8-6.2m30.8 10c6-.8 8.8-10.5 5.5-8.6-2.2 1.3-5.1 4.4-6.3 7.6-.3.6-.2 1.3.8 1"/><path fill="#FFF" d="M148.7 63.6c-1.1-.1-2-.7-2.5-1.5-.6-.9-.7-2.1-.4-3.1.3-.7 1-1.2 1.9-1.6l2.9-1.4.4-1.1c.3-.7.9-2.4 1.1-3 0 0-.9.6-2.6 1.1-1.7.6-4.4 1.2-5.5 1.3-1 .1-1.4.5-1.8.9-1 1.2-2.2 2.8-3.2 4.2-.3.4-.7.9-1.3.8-.2 0-.8-.3-1.1-.6-.2-.3-.3-.5 0-1.3.2-.3 1.2-2.3 1.4-2.7v-.1c-.8.8-6.2 5.9-9.3 5.6-2.8-.2-3.2-3.7-3.2-3.7s-.7.2-.8.2c-.3 0-.7-.4-.9-1-.2-.4-.5-1.2-.1-1.3 1.2-.3 1.8-.5 1.8-.5.5-3.1 2-5.1 2.5-5.7 1.4-1.7 3.1-2.2 3.5-2.3 2-.3 2.8 1 2.8 2.1 0 1.7-.7 3.1-1.3 4-1.9 2.8-4.9 3.7-4.9 3.7s0 1.6 1 1.7c2.3.2 8.2-5 10.5-7.8.5-.6 2.9-3.7 3.1-3.9.2-.2.4-.2.8-.1.4.2 1.6.9 1 1.8-.5.9-2.1 3.6-2.1 3.6.3-.3.7-.5 1.3-.5 4.4-.4 8.2-1.9 9.5-3.7.7-.9 1.7-1.8 2.7-1.1.9.7 1 1.6.7 2.2-.2.4-.8.9-1.5 1.4l-1.6 4.3s7.6-3.9 8.9-4.4c.4-.2 1.2 0 1.7.7.3.4.2.8-.2 1-2.2 1-11.6 5.9-11.6 5.9s-1.5 3.9-2.1 5c-.2.8-1.1.9-1.5.9zm.8-4.4c-.8.4-1.3.7-1.4 1.1 0 .2.1.5.3.6.4.2.9-1.1 1.1-1.7m-19.9-8.1c-.7 1.2-1.1 2.6-1.1 2.7 2.2-1.2 3.7-3 3.5-4.7-.4 0-1.7.8-2.4 2"/></svg></span>'
            }
        },
        379: function(e, t) {
            e.exports = {
                markup: '<span class="inline-star inline-icon"><svg width="14" height="13" viewBox="0 0 14 13"><path d="M0 5.2l3.7 2.8-1.4 4.6.5.4 3.7-2.8 3.7 2.8.5-.4-1.4-4.6 3.7-2.8-.2-.6h-4.6l-1.4-4.6h-.6l-1.4 4.6h-4.6l-.2.6z"/></svg></span>'
            }
        },
        380: function(e, t) {
            e.exports = {
                markup: '<span class="inline-chevron-right inline-icon"><svg width="6" height="12" viewBox="-8 7 6 12"><path d="M-8 18.5l.5.5 5.5-5.8v-.5L-7.5 7l-.5.5 4.5 5.5-4.5 5.5z"/></svg></span>'
            }
        },
        489: function(e, t, n) {
            "use strict";
            n.d(t, "d", function() {
                return m
            }), n.d(t, "a", function() {
                return r
            }), n.d(t, "b", function() {
                return l
            }), n.d(t, "c", function() {
                return u
            });
            var a = n(6),
                i = n(30),
                o = n.n(i),
                s = [],
                c = Date.now(),
                r = function(e) {
                    s.push({
                        name: e,
                        status: "unfinished"
                    })
                },
                l = function(e) {
                    s.filter(function(t) {
                        return t.name === e
                    }).forEach(function(e) {
                        e.status = "completed", e.endTime = "".concat(Date.now() - c, "ms")
                    })
                },
                u = function(e) {
                    s.filter(function(t) {
                        return t.name === e
                    }).forEach(function(e) {
                        e.status = "failed", e.endTime = "".concat(Date.now() - c, "ms")
                    })
                },
                d = function() {
                    o.a.record({
                        register: s
                    })
                },
                m = function() {
                    a.a.on("register:begin", r), a.a.on("register:end", l), a.a.on("register:error", u), window.setTimeout(d, 5e3)
                }
        },
        492: function(e, t, n) {
            "use strict";
            n.d(t, "c", function() {
                return d
            }), n.d(t, "b", function() {
                return r
            }), n.d(t, "d", function() {
                return m
            }), n.d(t, "a", function() {
                return h
            });
            var a = n(8),
                i = n(11),
                o = n.n(i),
                s = function(e) {
                    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][e]
                },
                c = function(e) {
                    return e < 10 ? "0".concat(e) : e
                },
                r = function(e, t) {
                    var n = new Date;
                    return e && e.valueOf() > n.valueOf() - 1e3 * (t || 0)
                },
                l = function(e, t, n) {
                    var a, i = {
                        s: {
                            short: ["s"],
                            med: ["s ago"],
                            long: [" second ago", " seconds ago"]
                        },
                        m: {
                            short: ["m"],
                            med: ["m ago"],
                            long: [" minute ago", " minutes ago"]
                        },
                        h: {
                            short: ["h"],
                            med: ["h ago"],
                            long: [" hour ago", " hours ago"]
                        },
                        d: {
                            short: ["d"],
                            med: ["d ago"],
                            long: [" day ago", " days ago"]
                        }
                    };
                    return i[e] ? (a = i[e][t], 1 === n ? a[0] : a[a.length - 1]) : ""
                },
                u = function(e) {
                    return " ".concat(e.getHours(), ":").concat(c(e.getMinutes()))
                },
                d = function(e) {
                    var t, n, a, i, o, c, r, d, m, h = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        g = new Date(Number(e)),
                        f = new Date,
                        p = h.format || "short",
                        v = "short" === h.format || "med" === h.format;
                    return o = g, "[object Date]" === Object.prototype.toString.call(o) && !Number.isNaN(o.getTime()) && !((i = parseInt((f.getTime() - g) / 1e3, 10)) < 0) && !(h.notAfter && i > h.notAfter) && (i < 55 ? i + l("s", p, i) : i < 3300 ? (t = Math.round(i / 60)) + l("m", p, t) : function(e) {
                        var t = new Date;
                        return e && e.toDateString() === t.toDateString()
                    }(g) || v && function(e) {
                        var t = new Date;
                        return e && e.valueOf() > t.valueOf() - 864e5
                    }(g) ? (n = Math.round(i / 3600)) + l("h", p, n) : v && function(e) {
                        var t = (new Date).valueOf() - 6048e5;
                        return e.valueOf() >= t
                    }(g) ? (a = Math.round(i / 3600 / 24)) + l("d", p, a) : (r = g, d = new Date, (m = new Date).setDate(d.getDate() - 1), r.toDateString() === m.toDateString() ? "Yesterday".concat(u(g)) : i < 432e3 ? [(c = g.getDay(), ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][c]), g.getDate(), s(g.getMonth()), g.getFullYear()].join(" ") + (h.showTime ? u(g) : "") : [g.getDate(), s(g.getMonth()), g.getFullYear()].join(" ") + (h.showTime ? u(g) : "")))
                },
                m = function(e) {
                    var t = "js-locale-timestamp",
                        n = e || document;
                    Object(a.a)(".".concat(t), n).each(function(e) {
                        var n, a = o()(e),
                            i = parseInt(a.attr("data-timestamp"), 10);
                        i && (n = new Date(i), e.innerHTML = "".concat(c(n.getHours()), ":").concat(c(n.getMinutes())), a.removeClass(t))
                    })
                },
                h = function() {
                    (function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        Object(a.a)(".js-timestamp, .js-item__timestamp").each(function(t) {
                            var n, a = o()(t),
                                i = parseInt(a.attr("data-timestamp"), 10) || a.attr("datetime"),
                                s = new Date(i),
                                c = d(s.getTime(), {
                                    showTime: o()(a.parent()).hasClass("block-time"),
                                    format: a.attr("data-relativeformat"),
                                    notAfter: e.notAfter
                                });
                            c ? ((n = a[0].querySelector(".timestamp__text") || a[0]).getAttribute("title") || n.setAttribute("title", o()(n).text()), n.innerHTML = c) : e.notAfter && a.addClass("modern-hidden")
                        })
                    })(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}), m()
                }
        },
        504: function(e, t, n) {
            "use strict";
            n.d(t, "a", function() {
                return a
            });
            var a = function(e, t) {
                var n = parseInt(e, 10);
                if (!Number.isNaN(n)) {
                    if (t && n > 9999) {
                        var a = Math.floor(n / 1e3);
                        return "".concat(a.toLocaleString(), "k")
                    }
                    return n.toLocaleString()
                }
            }
        },
        505: function(e, t, n) {
            "use strict";
            n.d(t, "a", function() {
                return a
            });
            var a = new Promise(function(e) {
                window.guardian.css.loaded ? e() : window.guardian.css.onLoad = e
            })
        },
        514: function(e, t, n) {
            "use strict";
            var a = n(6),
                i = n(4),
                o = n(104),
                s = n(159),
                c = document.location,
                r = function(e) {
                    Object(o.c)(e)
                },
                l = function(e) {
                    if (e.validTarget) return e.target.hasAttribute("data-sponsor") ? Object(o.f)(e.target) : void(e.sameHost ? e.samePage ? function(e) {
                        e.tag && Object(o.e)(e.target, e.tag)
                    }(e) : function(e) {
                        var t = {
                            path: c.pathname,
                            tag: e.tag || "untracked",
                            time: (new Date).getTime()
                        };
                        i.b.set("gu.analytics.referrerVars", t)
                    }(e) : function(e) {
                        Object(o.a)(e.target, e.tag)
                    }(e))
                };
            t.a = {
                init: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    e.location && (c = e.location), a.a.on("module:clickstream:interaction", r), a.a.on("module:clickstream:click", function(e) {
                        Object(s.b)([
                            ["c-analytics", function() {
                                l(e)
                            }]
                        ])
                    })
                },
                trackClick: l,
                trackNonClickInteraction: r
            }
        },
        531: function(e, t, n) {
            "use strict";
            n.d(t, "e", function() {
                return c
            }), n.d(t, "b", function() {
                return r
            }), n.d(t, "d", function() {
                return l
            }), n.d(t, "c", function() {
                return u
            }), n.d(t, "a", function() {
                return d
            });
            var a = n(8),
                i = n(0),
                o = n(7),
                s = function(e, t, n, a) {
                    return e ? t ? !!t(a || e) : a || !!e : !!n && !!n()
                },
                c = function(e, t) {
                    var n = i.a.referencesOfType("pa-football-team"),
                        a = i.a.get("page.footballMatch", {}),
                        o = [
                            ["minbymin", i.a.get("page.isLiveBlog")],
                            ["report", i.a.hasTone("Match reports")],
                            ["preview", i.a.hasSeries("Match previews")],
                            ["stats", a.id]
                        ].find(function(e) {
                            return !0 === e[1]
                        });
                    return Object.assign(a, {
                        date: i.a.webPublicationDateAsUrlPart(),
                        teams: n,
                        isLive: !!i.a.get("page.isLive"),
                        pageType: o && o[0]
                    }), s(a.id || a.pageType && 2 === a.teams.length, e, t, a)
                },
                r = function(e) {
                    var t = "mobile" !== Object(o.d)() ? (Object(a.a)(".js-football-competition").attr("data-link-name") || "").replace("keyword: football/", "") : "";
                    return s(t, e)
                },
                l = function(e) {
                    return function(e) {
                        return s(i.a.hasSeries("Clockwatch"), e)
                    }(function() {
                        return s(!!i.a.get("page.isLive"), e)
                    })
                },
                u = function(e) {
                    return s(!!i.a.get("page.footballMatch"), e)
                },
                d = function(e, t) {
                    var n = Object(a.a)(".js-after-article")[0],
                        i = !!n && "none" !== window.getComputedStyle(n).getPropertyValue("display");
                    return s(i, e, t, n)
                }
        },
        532: function(e, t, n) {
            "use strict";
            n.d(t, "a", function() {
                return _
            });
            var a = n(16),
                i = n.n(a),
                o = n(21),
                s = n.n(o),
                c = n(78),
                r = n.n(c),
                l = n(75),
                u = n.n(l),
                d = n(79),
                m = n.n(d),
                h = n(45),
                g = n.n(h),
                f = n(1),
                p = n.n(f),
                v = n(11),
                b = n.n(v),
                w = n(76),
                y = n(7),
                k = n(8),
                j = function(e) {
                    return '\n    <div class="score-container">\n        <div class="score__loading '.concat(e.loadingState, '">\n            <div class="loading__text">Fetching the scores…</div>\n            <div class="is-updating"></div>\n        </div>\n    </div>\n')
                },
                _ = function(e) {
                    function t(e) {
                        var n;
                        i()(this, t), n = r()(this, u()(t).call(this)), p()(g()(g()(n)), "placeholder", void 0), p()(g()(g()(n)), "pageType", void 0), p()(g()(g()(n)), "parent", void 0), Object.assign(g()(g()(n)), e);
                        var a = j({
                            loadingState: "report" !== n.pageType ? " score__loading--live" : ""
                        });
                        return n.updateEvery = Object(y.m)({
                            min: "desktop"
                        }) ? 30 : 60, n.placeholder = b.a.create(a)[0], "report" === n.pageType ? e.parent.after(n.placeholder) : e.parent.addClass("u-h").before(n.placeholder), n
                    }
                    return m()(t, e), s()(t, [{
                        key: "prerender",
                        value: function() {
                            var e = Object(k.a)(".score__loading", Object(k.a)(this.placeholder));
                            e.length && e.remove()
                        }
                    }, {
                        key: "ready",
                        value: function() {
                            this.setState(this.pageType)
                        }
                    }, {
                        key: "load",
                        value: function() {
                            this.fetch(this.placeholder)
                        }
                    }, {
                        key: "loadFromJson",
                        value: function(e) {
                            this.template = e, this.render(this.placeholder)
                        }
                    }, {
                        key: "error",
                        value: function() {
                            this.placeholder.innerHTML = "", this.parent.removeClass("u-h")
                        }
                    }]), t
                }(w.a)
        },
        533: function(e, t, n) {
            var a = n(430);
            e.exports = function(e) {
                return e && e.length ? a(e) : []
            }
        },
        534: function(e, t, n) {
            "use strict";
            n.d(t, "a", function() {
                return r
            });
            var a = n(3),
                i = ["tabs__tab--selected", "tone-colour", "tone-accent-border"],
                o = function(e) {
                    return a.a.read(function() {
                        return e.getAttribute("href")
                    })
                },
                s = function(e, t) {
                    var n = e.parentNode;
                    return a.a.write(function() {
                        n && (n.setAttribute("aria-selected", "false"), i.forEach(function(e) {
                            return n.classList.remove(e)
                        })), t.classList.add("u-h")
                    })
                },
                c = function(e, t) {
                    var n = e.parentNode;
                    return a.a.write(function() {
                        n && (n.setAttribute("aria-selected", "true"), i.forEach(function(e) {
                            return n.classList.add(e)
                        })), t.classList.remove("u-h", "modern-hidden"), t.focus()
                    })
                },
                r = function() {
                    return a.a.read(function() {
                        return Array.from(document.querySelectorAll(".tabs"))
                    }).then(function(e) {
                        e.forEach(function(e) {
                            var t = e.querySelector(".js-tabs");
                            if (t && "true" !== t.dataset.tabsInitialized) return a.a.write(function() {
                                t.setAttribute("data-tabs-initialized", "true")
                            }), t.addEventListener("click", function(t) {
                                var n = t.target;
                                if (n && "A" === n.nodeName) {
                                    t.preventDefault();
                                    var a = e.querySelector(".tabs__tab--selected a");
                                    o(n).then(function(t) {
                                        if (t) {
                                            var a = e.querySelector(t);
                                            a && c(n, a)
                                        }
                                    }), a && o(a).then(function(t) {
                                        if (t) {
                                            var i = e.querySelector(t);
                                            i && n !== a && s(a, i)
                                        }
                                    })
                                }
                            }), a.a.write(function() {
                                t.setAttribute("data-tabs-initialized", "true")
                            })
                        })
                    })
                }
        },
        548: function(e, t, n) {
            "use strict";
            var a = n(11),
                i = n.n(a),
                o = n(8),
                s = function(e) {
                    return o.a.create(document.createElementNS("http://www.w3.org/2000/svg", e))
                },
                c = function(e) {
                    return "translate(".concat(e.toString(), ")")
                };
            n.d(t, "a", function() {
                return r
            });
            var r = function() {};
            r.prototype.render = function(e) {
                var t = e.scrollWidth || e.getAttribute("data-chart-width"),
                    n = Object(o.a)("th", e),
                    a = Object(o.a)("td", e).map(function(e, t) {
                        return {
                            label: n[t].innerHTML,
                            value: parseInt(e.getAttribute("data-chart-value"), 10),
                            color: e.getAttribute("data-chart-color")
                        }
                    });
                i()(e).addClass("u-h");
                var r = new function(e, t) {
                        var n, a, i, r, l, u, d, m, h, g, f = Object.assign({
                                percentCutout: 35,
                                unit: "",
                                showValues: !1
                            }, t || {}),
                            p = f.width,
                            v = f.height || p,
                            b = Math.min(v / 2, p / 2),
                            w = b * (f.percentCutout / 100),
                            y = e.reduce(function(e, t) {
                                return {
                                    value: e.value + t.value
                                }
                            }).value,
                            k = Math.PI / 2,
                            j = 2 * Math.PI,
                            _ = [p / 2, v / 2],
                            O = p / 2,
                            C = v / 2,
                            M = o.a.create('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMinYMin" class="chart chart--doughnut"></svg>').attr({
                                width: p,
                                height: v,
                                viewbox: "0 0 ".concat([p, v].join(" "))
                            }),
                            x = -k;
                        return e.forEach(function(e) {
                            n = e.value / y * j, i = ((a = x + n) - x) % j > Math.PI ? 1 : 0, r = {
                                start: {
                                    x: O + Math.cos(x) * b,
                                    y: C + Math.sin(x) * b
                                },
                                end: {
                                    x: O + Math.cos(a) * b,
                                    y: C + Math.sin(a) * b
                                }
                            }, l = {
                                start: {
                                    x: O + Math.cos(a) * w,
                                    y: C + Math.sin(a) * w
                                },
                                end: {
                                    x: O + Math.cos(x) * w,
                                    y: C + Math.sin(x) * w
                                }
                            }, u = (w + b) / 2, d = (x + a) / 2, m = ["M", r.start.x, r.start.y, "A", b, b, 0, i, 1, r.end.x, r.end.y, "L", l.start.x, l.start.y, "A", w, w, 0, i, 0, l.end.x, l.end.y, "Z"], h = s("g").attr("class", "chart__arc").append(s("path").attr({
                                d: m.join(" "),
                                fill: e.color
                            })), g = s("text").attr("class", "chart__label"), f.showValues ? g.append(s("tspan").attr("class", "chart__label-text").text(e.label).attr({
                                x: 0,
                                dy: "0"
                            })).append(s("tspan").attr("class", "chart__label-value").text(e.value).attr({
                                x: 0,
                                dy: ".9em"
                            })) : g.text(e.label), g.attr({
                                transform: c([Math.cos(d) * u + O, Math.sin(d) * u + C])
                            }).appendTo(h), h.appendTo(M), x += e.value / y * j
                        }), M.append(s("text").attr("class", "chart__unit").text(f.unit).attr({
                            transform: c(_),
                            dy: "0.4em"
                        }))
                    }(a, {
                        showValues: "true" === e.getAttribute("data-chart-show-values"),
                        unit: e.getAttribute("data-chart-unit"),
                        width: t
                    }),
                    l = r.attr("class");
                return r.attr("class", "".concat(l, " ").concat(e.getAttribute("data-chart-class") || ""))[0].outerHTML
            }
        },
        549: function(e, t) {
            e.exports = {
                markup: '<span class="inline-envelope inline-icon"><svg width="44" height="32" viewBox="0 0 44 32"><path d="M40 28H4V6l16 14h4L40 6v22zM36 4L22 16 8 4h28zm4-4H4L0 4v24l4 4h36l4-4V4l-4-4z"/></svg></span>'
            }
        },
        550: function(e, t) {
            e.exports = '<div class="js-breaking-news__item breaking-news__item" data-breaking-article-id="<%=id%>">\n    <div class="breaking-news__item-content">\n        <div class="breaking-news__item-header">\n            <em class="breaking-news__item-kicker">Breaking news</em>\n            <div class="breaking-news__item-headline"><%=headline%></div>\n        </div>\n        <div class="breaking-news__item-options">\n            <button class="js-breaking-news__item__close button button--tertiary u-faux-block-link__promote"\n                    aria-label="Dismiss"\n                    data-link-name="close button"><%=closeIcon%></button>\n        </div>\n    </div>\n    <a class="u-faux-block-link__overlay" href="/<%=id%>"></a>\n</div>\n'
        },
        649: function(e, t, n) {
            "use strict";
            n.r(t);
            var a, i, o, s = n(23),
                c = n.n(s),
                r = n(0),
                l = n(2),
                u = n(6),
                d = n(20),
                m = n(159),
                h = n(4),
                g = function() {
                    if (window.matchMedia) {
                        var e = window.matchMedia("print");
                        e.addListener(function() {
                            e.matches && u.a.emit("module:clickstream:interaction", "print")
                        })
                    }
                },
                f = n(514),
                p = n(489),
                v = n(16),
                b = n.n(v),
                w = n(21),
                y = n.n(w),
                k = n(1),
                j = n.n(k),
                _ = n(55),
                O = n.n(_),
                C = function() {
                    function e(t) {
                        b()(this, e), j()(this, "opts", void 0), j()(this, "data", void 0), j()(this, "timeoutId", void 0), this.opts = Object.assign({}, {
                            changeThreshold: 10,
                            isContent: !1,
                            pageEl: document.body
                        }, t), this.data = {
                            page: {
                                start: (new Date).getTime(),
                                depth: 0,
                                duration: 0
                            },
                            content: {
                                depth: 0
                            }
                        }, this.init()
                    }
                    return y()(e, [{
                        key: "setData",
                        value: function(e) {
                            var t = this.opts["".concat(e, "El")];
                            if (!t) return !1;
                            var n, a = function(e) {
                                if (document.body) {
                                    var t = window.innerHeight || document.body.clientHeight,
                                        n = e.getBoundingClientRect();
                                    return n.bottom < 0 || n.bottom < t ? 100 : n.top > t ? 0 : n.top > 0 ? 100 / (n.height || 1) * (t - n.top) : 100 / (n.height || 1) * (Math.abs(n.top) + t)
                                }
                            }(t);
                            return !!(a && a - this.data[e].depth > this.opts.changeThreshold) && (this.data[e].depth = a, "number" == typeof this.data[e].duration && (this.data[e].duration = (n = this.data[e].start, (new Date).getTime() - n)), !0)
                        }
                    }, {
                        key: "hasDataChanged",
                        value: function() {
                            var e = this.setData("page"),
                                t = !!this.opts.isContent && this.setData("content");
                            (e || t) && this.log()
                        }
                    }, {
                        key: "assertScrolling",
                        value: function() {
                            "number" == typeof this.timeoutId && window.clearTimeout(this.timeoutId), this.timeoutId = window.setTimeout(function() {
                                u.a.emit("scrolldepth:inactive")
                            }, 1e3)
                        }
                    }, {
                        key: "log",
                        value: function() {
                            u.a.emit("scrolldepth:data", this.data)
                        }
                    }, {
                        key: "init",
                        value: function() {
                            var e = this;
                            u.a.on("window:throttledScroll", O()(function() {
                                e.assertScrolling()
                            }, 200)), u.a.on("scrolldepth:inactive", function() {
                                e.hasDataChanged()
                            }), u.a.on("module:clickstream:click", function() {
                                e.hasDataChanged()
                            })
                        }
                    }]), e
                }(),
                M = n(210),
                x = n(40),
                E = n(3),
                T = n(15),
                A = n(504),
                S = n(327),
                L = function(e) {
                    var t = e || document.body;
                    return t ? function(e) {
                        return E.a.read(function() {
                            return Array.from(e.querySelectorAll("[".concat("data-discussion-id", "]")))
                        }).then(function(e) {
                            if (0 !== e.length) return e.reduce(function(e, t) {
                                var n = t.getAttribute("data-discussion-id");
                                return e[n] || (e[n] = []), e[n].push(t), e
                            }, {})
                        })
                    }(t).then(function(e) {
                        if (e) {
                            var t = "".concat("/discussion/comment-counts.json?shortUrls=").concat(function(e) {
                                return Object.keys(e).sort().join(",")
                            }(e));
                            return Object(T.a)(t, {
                                mode: "cors"
                            }).then(function(t) {
                                if (t && t.counts) return function(e, t) {
                                    var n = e.map(function(e) {
                                        return t[e.id].map(function(t) {
                                            return function(e, t) {
                                                var n = e.dataset.discussionUrl || function(e) {
                                                    var t = e.getElementsByTagName("a")[0];
                                                    return "".concat(t ? t.pathname : "", "#comments")
                                                }(e);
                                                if ("true" === e.dataset.discussionClosed && 0 === t) return Promise.resolve();
                                                var a = e.dataset.commentcountFormat || "",
                                                    i = function(e, t) {
                                                        var n = e.url,
                                                            a = e.icon,
                                                            i = e.count;
                                                        return "content" === t ? '<a href="'.concat(n, '" data-link-name="Comment count" class="commentcount2 tone-colour" aria-label="').concat(i, ' comments">\n                    <h3 class="commentcount2__heading">').concat(a, ' <span class ="commentcount2__text u-h">Comments</span></h3>\n                    <span class="commentcount2__value tone-colour js_commentcount_actualvalue">').concat(i, "</span>\n                </a>") : '<a class="fc-trail__count fc-trail__count--commentcount" href="'.concat(n, '" data-link-name="Comment count" aria-label="').concat(i, ' comments">').concat(a, " ").concat(i, "</a>")
                                                    }({
                                                        url: n,
                                                        icon: Object(S.a)("commentCount16icon", ["inline-tone-fill"]),
                                                        count: Object(A.a)(t, !0) || ""
                                                    }, a),
                                                    o = Array.from(e.getElementsByClassName("js-item__meta")),
                                                    s = o.length ? o : [e];
                                                return E.a.write(function() {
                                                    s.forEach(function(e) {
                                                        e.insertAdjacentHTML("beforeend", i)
                                                    }), e.removeAttribute("data-discussion-id"), e.classList.remove("u-h")
                                                })
                                            }(t, e.count)
                                        })
                                    });
                                    return Promise.all(n)
                                }(t.counts, e)
                            })
                        }
                    }) : Promise.resolve()
                },
                N = n(26),
                B = n(56),
                I = n.n(B),
                P = n(7),
                D = n(8),
                z = n(11),
                U = n.n(z),
                R = n(12),
                H = n.n(R),
                q = {
                    classes: {
                        container: "js-profile-nav",
                        content: "js-profile-info",
                        popup: "js-profile-popup",
                        register: "js-profile-register",
                        commentActivity: "js-comment-activity",
                        action: "brand-bar__item--action"
                    }
                },
                G = function() {
                    function e(t) {
                        b()(this, e), j()(this, "dom", void 0), j()(this, "opts", void 0), this.opts = Object.assign({}, {
                            url: "https://profile.theguardian.com"
                        }, t), this.dom = {}, document.body && (this.dom.container = document.body.getElementsByClassName(q.classes.container)[0], this.dom.container && (this.dom.content = this.dom.container.getElementsByClassName(q.classes.content)[0])), document.body && (this.dom.popup = document.body.getElementsByClassName(q.classes.popup)[0]), document.body && (this.dom.register = document.body.getElementsByClassName(q.classes.register)[0]), document.body && (this.dom.commentActivity = document.body.getElementsByClassName(q.classes.commentActivity)[0])
                    }
                    return y()(e, [{
                        key: "init",
                        value: function() {
                            var e = Object(N.i)(),
                                t = U()(this.dom.container),
                                n = U()(this.dom.content),
                                a = U()(this.dom.register),
                                i = U()(this.dom.commentActivity);
                            e && (t.hasClass("is-signed-in") || H.a.write(function() {
                                n.text(e.displayName), t.addClass("is-signed-in"), a.hide()
                            }), i.removeClass("u-h"), i.attr("href", "".concat(this.opts.url, "/user/id/").concat(e.id)))
                        }
                    }]), e
                }(),
                F = function() {
                    function e() {
                        var t = this;
                        b()(this, e), j()(this, "gcsUrl", void 0), j()(this, "resultSetSize", void 0), E.a.read(function() {
                            return Array.from(document.getElementsByClassName("js-search-toggle"))
                        }).then(function(e) {
                            var n = r.a.get("switches.googleSearch"),
                                a = r.a.get("page.googleSearchUrl"),
                                i = r.a.get("page.googleSearchId");
                            n && a && i && e.length > 0 && (t.gcsUrl = "".concat(a, "?cx=").concat(i), t.resultSetSize = "identity" === r.a.get("page.section") ? 3 : 10, e.forEach(function(e) {
                                var n = e.getAttribute("data-toggle");
                                n && (E.a.write(function() {
                                    e.setAttribute("role", "button"), e.setAttribute("aria-controls", "search-popup"), e.setAttribute("aria-haspopup", "dialog")
                                }), E.a.read(function() {
                                    return document.getElementsByClassName(n)[0]
                                }).then(function(a) {
                                    a && c.a.on(e, "click", function(i) {
                                        var o = function(t) {
                                                var n = t;
                                                "Escape" === n.key && (s(n), e.focus())
                                            },
                                            s = function(t) {
                                                t.preventDefault(), e.classList.remove("is-active"), a.classList.add("is-off"), c.a.off(document, "click", r), document.removeEventListener("keyup", o)
                                            },
                                            r = function(e) {
                                                for (var t = e.target, a = !1; t && !a;) t && t.classList && (t.classList.contains(n) || t.classList.contains("gsq_a")) && (a = !0), t = t && t.parentElement;
                                                a || s(e)
                                            };
                                        setTimeout(function() {
                                            e.classList.contains("is-active") && (a.focus(), c.a.on(document, "click", r), document.addEventListener("keyup", o))
                                        }), t.load(a), i.preventDefault()
                                    })
                                }))
                            }))
                        })
                    }
                    return y()(e, [{
                        key: "load",
                        value: function(e) {
                            var t, n, a = this;
                            E.a.read(function() {
                                return {
                                    allSearchPlaceholders: Array.from(document.getElementsByClassName("js-search-placeholder")),
                                    searchPlaceholder: e.getElementsByClassName("js-search-placeholder")[0]
                                }
                            }).then(function(e) {
                                var i = e.allSearchPlaceholders,
                                    o = e.searchPlaceholder;
                                o && (i.forEach(function(e) {
                                    e !== o && E.a.write(function() {
                                        e.innerHTML = ""
                                    })
                                }), o.innerHTML || (E.a.write(function() {
                                    o && (o.innerHTML = '<div class="search-box" role="search">\n                            <gcse:searchbox></gcse:searchbox>\n                            </div>\n                            <div class="search-results" data-link-name="search">\n                            <gcse:searchresults webSearchResultSetSize="\'}'.concat(a.resultSetSize, '" linkTarget="_self"></gcse:searchresults>\n                            </div>'))
                                }), c.a.on(o, "keydown", ".gsc-input", function() {
                                    E.a.read(function() {
                                        var e = Object(D.a)(".gssb_c"),
                                            t = e.css("top"),
                                            n = Object(D.a)(window).scrollTop();
                                        E.a.write(function() {
                                            e.css({
                                                top: parseInt(t, 10) + n,
                                                "z-index": "1030"
                                            })
                                        })
                                    })
                                }), c.a.on(o, "click", ".search-results", function(e) {
                                    var t = e.target;
                                    "a" === t.nodeName.toLowerCase() && (t.target = "_self")
                                }), (t = document.createElement("script")).async = !0, t.src = a.gcsUrl, n = document.getElementsByTagName("script")[0], E.a.write(function() {
                                    n.parentNode && n.parentNode.insertBefore(t, n)
                                })))
                            })
                        }
                    }]), e
                }(),
                V = n(18),
                $ = n.n(V),
                J = n(95),
                W = n(80),
                Y = n(533),
                K = n.n(Y),
                Q = function() {
                    function e(t, n) {
                        b()(this, e), j()(this, "id", void 0), j()(this, "important", void 0), j()(this, "permanent", void 0), j()(this, "blocking", void 0), j()(this, "trackDisplay", void 0), j()(this, "type", void 0), j()(this, "position", void 0), j()(this, "siteMessageComponentName", void 0), j()(this, "siteMessageLinkName", void 0), j()(this, "siteMessageCloseBtn", void 0), j()(this, "prefs", void 0), j()(this, "widthBasedMessage", void 0), j()(this, "cssModifierClass", void 0), j()(this, "customJs", void 0), j()(this, "customOpts", void 0), j()(this, "$siteMessage", void 0), j()(this, "$siteMessageContainer", void 0), j()(this, "$siteMessageOverlay", void 0);
                        var a = n || {};
                        this.id = t, this.important = a.important || !1, this.permanent = a.permanent || !1, this.blocking = a.blocking || !1, this.trackDisplay = a.trackDisplay || !1, this.type = a.type || "banner", this.position = a.position || "bottom", this.siteMessageComponentName = a.siteMessageComponentName || "", this.siteMessageLinkName = a.siteMessageLinkName || "", this.siteMessageCloseBtn = a.siteMessageCloseBtn || "", this.prefs = "messages", this.widthBasedMessage = a.widthBasedMessage || !1, this.cssModifierClass = a.cssModifierClass || "", this.customJs = a.customJs || J.a, this.customOpts = a.customOpts || {}, this.$siteMessageContainer = Object(D.a)(".js-site-message"), this.$siteMessageOverlay = Object(D.a)(".js-site-message-overlay")
                    }
                    return y()(e, [{
                        key: "show",
                        value: function(e) {
                            var t = this;
                            if (!this.$siteMessageContainer.hasClass("is-hidden") && !this.important) return !1;
                            if ("top" === this.position) {
                                var n = document.body;
                                if (!n) throw new Error("Missing <body>");
                                var a = n.childNodes[0];
                                if (!a) throw new Error("<body> is empty");
                                n.insertBefore(this.$siteMessageContainer[0], a), this.$siteMessageContainer.addClass("site-message--on-top")
                            }
                            return Object(D.a)(".js-site-message-copy").html(e), this.blocking && (Object(D.a)("body, html").addClass("is-scroll-blocked"), this.$siteMessageOverlay.removeClass("is-hidden"), this.$siteMessageOverlay[0].addEventListener("click", function() {
                                t.$siteMessageContainer[0].focus()
                            }), this.$siteMessageOverlay[0].addEventListener("focus", function() {
                                t.$siteMessageContainer[0].focus()
                            }), this.trapFocus()), this.cssModifierClass && this.$siteMessageContainer.addClass("site-message--".concat(this.cssModifierClass)), this.$siteMessage = Object(D.a)(".js-site-message__message"), this.updateMessageOnWidth(), u.a.on("window:throttledResize", this.updateMessageOnWidth.bind(this)), this.siteMessageComponentName && (this.$siteMessageContainer.attr("data-component", this.siteMessageComponentName), this.trackDisplay && Object(p.a)(this.siteMessageComponentName)), this.siteMessageLinkName && this.$siteMessageContainer.attr("data-link-name", this.siteMessageLinkName), this.siteMessageCloseBtn && Object(D.a)(".site-message__close-btn", ".js-site-message").attr("data-link-name", this.siteMessageCloseBtn), this.$siteMessageContainer.addClass("site-message--".concat(this.type)).addClass("site-message--".concat(this.id)), this.$siteMessageContainer.removeClass("is-hidden"), this.permanent ? (this.$siteMessageContainer.addClass("site-message--permanent"), Object(D.a)(".site-message__close").addClass("is-hidden")) : c.a.on(document, "click", ".js-site-message-close", this.acknowledge.bind(this)), this.customJs(this.customOpts), "modal" === this.type && this.bindModalListeners(), !0
                        }
                    }, {
                        key: "bindModalListeners",
                        value: function() {
                            c.a.on(document, "click", ".js-site-message-inner", function(e) {
                                e.stopImmediatePropagation(), e.stopPropagation()
                            }), c.a.on(document, "click", ".js-site-message", this.acknowledge.bind(this))
                        }
                    }, {
                        key: "trapFocus",
                        value: function() {
                            var e = this.$siteMessageContainer[0],
                                t = document.createElement("div");
                            t.tabIndex = 0, t.addEventListener("focus", function() {
                                e.focus()
                            }), e.append(t), e.focus()
                        }
                    }, {
                        key: "hide",
                        value: function() {
                            Object(D.a)("#header").removeClass("js-site-message"), this.$siteMessageContainer.addClass("is-hidden"), this.$siteMessageOverlay.addClass("is-hidden"), Object(D.a)("body, html").removeClass("is-scroll-blocked")
                        }
                    }, {
                        key: "remember",
                        value: function() {
                            if (!this.isRemembered()) {
                                var e = W.a.get(this.prefs) || [];
                                e.push(this.id), W.a.set(this.prefs, K()(e))
                            }
                        }
                    }, {
                        key: "isRemembered",
                        value: function() {
                            return (W.a.get(this.prefs) || []).includes(this.id)
                        }
                    }, {
                        key: "acknowledge",
                        value: function() {
                            this.remember(), this.hide()
                        }
                    }, {
                        key: "updateMessageOnWidth",
                        value: function() {
                            this.widthBasedMessage && this.$siteMessage && this.$siteMessage.length && this.updateMessageFromData(Object(P.m)({
                                max: "tablet"
                            }) ? "site-message-narrow" : "site-message-wide")
                        }
                    }, {
                        key: "updateMessageFromData",
                        value: function(e) {
                            if (this.$siteMessage) {
                                var t = this.$siteMessage.data(e);
                                t && this.$siteMessage && this.$siteMessage.text(t)
                            }
                        }
                    }]), e
                }(),
                X = function(e) {
                    var t = W.a.get("messages");
                    return t && t.includes(e)
                },
                Z = n(104),
                ee = n(30),
                te = n.n(ee),
                ne = "email-sign-in-banner",
                ae = [{
                    name: "Guardian Today UK",
                    utm: "GU Today main NEW H categories"
                }, {
                    name: "Test Campaign",
                    utm: "test1212"
                }],
                ie = function(e) {
                    return ae.find(function(t) {
                        return t.utm === e
                    })
                },
                oe = "".concat(ne, " : display"),
                se = "emailbanner.referrerEmail",
                ce = "https://".concat(r.a.get("page.host"), "/email-newsletters");
            "".concat(r.a.get("page.idUrl"), "/signin?returnUrl=").concat(r.a.get(ce)), a = (new window.URLSearchParams(window.location.search).getAll("utm_campaign") || [""])[0], i = ie(a), o = W.a.get(se), i && !o ? W.a.set(se, {
                utm: i.utm,
                pv: 1
            }) : o && i && o.utm !== i.utm ? (W.a.remove(se), W.a.set(se, {
                utm: i.utm,
                pv: 1
            })) : o && W.a.set(se, $()({}, o, {
                pv: o.pv + 1
            }));
            var re, le, ue, de, me, he = {
                    id: ne,
                    show: function() {
                        var e;
                        e = oe, te.a.record({
                            component: "first-pv-consent",
                            value: e
                        }), Object(Z.c)(e);
                        var t = W.a.get(se) || {};
                        if (!t || !t.utm) throw new Error("email-sign-in : wrong store format");
                        var n = ie(t.utm);
                        if (!n) throw new Error("email-sign-in missing campaign for utm (".concat(t.utm, ")"));
                        W.a.remove(se);
                        var a = new Q(ne, {
                            cssModifierClass: ne,
                            trackDisplay: !0,
                            siteMessageLinkName: ne,
                            siteMessageComponentName: ne
                        });
                        return Promise.resolve(a.show('<div class="site-message--email-sign-in-banner-slide">\n        <h3 class="site-message--email-sign-in-banner-title">\n            Enjoying '.concat(n.name, '?\n         </h3>\n         <p class="site-message--email-sign-in-banner-text">\n            We want to help you find more newsletters you\'ll love. If you sign in we can suggest you newsletters tailored to your personal taste. And you can manage your preferences at any time.\n         </p>\n         <a data-link-name="').concat(ne, ' : to-sign-in" data-link-name="').concat(ne, ' : success" class="site-message--email-sign-in-banner-cta">\n            Sign in / Register\n         </a>\n         <p class="site-message--email-sign-in-banner-text">\n            Free. Takes a minute. \n         </p>\n    </div>')))
                    },
                    canShow: function() {
                        var e;
                        return Promise.resolve(!X(ne) && r.a.get("switches.idEmailSignInUpsell", !1) && (e = W.a.get(se) || {}).pv && e.pv >= 2)
                    }
                },
                ge = n(357),
                fe = n.n(ge),
                pe = n(32),
                ve = function(e) {
                    return "".concat(r.a.get("page.mmaUrl"), "/banner/").concat(e, "?INTCMP=BANNER")
                },
                be = function() {
                    var e = new Date;
                    e.setDate(e.getDate() + 1), W.a.set("mmaActionRequiredBannerCanBeShownAgainAfter", e.toISOString())
                },
                we = function(e, t) {
                    return function(n) {
                        window.ga("".concat(r.a.get("googleAnalytics.trackers.editorial"), ".send"), "event", e, t, n)
                    }
                },
                ye = Object(x.a)(),
                ke = {
                    id: "membership-action-required",
                    show: function() {
                        return ye ? (e = ye, new Q("membership-action-required", {
                            cssModifierClass: "membership-action-required",
                            trackDisplay: !0,
                            siteMessageLinkName: "membership-action-required",
                            siteMessageComponentName: "membership-action-required",
                            customJs: function() {
                                var e = we("click", "in page"),
                                    t = we("element view", "internal");
                                c.a.on(document, "click", ".js-site-message-close", function() {
                                    e("membership action required | banner hidden"), e("mma action required | banner hidden | ".concat(ye || "?")), be()
                                }), c.a.on(document, "click", ".js-mma-update-details-button", function() {
                                    e("membership action required | banner update details clicked"), e("mma action required | banner update details clicked | ".concat(ye || "?")), be()
                                }), t("membership action required | banner impression"), t("mma action required | banner impression | ".concat(ye || "?"))
                            }
                        }).show('<div class="site-message__copy-heading">\n            Action is needed on your Guardian account\n        </div>\n        <div class="site-message__copy-text">\n            Please review and update your details as&nbsp;soon&nbsp;as&nbsp;you&nbsp;can. Thank&nbsp;you.\n        </div>\n        <div class="site-message__copy-text">\n            <a class="button site-message__copy-button js-mma-update-details-button" href="'.concat(function(e) {
                            switch (e) {
                                case "contribution":
                                    return ve("contributions");
                                case "membership":
                                case "digitalpack":
                                    return ve(e);
                                default:
                                    return "".concat(r.a.get("page.idUrl"), "/").concat(e, "/edit")
                            }
                        }(e), '">\n                Update details ').concat(fe.a.markup, "\n            </a>\n        </div>")), Promise.resolve(!0)) : Promise.resolve(!1);
                        var e
                    },
                    canShow: function() {
                        var e = W.a.get("mmaActionRequiredBannerCanBeShownAgainAfter");
                        return Promise.resolve(null !== ye && Object(N.l)() && !(e && new Date(e) > new Date))
                    }
                },
                je = function() {
                    var e = Object(x.e)(),
                        t = Object(x.f)();
                    e && Object(pe.f)({
                        component: {
                            componentType: "ACQUISITIONS_OTHER",
                            id: "acquisitions-cookie-one-off"
                        },
                        value: e.toString()
                    }), t && Object(pe.f)({
                        component: {
                            componentType: "ACQUISITIONS_OTHER",
                            id: "acquisitions-cookie-recurring"
                        },
                        value: t.toString()
                    }), Object(x.h)() && (E.a.read(function() {
                        return document.getElementsByClassName("js-become-member")
                    }).then(function(e) {
                        e.length && e[0].setAttribute("hidden", "hidden")
                    }), E.a.read(function() {
                        return document.getElementsByClassName("js-subscribe")
                    }).then(function(e) {
                        e.length && e[0].classList.remove("brand-bar__item--split--last")
                    }))
                },
                _e = n(51),
                Oe = n(64),
                Ce = !1,
                Me = "#feedback__form input, #feedback__form textarea, #feedback__form button",
                xe = function() {
                    return {
                        browser: window.navigator.userAgent,
                        referrer: document.referrer,
                        page: window.location,
                        width: window.innerWidth,
                        adBlock: Ce,
                        devicePixelRatio: window.devicePixelRatio,
                        gu_u: Object(l.d)("GU_U"),
                        payingMember: Object(l.d)("gu_paying_member"),
                        abTests: (e = Object(Oe.c)(), t = Object.keys(e), 0 === t.length ? "No tests running" : t.map(function(t) {
                            var n = e[t];
                            return "".concat(t, "=").concat(n.variant)
                        }).join(", "))
                    };
                    var e, t
                },
                Ee = function(e) {
                    var t = e.target;
                    D.a.forEachElement("#feedback-category > option", function(e) {
                        if ("nothing" !== e.value) {
                            var t = document.getElementById(e.value);
                            t && t.classList.toggle("feedback__blurb--selected", e.selected)
                        }
                    }), D.a.forEachElement(Me, function(e) {
                        e.disabled = "nothing" === t.value
                    })
                },
                Te = function() {
                    return document.getElementById("feedback-category") ? (P.a.then(function(e) {
                        Ce = e
                    }), e = document.getElementById("feedback__explainer"), t = document.getElementById("feedback-category"), D.a.forEachElement(".feedback__form", function(t) {
                        t.addEventListener("submit", function() {
                            var t = !1;
                            return D.a.forEachElement("#feedback__form input, #feedback__form textarea", function(e) {
                                "" !== e.value && (t = !0)
                            }), t && e && (e.innerHTML = "All fields must be filled to proceed"), !t
                        })
                    }), D.a.forEachElement(Me, function(e) {
                        e.disabled = !0
                    }), t && t.addEventListener("change", Ee, !1), Object(T.a)("https://members-data-api.theguardian.com/user-attributes/me", {
                        mode: "cors"
                    }).then(function(e) {
                        return {
                            basicInformation: xe(),
                            subscriptionInformation: e
                        }
                    }).catch(function() {
                        return {
                            basicInformation: xe()
                        }
                    }).then(function(e) {
                        D.a.forEachElement("#feedback__form input[name=extra]", function(t) {
                            t.value = JSON.stringify(e, null, "  ")
                        })
                    })) : Promise.resolve();
                    var e, t
                },
                Ae = ["sepia", "grayscale", "invert", "contrast", "saturate", "opacity"],
                Se = function() {
                    H.a.write(function() {
                        Ae.forEach(function(e) {
                            var t, n, a;
                            W.a.isOn(e) && (t = e, n = document.body, a = "".concat(t, "(100%)"), n && Object.assign(n.style, {
                                "-webkit-filter": a,
                                filter: a
                            }))
                        })
                    }), W.a.isOn("breuerMode") && document.body && document.body.classList.add("is-breuer-mode")
                },
                Le = n(13),
                Ne = n.n(Le),
                Be = function(e) {
                    var t = e.classList.contains("dropdown--active"),
                        n = Array.from(e.getElementsByClassName("dropdown__content")),
                        a = Array.from(e.getElementsByClassName("dropdown__button"));
                    n.forEach(function(e) {
                        e.setAttribute("aria-hidden", (!t).toString())
                    }), Ne()(n).concat(Ne()(a)).forEach(function(e) {
                        e.setAttribute("aria-expanded", t.toString())
                    })
                },
                Ie = function(e) {
                    H.a.write(function() {
                        e.currentTarget.parentElement && e.currentTarget.parentElement.classList.add("u-faux-block-link--hover")
                    })
                },
                Pe = function(e) {
                    H.a.write(function() {
                        e.currentTarget.parentElement && e.currentTarget.parentElement.classList.remove("u-faux-block-link--hover")
                    })
                },
                De = function() {
                    c.a.on(document.body, "mouseenter", ".u-faux-block-link__overlay", Ie), c.a.on(document.body, "mouseleave", ".u-faux-block-link__overlay", Pe)
                },
                ze = n(78),
                Ue = n.n(ze),
                Re = n(75),
                He = n.n(Re),
                qe = n(79),
                Ge = n.n(qe),
                Fe = n(45),
                Ve = n.n(Fe),
                $e = n(5),
                Je = n(114),
                We = n(72),
                Ye = n(14),
                Ke = n(43),
                Qe = n(161),
                Xe = n.n(Qe),
                Ze = {
                    membershipEngagementBannerBlockUk: {
                        urls: ["/uk", "/uk-news"],
                        geolocation: "GB"
                    },
                    membershipEngagementBannerBlockUs: {
                        urls: ["/us", "/us-news"],
                        geolocation: "US"
                    },
                    membershipEngagementBannerBlockAu: {
                        urls: ["/au", "/australia-news"],
                        geolocation: "AU"
                    }
                },
                et = ["Uk", "Us", "Au"].map(function(e) {
                    return "membershipEngagementBannerBlock".concat(e)
                }),
                tt = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : et,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Ze,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : document.location.pathname,
                        a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : Object($e.g)(),
                        i = e.filter(function(e) {
                            return !!r.a.get("switches.".concat(e))
                        }).map(function(e) {
                            return t[e]
                        }).filter(function(e) {
                            return e.geolocation === a
                        });
                    return Xe()(i.map(function(e) {
                        return e.urls
                    })).includes(n)
                },
                nt = n(10),
                at = n(169),
                it = n(31),
                ot = function(e) {
                    return Object(We.b)().then(function(e) {
                        return function(e) {
                            var t = e && e[0];
                            if (!(t && t.messageText && t.ctaText && t.buttonCaption && t.linkUrl)) throw new Error("Required data from the Google Doc was missing. Got row: ".concat(t));
                            var n = '<span class="engagement-banner__highlight"> '.concat(t.ctaText.replace(/%%CURRENCY_SYMBOL%%/g, Object($e.f)()), "</span>");
                            return {
                                messageText: t.messageText,
                                ctaText: n,
                                buttonCaption: t.buttonCaption,
                                linkUrl: Object(Ke.a)(t.linkUrl),
                                hasTicker: !1,
                                campaignCode: "control_banner_from_google_doc",
                                pageviewId: r.a.get("ophan.pageViewId", "not_found"),
                                products: ["CONTRIBUTION", "RECURRING_CONTRIBUTION"],
                                isHardcodedFallback: !1,
                                template: Je.a,
                                minArticlesBeforeShowingBanner: 3,
                                userCohort: "AllNonSupporters"
                            }
                        }(e)
                    }).catch(function(e) {
                        return Object(Ye.a)(new Error("Could not fetch control banner copy from Google Doc. ".concat(e.message, ". Stack: ").concat(e.stack)), {
                            feature: "engagement-banner"
                        }, !1), {
                            messageText: "<strong>The Guardian is editorially independent &ndash;\n    our journalism is free from the influence of billionaire owners or politicians.\n    No one edits our editor. No one steers our opinion.</strong> And unlike many others, we haven’t put\n    up a paywall as we want to keep our journalism open and accessible. But the revenue we get from\n    advertising is falling, so we increasingly need our readers to fund our independent, investigative reporting.",
                            ctaText: '<span class="engagement-banner__highlight"> Support The Guardian from as little as '.concat(Object($e.f)(), "1</span>"),
                            buttonCaption: "Support The Guardian",
                            linkUrl: Object(Ke.b)(),
                            hasTicker: !1,
                            campaignCode: "fallback_hardcoded_banner",
                            pageviewId: r.a.get("ophan.pageViewId", "not_found"),
                            products: ["CONTRIBUTION", "RECURRING_CONTRIBUTION"],
                            isHardcodedFallback: !0,
                            template: Je.a,
                            minArticlesBeforeShowingBanner: 3,
                            userCohort: "AllNonSupporters"
                        }
                    }).then(function(t) {
                        return e && !t.isHardcodedFallback ? $()({}, t, e.variantToRun.engagementBannerParams, {
                            abTest: {
                                name: e.id,
                                variant: e.variantToRun.id
                            },
                            campaignCode: "".concat(e.id, "_").concat(e.variantToRun.id)
                        }) : t
                    })
                },
                st = function(e) {
                    e.hide(), W.a.set("engagementBannerLastClosedAt", (new Date).toISOString())
                },
                ct = function(e) {
                    var t, n = Array.isArray(e.messageText) ? (t = e.messageText)[Object(nt.h)() % t.length] : e.messageText,
                        a = e.ctaText,
                        i = e.leadSentence,
                        o = Object(pe.b)($()({
                            base: e.linkUrl,
                            componentType: "ACQUISITIONS_ENGAGEMENT_BANNER",
                            componentId: e.campaignCode,
                            campaignCode: e.campaignCode
                        }, e.abTest ? {
                            abTest: e.abTest
                        } : {})),
                        s = e.buttonCaption,
                        c = {
                            titles: e.titles,
                            leadSentence: i,
                            messageText: n,
                            mobileMessageText: e.mobileMessageText,
                            closingSentence: e.closingSentence,
                            ctaText: a,
                            linkUrl: o,
                            buttonCaption: s,
                            hasTicker: e.hasTicker,
                            signInUrl: e.signInUrl
                        };
                    return e.template ? e.template(c) : Object(Je.a)(c)
                },
                rt = function(e) {
                    ["INSERT", "VIEW"].forEach(function(t) {
                        Object(pe.d)($()({
                            component: {
                                componentType: "ACQUISITIONS_ENGAGEMENT_BANNER",
                                products: e.products,
                                campaignCode: e.campaignCode,
                                id: e.campaignCode
                            },
                            action: t
                        }, e.abTest ? {
                            abTest: e.abTest
                        } : {}))
                    })
                },
                lt = function(e) {
                    return t = e, n = ct(e), !!new Q("engagement-banner", {
                        siteMessageLinkName: "membership message",
                        siteMessageCloseBtn: "hide",
                        siteMessageComponentName: t.campaignCode,
                        trackDisplay: !0,
                        cssModifierClass: t.bannerModifierClass || "engagement-banner",
                        customJs: function() {
                            var e = this;
                            c.a.on(document, "click", ".js-engagement-banner-close-button", function() {
                                return st(e)
                            })
                        }
                    }).show(n) && (e.bannerShownCallback && e.bannerShownCallback(), rt(e), e.hasTicker && Object(at.a)(".js-engagement-banner-ticker"), !0);
                    var t, n
                },
                ut = n.n(it)()(function() {
                    return Object(Oe.a)().then(ot)
                }),
                dt = function() {
                    return !r.a.get("switches.membershipEngagementBanner") || tt() ? Promise.resolve(!1) : ut().then(function(e) {
                        if (Object(nt.c)(e.minArticlesBeforeShowingBanner, e.userCohort)) {
                            var t = W.a.get("engagementBannerLastClosedAt");
                            return t ? function(e, t) {
                                return function(e) {
                                    return Object(T.a)("/reader-revenue/contributions-banner-deploy-log/".concat(e), {
                                        mode: "cors"
                                    }).then(function(e) {
                                        return e && e.time
                                    })
                                }(t).then(function(t) {
                                    return new Date(t) > new Date(e)
                                }).catch(function(e) {
                                    return Object(Ye.a)(new Error("Unable to get engagement banner deploy log: ".concat(e)), {
                                        feature: "engagement-banner"
                                    }, !1), !1
                                })
                            }(t, Object(nt.g)(Object($e.g)())) : Promise.resolve(!0)
                        }
                        return Promise.resolve(!1)
                    })
                },
                mt = {
                    id: "engagement-banner",
                    show: function() {
                        return ut().then(lt).catch(function(e) {
                            return Object(Ye.a)(new Error("Could not show banner. ".concat(e.message, ". Stack: ").concat(e.stack)), {
                                feature: "engagement-banner"
                            }, !1), !1
                        })
                    },
                    canShow: dt
                },
                ht = n(331),
                gt = n.n(ht),
                ft = n(128),
                pt = n(344),
                vt = n(119),
                bt = {
                    heading: "Your privacy",
                    consentText: ["We use cookies to improve your experience on our site and to show you personalised advertising.", 'To find out more, read our <a class="u-underline" data-link-name="first-pv-consent : to-privacy" href="'.concat("https://www.theguardian.com/help/privacy-policy", '">privacy policy</a> and <a class="u-underline" data-link-name="first-pv-consent : to-cookies" href="').concat("https://www.theguardian.com/info/cookies", '">cookie policy</a>.')],
                    agreeButton: "I'm OK with that",
                    choicesButton: "My options",
                    linkToPreferences: "".concat(r.a.get("page.idUrl"), "/privacy-settings")
                },
                wt = "js-first-pv-consent-agree",
                yt = function() {
                    return '\n    <div class="site-message--first-pv-consent__block site-message--first-pv-consent__block--head ">'.concat(bt.heading, '</div>\n    <div class="site-message--first-pv-consent__block site-message--first-pv-consent__block--intro">').concat(bt.consentText.map(function(e) {
                        return "<p>".concat(e, "</p>")
                    }).join(""), '\n    </div>\n    <div class="site-message--first-pv-consent__actions">\n        <button\n            data-link-name="first-pv-consent : agree"\n            class="site-message--first-pv-consent__button site-message--first-pv-consent__button--main ').concat(wt, '"\n        >').concat(gt.a.markup, "<span>").concat(bt.agreeButton, '</span></button>\n        <a\n            href="').concat(bt.linkToPreferences, '"\n            data-link-name="first-pv-consent : to-prefs"\n            class="site-message--first-pv-consent__link u-underline"\n        >').concat(bt.choicesButton, "</a>\n    </div>\n")
                },
                kt = function() {
                    return Promise.resolve(ft.a.some(function(e) {
                        return null === Object(ft.b)(e)
                    }) && !X("first-pv-consent") && !Object(Oe.d)(vt.a, "variant"))
                },
                jt = function() {
                    var e;
                    Object(pt.c)(), e = "first-pv-consent : display", te.a.record({
                        component: "first-pv-consent",
                        action: e,
                        value: e
                    }), Object(Z.c)(e)
                },
                _t = function(e) {
                    Array.from(document.querySelectorAll(".".concat(wt))).forEach(function(t) {
                        t.addEventListener("click", function() {
                            return function(e) {
                                ft.a.forEach(function(e) {
                                    Object(ft.d)(e, !0)
                                }), e.hide()
                            }(e)
                        })
                    })
                },
                Ot = {
                    id: "first-pv-consent",
                    canShow: kt,
                    show: function() {
                        jt();
                        var e = new Q("first-pv-consent", Object.assign({}, {
                            important: !0,
                            permanent: !0,
                            customJs: function() {
                                _t(e)
                            }
                        }, {}));
                        return Promise.resolve(e.show(yt()))
                    }
                },
                Ct = n(70),
                Mt = n.n(Ct),
                xt = function(e) {
                    function t(e, n, a, i) {
                        var o;
                        return b()(this, t), o = Ue()(this, He()(t).call(this, e, i)), j()(Ve()(Ve()(o)), "elementSelector", void 0), j()(Ve()(Ve()(o)), "parent", void 0), o.elementSelector = n, o.parent = a, o
                    }
                    return Ge()(t, e), y()(t, [{
                        key: "hide",
                        value: function() {
                            var e = document.querySelector(this.elementSelector);
                            if (e) {
                                var t = e.parentElement;
                                e.remove(), t && 0 === t.childElementCount && t.remove()
                            }
                            this.parent.remember()
                        }
                    }, {
                        key: "bindCloseHandler",
                        value: function(e) {
                            var t = this,
                                n = document.querySelector(this.elementSelector);
                            if (n) {
                                var a = n.querySelectorAll(".js-site-message-close");
                                Array.prototype.forEach.call(a, function(n) {
                                    n.addEventListener("click", function() {
                                        e(t)
                                    })
                                })
                            }
                        }
                    }]), t
                }(Q),
                Et = new Q("first-pv-consent-plus-engagement-banner"),
                Tt = new xt("first-pv-consent", ".js-first-pv-consent-site-message", Et),
                At = new xt("engagement-banner", ".js-engagement-banner-site-message", Et),
                St = {
                    id: "first-pv-consent-plus-engagement-banner",
                    canShow: function() {
                        return Promise.all([kt(), dt()]).then(function(e) {
                            return e.every(function(e) {
                                return !0 === e
                            })
                        })
                    },
                    show: function() {
                        return jt(), Object(Oe.a)().then(ot).then(function(e) {
                            var t = $()({}, e, {
                                campaignCode: "double_banner"
                            });
                            return {
                                params: t,
                                html: ct(t)
                            }
                        }).then(function(e) {
                            return E.a.write(function() {
                                var t, n = e.params.bannerModifierClass ? "site-message--".concat(e.params.bannerModifierClass) : "",
                                    a = (t = e.html, '\n    <div class="site-message js-site-message js-double-site-message site-message--banner site-message--double-banner" tabindex="-1" role="dialog" aria-label="welcome" aria-describedby="site-message__message" data-component="AcquisitionsEngagementBannerStylingTweaks_control" aria-live="polite">\n        <div class="js-engagement-banner-site-message '.concat(n, ' site-message--engagement-banner">\n            <div class="gs-container">\n                <div class="site-message__inner js-site-message-inner">\n                    <div class="site-message__roundel">\n                        ').concat(Mt.a.markup, '\n                    </div>\n                    <div class="site-message__copy js-site-message-copy u-cf">\n                        ').concat(t, '\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class="js-first-pv-consent-site-message site-message--first-pv-consent" tabindex="-1" data-link-name="release message" role="dialog" aria-label="welcome" aria-describedby="site-message__message">\n            <div class="gs-container">\n                <div class="site-message__inner js-site-message-inner">\n                    <div class="site-message__copy js-site-message-copy u-cf">\n                        ').concat(yt(), "\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n"));
                                return document.body && document.body.insertAdjacentHTML("beforeend", a), _t(Tt), At.bindCloseHandler(st), rt(e.params), e.params.bannerShownCallback && e.params.bannerShownCallback(), !0
                            })
                        }).catch(function(e) {
                            return Object(Ye.a)(new Error("Could not show banner within double banner. ".concat(e.message, ". Stack: ").concat(e.stack)), {
                                feature: "engagement-banner"
                            }, !1), !1
                        })
                    }
                },
                Lt = n(492),
                Nt = n(59),
                Bt = n.n(Nt),
                It = n(505),
                Pt = {
                    IOS: {
                        LOGO: "https://assets.guim.co.uk/images/apps/app-logo.png",
                        SCREENSHOTS: "https://assets.guim.co.uk/images/apps/ios-screenshots.jpg",
                        LINK: "https://itunes.apple.com/gb/app/the-guardian/id409128287?mt=8",
                        STORE: "on the App Store"
                    },
                    ANDROID: {
                        LOGO: "https://assets.guim.co.uk/images/apps/app-logo.png",
                        SCREENSHOTS: "https://assets.guim.co.uk/images/apps/ios-screenshots.jpg",
                        LINK: "https://play.google.com/store/apps/details?id=com.guardian",
                        STORE: "in Google Play"
                    }
                },
                Dt = Object(l.d)("GU_SMARTAPPBANNER"),
                zt = Dt && !Number.isNaN(Dt) ? parseInt(Dt, 10) : 0,
                Ut = Object(P.o)() ? "ios" : "android",
                Rt = {
                    id: Ut,
                    show: function() {
                        return It.a.then(function() {
                            var e = new Q(Ut, {
                                    position: "top"
                                }),
                                t = '<img src="<%=LOGO%>" class="app__logo" alt="Guardian App logo" /><div class="app__cta"><h4 class="app__heading">The Guardian app</h4><p class="app__copy">Instant alerts. Offline reading.<br/>Tailored to you.</p><p class="app__copy"><strong>FREE</strong> – <%=STORE%></p></div><a href="<%=LINK%>" class="app__link">View</a>' + ("mobile" === Object(P.d)() ? "" : '<img src="<%=SCREENSHOTS%>" class="app__screenshots" alt="screenshots" />');
                            return e.show(Bt()(t)(Pt[Ut.toUpperCase()])), Object(l.a)("GU_SMARTAPPBANNER", String(zt + 1)), H.a.read(function() {
                                var e = Object(D.a)(".site-message--ios, .site-message--android").dim().height;
                                0 !== window.scrollY && window.scrollTo(window.scrollX, window.scrollY + e)
                            }), !0
                        })
                    },
                    canShow: function() {
                        return new Promise(function(e) {
                            e(!(r.a.get("switches.smartAppBanner") && "Safari" === P.f.browser && Object(P.o)()) && (Object(P.o)() || Object(P.l)()) && zt < 4 && !X(Ut))
                        })
                    }
                },
                Ht = n(534),
                qt = n(359),
                Gt = n(85),
                Ft = function(e) {
                    e.preventDefault();
                    var t = (new Date).getTime(),
                        n = Array.from(document.querySelectorAll("img:not(.gu-image):not(.responsive-img)"));
                    H.a.write(function() {
                        n.forEach(function(e) {
                            e.setAttribute("data-pin-nopin", "true")
                        })
                    }), Object(Gt.a)("".concat("https://assets.pinterest.com/js/pinmarklet.js", "?r=").concat(t))
                },
                Vt = function(e, t, n, a) {
                    return function() {
                        (void 0 === a || a()) && H.a.write(function() {
                            t["add" === e ? "addClass" : "removeClass"](n)
                        })
                    }
                },
                $t = n(82),
                Jt = n(549),
                Wt = n.n(Jt),
                Yt = n(209),
                Kt = n.n(Yt),
                Qt = {
                    submitting: !1
                },
                Xt = function(e, t) {
                    var n = t.iframe,
                        a = t.analytics,
                        i = W.a.get("email-sign-up-".concat(a.formType)) || [];
                    i.push("".concat(a.listName)), W.a.set("email-sign-up-".concat(a.formType), K()(i)), Object(D.a)(n).remove(), Object(Z.c)("rtrt | email form inline | ".concat(a.formType, " | ").concat(a.listName, " | ").concat(a.signedIn, " | form hidden"))
                },
                Zt = function(e, t, n) {
                    var a = Object(D.a)(e).data(),
                        i = a.formDisplayNameNormalText || !1,
                        o = a.formDisplayNameAccentedText || !1,
                        s = a.formTitle || !1,
                        r = a.formDescription || !1,
                        l = a.formCampaignCode || "",
                        u = a.formSuccessHeadline,
                        d = a.formSuccessDesc,
                        m = a.removeComforter || !1,
                        h = a.formCloseButton || !1,
                        g = a.formSuccessEventName || !1;
                    Object(N.g)(function(e) {
                        ! function(e, t) {
                            e && e.primaryEmailAddress && E.a.write(function() {
                                Object(D.a)(".js-email-sub__inline-label", t).addClass("email-sub__inline-label--is-hidden"), Object(D.a)(".js-email-sub__submit-button", t).addClass("email-sub__submit-button--solo"), Object(D.a)(".js-email-sub__text-input", t).val(e.primaryEmailAddress)
                            })
                        }(e, t)
                    }), E.a.write(function() {
                        if (i ? (Object(D.a)(".js-email-sub__display-name-normal-text", t).text(i), o && Object(D.a)(".js-email-sub__display-name-accented-text", t).text(o)) : s && Object(D.a)(".js-email-sub__heading", t).text(s), r && Object(D.a)(".js-email-sub__description", t).text(r), m && Object(D.a)(".js-email-sub__small", t).remove(), h) {
                            var a = '\n                <button class="email-sub__close js-email-sub--close" data-link-name="hide">\n                    <span class="email-sub__hidden">Close</span>\n                    <span class="email-sub__close-icon">\n                        '.concat(Object(S.a)("closeCentralIcon"), "\n                    </span>\n                </button>");
                            t.append(a), c.a.on(t[0], "click", ".js-email-sub--close", Xt, {
                                iframe: e,
                                analytics: n
                            })
                        }
                    }), Object(D.a)(".js-email-sub__form", t).data("formData", {
                        customSuccessEventName: g,
                        campaignCode: l,
                        referrer: window.location.href,
                        customSuccessHeadline: u,
                        customSuccessDesc: d
                    })
                },
                en = function(e, t) {
                    var n, a = function() {
                            E.a.read(function() {
                                n = e[0].clientHeight
                            })
                        },
                        i = function() {
                            E.a.defer(function() {
                                e.css("min-height", n)
                            })
                        };
                    return function() {
                        t ? E.a.write(function() {
                            e.css("min-height", ""), a(), i()
                        }) : (a(), i())
                    }
                },
                tn = function(e, t) {
                    return function() {
                        E.a.read(function() {
                            return e.contentWindow.document.body.clientHeight
                        }).then(function(t) {
                            return E.a.write(function() {
                                e.height = "".concat(t, "px")
                            })
                        }).then(t())
                    }
                },
                nn = function(e, t) {
                    return function() {
                        ! function(e, t) {
                            var n = t.data("formData"),
                                a = e ? "email-sub__message--success" : "email-sub__message--failure",
                                i = e ? n.customSuccessHeadline || "Check your Inbox to confirm subscription" : "Something went wrong",
                                o = e ? n.customSuccessDesc || "" : "Please try again.",
                                s = e ? Wt.a.markup : Kt.a.markup,
                                c = '\n        <div class="email-sub__message '.concat(a, '" role="alert" aria-live="assertive">\n            ').concat(s, '\n            <h3 class="email-sub__message__headline">').concat(i, '</h3>\n            <p class="email-sub__message__description">').concat(o, "</p>\n        </div>");
                            E.a.write(function() {
                                t.addClass("email-sub__form--is-hidden"), t.after(c)
                            })
                        }(e, t), Qt.submitting = !1
                    }
                },
                an = function(e, t) {
                    c.a.on(e[0], "submit", function(e, t, n) {
                        return function(t) {
                            var a, i = Object(D.a)(".".concat("js-email-sub__text-input"), e).val(),
                                o = Object(D.a)("input[name=csrfToken]", e).val(),
                                s = Object(D.a)(".".concat("js-email-sub__text-name"), e).val(),
                                c = Object(D.a)(".".concat("js-email-sub__listname-input"), e);
                            if (t.preventDefault(), !Qt.submitting && i.includes("@")) {
                                var l = e.data("formData"),
                                    d = "email=".concat(encodeURIComponent(i), "&name=").concat(encodeURIComponent(s), "&campaignCode=").concat(l.campaignCode, "&referrer=").concat(l.referrer, "&csrfToken=").concat(encodeURIComponent(o), "&listName=").concat(c.val());
                                return a = "rtrt | email form inline | ".concat(n.formType, " | ").concat(n.listName, " | ").concat(n.signedIn, " | %action%"), Qt.submitting = !0, new Promise(function() {
                                    return l.customSuccessEventName && u.a.emit(l.customSuccessEventName), Object(Z.c)(a.replace("%action%", "subscribe clicked")), Object($t.a)(r.a.get("page.ajaxUrl") + "/email", {
                                        method: "post",
                                        body: d,
                                        headers: {
                                            Accept: "application/json"
                                        }
                                    }).then(function(e) {
                                        if (!e.ok) throw new Error("Fetch error: ".concat(e.status, " ").concat(e.statusText))
                                    }).then(function() {
                                        Object(Z.c)(a.replace("%action%", "subscribe successful"))
                                    }).then(nn(!0, e)).catch(function(t) {
                                        Object(m.c)("c-email", t), Object(Z.c)(a.replace("%action%", "error")), nn(!1, e)()
                                    })
                                })
                            }
                        }
                    }(e, 0, t))
                },
                on = function(e, t) {
                    Object(D.a)(".".concat("js-email-sub__inline-label"), e).each(function(e) {
                        ! function(e, t) {
                            var n = Object(D.a)(e),
                                a = Object(D.a)(t.textInputClass, e),
                                i = Object(D.a)(t.labelClass, e),
                                o = t.hiddenLabelClass,
                                s = t.labelEnabledClass;
                            Vt("add", n, s)(), "" !== a.val() && Vt("add", i, o)(), c.a.on(a[0], {
                                focus: Vt("add", i, o),
                                blur: Vt("remove", i, o, function() {
                                    return "" === a.val()
                                })
                            })
                        }(e, {
                            textInputClass: ".js-email-sub__text-input",
                            labelClass: ".js-email-sub__label",
                            hiddenLabelClass: "email-sub__label--is-hidden",
                            labelEnabledClass: "email-sub__inline-label--enabled"
                        })
                    }), Object(D.a)(".".concat("js-email-sub"), e).each(function(e) {
                        var n, a = Object(D.a)(e),
                            i = en(a, !1),
                            o = en(a, !0),
                            s = Object(D.a)(".".concat("js-email-sub__form"), e),
                            c = {
                                formType: s.data("email-form-type"),
                                listName: s.data("email-list-name"),
                                signedIn: Object(N.l)() ? "user signed-in" : "user not signed-in"
                            };
                        an(s, c), t ? (Zt(t, a, c), tn(t, i)(), n = tn(t, o)) : (i(), n = o), u.a.on("window:throttledResize", n)
                    })
                },
                sn = function(e) {
                    "object" === I()(P.f) && "MSIE" === P.f.browser && ["7", "8", "9"].includes(P.f.version) ? (Object(D.a)(".js-footer__secondary").addClass("l-footer__secondary--no-email"), Object(D.a)(".js-footer__email-container", ".js-footer__secondary").addClass("is-hidden")) : e && "IFRAME" === e.tagName ? e.contentDocument && (on(e.contentDocument.body, e), c.a.on(e, "load", function() {
                        e && e.contentDocument && on(e.contentDocument.body, e)
                    })) : on(document)
                },
                cn = function() {
                    if (Object(N.l)() && document.documentElement) {
                        var e = document.documentElement.classList;
                        e.add("id--signed-in"), e.remove("id--signed-out")
                    }
                },
                rn = function() {
                    Object(m.b)([
                        ["i-css-class", cn]
                    ])
                },
                ln = n(22),
                un = n.n(ln),
                dn = n(218),
                mn = n.n(dn),
                hn = n(550),
                gn = n.n(hn),
                fn = {
                    sport: "sport",
                    football: "sport"
                },
                pn = r.a.get("page"),
                vn = function() {
                    h.a.set("gu.breaking-news.hidden", de)
                },
                bn = function(e, t) {
                    de[e] = t, vn()
                },
                wn = function(e) {
                    return (e.collections || []).filter(function(e) {
                        return Array.isArray(e.content) && e.content.length
                    }).map(function(e) {
                        return e.href = (e.href || "").toLowerCase(), e
                    })
                },
                yn = function(e) {
                    var t = (pn.edition || "").toLowerCase(),
                        n = fn[pn.section];
                    return Xe()([e.filter(function(e) {
                        return "global" === e.href
                    }).map(function(e) {
                        return e.content
                    }), e.filter(function(e) {
                        return e.href === t
                    }).map(function(e) {
                        return e.content
                    }), e.filter(function(e) {
                        return n && e.href === n
                    }).map(function(e) {
                        return e.content
                    })])
                },
                kn = function(e) {
                    return de[pn.pageId] = !0, de = mn()(de, function(t, n) {
                        return e.some(function(e) {
                            return e.id === n
                        })
                    }), vn(), e
                },
                jn = function(e) {
                    return e.filter(function(e) {
                        return !0 !== de[e.id]
                    })
                },
                _n = function(e) {
                    return e.filter(function(e) {
                        var t = e.frontPublicationDate;
                        return t && Object(Lt.b)(new Date(t), 1200)
                    })
                },
                On = function(e) {
                    return e.sort(function(e, t) {
                        return t.frontPublicationDate - e.frontPublicationDate
                    })[0]
                },
                Cn = {
                    id: "breakingNewsBanner",
                    show: function() {
                        var e = U()(document.body),
                            t = U()(un()(".js-breaking-news-placeholder")),
                            n = de.hasOwnProperty(ue.id) ? 0 : 3e3;
                        t.append(function(e) {
                            e.closeIcon = Object(S.a)("closeCentralIcon");
                            var t = U.a.create(Bt()(gn.a)(e)),
                                n = Object(D.a)(".js-breaking-news__item__close", t)[0];
                            return n && c.a.on(n, "click", function() {
                                var t;
                                H.a.write(function() {
                                    Object(D.a)("[data-breaking-article-id]").hide()
                                }), t = e.id, bn(t, !0)
                            }), t
                        }(ue));
                        var a = function(e) {
                            return U()(U.a.create(e[0])).addClass("breaking-news--spectre").removeClass("breaking-news--fade-in breaking-news--hidden")
                        }(t);
                        return setTimeout(function() {
                            H.a.write(function() {
                                var i;
                                0 === n && t.removeClass("breaking-news--fade-in"), e.append(a), t.removeClass("breaking-news--hidden"), i = ue.id, bn(i, !1)
                            })
                        }, n), Promise.resolve(!0)
                    },
                    canShow: function() {
                        return h.a.isAvailable() ? (de = h.a.get("gu.breaking-news.hidden") || {}, Object(T.a)("/news-alert/alerts", {
                            mode: "cors"
                        }).then(wn).then(yn).then(kn).then(jn).then(_n).then(On).then(function(e) {
                            return !!e && (ue = e, !0)
                        }).catch(function(e) {
                            return Object(Ye.a)(e, {
                                feature: "breaking-news"
                            }), !1
                        })) : Promise.resolve(!1)
                    }
                },
                Mn = r.a.get("images.acquisitions.ad-free", ""),
                xn = {
                    id: "ad-free-banner",
                    show: function() {
                        return new Q("ad-free-banner", {
                            siteMessageLinkName: "ad-free-banner",
                            siteMessageCloseBtn: "hide",
                            trackDisplay: !0,
                            cssModifierClass: "ad-free-banner",
                            customJs: function() {
                                var e = this;
                                c.a.on(document, "click", ".js-ad-free-banner-dismiss-button", function() {
                                    e.acknowledge()
                                })
                            }
                        }).show('\n        <div class="site-message__copy-text">\n            <h2 class="site-message__copy-heading">No ads, no interruptions</h2>\n            <p>As a valued subscriber, you won’t see adverts while logged in to the Guardian. Thank you for your support.</p>\n            <button data-link-name="ad-free-banner : dismiss" class="button site-message__copy-button js-ad-free-banner-dismiss-button">\n                '.concat(gt.a.markup, ' Got it, thanks\n            </button>\n        </div>\n        <div class="site-message__image">\n            <img src="').concat(Mn, '" alt="" />\n        </div>\n    ')), Promise.resolve(!0)
                    },
                    canShow: function() {
                        return Promise.resolve(!X("ad-free-banner") && Object(x.g)() && r.a.get("switches.scAdFreeBanner", !1))
                    }
                },
                En = n(44),
                Tn = n(158),
                An = n(84),
                Sn = n(63),
                Ln = function(e) {
                    if (Object(nt.j)()) alert('This page has "Prevent membership/contribution appeals" ticked in Composer. Please try a different page');
                    else if (x.j.forEach(function(e) {
                            return Object(l.e)(e)
                        }), Object(Tn.e)(), Object(An.a)(), Object(En.a)(), e && Object(x.d)(), Object(N.l)() && !e)
                        if (window.location.origin.includes("localhost")) Object(l.e)("GU_U");
                        else {
                            var t = window.location.origin.replace(/(www\.|m\.)/, "profile.");
                            window.location.assign("".concat(t, "/signout"))
                        }
                    else window.location.reload()
                },
                Nn = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    Ln(e)
                },
                Bn = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    r.a.get("switches.membershipEngagementBanner") ? tt() ? alert("Banner is blocked by a switch in the dotcom switchboard") : (W.a.remove("engagementBannerLastClosedAt"), h.a.set("gu.alreadyVisited", 4), Ln(e)) : alert("Membership engagement banner switch is turned off on the dotcom switchboard")
                },
                In = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    Object(l.a)("GU_geo_continent", "EU"), Object(l.e)(Sn.d), Bn(e)
                },
                Pn = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    Object(Tn.d)(), Ln(e)
                },
                Dn = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    Object(Tn.a)(), Ln(e)
                },
                zn = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        t = window.prompt("Enter two-letter geolocation code (e.g. GB, US, AU). Current is ".concat(Object($e.g)(), "."));
                    t && (Object($e.i)(t), Ln(e))
                },
                Un = function() {
                    window.guardian.readerRevenue = {
                        showMeTheEpic: Nn,
                        showMeTheBanner: Bn,
                        showMeTheDoubleBanner: In,
                        showNextVariant: Pn,
                        showPreviousVariant: Dn,
                        changeGeolocation: zn
                    }
                },
                Rn = n(105),
                Hn = !1,
                qn = function() {
                    return new Promise(function(e) {
                        setTimeout(function() {
                            E.a.write(function() {
                                me && me.parentNode && (me.classList.add("cmp-animate"), document.body && document.body.classList.add("no-scroll"), e())
                            })
                        }, 0)
                    })
                },
                Gn = function() {
                    return E.a.write(function() {
                        me && me.parentNode && me.classList.add("cmp-iframe-ready")
                    }).then(qn)
                },
                Fn = function() {
                    return new Promise(function(e) {
                        setTimeout(function() {
                            E.a.write(function() {
                                me && me.parentNode && (me.remove(), me.classList.remove("cmp-iframe-ready"))
                            }).then(e)
                        }, 600)
                    })
                },
                Vn = function() {
                    return E.a.write(function() {
                        me && me.parentNode && (document.body && document.body.classList.remove("no-scroll"), me.classList.remove("cmp-animate"))
                    }).then(Fn)
                },
                $n = function(e) {
                    Object(Ye.a)(e, {
                        feature: "cmp"
                    }, !1)
                },
                Jn = function() {
                    return Hn || ((me = document.createElement("div")).className = "cmp-overlay", me.innerHTML = '<div class="'.concat("cmp-container", '"><iframe src="').concat(Rn.cmpConfig.CMP_URL, '" class="').concat("cmp-iframe", '" tabIndex="1"></iframe></div>'), Rn.cmpUi.setupMessageHandlers(Gn, Vn, $n), Hn = !0), document.body && me && !me.parentElement && document.body.appendChild(me), Promise.resolve(!0)
                },
                Wn = function(e) {
                    e.preventDefault(), Jn()
                },
                Yn = function() {
                    if (Object(Oe.d)(vt.a, "variant")) {
                        var e = document.querySelector("a[data-link-name=privacy]");
                        if (e) {
                            var t = e.parentElement;
                            if (t) {
                                var n = e.cloneNode(!1);
                                n.dataset.linkName = "privacy-settings", n.removeAttribute("href"), n.innerText = "Privacy settings";
                                var a = t.cloneNode(!1);
                                a.appendChild(n), t.insertAdjacentElement("afterend", a), n.addEventListener("click", Wn)
                            }
                        }
                    }
                },
                Kn = {
                    id: "cmpUi",
                    canShow: function() {
                        return Object(Oe.d)(vt.a, "variant") ? Promise.resolve(Rn.cmpUi.canShow()) : Promise.resolve(!1)
                    },
                    show: Jn
                };
            n.d(t, "init", function() {
                return ja
            });
            var Qn = function() {
                    var e = document.getElementById("header");
                    new F, e && r.a.get("switches.idProfileNavigation") && new G({
                        url: r.a.get("page.idUrl")
                    }).init()
                },
                Xn = function() {
                    ! function() {
                        var e, t;
                        c.a.on(document, "click", ".js-navigation-toggle", function(e) {
                            var t = Object(D.a)(".".concat(e.currentTarget.getAttribute("data-target-nav")));
                            e.preventDefault(), E.a.write(function() {
                                t.toggleClass("navigation-container--expanded navigation-container--collapsed"), u.a.emit(t.hasClass("navigation-container--expanded") ? "modules:nav:open" : "modules:nav:close")
                            })
                        }), e = window.location.pathname, t = Array.from(document.getElementsByClassName("js-discount-code-link")), console.log(t), t.map(function(t) {
                            return t.href += function(e) {
                                var t = e.split("/")[1];
                                return "us" === t || "us-news" === t ? "us" : "uk" === t || "uk-news" === t ? "uk" : "au" === t || "australia-news" === t ? "au" : ""
                            }(e), !0
                        });
                        var n, a = [E.a.write(function() {
                            Object(D.a)(".navigation-container--default").removeClass("navigation-container--default").addClass("navigation-container--collapsed")
                        }), E.a.read(function() {
                            return Object(D.a)(".js-mega-nav")
                        }).then(function(e) {
                            return n = e, E.a.read(function() {
                                return Object(D.a)(".js-mega-nav-placeholder")
                            })
                        }).then(function(e) {
                            var t = D.a.create(n.html());
                            if (Object(D.a)(".global-navigation", t).addClass("global-navigation--top"), e) return E.a.write(function() {
                                e.append(t)
                            })
                        }), E.a.read(function() {
                            return Object(D.a)(".js-navigation-header .js-navigation-toggle")
                        }).then(function(e) {
                            return E.a.write(function() {
                                e.attr("href", "#nav-allsections")
                            })
                        })];
                        Object(P.o)() && "object" === I()(P.f) && parseInt(P.f.version, 10) > 5 && a.push(E.a.read(function() {
                            return Object(D.a)(".navigation__scroll")
                        }).then(function(e) {
                            if (e) return E.a.write(function() {
                                e.css({
                                    "-webkit-overflow-scrolling": "touch"
                                })
                            })
                        })), Promise.all(a)
                    }()
                },
                Zn = function() {
                    ["modules:popular:loaded", "modules:geomostpopular:ready"].forEach(function(e) {
                        u.a.on(e, Ht.a)
                    })
                },
                ea = function() {
                    var e = new qt.a;
                    e.init(), e.reset(), c.a.on(document.body, "click", ".".concat("dropdown__button"), function(e) {
                        var t = e.currentTarget.closest(".dropdown");
                        t && E.a.read(function() {
                            var e = document.documentElement,
                                n = t.querySelector(".".concat("dropdown__content"));
                            return {
                                content: n,
                                isActive: t.classList.contains("dropdown--active"),
                                isAnimated: t.classList.contains("dropdown--animated") && null != e && !1 === e.classList.contains("disable-flashing-elements"),
                                contentEstimatedHeight: void 0 !== n.offsetHeight && n.offsetHeight < window.innerHeight ? n.offsetHeight : window.innerHeight
                            }
                        }).then(function(e) {
                            var n = e.content,
                                a = e.isActive,
                                i = e.isAnimated,
                                o = e.contentEstimatedHeight;
                            i && "ontransitionend" in window ? E.a.write(function() {
                                t.style.pointerEvents = "none", a || t.classList.toggle("dropdown--active"), n.style.height = a ? "".concat(o, "px") : 0
                            }).then(function() {
                                requestAnimationFrame(function() {
                                    n.style.height = a ? 0 : "".concat(o, "px"), c.a.one(n, "transitionend", function() {
                                        E.a.write(function() {
                                            n.style.height = "auto", t.style.pointerEvents = "all", a && t.classList.toggle("dropdown--active"), Be(t)
                                        })
                                    })
                                })
                            }) : E.a.write(function() {
                                t.classList.toggle("dropdown--active"), Be(t)
                            })
                        })
                    })
                },
                ta = function() {
                    Object(Lt.a)()
                },
                na = function() {
                    ! function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        re = e.location || window.location, le = e.filter || [], c.a.add(document.body, "click", function(e) {
                            var t = function e(t, n) {
                                if (!t.el) return !1;
                                var a = t.el,
                                    i = a.tagName.toLowerCase(),
                                    o = a.getAttribute("data-link-name");
                                if (o && t.tags.unshift(o), "body" === i) return t.tag = t.tags.join(" | "), delete t.el, t.validTarget && a.getAttribute("data-link-test") && (t.tag = "".concat(a.getAttribute("data-link-test") || "", " | ").concat(t.tag || "")), t;
                                var s, c = JSON.parse(a.getAttribute("data-custom-event-properties") || "{}");
                                if (t.customEventProperties = Object.assign(c, t.customEventProperties), !t.validTarget && (t.validTarget = (s = i, le.filter(function(e) {
                                        return e === s
                                    })).length > 0 || !!n, t.validTarget)) {
                                    var r = a.getAttribute("href");
                                    t.target = a, t.samePage = r && r.startsWith("#") || "button" === i || !!a.hasAttribute("data-is-ajax"), t.sameHost = t.samePage || !!r && function() {
                                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                                        if (e.startsWith("mailto:")) return !1;
                                        var t = e.match(/:\/\/(.[^\/]+)/);
                                        return !t || t[1] === re.hostname
                                    }(r)
                                }
                                return !t.linkContext && a.getAttribute("data-link-context-path") && (t.linkContextPath = a.getAttribute("data-link-context-path") || "", t.linkContextName = a.getAttribute("data-link-context-name") || ""), t.el = a.parentNode, e(t)
                            }({
                                el: e.target,
                                tags: [],
                                target: e.target
                            });
                            u.a.emit("module:clickstream:click", t)
                        })
                    }({
                        filter: ["a", "button"]
                    })
                },
                aa = function() {
                    f.a.init(), r.a.get("switches.ophan") && r.a.get("switches.scrollDepth") && (u.a.on("scrolldepth:data", te.a.record), new C({
                        isContent: /Article|LiveBlog/.test(r.a.get("page.contentType"))
                    }))
                },
                ia = function() {
                    Object(l.c)(["mmcore.pd", "mmcore.srv", "mmid", "GU_ABFACIA", "GU_FACIA", "GU_ALPHA", "GU_ME", "at", "gu_join_date"])
                },
                oa = function() {
                    ["gu.subscriber", "gu.contributor", "gu.cachedRecommendations", "gu.recommendationsEnabled", "gu.abb3.exempt"].forEach(function(e) {
                        return h.a.remove(e)
                    })
                },
                sa = function() {
                    var e = r.a.get("page");
                    e && ("Network Front" !== e.contentType && Object(_e.h)(e), Object(_e.g)(e))
                },
                ca = function() {
                    var e = r.a.get("page");
                    e && (Object(_e.d)(e), Object(_e.e)(e))
                },
                ra = function() {
                    r.a.get("switches.historyTags") && u.a.once("modules:nav:open", function() {
                        Object(_e.i)()
                    })
                },
                la = function() {
                    r.a.get("switches.idCookieRefresh") && function() {
                        if (h.a.isAvailable() && Object(N.l)()) {
                            var e = (new Date).getTime();
                            (function(e, t) {
                                return !e || t > parseInt(e, 10) + 2592e6
                            })(h.a.get("identity.lastRefresh"), e) && (Object(N.h)(), h.a.set("identity.lastRefresh", e))
                        }
                    }()
                },
                ua = function() {
                    ["orientationchange"].forEach(function(e) {
                        window.addEventListener(e, u.a.emit.bind(u.a, "window:".concat(e)))
                    })
                },
                da = function() {
                    if (window.self !== window.top) {
                        var e = document.documentElement;
                        e && e.classList.add("iframed")
                    }
                },
                ma = function() {
                    "#nfn" === document.location.hash && h.a.set("nfn", !0), "#nnfn" === document.location.hash && h.a.remove("nfn"), h.a.get("nfn") && n.e(42).then(n.bind(null, 675)).then(function(e) {
                        (0, e.go)()
                    })
                },
                ha = function() {
                    Object(p.d)()
                },
                ga = function() {
                    r.a.get("switches.enableDiscussionSwitch") && (u.a.on("modules:related:loaded", L), L())
                },
                fa = function() {
                    var e = Object(d.d)();
                    e.test && Object(l.b)("GU_TEST", encodeURIComponent(e.test))
                },
                pa = function() {
                    var e, t = document.body;
                    t && (c.a.on(t, "click", "[data-open-overlay-on-click]", function(n) {
                        var a = n.currentTarget.getAttribute("data-open-overlay-on-click");
                        e = t.scrollTop, t.classList.add("has-overlay");
                        var i = document.getElementById(a);
                        i && (i.classList.add("overlay--open"), t.appendChild(i))
                    }), c.a.on(t, "click", ".js-overlay-close", function(n) {
                        var a = n.target.closest(".overlay");
                        a && a.classList.remove("overlay--open"), t.classList.remove("has-overlay"), window.setTimeout(function() {
                            e && (t.scrollTop = e, e = null)
                        }, 1)
                    }))
                },
                va = function() {
                    window.guardian.api = {}
                },
                ba = function() {
                    var e;
                    /Article|LiveBlog|Gallery|Video/.test(r.a.get("page.contentType")) && (e = Array.from(document.querySelectorAll(".social__item--pinterest")), H.a.write(function() {
                        e.forEach(function(e) {
                            e.addEventListener("click", Ft)
                        })
                    }))
                },
                wa = function() {
                    sn(), Array.from(document.getElementsByClassName("js-email-sub__iframe")).forEach(function(e) {
                        sn(e)
                    }), c.a.on(window, "interactive-loaded", function() {
                        Array.from(document.querySelectorAll(".guInteractive .js-email-sub__iframe")).forEach(function(e) {
                            sn(e)
                        })
                    })
                },
                ya = function() {
                    var e, t;
                    e = [Kn, St, Ot, Cn, ke, mt, Rt, xn, he], t = new Array(e.length).fill("pending", 0), new Promise(function(n) {
                        var a = !1;
                        e.forEach(function(i, o) {
                            var s = function(i) {
                                    t[o] = i;
                                    var s, c = (s = t.findIndex(function(e) {
                                        return !0 === e
                                    })) <= 0 ? s : -1 === t.slice(0, s).findIndex(function(e) {
                                        return "pending" === e
                                    }) ? s : -1;
                                    if (!a && -1 !== c) {
                                        var r = e[c];
                                        r.show(), a = !0;
                                        var l = {
                                            component: "banner-picker",
                                            value: r.id
                                        };
                                        te.a.record(l)
                                    }
                                    t.includes("pending") || n()
                                },
                                c = !1,
                                r = setTimeout(function() {
                                    c = !0, s(!1);
                                    var e = {
                                        component: "banner-picker-timeout",
                                        value: i.id
                                    };
                                    te.a.record(e)
                                }, 2e3);
                            i.canShow().then(function(e) {
                                c || (clearTimeout(r), s(e))
                            })
                        })
                    })
                },
                ka = function() {
                    return Object(pt.b)(Object(ft.c)())
                },
                ja = function() {
                    Object(m.b)([
                        ["c-analytics", aa],
                        ["c-consent-cookie-tracking", ka],
                        ["c-identity", rn],
                        ["c-adverts", M.b],
                        ["c-discussion", ga],
                        ["c-test-cookie", fa],
                        ["c-event-listeners", ua],
                        ["c-block-link", De],
                        ["c-iframe", da],
                        ["c-normalise", ma],
                        ["c-tabs", Zn],
                        ["c-top-nav", Qn],
                        ["c-init-nav", Xn],
                        ["c-toggles", ea],
                        ["c-dates", ta],
                        ["c-clickstream", na],
                        ["c-history", sa],
                        ["c-id-cookie-refresh", la],
                        ["c-history-nav", ra],
                        ["c-start-register", ha],
                        ["c-cookies", ia],
                        ["c-extend-contribs-expiry", x.c],
                        ["c-localStorage", oa],
                        ["c-overlay", pa],
                        ["c-public-api", va],
                        ["c-tech-feedback", Te],
                        ["c-media-listeners", g],
                        ["c-accessibility-prefs", Se],
                        ["c-pinterest", ba],
                        ["c-email", wa],
                        ["c-user-features", x.k],
                        ["c-membership", je],
                        ["c-banner-picker", ya],
                        ["c-increment-article-counts", ca],
                        ["c-reader-revenue-dev-utils", Un],
                        ["c-add-privacy-settings-link", Yn]
                    ])
                }
        },
        682: function(e, t, n) {
            "use strict";
            n.r(t);
            var a = n(13),
                i = n.n(a),
                o = n(3),
                s = n(22),
                c = n.n(s),
                r = n(35),
                l = n(8),
                u = n(0),
                d = n(47),
                m = n(159),
                h = n(64),
                g = n(76),
                f = n(7),
                p = n(548),
                v = n(531),
                b = n(532),
                w = n(59),
                y = n.n(w),
                k = function(e) {
                    0 === e.filter(function(e) {
                        return e && !1 === e.ready
                    }).length && Object(v.a)(function() {
                        Object(l.a)(".js-after-article").append(l.a.create('<div class="football-extras"></div>').each(function(t) {
                            e.forEach(function(e) {
                                t.appendChild(e.content)
                            })
                        }))
                    }, function() {
                        e.forEach(function(e) {
                            ! function(e) {
                                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
                                    n = Object(l.a)(".js-components-container");
                                l.a.create('<div class="'.concat("component--rhc", '" data-importance="').concat(t, '"></div>')).append(e).each(function(e) {
                                    var a = Object(l.a)(".".concat("component--rhc"), n[0]) || [],
                                        i = Array.from(a).filter(function(e) {
                                            return !e.hasAttribute("data-importance") || t > parseInt(e.getAttribute("data-importance"), 10)
                                        });
                                    0 === i.length ? n.append(e) : Object(l.a)(i[0]).before(e)
                                })
                            }(e.content, e.importance)
                        })
                    })
                },
                j = function() {
                    ! function() {
                        var e = u.a.get("page.cricketMatchDate"),
                            t = u.a.get("page.cricketTeam");
                        if (e && t) {
                            var n = new g.a;
                            n.endpoint = "/sport/cricket/match/".concat(e, "/").concat(t, ".json"), o.a.read(function() {
                                return document.querySelector(".js-cricket-score")
                            }).then(function(e) {
                                n.fetch(e, "summary")
                            })
                        }
                    }(),
                    function() {
                        var e = "";
                        if (u.a.get("page.isLiveBlog") ? e = "minbymin" : u.a.hasTone("Match reports") && (e = "report"), u.a.get("page.rugbyMatch") && e) {
                            var t = encodeURIComponent(u.a.get("page.pageId")),
                                n = new b.a({
                                    pageType: e,
                                    parent: Object(l.a)(".js-score"),
                                    autoupdated: u.a.get("page.isLive"),
                                    responseDataKey: "matchSummary",
                                    endpoint: "".concat(u.a.get("page.rugbyMatch"), ".json?page=").concat(t)
                                });
                            n.fetched = function(e) {
                                o.a.read(function() {
                                    return document.querySelector("article")
                                }).then(function(e) {
                                    e.classList.add("content--has-scores")
                                }), o.a.read(function() {
                                    return document.querySelector(".content--liveblog")
                                }).then(function(e) {
                                    e.classList.add("content--liveblog--rugby")
                                }), l.a.create(e.nav).first().each(function(e) {
                                    2 === Object(l.a)(".tabs__tab", e).length && (Object(l.a)(".js-sport-tabs").empty(), Object(l.a)(".js-sport-tabs").append(e))
                                });
                                var t = e.scoreEvents;
                                if (Object(f.m)({
                                        max: "mobile"
                                    })) {
                                    var n = l.a.create(y()(e.dropdown)({
                                        name: "Score breakdown",
                                        content: t
                                    }));
                                    u.a.get("page.isLiveBlog") && n.addClass("dropdown--key-events"), n.addClass("dropdown--active"), Object(l.a)(".js-after-article").append(n)
                                } else {
                                    var a = l.a.create(t);
                                    a.addClass("hide-on-mobile"), Object(l.a)(".rugby-stats").remove(), Object(l.a)(".score-container").after(a)
                                }
                                Object(l.a)(".js-match-stats").remove(), e.matchStat && l.a.create('<div class="match-stats__container js-match-stats">'.concat(e.matchStat, "</div>")).each(function(e) {
                                    Object(l.a)(".js-chart", e).each(function(e) {
                                        (new p.a).render(e)
                                    }), k([{
                                        name: "Match stats",
                                        importance: 3,
                                        content: e,
                                        ready: !0
                                    }])
                                }), Object(l.a)(".js-football-table").remove(), e.groupTable && l.a.create('<div class="js-football-table" data-link-name="football-table-embed">'.concat(e.groupTable, "</div>")).each(function(e) {
                                    k([{
                                        name: "Table",
                                        importance: 3,
                                        content: e,
                                        ready: !0
                                    }])
                                })
                            }, n.load()
                        }
                    }()
                },
                _ = n(104),
                O = n(5),
                C = n(18),
                M = n.n(C),
                x = n(32),
                E = n(43),
                T = ["https://interactive.guim.co.uk/embed/2017/12/the-mother-load/", "https://interactive.guim.co.uk/embed/2018/this-wide-brown-land/"],
                A = function() {
                    window.addEventListener("message", function(e) {
                        var t;
                        try {
                            t = JSON.parse(e.data)
                        } catch (e) {
                            return
                        }
                        "enrich-acquisition-links" === t.type && t.id && (t.referrerData = Object(x.a)({}), Array.from(document.getElementsByTagName("iframe")).forEach(function(e) {
                            e.contentWindow.postMessage(JSON.stringify(t), "https://interactive.guim.co.uk")
                        })), "acquisition-data-request" === t.type && Array.from(document.getElementsByTagName("iframe")).forEach(function(e) {
                            var t = e.getAttribute("src");
                            t && function(e) {
                                return T.some(function(t) {
                                    return e.startsWith(t)
                                })
                            }(t) && e.contentWindow.postMessage(JSON.stringify({
                                type: "acquisition-data-response",
                                acquisitionData: M()({}, Object(x.a)({}), {
                                    source: "GUARDIAN_WEB"
                                })
                            }), "*")
                        })
                    }), Array.from(document.getElementsByClassName("js-acquisition-link")).forEach(function(e) {
                        var t = e.getAttribute("href");
                        if (t) {
                            var n = function(e) {
                                var t, n;
                                try {
                                    t = new URL(e)
                                } catch (t) {
                                    return e
                                }
                                try {
                                    var a = t.searchParams.get("acquisitionData");
                                    if (!a) return e;
                                    n = JSON.parse(a)
                                } catch (t) {
                                    return e
                                }
                                return n && (n = Object(x.a)(n), t.searchParams.set("acquisitionData", JSON.stringify(n))), t.toString()
                            }(t);
                            n = Object(E.a)(n), e.setAttribute("href", n)
                        }
                    })
                };
            n.d(t, "bootEnhanced", function() {
                return S
            });
            var S = function() {
                var e = function(e, t) {
                    r.a.context({
                        tags: {
                            feature: e
                        }
                    }, t, [])
                };
                Object(d.c)("App Begin"), Object(m.b)([
                    ["ga-user-timing-enhanced-start", function() {
                        Object(_.d)("Javascript Load", "enhancedStart", "Enhanced start parse time")
                    }],
                    ["ab-tests", function() {
                        Object(m.b)([
                            ["ab-tests-run", function() {
                                Object(h.e)()
                            }]
                        ])
                    }],
                    ["enrich-acquisition-links", A]
                ]), Promise.resolve().then(n.bind(null, 649)).then(function(t) {
                    var n = t.init;
                    e("common", n)
                }).then(function() {
                    if (Object(m.b)([
                            ["geolocation", O.h]
                        ]), u.a.get("page.isFront") && Promise.all([n.e(8), n.e(0), n.e(18)]).then(function(t) {
                            e("facia", n(679).init)
                        }.bind(null, n)).catch(n.oe), "Article" !== u.a.get("page.contentType") || u.a.get("page.isMinuteArticle") || Promise.all([n.e(3), n.e(0), n.e(1), n.e(2)]).then(function(t) {
                            e("article", n(680).init), e("article : lightbox", n(669).init)
                        }.bind(null, n)).catch(n.oe), "Crossword" === u.a.get("page.contentType") && Promise.all([n.e(4), n.e(1), n.e(13)]).then(function(t) {
                            e("crosswords", n(678).init)
                        }.bind(null, n)).catch(n.oe), "LiveBlog" === u.a.get("page.contentType") && Promise.all([n.e(3), n.e(0), n.e(1), n.e(2)]).then(function(t) {
                            e("liveBlog", n(683).init), e("liveBlog : lightbox", n(669).init)
                        }.bind(null, n)).catch(n.oe), u.a.get("page.isMinuteArticle") && Promise.all([n.e(3), n.e(0), n.e(1), n.e(2)]).then(function(t) {
                            e("articleMinute", n(686).init), e("article : lightbox", n(669).init)
                        }.bind(null, n)).catch(n.oe), "Audio" !== u.a.get("page.contentType") && "Video" !== u.a.get("page.contentType") && "Interactive" !== u.a.get("page.contentType") || Promise.all([n.e(0), n.e(1), n.e(29)]).then(function(t) {
                            e("media : trail", n(503).initTrails)
                        }.bind(null, n)).catch(n.oe), o.a.read(function() {
                            return c()("".concat(u.a.get("switches.videojs") ? "video, " : "", " audio"))
                        }).then(function(t) {
                            t.length && Promise.all([n.e(34), n.e(21)]).then(function(t) {
                                e("media-player", n(685).initMediaPlayer)
                            }.bind(null, n)).catch(n.oe)
                        }), u.a.get("switches.videojs") || o.a.read(function() {
                            return c()("video")
                        }).then(function(t) {
                            t.length && n.e(38).then(function(t) {
                                e("video-player", n(421).initVideoPlayer)
                            }.bind(null, n)).catch(n.oe)
                        }), "Gallery" === u.a.get("page.contentType") && Promise.all([n.e(3), n.e(0), n.e(1), n.e(2)]).then(function(t) {
                            e("gallery", n(670).init), e("gallery : lightbox", n(669).init)
                        }.bind(null, n)).catch(n.oe), "ImageContent" === u.a.get("page.contentType") && Promise.all([n.e(3), n.e(0), n.e(1), n.e(2)]).then(function(t) {
                            e("image-content : lightbox", n(669).init), e("image-content : trail", n(503).initTrails)
                        }.bind(null, n)).catch(n.oe), "football" === u.a.get("page.section") && n.e(19).then(function(t) {
                            e("football", n(681).init)
                        }.bind(null, n)).catch(n.oe), "sport" === u.a.get("page.section") && e("sport", j), "identity" === u.a.get("page.section") && Promise.all([n.e(4), n.e(25)]).then(function(t) {
                            e("profile", n(677).initProfile)
                        }.bind(null, n)).catch(n.oe), u.a.get("page.isPreferencesPage") && Promise.all([n.e(4), n.e(6)]).then(function(t) {
                            e("preferences", n(671).init)
                        }.bind(null, n)).catch(n.oe), "newsletter-signup-page" === u.a.get("page.section") && n.e(23).then(function(t) {
                            e("newsletters", n(672).init)
                        }.bind(null, n)).catch(n.oe), "https:" === window.location.protocol && "identity" !== u.a.get("page.section") || window.location.hash.indexOf("force-sw") > -1) {
                        var t = window.navigator;
                        t && t.serviceWorker && (u.a.get("switches.serviceWorkerEnabled") ? t.serviceWorker.register("/service-worker.js") : t.serviceWorker.getRegistrations().then(function(e) {
                            i()(e).forEach(function(e) {
                                e.unregister()
                            })
                        }))
                    }
                    "help/accessibility-help" === u.a.get("page.pageId") && Promise.all([n.e(4), n.e(6)]).then(function(t) {
                        e("accessibility", n(673).init)
                    }.bind(null, n)).catch(n.oe), o.a.read(function() {
                        Object(l.a)(".youtube-media-atom").length > 0 && Promise.all([n.e(0), n.e(40)]).then(function(t) {
                            e("youtube", n(422).init)
                        }.bind(null, n)).catch(n.oe)
                    }), window.location.hash.includes("experiments") && n.e(16).then(function(t) {
                        e("experiments", n(674).showExperiments)
                    }.bind(null, n)).catch(n.oe), "Audio" === u.a.get("page.contentType") && Promise.all([n.e(31), n.e(10)]).then(function(t) {
                        e("audio", n(684).init)
                    }.bind(null, n)).catch(n.oe), Object(d.c)("App End"), Object(m.b)([
                        ["ga-user-timing-enhanced-end", function() {
                            Object(_.d)("Javascript Load", "enhancedEnd", "Enhanced end parse time")
                        }]
                    ])
                })
            }
        }
    }
]);
//# sourceMappingURL=graun.enhanced.js.map