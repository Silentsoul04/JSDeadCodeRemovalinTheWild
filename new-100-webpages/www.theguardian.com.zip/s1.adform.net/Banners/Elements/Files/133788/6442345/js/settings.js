var bb = bb || {};
bb.settings = {};
bb.settings.magenta = '#E20074';
/* Phone Interactive */
bb.settings.phone = {};
bb.settings.phone.perspective = 500;
bb.settings.phone.maxShineOpacity = .5;
bb.settings.phone.moveAmount = 10;
bb.settings.phone.friction = .08;