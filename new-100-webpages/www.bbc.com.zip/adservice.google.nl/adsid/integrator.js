processGoogleToken({
    "newToken": "NT",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "",
    "pucrd": ""
});