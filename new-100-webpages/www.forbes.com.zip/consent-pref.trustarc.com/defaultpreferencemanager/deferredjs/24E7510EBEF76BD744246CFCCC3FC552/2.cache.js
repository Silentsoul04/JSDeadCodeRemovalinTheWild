var I2b = 'Adding window resize handler for mobile browsers.';
dN(707, 1, XSb);
_.hd = function Pfb() {
    Uwb();
    Swb && (Vwb(I2b), tO(Twb, (sQb(), qQb), I2b));
    NW(new Rfb(this))
};

function Rfb(a) {
    this.b = a
}
dN(708, 1, DSb, Rfb);
_.yd = function Sfb(a) {
    qxb(this.b.b.c, a_b, BTb)
};
_.b = null;
var pD = TEb(gZb, 'PreferenceManagerEntryPoint$1$1', 708);
yTb(ji)(2);