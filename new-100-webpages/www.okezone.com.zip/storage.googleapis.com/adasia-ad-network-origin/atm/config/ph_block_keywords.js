var ph_keywords = [];
adAsiaDataLayer['ph_keywords'] = ph_keywords;