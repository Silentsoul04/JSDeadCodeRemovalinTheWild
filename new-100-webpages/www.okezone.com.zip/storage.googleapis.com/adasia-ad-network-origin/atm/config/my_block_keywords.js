var my_keywords = ['memperkosa', 'porno'];
adAsiaDataLayer['my_keywords'] = my_keywords;