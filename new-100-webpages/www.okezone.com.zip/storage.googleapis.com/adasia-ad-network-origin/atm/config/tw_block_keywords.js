var tw_keywords = [];
adAsiaDataLayer['tw_keywords'] = tw_keywords;