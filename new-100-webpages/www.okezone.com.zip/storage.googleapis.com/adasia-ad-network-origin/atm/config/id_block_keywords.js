var id_keywords = ['Payudara', 'Spermanya', 'bokep', 'porno', 'pornode', 'seks', 'seksual', 'sex', 'vagina', 'viagra'];
adAsiaDataLayer['id_keywords'] = id_keywords;