var kh_keywords = [];
adAsiaDataLayer['kh_keywords'] = kh_keywords;