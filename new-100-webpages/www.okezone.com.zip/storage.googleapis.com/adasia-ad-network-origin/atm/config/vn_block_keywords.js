var vn_keywords = ['sex', 'đồ chơi tình dục'];
adAsiaDataLayer['vn_keywords'] = vn_keywords;