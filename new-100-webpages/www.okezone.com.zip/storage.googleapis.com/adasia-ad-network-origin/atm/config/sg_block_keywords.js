var sg_keywords = ['porn', 'rape'];
adAsiaDataLayer['sg_keywords'] = sg_keywords;