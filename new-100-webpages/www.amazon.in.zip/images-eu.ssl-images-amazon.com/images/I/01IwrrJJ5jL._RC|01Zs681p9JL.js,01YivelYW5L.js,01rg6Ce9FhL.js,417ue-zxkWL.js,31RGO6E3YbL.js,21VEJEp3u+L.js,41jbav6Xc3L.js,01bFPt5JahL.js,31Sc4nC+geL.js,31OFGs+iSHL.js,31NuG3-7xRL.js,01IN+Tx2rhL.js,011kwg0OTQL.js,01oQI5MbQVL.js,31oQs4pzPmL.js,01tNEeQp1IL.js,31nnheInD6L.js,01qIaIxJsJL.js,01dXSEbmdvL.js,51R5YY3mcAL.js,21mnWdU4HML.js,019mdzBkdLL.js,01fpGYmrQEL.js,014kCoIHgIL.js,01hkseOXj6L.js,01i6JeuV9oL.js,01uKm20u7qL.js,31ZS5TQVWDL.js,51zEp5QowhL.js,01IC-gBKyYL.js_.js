(function(a) {
    var c = window.AmazonUIPageJS || window.P,
        d = c._namespace || c.attributeErrors,
        b = d ? d("AmazonsChoiceAssets", "") : c;
    b.guardFatal ? b.guardFatal(a)(b, window) : b.execute(function() {
        a(b, window)
    })
})(function(a, c, d) {
    a.when("A", "a-popover", "ready").execute(function(b, e) {
        var a = b.$;
        a(document).delegate("#why-we-love-this-product-link", "click mouseenter", function(b) {
            e.get(a("#ac-badge-popover-declarative")).show();
            b.preventDefault()
        })
    });
    "use strict";
    a.when("A", "atf", "dp-refresh-handler").execute(function(b,
        a, c) {
        a = b.state("acState");
        b = {
            featureName: "acBadge"
        };
        a !== d && (a = a.acAsin, (new c(b)).addParams({
            acAsin: a
        }))
    })
});
/* ******** */
(function(a) {
    var b = window.AmazonUIPageJS || window.P,
        e = b._namespace || b.attributeErrors,
        c = e ? e("WestlakeAssets", "") : b;
    c.guardFatal ? c.guardFatal(a)(c, window) : c.execute(function() {
        a(c, window)
    })
})(function(a, b, e) {
    a.when("A", "jQuery").register("alw-delay-load-images", function(c, b) {
        function d() {
            if (null !== document.getElementById("skycity-soft-merge"))
                for (var a = document.querySelectorAll(".skycity-image-html"), d = 0; d < a.length; d++) {
                    var e = b(a[d]);
                    e.hasClass("skycity-image-loaded") || (a[d].insertAdjacentHTML("afterend",
                        a[d].getAttribute("data-html")), e.addClass("skycity-image-loaded"))
                }
            c.trigger("skycity-image-loaded")
        }
        c.on("a:pageUpdate", d);
        a.when("atf").execute("alw-load-images", d)
    });
    "use strict";
    a.when("A").register("alw-delay-load-widget", function(a) {
        function b() {
            var a = document.getElementById("skycity-soft-merge");
            null !== a && (a.style.display = "block")
        }
        b();
        a.on("a:pageUpdate", b)
    })
});
/* ******** */
(function(a) {
    var c = window.AmazonUIPageJS || window.P,
        e = c._namespace || c.attributeErrors,
        b = e ? e("DetailPagePRSubsWidgetAssets", "") : c;
    b.guardFatal ? b.guardFatal(a)(b, window) : b.execute(function() {
        a(b, window)
    })
})(function(a, c, e) {
    a.when("A", "jQuery", "ready", "cf").execute(function(b, d) {
        function a() {
            d(".prsubswidget-asin-title, .prsubswidget-asin-image").unbind("mousedown.prsubswidget");
            d(".prsubswidget-asin-title, .prsubswidget-asin-image").bind("mousedown.prsubswidget", function(a) {
                if (c.ue && c.ue.event && d(a.target).parents("a")) {
                    var b =
                        d(a.target).parents("a").data("subsAsin");
                    a = d(a.target).parents("a").data("surfacedAsinRequestId");
                    b && a && c.ue.event({
                        producerId: "prservices_subs_feedback_loop",
                        schemaId: "prservices.ClickedSubstituteEvent.3",
                        subsAsin: b,
                        surfacedAsinRequestId: a
                    }, "producer", "schema")
                }
            })
        }
        a();
        b.on("a:pageUpdate", a)
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageInstallmentCalculatorAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(n) {
    var p = window.AmazonUIPageJS || window.P,
        r = p._namespace || p.attributeErrors,
        m = r ? r("DetailPageSTSAssets", "") : p;
    m.guardFatal ? m.guardFatal(n)(m, window) : m.execute(function() {
        n(m, window)
    })
})(function(n, p, r) {
    function m(f, k) {
        if (!(f instanceof k)) throw new TypeError("Cannot call a class as a function");
    }

    function m(f, k) {
        if (!(f instanceof k)) throw new TypeError("Cannot call a class as a function");
    }

    function m(f, k) {
        if (!(f instanceof k)) throw new TypeError("Cannot call a class as a function");
    }

    function m(f,
        k) {
        if (!(f instanceof k)) throw new TypeError("Cannot call a class as a function");
    }

    function m(f, k) {
        if (!(f instanceof k)) throw new TypeError("Cannot call a class as a function");
    }
    "use strict";
    "use strict";
    "use strict";
    var t = function() {
        function f(f, l) {
            for (var d = 0; d < l.length; d++) {
                var c = l[d];
                c.enumerable = c.enumerable || !1;
                c.configurable = !0;
                "value" in c && (c.writable = !0);
                Object.defineProperty(f, c.key, c)
            }
        }
        return function(k, l, d) {
            l && f(k.prototype, l);
            d && f(k, d);
            return k
        }
    }();
    n.when("ship-to-store-settings", "vas-common-settings",
        "vas-mobile-widgets").execute(function(f, k) {
        var l = f.fetch();
        if (!l || !l.stsVM || "stsPdpOnly" !== l.stsVM.winningWidgetName) return !1;
        n.when("A", "ship-to-store-metric-publisher", "ship-to-store-metric-names", "query-param", "vas-mobile-core-buybox").execute(function(d, c, b, h, f) {
            var e = new c(l.refTagPrefix);
            e.publish(b.LOADED);
            var g = d.$;
            new(function() {
                function c() {
                    var a = this;
                    m(this, c);
                    this.hideQuickPurchaseIngress = function() {
                        a.$buyBoxOneClickButtonContainer.hide();
                        a.$buyNowFeature.hide();
                        a.$buyNowButtonContainer.hide()
                    };
                    this.showQuickPurchaseIngress = function() {
                        a.$buyBoxOneClickButtonContainer.show();
                        a.$buyNowFeature.show();
                        a.$buyNowButtonContainer.show()
                    };
                    this.generateHTMLTemplatesFromOffers = function(c, h) {
                        h = l.stsVM.productQuantityToUpsellAsinMap[h];
                        var g = c[h];
                        h ? g && g.length ? function() {
                            e.publish(b.SELECTED_QTY_MAPPED_TO_ASIN_W_OFFERS);
                            a.$addProfessionalServicesRow.show();
                            a.$bottomSheetOffersScrollerContainer.empty();
                            var c = 0;
                            g && (d.each(g, function(b) {
                                var e = a.$shipToStoreModalOfferTemplate.clone(),
                                    d = a.$shipToStoreModalOfferPriceTemplate.clone();
                                d.removeClass("aok-hidden");
                                d.html(b.localizedPrice);
                                d.removeAttr("id");
                                e.find(".sts-merchant-name").html(b.merchantName);
                                e.find(".sts-display-address").html(b.displayAddress);
                                e.find(".sts-ratings-and-reviews").html(b.ratingsAndReviews);
                                e.find(".sts-localized-price").html(b.priceAndServiceCount).find(".price").append(d);
                                a.includedServicesEnabled && a.showIncludedServices(e, b);
                                e.data("offerListingId", b.offerListingId);
                                e.data("upsellAsin", b.asin);
                                e.data("merchantId", b.merchantId);
                                e.data("storeId", b.storeId);
                                e.attr("data-sts-ao", b.storeId);
                                e.removeClass("aok-hidden");
                                e.removeAttr("id");
                                a.$bottomSheetOffersScrollerContainer.append(e);
                                c++
                            }), a.highlightOffer(a.getDefaultOffer()), e.publish(b.OFFERS_GENERATED, c), a.$offeredIngressBelowButton.html(a.highlightedOfferData.installationOfferedBelowButtonString))
                        }() : (e.publish(b.SELECTED_QTY_MAPPED_TO_ASIN_WO_OFFERS), a.$addProfessionalServicesRow.hide()) : (e.publish(b.SELECTED_QTY_NOT_MAPPED_TO_ASIN), a.$addProfessionalServicesRow.hide());
                        performance && (performance.mark("ship-to-store-ingress-end"),
                            performance.measure(b.INGRESS_SHOWING_SINCE_PAGE_LOAD_LATENCY, "ship-to-store-ingress-start", "ship-to-store-ingress-end"), c = performance.getEntriesByName(b.INGRESS_SHOWING_SINCE_PAGE_LOAD_LATENCY), c.length && (h = c[0].duration, e.publish(b.INGRESS_SHOWING_SINCE_PAGE_LOAD_LATENCY, c[0].startTime + h), e.publish(b.INGRESS_SHOWING_SINCE_MODULE_LOAD_LATENCY, h)))
                    };
                    this.showIncludedServices = function(a, c) {
                        if (c.includedServicesList && 0 < c.includedServicesList.length) {
                            c.includedServicesList.sort();
                            a.find(".sts-bottom-sheet-included-services-number-of-services").html(c.includedServicesNumberOfServicesNoPreviewString);
                            var h = a.find(".sts-bottom-sheet-included-services-popover-trigger"),
                                f = g(".sts-bottom-sheet-included-services-popover-content-template").clone();
                            f.find(".sts-bottom-sheet-included-services-all-providers").html(c.includedServicesAllProviders);
                            var k = g.map(c.includedServicesList, function(a) {
                                var b = document.createElement("li");
                                b.innerHTML = a;
                                return b
                            });
                            f.find(".sts-bottom-sheet-included-services-list").append(k);
                            f = {
                                name: "includedServicesPopover",
                                header: g(".sts-bottom-sheet-included-services-popover-header").prop("outerHTML"),
                                inlineContent: f.prop("outerHTML")
                            };
                            d.declarative.create(h, "a-modal", f);
                            a.find(".sts-bottom-sheet-included-services-container").removeClass("aok-hidden");
                            e.publish(b.INCLUDED_SERVICES_NUMBER_OF_SERVICES, c.includedServicesList.length)
                        }
                    };
                    this.getDefaultOffer = function() {
                        return a.$bottomSheetContainer.find(".sts-bottom-sheet-offer-wrapper:first-of-type")
                    };
                    this.addToCartButtonClick = function(c) {
                        e.publish(b.ATC_CLICK);
                        f.registerBuyboxEventHandlers();
                        a.$addProfessionalServicesRow.is(":visible") ? a.$acceptedOffer ||
                            0 < a.sheetOpenCount || !a.atcSiEnabled ? a.$buyBoxAddToCartButton.click() : (a.bottomSheetObject.show(), d.on("a:sheet:afterHide:ship-to-store-pdp-only-sheet", function() {
                                a.$buyBoxAddToCartButton.click()
                            })) : (a.declineOffer(), a.$buyBoxAddToCartButton.click());
                        return !1
                    };
                    this.addToCartButtonUBBClick = function(c) {
                        e.publish(b.ATC_UBB_CLICK);
                        g("body").undelegate("#add-to-cart-button-ubb-mobile", "click.lsatc");
                        a.$acceptedOffer && a.declineOffer();
                        a.$buyBoxAddToCartUBBButton.click();
                        return !1
                    };
                    this.offeredIngressClick =
                        function(c) {
                            e.publish(b.OFFER_INGRESS_CLICK);
                            a.bottomSheetObject.show();
                            return !1
                        };
                    this.selectedIngressClick = function(c) {
                        e.publish(b.SELECTED_INGRESS_CHANGE_CLICK);
                        a.bottomSheetObject.show();
                        return !1
                    };
                    this.highlightOfferClick = function(c) {
                        e.publish(b.OFFER_SELECTED);
                        a.highlightOffer(g(c.currentTarget))
                    };
                    this.highlightOffer = function(b) {
                        a.$highlightedOffer && a.$highlightedOffer.removeClass("sts-bottom-sheet-offer-selected");
                        a.$highlightedOffer = b;
                        0 < a.$highlightedOffer.length && a.$highlightedOffer.addClass("sts-bottom-sheet-offer-selected");
                        (b = a.shipToStoreModalOffersMap[a.$highlightedOffer.data("upsellAsin")]) && b.length && (a.highlightedOfferData = b.find(function(b) {
                            return b.offerListingId === a.$highlightedOffer.data("offerListingId")
                        }));
                        n.when("vas-common-settings").execute(function(b) {
                            b.setSetting("selectedVasTwisterOption", {
                                offerData: {
                                    offerListingId: a.$highlightedOffer.data("offerListingId"),
                                    merchantId: a.$highlightedOffer.data("merchantId"),
                                    upsellAsin: a.$highlightedOffer.data("upsellAsin")
                                },
                                serviceAsin: a.$highlightedOffer.data("upsellAsin")
                            })
                        })
                    };
                    this.highlightOfferByStoreId = function(b) {
                        a.highlightOffer(a.$bottomSheetContainer.find('[data-sts-ao\x3d"' + b + '"]'))
                    };
                    this.acceptOfferClick = function(c) {
                        e.publish(b.OFFER_ACCEPTED_CLICK);
                        a.acceptOffer();
                        a.bottomSheetObject.hide();
                        return !1
                    };
                    this.acceptOffer = function() {
                        e.publish(b.OFFER_ACCEPTED);
                        a.$acceptedOffer = a.$highlightedOffer;
                        a.$offerSelectedIngress.find("#sts-selected-merchant-name").text(a.$acceptedOffer.find(".sts-merchant-name").text());
                        a.$offerSelectedIngress.find("#sts-selected-display-address").text(a.$acceptedOffer.find(".sts-display-address").text());
                        a.$presentOfferIngress.hide();
                        a.$offerSelectedIngress.show();
                        a.$dummyVASCheckboxForItemAssociation.prop("checked", !0);
                        a.hideQuickPurchaseIngress();
                        a.$ingressSelectedBelowAddress.html(a.$acceptedOffer.find(".sts-localized-price").html());
                        a.setQueryParameters(a.$acceptedOffer)
                    };
                    this.declineOfferClick = function(c) {
                        e.publish(b.OFFER_DECLINED_CLICK);
                        a.declineOffer();
                        a.bottomSheetObject.hide()
                    };
                    this.declineOffer = function() {
                        e.publish(b.OFFER_DECLINED);
                        a.$acceptedOffer = null;
                        a.$presentOfferIngress.show();
                        a.$offerSelectedIngress.hide();
                        a.$dummyVASCheckboxForItemAssociation.prop("checked", !1);
                        a.showQuickPurchaseIngress()
                    };
                    this.beforeSheetShow = function() {
                        if (performance) {
                            performance.mark("ship-to-store-modal-opened");
                            performance.measure(b.MODAL_OPENED_AFTER_MILLISECONDS, "ship-to-store-ingress-start", "ship-to-store-modal-opened");
                            var c = d.map(performance.getEntriesByName(b.MODAL_OPENED_AFTER_MILLISECONDS), function(a) {
                                return a.duration
                            }).shift();
                            c && e.publish(b.MODAL_OPENED_AFTER_MILLISECONDS, c)
                        }
                        d.off("a:sheet:beforeShow:ship-to-store-pdp-only-sheet",
                            a.beforeSheetShow)
                    };
                    this.afterSheetShow = function() {
                        a.sheetOpenCount++;
                        e.publish(b.OFFER_LIST_OPENED);
                        a.bottomSheetObject.$container.height("auto")
                    };
                    this.afterSheetHide = function() {
                        e.publish(b.OFFER_LIST_CLOSED);
                        a.setQueryParameters(a.$acceptedOffer)
                    };
                    this.includedServicesPopoverClick = function() {
                        e.publish(b.INCLUDED_SERVICES_MOBILE_CLICK)
                    };
                    this.setQueryParameters = function(b) {
                        b ? a.queryParam.setParameter("sts-ao", b.data("storeId")) : a.queryParam.removeParameter("sts-ao")
                    };
                    this.changedQuantityEvent = function(c) {
                        e.publish(b.CHANGED_QUANTITY);
                        a.selectedQuantity = c.value;
                        a.generateHTMLTemplatesFromOffers(a.shipToStoreModalOffersMap, a.selectedQuantity);
                        if (a.$acceptedOffer) {
                            c = a.$acceptedOffer.find(".sts-display-address").html();
                            var d = a.shipToStoreModalOffersMap[a.highlightedOfferData.asin];
                            if (d) {
                                for (var h = null, g = 0; g < d.length; g++)
                                    if (d[g].displayAddress === c) {
                                        h = d[g];
                                        break
                                    }
                                h ? (a.highlightOfferByStoreId(h.storeId), a.acceptOffer()) : a.declineOffer()
                            }
                        }
                    };
                    this.toggleZipUpdateVisibilityClick = function(c) {
                        e.publish(b.ZIP_UPDATE_SHOW_CLICK);
                        a.$bottomSheetZipUpdateContainer.is(":visible") ?
                            (e.publish(b.ZIP_UPDATE_HIDE), d.slideUp(a.$bottomSheetZipUpdateContainer, 300, "ease-out")) : (e.publish(b.ZIP_UPDATE_SHOW), d.slideDown(a.$bottomSheetZipUpdateContainer, 300, "ease-out"))
                    };
                    this.updateZipCodeSubmitEventHandler = function(h) {
                        n.when("vas-mobile-utilities").execute(function(f) {
                            e.publish(b.ZIP_UPDATE_HIDE_CLICK);
                            var q = k.getSetting("widgetCommonVM"),
                                l = a.$bottomSheetZipUpdateInput.val();
                            a.$bottomSheetZipUpdateError.addClass("aok-hidden");
                            a.$bottomSheetZipUpdateInvalidZipEntered.addClass("aok-hidden");
                            a.$bottomSheetZipUpdateNoOffers.addClass("aok-hidden");
                            f.validateZipCode(l, a.$vasZipValidationRegex) ? g.get(g(h.target).attr("action"), {
                                a: q.productAsin,
                                z: l,
                                ms: q.mappingSet
                            }).done(function(h) {
                                h && h.length ? (e.publish(b.ZIP_UPDATE_SUCCESS), a.shipToStoreModalOffersMap = c.convertShipToStoreModalOffersListToMap(h), a.generateHTMLTemplatesFromOffers(a.shipToStoreModalOffersMap, a.selectedQuantity), a.$bottomSheetZipUpdateLinks.text(l), d.slideUp(a.$bottomSheetZipUpdateContainer, 300, "ease-out"), a.$bottomSheetZipUpdateInputWrapper.removeClass("a-form-error"),
                                    e.publish(b.OFFERS_ON_ZIP_UPDATE, h.length)) : (e.publish(b.ZIP_UPDATE_NO_OFFERS), a.$bottomSheetZipUpdateInputWrapper.addClass("a-form-error"), a.$bottomSheetZipUpdateNoOffers.removeClass("aok-hidden"), e.publish(b.OFFERS_ON_ZIP_UPDATE, 0))
                            }).error(function() {
                                e.publish(b.ZIP_UPDATE_ERROR);
                                a.$bottomSheetZipUpdateInputWrapper.addClass("a-form-error");
                                a.$bottomSheetZipUpdateError.removeClass("aok-hidden")
                            }) : (e.publish(b.ZIP_UPDATE_INVALID_ZIP_ENTERED), a.$bottomSheetZipUpdateInputWrapper.addClass("a-form-error"),
                                a.$bottomSheetZipUpdateInvalidZipEntered.removeClass("aok-hidden"))
                        });
                        return !1
                    };
                    performance && performance.mark("ship-to-store-ingress-start");
                    n.when("a-sheet", "a-dropdown", "ready").execute(function(f, q) {
                        e.publish(b.INIT);
                        a.$addProfessionalServicesRow = g("#addProfessionalServicesRow");
                        d.isArray(l.stsVM.modalOffers) && l.stsVM.modalOffers.length ? (a.$bottomSheetContainer = g("#sts-pdp-only-sheet"), a.$bottomSheetOffersScrollerContainer = g("#sts-bottom-sheet-offers-scroller-container"), a.$bottomSheetZipUpdateContainer =
                            a.$bottomSheetContainer.find("#sts-pdp-only-sheet-zip-updater-container"), a.$bottomSheetZipUpdateError = g("#sts-pdp-only-zip-update-error"), a.$bottomSheetZipUpdateInput = g("#sts-pdp-only-sheet-zip-update-input"), a.$bottomSheetZipUpdateInputWrapper = g("#sts-pdp-only-sheet-zip-update-input-wrapper"), a.$bottomSheetZipUpdateInvalidZipEntered = g("#sts-pdp-only-zip-update-invalid-zip-entered"), a.$bottomSheetZipUpdateLinks = g(".sts-pdp-only-sheet-zip-update-link"), a.$bottomSheetZipUpdateNoOffers = g("#sts-pdp-only-zip-update-no-offers"),
                            a.$buyBoxAddToCartButton = g("#add-to-cart-button"), a.$buyBoxAddToCartUBBButton = g("#add-to-cart-button-ubb-mobile"), a.$buyBoxOneClickButtonContainer = g("#oneClickBuy").parent(), a.$buyNowButtonContainer = g("#buyNow").parent(), a.$buyNowFeature = g("#buyNow_feature_div"), a.$dummyVASCheckboxForItemAssociation = g("#vas-checkbox-input"), a.$ingressSelectedBelowAddress = g("#sts-selected-service-below-address"), a.$offeredIngressBelowButton = g("#sts-offered-below-button"), a.$offerSelectedIngress = g("#sts-installation-selected"),
                            a.$presentOfferIngress = g("#sts-installation-offered"), a.$shipToStoreModalOfferPriceTemplate = g("#sts-bottom-sheet-offer-price-template"), a.$shipToStoreModalOfferTemplate = g("#sts-bottom-sheet-offer-wrapper-template"), a.$vasZipValidationRegex = g("#vas-zipCodeValidationRegexString"), q = q.getSelect("mobileQuantityDropDown"), a.selectedQuantity = q ? q.val() : 1, a.includedServicesEnabled = l.stsVM.includedServicesEnabled, a.atcSiEnabled = l.stsVM.atcSiEnabled, a.sheetOpenCount = 0, e.publish(b.OFFERS_ON_PAGE_LOAD, l.stsVM.modalOffers.length),
                            a.shipToStoreModalOffersMap = c.convertShipToStoreModalOffersListToMap(l.stsVM.modalOffers), a.bottomSheetObject = f.create({
                                name: "ship-to-store-pdp-only-sheet",
                                preloadDomId: "sts-pdp-only-sheet",
                                sheetType: "web"
                            }), a.generateHTMLTemplatesFromOffers(a.shipToStoreModalOffersMap, a.selectedQuantity), d.on("a:sheet:beforeShow:ship-to-store-pdp-only-sheet", a.beforeSheetShow), d.on("a:sheet:afterShow:ship-to-store-pdp-only-sheet", a.afterSheetShow), d.on("a:sheet:afterHide:ship-to-store-pdp-only-sheet", a.afterSheetHide),
                            d.on("a:dropdown:mobileQuantityDropDown:select", a.changedQuantityEvent), a.queryParam = new h, a.queryParam.parameterExists("sts-ao") ? (a.highlightOfferByStoreId(a.queryParam.getParameter("sts-ao")), 0 === a.$highlightedOffer.length ? (e.publish(b.PAGE_RELOAD_OFFER_NOT_FOUND), a.highlightOffer(a.getDefaultOffer())) : (e.publish(b.PAGE_RELOAD_OFFER_FOUND), a.acceptOffer())) : e.publish(b.PAGE_RELOAD_OFFER_NOT_SPECIFIED), g("body").delegate("#sts-select-button", "click", a.offeredIngressClick).delegate("#sts-change-installation",
                                "click", a.selectedIngressClick).delegate(".sts-bottom-sheet-accept-offer", "click", a.acceptOfferClick).delegate(".sts-bottom-sheet-offer-wrapper", "click", a.highlightOfferClick).delegate(".sts-bottom-sheet-decline-offer", "click", a.declineOfferClick).delegate(".sts-bottom-sheet-included-services-popover-trigger", "click", a.includedServicesPopoverClick).delegate(".sts-pdp-only-sheet-zip-update-link", "click", a.toggleZipUpdateVisibilityClick).delegate("#sts-pdp-only-sheet-zip-update-form", "submit", a.updateZipCodeSubmitEventHandler).undelegate("#add-to-cart-button",
                                "click.lsatc").delegate("#add-to-cart-button", "click.lsatc", a.addToCartButtonClick).undelegate("#add-to-cart-button-ubb-mobile", "click.lsatc").delegate("#add-to-cart-button-ubb-mobile", "click.lsatc", a.addToCartButtonUBBClick).delegate("#sts-pdp-only-above-price a", "click", function(a) {
                                a = g(g(a.target).attr("href"));
                                a.length && (a = a.offset().top + a.height() / 2 - g(p).height() / 2, g("html, body").animate({
                                    scrollTop: a
                                }, 300));
                                return !1
                            })) : (e.publish(b.NO_OFFERS_ON_PAGE_LOAD), e.publish(b.OFFERS_ON_PAGE_LOAD, 0), a.$addProfessionalServicesRow.hide())
                    })
                }
                t(c, null, [{
                    key: "convertShipToStoreModalOffersListToMap",
                    value: function(a) {
                        var b = {},
                            c = void 0;
                        a && d.each(a, function(a) {
                            c = a.asin;
                            b.hasOwnProperty(c) || (b[c] = []);
                            b[c].push(a)
                        });
                        return b
                    }
                }]);
                return c
            }())
        })
    });
    "use strict";
    "use strict";
    "use strict";
    n.register("ship-to-store-metric-names", function() {
        return {
            ATC_CLICK: "add_to_cart_button_click",
            ATC_CLICK_SI_DISABLED: "add_to_cart_button_click_si_disabled",
            ATC_UBB_CLICK: "add_to_cart_ubb_button_click",
            CHANGED_QUANTITY: "changed_quantity_event",
            INCLUDED_SERVICES_DESKTOP_HOVER: "included_services_desktop_hover",
            INCLUDED_SERVICES_MOBILE_CLICK: "included_services_mobile_click",
            INCLUDED_SERVICES_NUMBER_OF_SERVICES: "included-services-number-of-services",
            INIT: "init",
            INGRESS_SHOWING_SINCE_PAGE_LOAD_LATENCY: "ingress-showing-since-page-load-latency",
            INGRESS_SHOWING_SINCE_MODULE_LOAD_LATENCY: "ingress-showing-since-module-load-latency",
            LOADED: "loaded",
            MODAL_OPENED_AFTER_MILLISECONDS: "modal_opened_after_milliseconds",
            NO_ACTIVE_OFFER_TYPE: "no_active_offer_type",
            NO_OFFERS_ON_PAGE_LOAD: "no_offers_on_page_load",
            OFFER_ACCEPTED: "offer_accepted",
            OFFER_ACCEPTED_CLICK: "offer_accepted_click",
            OFFER_DECLINED: "offer_declined",
            OFFER_DECLINED_CLICK: "offer_declined_click",
            OFFER_INGRESS_CLICK: "offer_ingress_click",
            OFFER_INGRESS_CLICK_MODAL_NOT_READY: "offer_ingress_click_modal_not_ready",
            OFFER_LIST_CLOSED: "offer_list_closed",
            OFFER_LIST_OPENED: "offer_list_opened",
            OFFER_SELECTED: "offer_selected",
            OFFERS_GENERATED: "offers_generated",
            OFFERS_ON_PAGE_LOAD: "offers_on_page_load",
            OFFERS_ON_ZIP_UPDATE: "offers_on_zip_update",
            PAGE_RELOAD_OFFER_FOUND: "page_reload_offer_found",
            PAGE_RELOAD_OFFER_NOT_FOUND: "page_reload_offer_not_found",
            PAGE_RELOAD_OFFER_NOT_SPECIFIED: "page_reload_offer_not_specified",
            SELECTED_INGRESS_CHANGE_CLICK: "selected_ingress_change_click",
            SELECTED_INGRESS_CHANGE_CLICK_MODAL_NOT_READY: "selected_ingress_change_click_modal_not_ready",
            SELECTED_QTY_MAPPED_TO_ASIN_W_OFFERS: "selected_quantity_mapped_to_asin_with_offers",
            SELECTED_QTY_MAPPED_TO_ASIN_WO_OFFERS: "selected_quantity_mapped_to_asin_with_no_offers",
            SELECTED_QTY_NOT_MAPPED_TO_ASIN: "selected_quantity_not_mapped_to_asin",
            ZIP_UPDATE_ERROR: "zip_update_error",
            ZIP_UPDATE_HIDE: "zip_update_hide",
            ZIP_UPDATE_HIDE_CLICK: "zip_update_hide_click",
            ZIP_UPDATE_INVALID_ZIP_ENTERED: "zip_update_invalid_zip_entered",
            ZIP_UPDATE_NO_OFFERS: "zip_update_no_offers",
            ZIP_UPDATE_SHOW: "zip_update_show",
            ZIP_UPDATE_SHOW_CLICK: "zip_update_show_click",
            ZIP_UPDATE_SUCCESS: "zip_update_success"
        }
    });
    "use strict";
    n.when("jQuery", "ship-to-store-settings", "ship-to-store-function", "query-param").register("ship-to-store-metric-publisher", function(f, k, l, d) {
        return function b(h) {
            var q =
                this;
            m(this, b);
            this.logError = function(b) {
                l.try(function() {
                    p.ueLogError(b, {
                        logLevel: "ERROR",
                        attribution: k.get("attribution")
                    })
                })
            };
            this.logRefTag = function(b) {
                var h = 1 < arguments.length && arguments[1] !== r ? arguments[1] : {};
                f.get("/gp/ls/impress.html/ref\x3d" + encodeURIComponent(b) + "?" + d.createQueryStringFromObject(h))
            };
            this.publish = function(b) {
                var h = 1 < arguments.length && arguments[1] !== r ? arguments[1] : 1;
                b = "" + q.refTagPrefix + b;
                l.try(function() {
                    p.ue.count("" + b, h)
                })
            };
            this.tag = function(b) {
                l.try(function() {
                    p.ue.tag(b)
                })
            };
            this.refTagPrefix = h
        }
    });
    "use strict";
    "use strict";
    "use strict";
    n.when("A", "vas-common-settings", "ready").register("ship-to-store-settings", function(f, k) {
        var l = f.$,
            d = {
                stsVM: {}
            },
            c = function h() {
                m(this, h)
            };
        c.setWidgetsMetaData = function(h) {
            k.clearSettings();
            f.each(c.parseWidgetsMetaData(h), function(c, h) {
                k.setSetting(h, c)
            })
        };
        c.parseWidgetsMetaData = function(c) {
            c = c || l("body");
            return {
                winningWidgetVM: f.parseJSON(c.find("[data-a-state*\x3dvas-winning-widget-vm]").html()),
                widgetCommonVM: f.parseJSON(c.find("[data-a-state*\x3dvas-common-vm]").html())
            }
        };
        c.logWidgetLoadMetrics = function() {
            p.ue && p.ue.tag && d.stsVM && (d.stsVM.isPdpOnlyExperience ? p.ue.tag("pdpOnlyShipToStoreWidget") : d.stsVM.isParentServiceAsin ? p.ue.tag("psaIngressWidget") : d.stsVM.isShipToStore && p.ue.tag("pdpShipToStoreWidget"))
        };
        c.fetch = function() {
            c.setWidgetsMetaData();
            d = c.createSettingsFromWinningWidgetVM();
            c.logWidgetLoadMetrics();
            return c.get()
        };
        c.createSettingsFromWinningWidgetVM = function(c) {
            var d = {};
            d.stsVM = c || k.getSetting("winningWidgetVM");
            if (!d.stsVM) return d;
            d.productAsin = d.stsVM.productAsin;
            d.zipCode = d.stsVM.zipCode;
            d.buyboxPrice = d.stsVM.buyboxPrice;
            d.refTagPrefix = "stsPdpOnly" === d.stsVM.winningWidgetName ? "vas_sts_pdp_only_" : d.stsVM.isParentServiceAsin ? "vas_psa_" : d.stsVM.isShipToStore ? "vas_sts_" : d.stsVM.isSdpOfferSelected ? "vas_sdp_offer_" : "vas_";
            return d
        };
        c.get = function(c) {
            return d.hasOwnProperty(c) ? d[c] : d
        };
        c.set = function(c, f, e) {
            c && e ? d[c][e] = f : d[c] = f
        };
        return c
    });
    "use strict";
    n.when("ship-to-store-settings", "3p-promise").register("ship-to-store-function", function(f, k) {
        var l = function c() {
            m(this,
                c)
        };
        l.try = function(c) {
            return (new k(function(b, h) {
                c(b, h)
            })).catch(function(b) {
                n.when("ship-to-store-metric-publisher").execute(function(c) {
                    c.logError(b, f.get("attribution"))
                });
                throw b;
            })
        };
        return l
    });
    "use strict";
    "use strict";
    var u = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(f) {
        return typeof f
    } : function(f) {
        return f && "function" === typeof Symbol && f.constructor === Symbol && f !== Symbol.prototype ? "symbol" : typeof f
    };
    n.when("a-util").register("query-param", function(f) {
        var k = function d() {
            var c =
                this;
            m(this, d);
            this._queryString = "";
            this._parameters = {};
            this.getParameters = function() {
                var b = d._getQueryStringFromBrowser();
                if (b === c._queryString) return c._parameters;
                c._queryString = b;
                c._queryString.slice(1).split("\x26").map(function(b) {
                    b = b.split("\x3d");
                    if (b.length && b[0].length) {
                        var d = decodeURIComponent(b[0]);
                        switch (b.length) {
                            case 2:
                                c._parameters[d] = decodeURIComponent(b[1]);
                                break;
                            case 1:
                                c._parameters[d] = null
                        }
                    }
                });
                return c._parameters
            };
            this.getParameter = function(b) {
                return c.getParameters()[b]
            };
            this.parameterExists =
                function(b) {
                    return c.getParameters().hasOwnProperty(b)
                };
            this.setParameters = function(b) {
                if ("object" !== ("undefined" === typeof b ? "undefined" : u(b)) || f.isArray(b)) return !1;
                c._queryString = "?" + d.createQueryStringFromObject(b);
                d._setQueryStringOnBrowser(c._queryString);
                return c
            };
            this.setParameter = function(b, d) {
                if (!b || !b.length) return !1;
                var f = c.getParameters();
                f[b] = d;
                return c.setParameters(f)
            };
            this.removeParameter = function(b) {
                if (!b || !b.length) return !1;
                var d = c.getParameters();
                delete d[b];
                return c.setParameters(d)
            };
            this.getQueryString = function() {
                return c._queryString
            }
        };
        k.createQueryStringFromObject = function(d) {
            var c = [];
            Object.keys(d).forEach(function(b) {
                if (!d.hasOwnProperty(b) || "" === b || "" === d[b]) return !1;
                c.push(encodeURIComponent(b) + "\x3d" + encodeURIComponent(d[b]))
            });
            return c.join("\x26")
        };
        k._getQueryStringFromBrowser = function() {
            return location.search.valueOf()
        };
        k._setQueryStringOnBrowser = function(d) {
            "function" === typeof history.replaceState ? history.replaceState({}, document.title, d) : location.search = d
        };
        return k
    });
    "use strict";
    "use strict"
});
/* ******** */
(function(n) {
    var p = window.AmazonUIPageJS || window.P,
        x = p._namespace || p.attributeErrors,
        a = x ? x("DetailPageAlohaAssets", "") : p;
    a.guardFatal ? a.guardFatal(n)(a, window) : a.execute(function() {
        n(a, window)
    })
})(function(n, p, x) {
    n.when("A", "a-secondary-view", "a-checkbox", "aloha-simplebundle-common", "ready").execute(function(a, k, d, f) {
        function c(f, c) {
            a.$(e.SB_ROOT + " " + e.SB_CHECKBOX).filter(function() {
                return a.$(this).data("asin") === f
            }).find("input[type\x3d'checkbox']").prop("checked", c).change()
        }

        function b(a) {
            (a = k.get("SBPopover_" +
                a)) && a.hide()
        }

        function h() {
            var f = a.$(e.BUY_BOX).find(e.A_DECLARATIVE).has(e.ADD_TO_CART_BUTTON);
            return 1 === f.length ? f : f = a.$(e.ATC_DECLARATIVE)
        }

        function g(f) {
            function e() {
                f.logExpandedLink()
            }
            a.declarative("add-to-order", "click", function(a) {
                c(a.data.targetAsin, !0);
                b(a.data.targetAsin)
            });
            a.declarative("hide-secondary-view", "click", function(a) {
                c(a.data.targetAsin, !1);
                b(a.data.targetAsin)
            });
            a.on("a:popover:afterShow:modal-expanded-items", e);
            a.one("a:pageUpdate", function() {
                a.off("a:popover:afterShow:modal-expanded-items",
                    e)
            })
        }
        var e = {
                ADD_TO_CART_FORM: "#addToCart, #mobile-installments",
                ADD_TO_CART_BUTTON: "#add-to-cart-button, #installments-button",
                SESSION_ID: "#verificationSessionID",
                ATC_DECLARATIVE: "#atc-declarative",
                A_DECLARATIVE: ".a-declarative",
                BUY_BOX: "#buybox",
                INPUT_TYPE_CHECKBOX: "input[type\x3d'checkbox']",
                BASE_PRODUCT_PRICE: "#base-product-price",
                BASE_PRODUCT_PRICE_DATA: "base-product-price",
                ACCORDION_BUYBOX: "#buyBoxAccordion",
                ACCORDION_BUYBOX_ROW_CONTENT: "#buyBoxAccordion .accordion-row-content",
                SB_ROOT: ".showBundleAsins.simpleBundleFeatureContainer",
                SB_DETAILS_LINK_PREFIX: ".sb-touch-link-",
                SB_CHECKBOX: ".sb-checkbox",
                SB_BUYBOX_CHECKBOX_PREFIX: ".sb-buybox-item-checkbox-",
                SB_EXPANDED_CHECKBOX_PREFIX: ".sb-expanded-item-checkbox-",
                SB_BUYBOX_CHECKBOX_CONTAINER_PREFIX: ".sb-buybox-item-section-",
                SB_EXPANDED_CHECKBOX_CONTAINER_PREFIX: ".sb-buybox-item-container-"
            },
            q = !1;
        d = a.debounce(function() {
            var c = a.$(e.SB_ROOT);
            if (c.length) {
                var b = a.$(e.ADD_TO_CART_FORM),
                    d = 0 < b.find(":submit").length,
                    k = a.$(e.ADD_TO_CART_BUTTON),
                    m = h(),
                    B = (m = m.data("aw-mash") || m.data("show-services-interstitial") ||
                        m.data("show-attach-interstitial") || m.data("show-hctp-attach")) && m.inputs && m.inputs.verificationSessionID;
                if (d || m) {
                    var z = f.getSimpleBundlePageState() || {},
                        G = z.selectionMode || "SINGLE",
                        y = z.items || [],
                        A = [],
                        C = B || a.$(e.SESSION_ID).val(),
                        d = {
                            baseAsin: z.baseAsin,
                            baseItemPrice: a.$(e.BASE_PRODUCT_PRICE).data(e.BASE_PRODUCT_PRICE_DATA),
                            clientType: "aloha-simplebundle-mobile",
                            currencyOfPreferenceSupported: z.currencyOfPreferenceSupported || !1
                        },
                        t = f.createMetricsLogger(d);
                    g(t);
                    y = y.slice(0, z.maxBuyboxItemsMobile);
                    y.forEach(function(a,
                        b) {
                        var d = c.find(e.SB_DETAILS_LINK_PREFIX + b);
                        d.unbind("click.MiniDpClickHandler");
                        d.bind("click.MiniDpClickHandler", function() {
                            t.logItemLink(b);
                            t.logNexusOpenMiniDP(b, a);
                            t.logMiniDPRefTag(b)
                        });
                        f.setupCheckboxes(A, b, a, z.maxBuyboxItemsMobile, e.SB_BUYBOX_CHECKBOX_PREFIX + b + " " + e.INPUT_TYPE_CHECKBOX, e.SB_EXPANDED_CHECKBOX_PREFIX + b + " " + e.INPUT_TYPE_CHECKBOX, e.SB_BUYBOX_CHECKBOX_CONTAINER_PREFIX + b, e.SB_EXPANDED_CHECKBOX_CONTAINER_PREFIX + b, G)
                    });
                    q || (q = !0, a.defer(function() {
                        var a = y.filter(function(a, l) {
                            return A[l] &&
                                A[l].isVisible()
                        });
                        t.logNexusImpression(a);
                        t.logImpressionRefTag()
                    }));
                    m ? k.each(function() {
                        var l = a.$(this),
                            b;
                        b = a.$(e.ACCORDION_BUYBOX).length ? l.closest(e.ACCORDION_BUYBOX_ROW_CONTENT) : a.$(e.BUY_BOX);
                        f.setupAddToCartForDeclarative(l, A, y, t, C, b)
                    }) : f.setupAddToCart(b, A, y, t, C);
                    b = a.$("#buyNowCheckout");
                    f.setupAddToCart(b, A, y, t, C)
                } else c.hide()
            }
        }, 200);
        d();
        a.on("a:pageUpdate", d)
    });
    "use strict";
    n.when("A", "a-checkbox", "aloha-uatc", "aloha-buy-now-integration", "aloha-buybox-form-util", "aloha-buy-back-integration",
        "abb-buynow-api").register("aloha-simplebundle-common", function(a, k, d, f, c, b, h) {
        function g(b, f) {
            var c = a.$(b);
            c.change(function() {
                c.prop("checked", this.checked);
                var a = {
                    asin: c.data("asin"),
                    offeringID: c.data("offeringID"),
                    quantity: c.data("quantity")
                };
                this.checked ? (h.addFormParams("#buyNow", a), h.addFormParams("#buyBackBuyNow", a), h.addFormParams("#buyNowCheckout", a)) : (h.removeFormParams("#buyNow", a), h.removeFormParams("#buyBackBuyNow", a), h.removeFormParams("#buyNowCheckout", a))
            });
            var d = a.$(f);
            d.length ||
                (d = c);
            return {
                $element: c,
                $container: d,
                api: k(b),
                show: function() {
                    d.hasClass(m.AUI_HIDDEN) && d.removeClass(m.AUI_HIDDEN);
                    d.show()
                },
                hide: function() {
                    d.hasClass(m.AUI_HIDDEN) || d.addClass(m.AUI_HIDDEN)
                },
                isVisible: function() {
                    return !d.hasClass(m.AUI_HIDDEN)
                }
            }
        }

        function e(a, b, c) {
            b.forEach(function(b) {
                a.addItem(b.asin, b.offerListingId, b.quantity);
                c.logCheckboxSelected(b.index, b.quantity);
                c.logAddToCartRefTag(b.index)
            })
        }

        function q(a, b, c) {
            var d = [],
                f = [];
            b.forEach(function(b, e) {
                var l = a[e];
                b.api.isChecked() ? d.push({
                    asin: l.asin,
                    offerListingId: l.offerListingId,
                    ourPrice: l.ourPrice,
                    ourPriceAmount: l.ourPriceAmount,
                    ourPriceSymbol: l.ourPriceSymbol,
                    ourPriceCode: l.ourPriceCode,
                    index: e,
                    quantity: c
                }) : f.push({
                    asin: l.asin,
                    ourPrice: l.ourPrice,
                    ourPriceAmount: l.ourPriceAmount,
                    ourPriceSymbol: l.ourPriceSymbol,
                    ourPriceCode: l.ourPriceCode,
                    index: e,
                    isVisible: b.isVisible()
                })
            });
            return {
                selectedLineItems: d,
                unselectedItems: f
            }
        }
        var x = /[^\d,\.]/g,
            D = /,/g,
            E = /\./g,
            F = /(^\D+|\D+$)/,
            m = {
                AUI_HIDDEN: "aok-hidden"
            };
        return {
            createMetricsLogger: function(b) {
                function c(a,
                    b) {
                    p.ue && p.ue.count && p.ue.count("aloha-simplebundle-" + a, b)
                }

                function d() {
                    var a;
                    a = b.currencyOfPreferenceSupported ? {
                        priceFormatted: b.baseItemPrice,
                        priceDecimal: null,
                        currencySymbol: null
                    } : h(b.baseItemPrice);
                    return {
                        baseAsin: b.baseAsin,
                        baseItemPrice: a.priceFormatted,
                        baseItemCurrencySymbol: a.currencySymbol,
                        baseItemPriceDecimal: a.priceDecimal,
                        clientType: b.clientType,
                        feature: "abb"
                    }
                }

                function f(a, b) {
                    p.ue && p.ue.event && p.ue.event(a, "atch", b)
                }

                function e(b) {
                    a.ajax("/gp/product/ajax-handlers/reftag.html?ref_\x3d" +
                        b, {
                            method: "get"
                        })
                }

                function g(a) {
                    return b.currencyOfPreferenceSupported ? {
                        priceFormatted: a.ourPrice,
                        priceDecimal: parseFloat(a.ourPriceAmount) || null,
                        currencySymbol: a.ourPriceSymbol
                    } : h(a.ourPrice)
                }

                function h(a) {
                    a = a || "";
                    var b = a.lastIndexOf(","),
                        c = a.lastIndexOf("."),
                        d;
                    b > c ? (c = E, d = D) : (c = D, d = E);
                    (b = a.match(F)) && (b = b[0].trim());
                    c = a.replace(x, "").replace(c, "").replace(d, ".");
                    c = parseFloat(c);
                    return {
                        priceFormatted: a,
                        currencySymbol: b,
                        priceDecimal: c
                    }
                }
                a.defer(function() {
                    c("view", 1)
                });
                return {
                    logAddToCart: function(a) {
                        c("addtocart",
                            a)
                    },
                    logExpandedLink: function() {
                        c("buybox-expanded-link", 1)
                    },
                    logCheckboxSelected: function(a, b) {
                        c("checkbox-" + (a + 1), b)
                    },
                    logItemLink: function(a) {
                        c("link-" + (a + 1), 1)
                    },
                    logImpressionRefTag: function() {
                        e("dp_atch_abb_i")
                    },
                    logAddToCartRefTag: function(a) {
                        e("dp_atch_abb_atc_" + (a + 1))
                    },
                    logMiniDPRefTag: function(a) {
                        e("dp_atch_abb_smdp_" + (a + 1))
                    },
                    logNexusImpression: function(a) {
                        var b = d();
                        b.accessories = a.map(function(a, b) {
                            var c = g(a);
                            return {
                                asin: a.asin,
                                displayPosition: b + 1,
                                price: c.priceFormatted,
                                currencySymbol: c.currencySymbol,
                                priceDecimal: c.priceDecimal
                            }
                        });
                        f(b, "attach.ABBImpression.3")
                    },
                    logNexusAddBaseToCart: function(a, b, c) {
                        var e = d();
                        e.baseQuantity = Number(c);
                        e.accessoriesAdded = a.map(function(a) {
                            var b = g(a);
                            return {
                                asin: a.asin,
                                displayPosition: a.index + 1,
                                quantity: Number(a.quantity),
                                price: b.priceFormatted,
                                currencySymbol: b.currencySymbol,
                                priceDecimal: b.priceDecimal
                            }
                        });
                        e.accessoriesNotAdded = b.map(function(a) {
                            var b = g(a);
                            return {
                                asin: a.asin,
                                displayPosition: a.index + 1,
                                price: b.priceFormatted,
                                currencySymbol: b.currencySymbol,
                                priceDecimal: b.priceDecimal
                            }
                        });
                        f(e, "attach.ABBAddBaseToCart.7")
                    },
                    logNexusOpenMiniDP: function(a, b) {
                        var c = g(b),
                            e = d();
                        e.accessoryAsin = b.asin;
                        e.accessoryDisplayPosition = Number(a) + 1;
                        e.accessoryPrice = c.priceFormatted;
                        e.accessoryItemCurrencySymbol = c.currencySymbol;
                        e.accessoryItemPriceDecimal = c.priceDecimal;
                        f(e, "attach.ABBShowMiniDP.3")
                    }
                }
            },
            getSimpleBundlePageState: function() {
                var b = a.$(".simpleBundleJavascriptParameters").find("script").html();
                return a.parseJSON(b)
            },
            getCheckboxCollectionObject: g,
            setupAddToCart: function(c, g, h, k, m) {
                function n(c,
                    r) {
                    if (t) {
                        var u = a.$(c.currentTarget);
                        if (f.isBuyNow(u)) {
                            var v = l.find("*[name\x3d'quantity']").val() || 1,
                                w = q(h, g, v);
                            f.checkoutWith(w.selectedLineItems, u)
                        } else if (b.isBuyBack(u)) v = l.find("*[name\x3d'quantity']").val() || 1, w = q(h, g, v), b.checkoutWith(w.selectedLineItems, u);
                        else return
                    }
                    var B = d.createAddToCartRequest(m, function() {
                            r()
                        }, function() {
                            p.ueLogError && p.ueLogError({
                                message: "[There was an error while adding items to the cart using the universal add to cart api.]"
                            }, {
                                logLevel: "ERROR",
                                attribution: "SimpleBundle"
                            });
                            r()
                        }),
                        v = l.find("*[name\x3d'quantity']").val() || 1,
                        w = q(h, g, v);
                    e(B, w.selectedLineItems, k);
                    u = w.unselectedItems.filter(function(a) {
                        return a.isVisible
                    });
                    k.logNexusAddBaseToCart(w.selectedLineItems, u, v);
                    v = B.count();
                    0 !== v && (u = a.$(c.currentTarget), f.isBuyNow(u) ? f.checkoutWith(w.selectedLineItems, u) : b.isBuyBack(u) ? b.checkoutWith(w.selectedLineItems, u) : (t = !0, c.preventDefault(), k.logAddToCart(v), B.call()))
                }
                var t = !1,
                    l = c;
                c.unbind("submit.SimpleBundleSubmitHandler");
                c.bind("submit.SimpleBundleSubmitHandler", function(b) {
                    var c =
                        a.$(this);
                    n(b, function() {
                        c.submit()
                    })
                });
                c.find(":submit").unbind("click.SBB");
                c.find(":submit").bind("click.SBB", function(b) {
                    var d = a.$(this),
                        e = d.closest(".a-accordion-row-container");
                    e.length && (l = e, "addToCart" !== c.attr("id") && "buyNow" !== c.attr("id") || c.unbind("submit.SimpleBundleSubmitHandler"), n(b, function() {
                        d.click()
                    }))
                })
            },
            setupAddToCartForDeclarative: function(a, b, c, f, g, h) {
                a.unbind("click.SimpleBundleClickHandler");
                a.bind("click.SimpleBundleClickHandler", function(a) {
                    a = d.createAddToCartRequest(g,
                        function() {
                            n.now("attach-external-atc-interceptor").execute(function(a) {
                                a && k.selectedLineItems.forEach(function(b) {
                                    a.updateAttachModule(b.asin)
                                })
                            })
                        },
                        function() {
                            p.ueLogError && p.ueLogError({
                                message: "[There was an error while adding items to the cart using the universal add to cart api.]"
                            }, {
                                logLevel: "ERROR",
                                attribution: "SimpleBundle"
                            })
                        });
                    var l = h.find("*[name\x3d'quantity']").val() || 1,
                        k = q(c, b, l);
                    e(a, k.selectedLineItems, f);
                    var r = k.unselectedItems.filter(function(a) {
                        return a.isVisible
                    });
                    f.logNexusAddBaseToCart(k.selectedLineItems,
                        r, l);
                    if (l = a.count()) f.logAddToCart(l), a.call()
                })
            },
            setupCheckboxes: function(b, c, d, e, f, h, k, l, q) {
                var r = g(f, k);
                b.push(r);
                r.api.enable();
                r.$element.data("asin", d.asin);
                r.$element.data("offeringID", d.offerListingId);
                r.$element.data("quantity", 1);
                a.on("a:dropdown:mobileQuantityDropDown:select", function(a) {
                    r.$element.data("quantity", a.value)
                });
                a.on("a2idpx:buyback:discount-price", function(a) {
                    r.$element.change()
                });
                "SINGLE" === q && r.$element.change(function() {
                    r.api.isChecked() && b.forEach(function(a, b) {
                        c !== b &&
                            a.api.uncheck()
                    })
                })
            },
            setupAddToCartForButton: function(b, d, e, f, g, h) {
                function k() {
                    var a = l.find("*[name\x3d'quantity']").val() || 1,
                        b = q(e, d, a);
                    c.addItems(h, b.selectedLineItems, f);
                    var g = b.unselectedItems.filter(function(a) {
                        return a.isVisible
                    });
                    n.now("attach-external-atc-interceptor").execute(function(a) {
                        a && b.selectedLineItems.forEach(function(b) {
                            a.updateAttachModule(b.asin)
                        })
                    });
                    f.logNexusAddBaseToCart(b.selectedLineItems, g, a);
                    f.logAddToCart(b.selectedLineItems.length)
                }
                var l = h;
                b.unbind("click.button.SBB");
                b.bind("click.button.SBB", function() {
                    var b = a.$(this).closest(".a-accordion-row-container");
                    b.length && (l = b);
                    k()
                })
            }
        }
    });
    n.when("A", "ready").register("abb-buynow-api", function(a) {
        var k = function(d) {
            return a.$(d + " \x3e input[name\x3dofferingID]")
        };
        return {
            addFormParams: function(d, f) {
                var c = a.$(d + " \x3e input[name\x3dasin]"),
                    b = k(d);
                d = a.$(d + " \x3e input[name\x3dquantity]");
                if ((c = a.$(c)) && 0 !== c.length && c.val() && -1 === c.val().indexOf(f.asin) && a.$(d) && 0 !== a.$(d).length && a.$(d).val() && a.$(b) && 0 !== a.$(b).length &&
                    a.$(b).val()) {
                    var h = c.val() + "|" + f.asin,
                        g = a.$(b).val() + "|" + f.offeringID;
                    f = a.$(d).val() + "|" + f.quantity;
                    c.val(h);
                    a.$(b).val(g);
                    a.$(d).val(f)
                }
            },
            removeFormParams: function(d, f) {
                var c = a.$(d + " \x3e input[name\x3dasin]"),
                    b = k(d);
                d = a.$(d + " \x3e input[name\x3dquantity]");
                if ((c = a.$(c)) && 0 !== c.length && c.val() && -1 !== c.val().indexOf(f.asin) && a.$(d) && 0 !== a.$(d).length && a.$(d).val() && a.$(b) && 0 !== a.$(b).length && a.$(b).val()) {
                    var h = c.val().split("|");
                    f = h.indexOf(f.asin);
                    h.splice(f, 1);
                    c.val(h.join("|"));
                    c = a.$(b).val().split("|");
                    c.splice(f, 1);
                    a.$(b).val(c.join("|"));
                    b = a.$(d).val().split("|");
                    b.splice(f, 1);
                    a.$(d).val(b.join("|"))
                }
            }
        }
    });
    "use strict";
    n.when("A").register("aloha-uatc", function(a) {
        function k(d, f, c, b, h) {
            var g = 0;
            h = h || 5E3;
            b = b || c;
            var e = {
                clientName: "AmazonWireless"
            };
            e.verificationSessionID = d;
            return {
                count: function() {
                    return g
                },
                call: function() {
                    g && a.post("/gp/add-to-cart/json", {
                        timeout: h,
                        params: e,
                        success: f,
                        error: c,
                        abort: b
                    })
                },
                addItem: function(a, b, c) {
                    e["ASIN." + g] = a;
                    e["offerListingID." + g] = b;
                    e["quantity." + g] = c || 1;
                    g++
                }
            }
        }
        return {
            createAddToCartRequest: k,
            createSingleFinalCallbackAddToCartRequest: function(a, f) {
                return k(a, f, f, f)
            }
        }
    });
    "use strict";
    n.when("A").register("aloha-buy-now-integration", function(a) {
        var k = a.$,
            d = {};
        n.when("turbo-checkout-buy-now-integration").execute(function(a) {
            d = a
        });
        return {
            isBuyNow: function(a) {
                return 0 === Object.entries(d).length && d.constructor === Object ? "buy-now-button" === a.attr("id") || "addToCart" === a.attr("id") : "function" === typeof d.isBuyNow && d.isBuyNow(a) || "buy-now-button" === a.attr("id")
            },
            checkoutWith: function(a, c) {
                if (0 === Object.entries(d).length &&
                    d.constructor === Object) {
                    var b;
                    for (b = 1; 0 < c.find('input[name\x3d"asin.' + b + '"]').length || 0 < c.find('input[name\x3d"offeringID.' + b + '"]').length;) b++;
                    for (var h = [], g = 0; g < a.length; g++) {
                        var e = a[g];
                        if (e !== x && e.asin && e.offerListingId) {
                            var q = b,
                                e = [k("\x3cinput /\x3e", {
                                    type: "hidden",
                                    name: "asin." + q,
                                    value: e.asin
                                }), k("\x3cinput /\x3e", {
                                    type: "hidden",
                                    name: "offeringID." + q,
                                    value: e.offerListingId
                                }), k("\x3cinput /\x3e", {
                                    type: "hidden",
                                    name: "quantity." + q,
                                    value: e.quantity || 1
                                })];
                            Array.prototype.push.apply(h, e);
                            b++
                        } else logError('Line item inputs are invalid. Expected "asin" and "offerListingId" keys in object. Customer purchase inputs ignored!',
                            e)
                    }
                    a = c.find('input[name\x3d"itemCount"]');
                    1 === a.length ? a.val(b) : c.append(k("\x3cinput /\x3e", {
                        type: "hidden",
                        name: "itemCount",
                        value: b
                    }));
                    c.append.apply(c, h)
                } else return d.checkoutWith(a, c)
            }
        }
    });
    "use strict";
    n.when("A").register("aloha-buy-back-integration", function(a) {
        var k = a.$;
        return {
            isBuyBack: function(a) {
                return "buyBackBuyNow" === a.attr("id")
            },
            checkoutWith: function(a, f) {
                var c;
                for (c = 1; 0 < f.find('input[name\x3d"asin.' + c + '"]').length || 0 < f.find('input[name\x3d"offeringID.' + c + '"]').length;) c++;
                for (var b = [], h = 0; h < a.length; h++) {
                    var g = a[h];
                    if (g !== x && g.asin && g.offerListingId) {
                        var e = c,
                            g = [k("\x3cinput /\x3e", {
                                type: "hidden",
                                name: "asin." + e,
                                value: g.asin
                            }), k("\x3cinput /\x3e", {
                                type: "hidden",
                                name: "offeringID." + e,
                                value: g.offerListingId
                            }), k("\x3cinput /\x3e", {
                                type: "hidden",
                                name: "quantity." + e,
                                value: g.quantity || 1
                            })];
                        Array.prototype.push.apply(b, g);
                        c++
                    } else logError('Line item inputs are invalid. Expected "asin" and "offerListingId" keys in object. Customer purchase inputs ignored!', g)
                }
                a = f.find('input[name\x3d"itemCount"]');
                1 === a.length ? a.val(c) : f.append(k("\x3cinput /\x3e", {
                    type: "hidden",
                    name: "itemCount",
                    value: c
                }));
                f.append.apply(f, b)
            }
        }
    });
    "use strict";
    n.when("A").register("aloha-buybox-form-util", function(a) {
        function k(a) {
            for (var b = 2; 0 < a.find('input[name\x3d"asin.' + b + '"]').length || 0 < a.find('input[name\x3d"offeringID.' + b + '"]').length;) b++;
            return b
        }

        function d(c, b) {
            return [a.$("\x3cinput /\x3e", {
                type: "hidden",
                name: "asin." + b,
                value: c.asin,
                class: "aloha-accessory-form-input"
            }), a.$("\x3cinput /\x3e", {
                type: "hidden",
                name: "offeringID." +
                    b,
                value: c.offerListingId,
                class: "aloha-accessory-form-input"
            }), a.$("\x3cinput /\x3e", {
                type: "hidden",
                name: "quantity." + b,
                value: c.quantity || 1,
                class: "aloha-accessory-form-input"
            })]
        }
        var f = [];
        a.on("aloha:detailPage:reappear", function() {
            f = [];
            a.$(".aloha-accessory-form-input").remove()
        });
        return {
            addItems: function(a, b, h) {
                var g = k(a);
                b.forEach(function(b) {
                    if (b !== x && b.asin && b.offerListingId) {
                        var k = d(b, g);
                        k.forEach(function(b) {
                            a.append(b)
                        });
                        f.push(k);
                        g++;
                        h && (h.logCheckboxSelected(b.index, b.quantity), h.logAddToCartRefTag(b.index))
                    }
                });
                b = a.find('input[name\x3d"itemCount"]');
                0 === b.length ? a.append('\x3cinput type\x3d"hidden" name\x3d"itemCount" value\x3d"' + g + '"\x3e') : b[0].value = g
            }
        }
    })
});
/* ******** */
(function(h) {
    var e = window.AmazonUIPageJS || window.P,
        n = e._namespace || e.attributeErrors,
        c = n ? n("DetailPageBTFSubNavAssets", "") : e;
    c.guardFatal ? c.guardFatal(h)(c, window) : c.execute(function() {
        h(c, window)
    })
})(function(h, e, n) {
    h.when("A", "ready").register("btf-sub-nav-utilities", function(c) {
        function d() {
            f("#btf-sub-nav-tab .sub-nav-tab").removeClass("active")
        }
        var f = c.$;
        return {
            processTargetIds: function(b) {
                var k = {};
                c.each(b, function(b, a) {
                    var g;
                    a: {
                        for (g = 0; g < b.length; g++)
                            if (f(b[g]).length && f(b[g]).height()) {
                                g =
                                    b[g];
                                break a
                            }
                        g = !1
                    }
                    g ? k[a] = g : f("#" + a).hide()
                });
                return k
            },
            activateTab: function(b) {
                d();
                f("#" + b).addClass("active")
            },
            deactivateTabs: d,
            registerRefTag: function(b) {
                f.get("/gp/product/ajax-handlers/reftag.html/ref\x3d" + b)
            },
            getTargetDivCoordinates: function(b) {
                var c = [];
                f(b).length && f(b).offset() && (c.push(f(b).offset().top), c.push(f(b).offset().top + f(b).height()));
                return c
            },
            onScreen: function(b, c) {
                var d = f(e),
                    a = d.scrollTop() + c,
                    d = e.innerHeight ? e.innerHeight : d.height(),
                    g = a + d,
                    l = b[0],
                    m = b[1];
                return l >= a && l < g || m > a &&
                    m <= g || m - l > d && l <= a && m >= g
            }
        }
    });
    h.when("A", "btf-sub-nav-utilities", "ready").execute(function(c, d) {
        function f() {
            h.register("btf-sub-nav-configs", function() {
                var b = {
                        btfSubNavDetailsTab: ["#aboutThisItem_feature_div", "#featureBulletsAndDetailBullets_feature_div"],
                        btfSubNavCompareTab: ["#HLCXComparisonWidget_feature_div"],
                        btfSubNavQATab: ["#ask-btf-container"],
                        btfSubNavCustomerReviewsTab: ["#aw-udpv3-customer-reviews_feature_div", ".customerReviewsMobileFeature", ".customerReviewsTitle"]
                    },
                    a = d.processTargetIds(b);
                return c.objectIsEmpty(a) ? (e("#btf-sub-nav-wrapper").hide(), !1) : {
                    elem: "#btf-sub-nav-tab",
                    subNavWrapper: "#btf-sub-nav-wrapper",
                    btfSubNavJQElemHeight: e("#btf-sub-nav-tab").outerHeight() + 10,
                    tabTargets: b,
                    tabsArray: ["btfSubNavTopTab", "btfSubNavDetailsTab", "btfSubNavCompareTab", "btfSubNavQATab", "btfSubNavCustomerReviewsTab"],
                    refTags: {
                        btfSubNavTopTab: "btf_sub_nav_top",
                        btfSubNavDetailsTab: "btf_sub_nav_details",
                        btfSubNavCompareTab: "btf_sub_nav_compare",
                        btfSubNavQATab: "btf_sub_nav_qa",
                        btfSubNavCustomerReviewsTab: "btf_sub_nav_cr"
                    },
                    persistentHeaderClass: "persistent-header",
                    fixedAmazonNavJQElem: "#nav-logobar",
                    fixedAmazonNavBodyClass: "fixed-navbar",
                    animationDuration: 100,
                    atfStarScrollDuration: 800
                }
            })
        }

        function b() {
            e("#btf-sub-nav-tab").length && (f(), c.off("a:pageUpdate", b))
        }
        var e = c.$;
        if (e("#btf-sub-nav-tab").length) f();
        else c.on("a:pageUpdate", b)
    });
    h.when("A", "btf-sub-nav-configs", "btf-sub-nav-utilities").execute(function(c, d, f) {
        if (!d) return !1;
        var b = c.$,
            k = 0,
            h = d.btfSubNavJQElemHeight,
            a = {};
        a.tabTargets = d.tabTargets;
        a.tabCoordinates = {};
        a.jqSubNav = null;
        a.topOffset = h + k;
        a.animationDuration = d.animationDuration;
        a.orientationChangeEvent = "orientationChange";
        a.showTab = function() {
            a.jqSubNav.removeClass("aok-hidden");
            a.jqSubNav.addClass(d.persistentHeaderClass)
        };
        a.hideTab = function() {
            a.jqSubNav.addClass("aok-hidden");
            a.jqSubNav.removeClass(d.persistentHeaderClass)
        };
        a.twisterUpdateHandler = function() {
            c.on("a:pageUpdate ready", a.initialize)
        };
        a.screenResizeHandler = function() {
            c.on("resize", a.initialize);
            c.on(a.orientationChangeEvent, a.initialize)
        };
        a.refreshTabCoordinates = function() {
            c.each(a.tabs, function(b, c) {
                a.tabCoordinates[c] = f.getTargetDivCoordinates(b)
            })
        };
        a.processTabChecks = function(b) {
            for (var c = !1, d = 0; d < b.length; d++)
                if (a.tabCoordinates[b[d]] && f.onScreen(a.tabCoordinates[b[d]], a.topOffset)) {
                    c = !0;
                    f.activateTab(b[d]);
                    break
                }
            c || f.deactivateTabs()
        };
        a.setTopOffset = function() {
            b("body").hasClass(d.fixedAmazonNavBodyClass) && b(d.fixedAmazonNavJQElem).length && (k = b(d.fixedAmazonNavJQElem).outerHeight());
            a.topOffset = h + k
        };
        a.scrollHandler = function() {
            a.setTopOffset();
            var c = b(e).scrollTop() + k;
            if (b(a.tabs.btfSubNavDetailsTab).offset()) {
                var l = b(a.tabs.btfSubNavDetailsTab).offset().top - a.topOffset;
                a.refreshTabCoordinates();
                c + e.innerHeight / 2 >= l ? (a.showTab(), a.jqSubNav.css({
                    top: k,
                    opacity: 1
                }), a.processTabChecks(d.tabsArray)) : (c + e.innerHeight / 2 < l && c + e.innerHeight >= l ? (a.showTab(), a.jqSubNav.css({
                    top: k,
                    opacity: (c + e.innerHeight / 2 - (l - e.innerHeight)) / e.innerHeight
                })) : a.hideTab(), f.activateTab("btfSubNavDetailsTab"))
            }
        };
        a.clickHandler = function(g) {
            g.preventDefault();
            c.off("scroll",
                a.scrollHandler);
            a.jqSubNav.css({
                opacity: 1
            });
            g = g.currentTarget.id;
            f.registerRefTag(d.refTags[g]);
            if ("btfSubNavTopTab" === g) b("html,body").animate({
                scrollTop: 0
            }, a.animationDuration), c.on("scroll", a.scrollHandler);
            else {
                var e = a.tabs[g];
                f.activateTab(g);
                b(e).offset() && b("html,body").animate({
                    scrollTop: b(e).offset().top - a.topOffset
                }, a.animationDuration);
                c.delay(function() {
                    c.on("scroll", a.scrollHandler);
                    a.showTab()
                }, a.animationDuration + 300)
            }
        };
        a.handleATFCRStarClicks = function() {
            c.off("scroll", a.scrollHandler);
            c.delay(function() {
                c.on("scroll", a.scrollHandler)
            }, d.atfStarScrollDuration)
        };
        a.detachHandlers = function() {
            c.off("scroll", a.scrollHandler);
            b("#acrCustomerReviewLink").length && b("#acrCustomerReviewLink").unbind("click", a.handleATFCRStarClicks);
            b("#btf-sub-nav-tab .sub-nav-tab").unbind("click", a.clickHandler)
        };
        a.attachHandlers = function() {
            c.on("scroll", a.scrollHandler);
            b("#acrCustomerReviewLink").length && b("#acrCustomerReviewLink").click(a.handleATFCRStarClicks);
            b("#btf-sub-nav-tab .sub-nav-tab").click(a.clickHandler)
        };
        a.initialize = function() {
            a.jqSubNav = b(d.elem);
            screen && (360 > screen.width || 640 > screen.height) || e.innerWidth > e.innerHeight ? (a.detachHandlers(), a.hideTab()) : (a.tabs = f.processTargetIds(a.tabTargets), c.objectIsEmpty(a.tabs) && b("#btf-sub-nav-wrapper").hide(), a.setTopOffset(), a.scrollHandler(), a.refreshTabCoordinates(), a.detachHandlers(), a.attachHandlers())
        };
        a.initialize();
        a.twisterUpdateHandler();
        a.screenResizeHandler()
    })
});
/* ******** */
(function(g) {
    var m = window.AmazonUIPageJS || window.P,
        u = m._namespace || m.attributeErrors,
        a = u ? u("DetailPageAddonWidgetAssets@addons", "DetailPageAddonWidgetAssets") : m;
    a.guardFatal ? a.guardFatal(g)(a, window) : a.execute(function() {
        g(a, window)
    })
})(function(g, m, u) {
    g.when("A", "addons-widget", "addons-page-state", "addons-feature-status", "metrics-publisher", "addons-metrics-type", "addons-client-promise-factory", "addons-checkout-event-handler", "addons-cart-api", "addons-peak-option-slot", "addons-bottom-sheet-handler",
        "addons-remove-option-slot", "addons-clients", "addons-clean-option-slot", "ready").execute(function(a, c, b, d, f, e, h, l, g, k, z, A, r, w) {
        var v = !1;
        a.declarative("addons-checkbox-toggle", "click", function(d) {
            if ("INPUT" === d.$event.target.tagName) {
                var c = b.getAsinState(d.data.asin);
                if (c) {
                    var B = h.getClientPromise(c.client);
                    if (B && "function" === typeof B.execute) {
                        var l = a.$(d.$event.target).is(":checked");
                        B.execute(l)
                    } else b.selectOption(d.data.asin);
                    a.delay(function() {
                        c = b.getAsinState(d.data.asin);
                        var h = a.$(d.$event.target).closest(".option-slot");
                        h && h.length && (h = h.data("metric-key"), c.selected ? f.log(c.client, e.ASIN_INCLUDED, {
                            metricKey: h,
                            asin: c.asin
                        }) : f.log(c.client, e.ASIN_EXCLUDED_AFTER_INCLUDED, {
                            metricKey: h,
                            asin: c.asin
                        }))
                    }, 100)
                }
            }
        });
        c.load();
        l.init();
        r.executeOnReady();
        a.on("a:pageUpdate", function() {
            v ? (A.remove(), b.reloadPageState(), g.clearCart(), a.delay(function() {
                k.execute(b.getPageState())
            }, 100), c.load(), z.execute(), r.executeOnReady(), w.clean()) : v = !0
        })
    });
    g.declare("addons-constants", {
        ADD_TO_CART: "addToCart",
        ADD_TO_CART_BUTTON_SELECTOR: "#add-to-cart-button",
        ADD_TO_CART_BUTTON_HANDLER: "click.addonsatc",
        ADD_TO_CART_LIGHTENING_DEAL: "addToCartLighteningDeal",
        ADD_TO_CART_LIGHTENING_DEAL_BUTTON_SELECTOR: ".gb-btn-atc",
        ADD_TO_CART_LIGHTENING_DEAL_BUTTON_HANDLER: "click.addonsldatc",
        ADD_TO_CART_ATF_REDESIGN_BUTTON_SELECTOR: "#atfRedesign-buy-box-bar .atcButton input",
        ADD_TO_CART_UBB_MOBILE_BUTTON_SELECTOR: "#add-to-cart-button-ubb-mobile",
        BUY_NOW: "buyNow",
        BUY_BACK_BUY_NOW: "buyBackBuyNow",
        TURBO_CHECKOUT_BUY_NOW: "buyNowCheckout",
        REGULAR_BUYBOX_ADD_TO_CART_FORM_SELECTOR: "#RegularBuybox #addToCart",
        REGULAR_BUYBOX_BUYNOW_FORM_SELECTOR: "#RegularBuybox #buyNow",
        LD_BUYBOX_ADD_TO_CART_FORM_SELECTOR: "#LDBuybox #atc-declarative",
        LD_BUYBOX_BUYNOW_FORM_SELECTOR: "#LDBuybox #buyNow",
        ADDONS_FEATURE_DIV: "addons_feature_div",
        ADDONS_WIDGET: ".addons-widget",
        BOTTOM_SHEET_SELECTOR: "#aggregator-slot-bottomsheet-container",
        ADDONS_SLOT_RIGHT_COLUMN_SELECTOR: ".addons-slot-right-column",
        PRIMARY_VIEW_OPTION_SLOT_SELECTOR: "#addons_feature_div .option-slot",
        BOTTOM_SHEET_OPTION_SLOT_SELECTOR: "#aggregator-slot-bottomsheet-container .option-slot",
        CLIENTS: {
            AHS: "AHS",
            PSD: "PSD",
            ADDONS: "ADDONS"
        },
        BUY_BOX_TYPES: {
            REGULAR: "addons-regular-box",
            BUY_BACK: "addons-buy-back-box",
            LIGHTENING_DEAL: "addons-lightening-deal-box"
        },
        ACCORDION_ROW_IDS: {
            buyBackAccordionRow: "addons-buy-back-box",
            LDBuybox: "addons-lightening-deal-box"
        }
    });
    g.when("A", "addons-constants", "metrics-publisher", "addons-metrics-type").register("addons-metrics", function(a, c, b, d) {
        var f = function(f) {
            if (f === d.GLANCE_VIEW) {
                var h = a.$(c.PRIMARY_VIEW_OPTION_SLOT_SELECTOR).first();
                if (0 !== h.length) {
                    var l =
                        h.data("client"),
                        g = h.data("metric-key"),
                        h = h.data("asin");
                    b.log(l, f, {
                        metricKey: g,
                        asin: h
                    })
                }
                a.$(c.ADDONS_WIDGET).length && b.log(c.CLIENTS.ADDONS, f, {})
            } else f === d.GLANCE_VIEW_NOT_ON_PRIMARY_SHEET && a.$(c.BOTTOM_SHEET_OPTION_SLOT_SELECTOR).each(function() {
                var d = a.$(this);
                if (d && d.length) {
                    var c = d.data("client"),
                        h = d.data("metric-key"),
                        d = d.data("asin");
                    b.log(c, f, {
                        metricKey: h,
                        asin: d
                    })
                }
            })
        };
        return {
            init: function() {
                f(d.GLANCE_VIEW);
                f(d.GLANCE_VIEW_NOT_ON_PRIMARY_SHEET);
                a.$(c.ADDONS_SLOT_RIGHT_COLUMN_SELECTOR).bind("click",
                    function(f) {
                        var c = a.$(f.target).closest(".option-slot");
                        if (c && c.length) {
                            f = c.data("client");
                            var l = c.data("metric-key"),
                                c = c.data("asin");
                            b.log(f, d.CLICKED, {
                                metricKey: l,
                                asin: c
                            })
                        }
                    })
            }
        }
    });
    g.when("A", "addons-client-promise-factory", "addons-constants", "ready").register("addons-clients", function(a, c, b) {
        return {
            executeOnReady: function() {
                a.each(b.CLIENTS, function(a) {
                    (a = c.getClientPromise(a)) && "function" === typeof a.executeOnReady && a.executeOnReady()
                })
            }
        }
    });
    g.when("A", "addons-buynow-api", "addons-constants").register("addons-add-item-in-buy-now-form",
        function(a, c, b) {
            a.on("a2idpx:addons:state-change", function(d, f) {
                (f = d.selectedAsin) && d[f] && d[f].selected && (c.addFormParams(b.BUY_NOW, a.$.extend(!0, {}, d[f])), c.addFormParams(b.BUY_BACK_BUY_NOW, a.$.extend(!0, {}, d[f])), c.addFormParams(b.TURBO_CHECKOUT_BUY_NOW, a.$.extend(!0, {}, d[f])))
            })
        });
    g.when("A", "addons-cart-api").register("addons-add-item-to-cart", function(a, c) {
        a.on("a2idpx:addons:state-change", function(a, d) {
            (d = a.selectedAsin) && a[d] && a[d].selected && c.addItem(d)
        })
    });
    g.when("A", "addons-peak-option-slot").register("addons-add-option-slot",
        function(a, c) {
            var b = function(b) {
                    var d = a.$(b);
                    if (a.$(d).length) {
                        var c = parseInt(a.$(d).data("order"));
                        if (1 === c) a.$(d).clone().prependTo(".addons-widget ul");
                        else {
                            var l, g = !1;
                            a.$(".addons-widget ul \x3e .option-slot").each(function() {
                                var b = parseInt(a.$(this).data("order"));
                                b === c - 1 && (a.$(d).clone().insertAfter(a.$(this)), g = !0);
                                b < c && (l = a.$(this))
                            });
                            !g && l ? a.$(d).clone().insertAfter(a.$(l)) : g || a.$(d).clone().prependTo(".addons-widget ul")
                        }
                    }
                },
                d = function(b) {
                    a.$(".addons-widget ul \x3e .option-slot").each(function() {
                        var d =
                            a.$(".aggregator-slot");
                        d && d.length && (d = a.$(this).data("asin")) && b[d] && b[d].canBeSelected && !b[d].selected && a.$(this).detach()
                    })
                };
            a.on("a2idpx:addons:state-change", function(f, e) {
                d(f);
                1 < f.totalOptions && (e = f.selectedAsin) && f[e] && f[e].selected && (e = "#aggregator-slot-bottomsheet-container ul \x3e ." + f.selectedOptionSlot, a.$(".addons-widget ul \x3e ." + f.selectedOptionSlot).length || b(e));
                c.execute(f)
            })
        });
    g.when("A", "addons-page-state", "ready").register("addons-client-option-selection", function(a, c) {
        a.on("a2idpx:addons:client-option-selection",
            function(a) {
                a && a.asin && c.selectOption(a.asin, a.offerName, a.offerSelected)
            })
    });
    g.when("A", "addons-constants", "addons-feature-status", "addons-active-buybox", "addons-page-state", "addons-update-price", "ready").register("addons-open-buybox-accordion", function(a, c, b, d, f, e) {
        a.on("a:accordion:buybox-accordion:newAccordionRow:select", function(a) {
            b.isInSecondaryBox() && (b.move(), d.setAccordionRowType(c.BUY_BOX_TYPES.REGULAR), e.update(f.getPageState()))
        });
        a.on("a:accordion:buybox-accordion:buyBackAccordionRow:select",
            function(a) {
                b.isInSecondaryBox() || (b.move(), d.setAccordionRowType(c.BUY_BOX_TYPES.BUY_BACK), e.update(f.getPageState()))
            });
        a.on("a:accordion:buybox_accordion:gb_ld_buybox:select", function(a) {
            b.isInSecondaryBox() && (b.move(), d.setAccordionRowType(c.BUY_BOX_TYPES.LIGHTENING_DEAL), e.update(f.getPageState()))
        });
        a.on("a:accordion:buybox_accordion:regular_buybox:select", function(a) {
            b.isInSecondaryBox() || (b.move(), d.setAccordionRowType(c.BUY_BOX_TYPES.REGULAR), e.update(f.getPageState()))
        })
    });
    g.when("A", "addons-buynow-api",
        "addons-constants").register("addons-remove-item-from-buy-now-form", function(a, c, b) {
        a.on("a2idpx:addons:state-change", function(d, f) {
            (f = d.selectedAsin) && d[f] && !d[f].selected && (c.removeFormParams(b.BUY_NOW, a.$.extend(!0, {}, d[f])), c.removeFormParams(b.BUY_BACK_BUY_NOW, a.$.extend(!0, {}, d[f])), c.removeFormParams(b.TURBO_CHECKOUT_BUY_NOW, a.$.extend(!0, {}, d[f])))
        })
    });
    g.when("A", "addons-cart-api").register("addons-remove-item-from-cart", function(a, c) {
        a.on("a2idpx:addons:state-change", function(a, d) {
            (d = a.selectedAsin) &&
            a[d] && !a[d].selected && c.removeItem(d)
        })
    });
    g.when("A").register("addons-update-option-name", function(a) {
        a.on("a2idpx:addons:state-change", function(c, b) {
            if (b = c.selectedAsin)
                if (c = c.selectedOptionText) b = '[data-asin\x3d"' + b + '"]', a.$(b + " .option-name .a-truncate-full") && a.$(b + " .option-name .a-truncate-full").length && a.$(b + " .option-name .a-truncate-full").html(c), a.$(b + " .option-name .a-truncate-cut") && a.$(b + " .option-name .a-truncate-cut").length && a.$(b + " .option-name .a-truncate-cut").html(c)
        })
    });
    g.when("A",
        "addons-constants", "addons-active-buybox").register("addons-update-price", function(a, c, b) {
        var d = function(d) {
            if (d) {
                var e = b.getAccordionRowType();
                if (e) {
                    var h = a.$(".total-price-block");
                    if (h && h.length) {
                        switch (e) {
                            case c.BUY_BOX_TYPES.REGULAR:
                                e = d.price.regular;
                                break;
                            case c.BUY_BOX_TYPES.BUY_BACK:
                                e = d.price.buyBack;
                                break;
                            case c.BUY_BOX_TYPES.LIGHTENING_DEAL:
                                e = d.price.lighteningDeal;
                                break;
                            default:
                                e = d.price.regular
                        }
                        var l, g = "₹ ",
                            k;
                        k = d.price.sumOfAddonsSelections;
                        k = parseFloat(e) + parseFloat(k);
                        try {
                            l = accounting.formatNumber(k),
                                g += l ? l : k
                        } catch (z) {
                            g += k
                        }
                        l = g;
                        (g = a.$(".addons-total-price")) && g.length && l && 0 !== e ? (g.text(l), 0 < d.selectedOptionCount ? h.show() : h.hide()) : h.hide()
                    }
                }
            }
        };
        a.on("a2idpx:addons:state-change", function(a, b) {
            d(a)
        });
        return {
            update: d
        }
    });
    g.when("A", "addons-page-state").register("addons-update-buy-back-price", function(a, c) {
        a.on("a2idpx:buyback:discount-price", function(a) {
            c.getPageState() && a && c.setBuyBackPrice(a)
        })
    });
    g.when("A", "ready").register("addons-buynow-api", function(a) {
        var c = function(b) {
            return a.$(b + " \x3e input[name\x3dofferingID]")
        };
        return {
            addFormParams: function(b, d) {
                var f = "#" + b,
                    e = a.$(f + " \x3e input[name\x3dasin]");
                b = c(f);
                f = a.$(f + " \x3e input[name\x3dquantity]");
                if ((e = a.$(e)) && 0 !== e.length && e.val() && -1 === e.val().indexOf(d.asin) && a.$(f) && 0 !== a.$(f).length && a.$(f).val() && a.$(b) && 0 !== a.$(b).length && a.$(b).val()) {
                    var h = e.val() + "|" + d.asin,
                        g = a.$(b).val() + "|" + d.offerListingId;
                    d = a.$(f).val() + "|" + d.quantity;
                    e.val(h);
                    a.$(b).val(g);
                    a.$(f).val(d)
                }
            },
            removeFormParams: function(b, d) {
                var f = "#" + b,
                    e = a.$(f + " \x3e input[name\x3dasin]");
                b = c(f);
                f =
                    a.$(f + " \x3e input[name\x3dquantity]");
                if ((e = a.$(e)) && 0 !== e.length && e.val() && -1 !== e.val().indexOf(d.asin) && a.$(f) && 0 !== a.$(f).length && a.$(f).val() && a.$(b) && 0 !== a.$(b).length && a.$(b).val()) {
                    var h = e.val().split("|");
                    d = h.indexOf(d.asin);
                    h.splice(d, 1);
                    e.val(h.join("|"));
                    e = a.$(b).val().split("|");
                    e.splice(d, 1);
                    a.$(b).val(e.join("|"));
                    b = a.$(f).val().split("|");
                    b.splice(d, 1);
                    a.$(f).val(b.join("|"))
                }
            }
        }
    });
    g.when("A", "addons-page-state", "addons-constants", "metrics-publisher", "addons-metrics-type", "atc-handler-component",
        "ready").register("addons-cart-api", function(a, c, b, d, f, e) {
        var h = {},
            g = function() {
                var b = a.$("input[name\x3dsessionID]"),
                    d = a.state("turbo-checkout-page-state");
                return c.getSessionId() ? c.getSessionId() : b.length && b.val() ? b.val() : d && d.inputs && d.inputs.verificationSessionID ? d.inputs.verificationSessionID : null
            },
            n = function() {
                var b = {
                        clientName: "AddonsWidget"
                    },
                    d = 1;
                a.$.each(h, function(a, c) {
                    b["ASIN." + d] = c.ASIN;
                    b["quantity." + d] = c.quantity;
                    b["offerListingID." + d] = c.offerListingID;
                    d++
                });
                b.verificationSessionID = g();
                return b
            },
            k = function(b) {
                a.trigger("hctp:attach:addon-cart-update")
            },
            z = function(a) {},
            m = function(d) {
                d === b.ADD_TO_CART_LIGHTENING_DEAL ? a.$(b.ADD_TO_CART_LIGHTENING_DEAL_BUTTON_SELECTOR).unbind(b.ADD_TO_CART_LIGHTENING_DEAL_BUTTON_HANDLER).click() : a.$(b.ADD_TO_CART_BUTTON_SELECTOR).unbind(b.ADD_TO_CART_BUTTON_HANDLER).click()
            };
        return {
            addToCart: function(b) {
                if (!a.$.isEmptyObject(h)) {
                    var g = n();
                    a.ajax("/gp/add-to-cart/json", {
                        method: "POST",
                        params: g,
                        success: k,
                        error: z,
                        always: m.bind(null, b)
                    });
                    a.$.each(h, function(b) {
                        var e =
                            c.getAsinState(b);
                        if (e && e.selected && a.$('div[data-asin\x3d"' + b + '"]') && a.$('div[data-asin\x3d"' + b + '"]').length) {
                            var h = a.$('div[data-asin\x3d"' + b + '"]').data("metric-key");
                            d.log(e.client, f.ADD_TO_CART, {
                                metricKey: h,
                                asin: b
                            })
                        }
                    });
                    e.setAddToCartApiCalled(!0)
                }
            },
            addItem: function(a) {
                var b = c.getAsinState(a);
                if (b) {
                    var d = {};
                    d.ASIN = a;
                    d.quantity = b.quantity;
                    d.offerListingID = b.offerListingId;
                    h[a] = d;
                    e.setAddToCartApiCalled(!1)
                }
            },
            removeItem: function(a) {
                h[a] && delete h[a]
            },
            clearCart: function() {
                h = {};
                e.setAddToCartApiCalled(!1)
            }
        }
    });
    g.when("A", "addons-cart-api", "addons-constants", "ready").register("addons-checkout-event-handler", function(a, c, b) {
        var d = function(a) {
            c.addToCart(a)
        };
        return {
            init: function() {
                a.$(document.body).undelegate(b.ADD_TO_CART_BUTTON_SELECTOR, b.ADD_TO_CART_BUTTON_HANDLER);
                a.$(document.body).delegate(b.ADD_TO_CART_BUTTON_SELECTOR, b.ADD_TO_CART_BUTTON_HANDLER, d, b.ADD_TO_CART);
                a.$(document.body).undelegate(b.ADD_TO_CART_ATF_REDESIGN_BUTTON_SELECTOR, b.ADD_TO_CART_BUTTON_HANDLER);
                a.$(document.body).delegate(b.ADD_TO_CART_ATF_REDESIGN_BUTTON_SELECTOR,
                    b.ADD_TO_CART_BUTTON_HANDLER, d, b.ADD_TO_CART);
                a.$(document.body).undelegate(b.ADD_TO_CART_UBB_MOBILE_BUTTON_SELECTOR, b.ADD_TO_CART_BUTTON_HANDLER);
                a.$(document.body).delegate(b.ADD_TO_CART_UBB_MOBILE_BUTTON_SELECTOR, b.ADD_TO_CART_BUTTON_HANDLER, d, b.ADD_TO_CART);
                a.$(document.body).undelegate(b.ADD_TO_CART_LIGHTENING_DEAL_BUTTON_SELECTOR, b.ADD_TO_CART_LIGHTENING_DEAL_BUTTON_HANDLER);
                a.$(document.body).delegate(b.ADD_TO_CART_LIGHTENING_DEAL_BUTTON_SELECTOR, b.ADD_TO_CART_LIGHTENING_DEAL_BUTTON_HANDLER,
                    d, b.ADD_TO_CART_LIGHTENING_DEAL)
            }
        }
    });
    g.when("A", "a-checkbox", "ready").register("addons-page-state", function(a, c) {
        a.state.bind("addons-state", function(b, d) {
            a.trigger("a2idpx:addons:state-change", b, d)
        });
        return {
            selectOption: function(b, d, f) {
                var e = a.state("addons-state");
                if (e && b && e[b] && f !== e[b].selected) {
                    f = !e[b].selected;
                    var h, g;
                    f ? (h = e.selectedOptionCount + 1, g = parseFloat(e.price.sumOfAddonsSelections) + parseFloat(e[b].price)) : (h = e.selectedOptionCount - 1, g = parseFloat(e.price.sumOfAddonsSelections) - parseFloat(e[b].price));
                    c("." + b).check(f);
                    e[b].selected = f;
                    e.selectedOptionCount = h;
                    e.selectedAsin = b;
                    e.selectedOptionSlot = e[b].optionSlotId;
                    e.price.sumOfAddonsSelections = g;
                    e.selectedOptionText = d ? d : "";
                    a.state("addons-state", e)
                }
            },
            setBuyBackPrice: function(b) {
                var d = a.state("addons-state");
                d && b && (d.price.buyBack = b, a.state("addons-state", d))
            },
            getAsinState: function(b) {
                var d = a.state("addons-state");
                if (d) return a.$.extend(!0, {}, d[b])
            },
            getSessionId: function() {
                var b = a.state("addons-state");
                if (b) return b.sessionId
            },
            getPreSelectedAsins: function() {
                var b =
                    a.state("addons-state");
                if (b) return a.$.extend(!0, {}, b.preSelectedAsins)
            },
            getDeviceType: function() {
                var b = a.state("addons-state");
                if (b) return b.deviceType
            },
            getSelectedOptionCount: function() {
                var b = a.state("addons-state");
                if (b) return b.selectedOptionCount
            },
            reloadPageState: function() {
                a.each(a.$("#addons_feature_div").find("[data-a-state]"), function(b, d) {
                    "addons-state" === a.parseJSON(a.$(b).attr("data-a-state")).key && (b = a.parseJSON(a.$(b).html())) && a.state.replace("addons-state", b, !0)
                })
            },
            getPageState: function() {
                var b =
                    a.state("addons-state");
                if (b) return a.$.extend(!0, {}, b)
            },
            getPageStateAsins: function() {
                var b = a.state("addons-state");
                if (b) {
                    var d = [];
                    a.each(b, function(a) {
                        a && "object" === typeof a && a.asin && d.push(a.asin)
                    });
                    return d
                }
            },
            isAvailable: function() {
                return !!a.state("addons-state")
            },
            getBaseAsin: function() {
                var b = a.state("addons-state");
                if (b) return b.baseAsin
            },
            getBaseAsinMerchantId: function() {
                var b = a.state("addons-state");
                if (b) return b.baseAsinMerchantId
            }
        }
    });
    g.when("A", "addons-page-state", "addons-client-promise-factory",
        "metrics-publisher", "addons-metrics-type").register("addons-asin-pre-selection-handler", function(a, c, b, d, f) {
        return {
            execute: function() {
                var e = c.getPreSelectedAsins();
                e && a.$.each(e, function(e, g) {
                    if (e = c.getAsinState(g)) {
                        var n = b.getClientPromise(e.client);
                        n && "function" === typeof n.execute ? n.execute(!0) : c.selectOption(g, "", !0);
                        a.$('div[data-asin\x3d"' + g + '"]') && a.$('div[data-asin\x3d"' + g + '"]').length && (n = a.$('div[data-asin\x3d"' + g + '"]').data("metric-key"), d.log(e.client, f.PRE_CHECKED_ASIN, {
                            metricKey: n,
                            asin: g
                        }))
                    }
                })
            }
        }
    });
    g.when("A", "a-sheet").execute(function(a, c) {
        var b = function(b) {
            var c = a.$("#a-page"),
                e = a.$("#addons_feature_div");
            e.length && (e = e.offset().top - 17, b ? c.length && c.css({
                position: "fixed",
                top: -e
            }) : (c.length && c.css({
                position: "",
                top: ""
            }), a.$("html,body").scrollTop(e)))
        };
        a.on("a:sheet:beforeShow:aggregator_slot_bottom_sheet", function(a) {
            b(!0)
        });
        a.on("a:sheet:beforeHide:aggregator_slot_bottom_sheet", function(a) {
            b(!1)
        })
    });
    g.when("A", "addons-constants").register("addons-feature-status", function(a, c) {
        var b, d, f;
        return {
            init: function() {
                var e =
                    a.$("#" + c.ADDONS_FEATURE_DIV);
                e.length && (b = e.prev());
                e = a.$("#" + c.BUY_BACK_BUY_NOW);
                e.length && (d = a.$("#" + c.BUY_BACK_BUY_NOW).parent().prev());
                var e = a.$(c.REGULAR_BUYBOX_ADD_TO_CART_FORM_SELECTOR),
                    h = a.$(c.REGULAR_BUYBOX_BUYNOW_FORM_SELECTOR),
                    e = e && e[0] && h && h[0] && e[0].compareDocumentPosition(h[0]) === Node.DOCUMENT_POSITION_FOLLOWING ? e : h;
                e.length && (d = e.prev());
                e = a.$(c.LD_BUYBOX_ADD_TO_CART_FORM_SELECTOR);
                h = a.$(c.LD_BUYBOX_BUYNOW_FORM_SELECTOR);
                e = e && e[0] && h && h[0] && e[0].compareDocumentPosition(h[0]) === Node.DOCUMENT_POSITION_FOLLOWING ?
                    e : h;
                e.length && (d = e.prev());
                f = !1
            },
            isInSecondaryBox: function() {
                return f
            },
            move: function() {
                var e = a.$("#" + c.ADDONS_FEATURE_DIV).detach();
                e.length && (f ? (a.$(e).insertAfter(a.$(b)), f = !1) : (a.$(e).insertAfter(a.$(d)), f = !0))
            }
        }
    });
    g.when("A", "addons-constants", "addons-client-promise-ahs", "ready").register("addons-client-promise-factory", function(a, c, b) {
        return {
            getClientPromise: function(a) {
                switch (a) {
                    case c.CLIENTS.AHS:
                        return b;
                    default:
                        return null
                }
            }
        }
    });
    g.when("A", "addons-asin-pre-selection-handler", "addons-active-buybox",
        "addons-update-price", "addons-page-state", "addons-feature-status", "addons-metrics", "ready").register("addons-widget", function(a, c, b, d, f, e, h) {
        return {
            load: function() {
                a.$(".info-icon").length && a.loadImageManually(a.$(".info-icon"));
                c.execute();
                b.init();
                d.update(f.getPageState());
                e.init();
                h.init()
            }
        }
    });
    g.when("A").register("addons-peak-option-slot", function(a) {
        return {
            execute: function(c) {
                c && 1 < c.totalOptions && (0 === a.$(".addons-widget ul \x3e .option-slot").length && a.$("#aggregator-slot-bottomsheet-container ul \x3e .option-slot").first().clone().prependTo(".addons-widget ul"),
                    c.selectedOptionCount === c.totalSelectableOptions ? a.$(".addons-widget ul \x3e .aggregator-slot").hide() : a.$(".addons-widget ul \x3e .aggregator-slot").show())
            }
        }
    });
    g.when("A", "ready").register("addons-bottom-sheet-handler", function(a) {
        var c = {};
        a.on("a:sheet:afterShow:aggregator_slot_bottom_sheet", function(b) {
            c && !c.isLoaded && (b = a.$(".a-sheet-web #aggregator-slot-bottomsheet-container"), c.prevNode = b.prev(), c.parentNode = b.parent(), c.isLoaded = !0)
        });
        return {
            execute: function() {
                a.delay(function() {
                    var b = a.$(".a-sheet-web #aggregator-slot-bottomsheet-container"),
                        d, f;
                    b.length ? (d = b.prev(), f = b.parent()) : c && c.isLoaded && (d = c.prevNode, f = c.parentNode);
                    if (d && d.length || f && f.length) b.detach(), b = a.$("#addons_feature_div #aggregator-slot-bottomsheet-container").detach(), a.$(b).removeClass("aok-hidden"), a.$(b).css({
                        display: "block"
                    }), d.length ? a.$(b).insertAfter(a.$(d)) : a.$(b).prependTo(a.$(f))
                }, 100)
            }
        }
    });
    g.when("A").register("addons-remove-option-slot", function(a) {
        return {
            remove: function() {
                var c = a.$(".aggregator-slot");
                c && c.length && a.$(".addons-widget ul \x3e .option-slot").each(function() {
                    a.$(this).detach()
                })
            }
        }
    });
    g.when("A", "addons-page-state").register("addons-clean-option-slot", function(a, c) {
        return {
            clean: function() {
                var b = c.getPageStateAsins();
                b && b.length && a.$(".addons-widget ul \x3e .option-slot").each(function() {
                    var d = a.$(this);
                    if (d && d.length) {
                        var c = d.data("asin");
                        c && -1 === b.indexOf(c) && d.detach()
                    }
                })
            }
        }
    });
    g.when("A", "ready").register("atc-handler-component", function(a) {
        var c = !1;
        return {
            setAddToCartApiCalled: function(a) {
                c = a
            },
            isAddToCartApiCalled: function() {
                return c
            }
        }
    });
    g.when("A", "addons-constants").register("addons-active-buybox",
        function(a, c) {
            var b;
            return {
                init: function() {
                    b = c.BUY_BOX_TYPES.REGULAR;
                    a.each(c.ACCORDION_ROW_IDS, function(d, c) {
                        (c = a.$("#" + c)) && c.length && c.hasClass("a-accordion-active") && (b = d)
                    })
                },
                setAccordionRowType: function(a) {
                    b = a
                },
                getAccordionRowType: function() {
                    return b
                }
            }
        });
    g.when("A", "a-secondary-view", "ready").register("psd-item-selection", function(a, c) {
        var b = function(b) {
            var f = c.get(b);
            a.delay(function() {
                f.hide(f.id)
            }, 200)
        };
        a.declarative("psd-no-thanks", "click", function(d) {
            var c = {};
            c.asin = d.data.asin;
            c.offerSelected = !1;
            a.trigger("a2idpx:addons:client-option-selection", c);
            b(d.data.secondaryViewName)
        });
        a.declarative("psd-add-to-cart", "click", function(d) {
            var c = {};
            c.asin = d.data.asin;
            c.offerSelected = !0;
            a.trigger("a2idpx:addons:client-option-selection", c);
            b(d.data.secondaryViewName)
        })
    });
    g.when("vas-mobile-widgets", "addons-page-state").execute(function(a, c) {
        c.isAvailable() && a.initialize()
    });
    g.when("A", "simple-message-secondary-view", "ready").register("addons-client-promise-ahs", function(a, c) {
        return {
            execute: function(b) {
                var d =
                    a.$('span[data-action\x3d"vas-mobile-twister"] .a-icon');
                b ? 1 < d.length && d[1].click() : 0 < d.length && d[0].click()
            },
            executeOnReady: function() {
                c.clear()
            }
        }
    });
    g.when("A", "addons-constants", "a-secondary-view", "ready").register("simple-message-secondary-view", function(a, c) {
        var b = {},
            d = function(d, c) {
                a.ajax(c, {
                    method: "GET",
                    success: function(c) {
                        if (c)
                            if ((c = a.$(c).find("#center")) && c.length) d.update({
                                inlineContent: c.html()
                            }), b.isLoaded = !0;
                            else if (c = b.url) m.location.href = c
                    },
                    error: function() {
                        var a = b.url;
                        a && (m.location.href =
                            a)
                    }
                })
            };
        a.on("a:popover:beforeShow:simple-message-secondary-view", function(a) {
            (a = a.popover) && a.data && a.data.redirectUrl && !a.inlineContent && (b.url = a.data.redirectUrl, d(a, b.url))
        });
        return {
            clear: function() {
                b = {}
            }
        }
    });
    g.when("A", "addons-metrics-factory", "addons-metrics-logger", "addons-metrics-csm").register("metrics-publisher", function(a, c, b, d) {
        return {
            log: function(f, e, h) {
                if (f) {
                    var g = c.getClient(f);
                    g && g.log(e, h);
                    b.log(e, a.$.extend(this, h, {
                        client: f
                    }));
                    d.log(e, f)
                }
            }
        }
    });
    g.when("A", "addons-constants", "addons-metrics-client-ahs",
        "addons-metrics-client-psd").register("addons-metrics-factory", function(a, c, b, d) {
        return {
            getClient: function(a) {
                switch (a) {
                    case c.CLIENTS.AHS:
                        return b;
                    case c.CLIENTS.PSD:
                        return d;
                    default:
                        return null
                }
            }
        }
    });
    g.when("A", "addons-metrics-type", "addons-page-state", "addons-metrics-service").register("addons-metrics-logger", function(a, c, b, d) {
        return {
            log: function(a, e) {
                if (a && e && e.client && b.getBaseAsin() && b.getBaseAsinMerchantId()) {
                    e = "addons_" + e.client + "_";
                    switch (a) {
                        case c.ADD_TO_CART:
                            e += "atc";
                            break;
                        case c.ASIN_INCLUDED:
                            e +=
                                "incl";
                            break;
                        case c.ASIN_EXCLUDED_AFTER_INCLUDED:
                            e += "cncl";
                            break;
                        case c.CLICKED:
                            e += "clk";
                            break;
                        case c.GLANCE_VIEW:
                            e += "gv";
                            break;
                        case c.GLANCE_VIEW_NOT_ON_PRIMARY_SHEET:
                            e += "gvs";
                            break;
                        case c.PRE_CHECKED_ASIN:
                            e += "pre";
                            break;
                        case c.REDIRECT:
                            e += "redir";
                            break;
                        default:
                            return
                    }
                    d.logReftag({
                        ref: e,
                        asin: b.getBaseAsin(),
                        merchantId: b.getBaseAsinMerchantId()
                    })
                }
            }
        }
    });
    g.when("A").register("addons-metrics-service", function(a) {
        return {
            logReftag: function(c) {
                if (c && c.ref && c.asin) {
                    var b = "/ref\x3d" + c.ref,
                        b = b + ("?pageAsin\x3d" +
                            c.asin),
                        b = b + ("\x26pageType\x3d" + (a.capabilities ? a.capabilities.mobile ? a.capabilities.isAmazonApp ? "DetailWebView" : "DetailAW" : "Detail" : "")),
                        b = b + "\x26subPageType\x3dAddonsWidget";
                    c.merchantId && (b += "\x26merchantId\x3d" + c.merchantId);
                    a.get("/gp/product/ajax/dpx-metrics-handler.html" + b)
                }
            }
        }
    });
    g.when("A", "addons-metrics-type", "postMetric").register("addons-metrics-csm", function(a, c, b) {
        return {
            log: function(a, f) {
                if (a && f) {
                    f = f.toLowerCase() + "_";
                    switch (a) {
                        case c.ADD_TO_CART:
                            f += "atc";
                            break;
                        case c.ASIN_INCLUDED:
                            f +=
                                "incl";
                            break;
                        case c.ASIN_EXCLUDED_AFTER_INCLUDED:
                            f += "cncl";
                            break;
                        case c.CLICKED:
                            f += "clk";
                            break;
                        case c.GLANCE_VIEW:
                            f += "gv";
                            break;
                        case c.GLANCE_VIEW_NOT_ON_PRIMARY_SHEET:
                            f += "gvs";
                            break;
                        case c.PRE_CHECKED_ASIN:
                            f += "pre";
                            break;
                        case c.REDIRECT:
                            f += "redir";
                            break;
                        default:
                            return
                    }
                    b.postCountMetric(f)
                }
            }
        }
    });
    g.declare("addons-metrics-type", {
        ADD_TO_CART: "add_to_cart",
        ASIN_INCLUDED: "asin_included",
        ASIN_EXCLUDED_AFTER_INCLUDED: "asin_excluded_after_included",
        CLICKED: "clicked_on_service_to_secondary_view",
        GLANCE_VIEW: "glance_view",
        GLANCE_VIEW_NOT_ON_PRIMARY_SHEET: "glance_view_not_primary_sheet",
        PRE_CHECKED_ASIN: "pre_checked_asin_in_widget",
        REDIRECT: "redirect_to_new_page",
        DEVICE_TYPES: {
            MOBILE_WEB: "mobile",
            MOBILE_APP: "mobileApp"
        }
    });
    g.when("A", "addons-page-state", "postMetric", "addons-metrics-type").register("addons-metrics-client-ahs", function(a, c, b, d) {
        return {
            log: function(f, e) {
                if (e && e.metricKey && e.asin) {
                    var h;
                    a: {
                        h = e.asin;
                        var g = c.getDeviceType();
                        if (h = c.getAsinState(h))
                            if (h = h.canBeSelected, g === d.DEVICE_TYPES.MOBILE_WEB) {
                                h = h ? "mao" :
                                    "maosm";
                                break a
                            } else if (g === d.DEVICE_TYPES.MOBILE_APP) {
                            h = h ? "aao" : "aaosm";
                            break a
                        }
                        h = null
                    }
                    if (h && (g = "vas_" + h + "_", e = "vas_" + e.metricKey + "_" + h + "_", h = {
                            pageType: "DetailPage",
                            subPageType: "AddServices"
                        }, f)) {
                        var n = !0;
                        switch (f) {
                            case d.ADD_TO_CART:
                                g += "att";
                                e += "att";
                                break;
                            case d.ASIN_INCLUDED:
                                g += "incl";
                                e += "incl";
                                break;
                            case d.ASIN_EXCLUDED_AFTER_INCLUDED:
                                g += "cncl";
                                e += "cncl";
                                break;
                            case d.CLICKED:
                                g += "clk";
                                e += "clk";
                                break;
                            case d.GLANCE_VIEW:
                                g += "gv";
                                e += "gv";
                                break;
                            case d.GLANCE_VIEW_NOT_ON_PRIMARY_SHEET:
                                g += "gvs";
                                e += "gvs";
                                break;
                            case d.PRE_CHECKED_ASIN:
                                g += "pre";
                                e += "pre";
                                break;
                            case d.REDIRECT:
                                g += "redir";
                                e += "redir";
                                break;
                            default:
                                n = !1
                        }
                        n && (b.postCountMetric(g), e && 32 >= e.length && (f = "?", g = "", h && (h.pageType && (g += f + "pageType\x3d" + h.pageType, f = "\x26"), h.subPageType && (g += f + "subPageType\x3d" + h.subPageType)), a.get("/gp/ls/impress.html/ref\x3d" + e + g)))
                    }
                }
            }
        }
    });
    g.when("A", "postMetric", "addons-metrics-type").register("addons-metrics-client-psd", function(a, c, b) {
        return {
            log: function(a, b) {}
        }
    });
    (function(a, c) {
        function b(a) {
            return !!("" === a ||
                a && a.charCodeAt && a.substr)
        }

        function d(a) {
            return A ? A(a) : "[object Array]" === r.call(a)
        }

        function f(a) {
            return "[object Object]" === r.call(a)
        }

        function e(a, b) {
            var c;
            a = a || {};
            b = b || {};
            for (c in b) b.hasOwnProperty(c) && null == a[c] && (a[c] = b[c]);
            return a
        }

        function g(a, b, c) {
            var d = [],
                e, f;
            if (!a) return d;
            if (m && a.map === m) return a.map(b, c);
            e = 0;
            for (f = a.length; e < f; e++) d[e] = b.call(c, a[e], e, a);
            return d
        }

        function l(a, b) {
            a = Math.round(Math.abs(a));
            return isNaN(a) ? b : a
        }

        function n(a) {
            var c = k.settings.currency.format;
            "function" === typeof a &&
                (a = a());
            return b(a) && a.match("%v") ? {
                pos: a,
                neg: a.replace("-", "").replace("%v", "-%v"),
                zero: a
            } : a && a.pos && a.pos.match("%v") ? a : b(c) ? k.settings.currency.format = {
                pos: c,
                neg: c.replace("%v", "-%v"),
                zero: c
            } : c
        }
        var k = {
                version: "0.4.1",
                settings: {
                    currency: {
                        symbol: "$",
                        format: "%s%v",
                        decimal: ".",
                        thousand: ",",
                        precision: 2,
                        grouping: 3
                    },
                    number: {
                        precision: 0,
                        grouping: 3,
                        thousand: ",",
                        decimal: "."
                    }
                }
            },
            m = Array.prototype.map,
            A = Array.isArray,
            r = Object.prototype.toString,
            w = k.unformat = k.parse = function(a, b) {
                if (d(a)) return g(a, function(a) {
                    return w(a,
                        b)
                });
                a = a || 0;
                if ("number" === typeof a) return a;
                b = b || ".";
                var c = RegExp("[^0-9-" + b + "]", ["g"]),
                    c = parseFloat(("" + a).replace(/\((.*)\)/, "-$1").replace(c, "").replace(b, "."));
                return isNaN(c) ? 0 : c
            },
            v = k.toFixed = function(a, b) {
                b = l(b, k.settings.number.precision);
                var c = Math.pow(10, b);
                return (Math.round(k.unformat(a) * c) / c).toFixed(b)
            },
            u = k.formatNumber = k.format = function(a, b, c, n) {
                if (d(a)) return g(a, function(a) {
                    return u(a, b, c, n)
                });
                a = w(a);
                var m = e(f(b) ? b : {
                        precision: b,
                        thousand: c,
                        decimal: n
                    }, k.settings.number),
                    t = l(m.precision),
                    p = 0 > a ? "-" : "",
                    q = parseInt(v(Math.abs(a || 0), t), 10) + "",
                    y = 3 < q.length ? q.length % 3 : 0;
                return p + (y ? q.substr(0, y) + m.thousand : "") + q.substr(y).replace(/(\d{3})(?=\d)/g, "$1" + m.thousand) + (t ? m.decimal + v(Math.abs(a), t).split(".")[1] : "")
            },
            C = k.formatMoney = function(a, b, c, m, r, t) {
                if (d(a)) return g(a, function(a) {
                    return C(a, b, c, m, r, t)
                });
                a = w(a);
                var p = e(f(b) ? b : {
                        symbol: b,
                        precision: c,
                        thousand: m,
                        decimal: r,
                        format: t
                    }, k.settings.currency),
                    q = n(p.format);
                return (0 < a ? q.pos : 0 > a ? q.neg : q.zero).replace("%s", p.symbol).replace("%v", u(Math.abs(a),
                    l(p.precision), p.thousand, p.decimal))
            };
        k.formatColumn = function(a, c, m, r, v, t) {
            if (!a) return [];
            var p = e(f(c) ? c : {
                    symbol: c,
                    precision: m,
                    thousand: r,
                    decimal: v,
                    format: t
                }, k.settings.currency),
                q = n(p.format),
                y = q.pos.indexOf("%s") < q.pos.indexOf("%v") ? !0 : !1,
                x = 0;
            a = g(a, function(a) {
                if (d(a)) return k.formatColumn(a, p);
                a = w(a);
                a = (0 < a ? q.pos : 0 > a ? q.neg : q.zero).replace("%s", p.symbol).replace("%v", u(Math.abs(a), l(p.precision), p.thousand, p.decimal));
                a.length > x && (x = a.length);
                return a
            });
            return g(a, function(a) {
                return b(a) && a.length <
                    x ? y ? a.replace(p.symbol, p.symbol + Array(x - a.length + 1).join(" ")) : Array(x - a.length + 1).join(" ") + a : a
            })
        };
        "undefined" !== typeof exports ? ("undefined" !== typeof module && module.exports && (exports = module.exports = k), exports.accounting = k) : "function" === typeof define && define.amd ? define([], function() {
            return k
        }) : (k.noConflict = function(b) {
            return function() {
                a.accounting = b;
                k.noConflict = c;
                return k
            }
        }(a.accounting), a.accounting = k)
    })(this)
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageEstimatedExtraTaxAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(h) {
    var g = window.AmazonUIPageJS || window.P,
        m = g._namespace || g.attributeErrors,
        e = m ? m("DetailPagePrePurchaseSupportAssets", "") : g;
    e.guardFatal ? e.guardFatal(h)(e, window) : e.execute(function() {
        h(e, window)
    })
})(function(h, g, m) {
    h.when("A", "ready").execute("triggerWeblab", function(e) {
        var a = !1,
            f = e.$;
        e.on("scroll", function() {
            var d;
            if (d = 0 != e.$("#PrePurchaseSupport_Template_Div").length)
                if (f("#aboutThisItem_feature_div").length) {
                    d = f("#aboutThisItem_feature_div").offset().top;
                    var c = f(g).scrollTop() + f(g).height();
                    d = d < c
                } else d = !1;
            d && !a && (e.$.post("/gp/detailpage/hardlines-util/get-treatment-and-record-weblabs.html", {
                weblabs: "DP_PRE_PURCHASE_SUPPORT_169891"
            }), a = !0)
        })
    });
    "use strict";
    h.when("A", "prePurchaseSupportConstants", "postMetric", "prePurchaseSupportUtils", "prePurchaseSupportMetricConstants", "redirect-url", "atf", "ready").execute("ppsT2Variant", function(e, a, f, d, c, n) {
        var b = e.$,
            p = !1,
            k = !1,
            l;
        0 != b(a.prePurchaseSupportTemplateDiv).length && b.ajax({
            dataType: "json",
            async: !1,
            traditional: !0,
            timeout: 5E3,
            url: "/gp/detailpage/hardlines-util/get-sembu-boolean-value.html",
            success: function(a) {
                1 == a && (k = !0)
            },
            error: function(a) {
                f.postCountMetric(c.SEMBU_GET_CALL_FAILED)
            }
        });
        k && (b(a.ppsStaticIngressId).removeClass(a.aokHiddenClass), b(a.ppsFabEnableCheckBox).removeClass(a.aokHiddenClass), b(a.ppsFabDismissCheckBox).addClass(a.aokHiddenClass));
        d.isCustomerLoggedInFromBottomSheet() && d.isCustomerAuthenticated() && (d.logWidgetImpression(c.LOG_KEY_FAB_SIGNIN), b(a.floatingActionButtonDiv).trigger("click"), d.initiatePrePurchaseSupport(), d.removeUserLoggedInQueryParam());
        e.on("scroll",
            function() {
                b(a.prePurchaseSupportTemplateDiv).removeClass(a.hiddenClass);
                b(a.prePurchaseSupportTemplateDiv).removeClass("a-box");
                0 != b(a.prePurchaseSupportTemplateDiv).length && d.isBelow(a.aboutThisItemDiv) ? (p || d.isCustomerLoggedInFromBottomSheet() || (p = !0, k || (f.postCountMetric(c.METRIC_FLOATING_WIDGET_SHOWN_ONCE), d.logWidgetImpression(c.LOG_KEY_FAB_SHOWN))), k || b(a.floatingActionButtonDiv).show()) : b(a.floatingActionButtonDiv).hide()
            });
        b(a.phoneNumberDiv).focus(function() {
            b(a.inputBoxWrapperClass).removeClass(a.auiErrorClass);
            b(a.errorMessageDiv).addClass(a.aokHiddenClass)
        });
        b("input[name\x3dprePurchaseSupportCheckbox]").change(function() {
            b(this).is(":checked") ? b(a.confirmText).removeClass(a.aokHiddenClass) : b(a.confirmText).addClass(a.aokHiddenClass)
        });
        b(a.confirmDismissFabClass).click(function(e) {
            k ? (b.ajax({
                    url: "/gp/detailpage/hardlines-util/set-sembu-boolean-value.html?reset\x3d1",
                    success: function(a, b, e) {
                        d.logWidgetImpression(c.LOG_KEY_FAB_RETAIN)
                    },
                    error: function(a) {
                        f.postCountMetric(c.SEMBU_SET_CALL_FAILED)
                    }
                }), b(a.floatingActionButtonDiv).show(),
                k = !1, h.when("a-sheet").execute("dismissBottomSheet", function(b) {
                    b.get(a.operationHoursContainerName).hide()
                }), b(a.ppsStaticIngressId).addClass(a.aokHiddenClass)) : (b.ajax({
                url: "/gp/detailpage/hardlines-util/set-sembu-boolean-value.html",
                success: function(a, b, e) {
                    f.postCountMetric(c.METRIC_DISMISS_CONFIRMED);
                    d.logWidgetImpression(c.LOG_KEY_FAB_DISMISS)
                },
                error: function(a) {
                    f.postCountMetric(c.SEMBU_SET_CALL_FAILED)
                }
            }), b(a.floatingActionButtonDiv).hide(), k = !0, h.when("a-sheet").execute("dismissBottomSheet",
                function(b) {
                    b.get(a.operationHoursContainerName).hide()
                }), b(a.ppsStaticIngressId).removeClass(a.aokHiddenClass))
        });
        b(a.floatingActionButtonDiv).click(function(c) {
            l = m;
            k || (b(a.ppsStaticIngressId).addClass(a.aokHiddenClass), b(a.ppsFabEnableCheckBox).addClass(a.aokHiddenClass), b(a.ppsFabDismissCheckBox).removeClass(a.aokHiddenClass));
            e.state(a.pageStateName) && e.state(a.pageStateName).inCallWindow && (d.fillFeedbackStars(), d.hideAllInferenceMessages(), b(a.feedbackErrorTextClass).addClass(a.aokHiddenClass),
                d.initiatePrePurchaseSupport())
        });
        b(a.unsignedProceedButtonClass).click(function(b) {
            f.postCountMetric(c.METRIC_SIGNIN_TO_CONTINUE);
            b = g.location.search;
            b = b.replace("?", "");
            b += a.userLoggedInQueryParam;
            b = e.$.param({
                useRedirectOnSuccess: 1,
                path: g.location.pathname,
                query: b
            });
            n.redirect("/gp/sign-in.html?" + b)
        });
        b(a.callMeNowButtonClass).click(function(c) {
            c = b(a.phoneNumberDiv).val();
            d.isValidPhoneNumber(c) ? d.initiateCallBackForNumber(c) : (b(a.inputBoxWrapperClass).addClass(a.auiErrorClass), b(a.errorMessageDiv).removeClass(a.aokHiddenClass))
        });
        b(a.cancelCallButtonClass).click(function(a) {
            d.disconnectCall()
        });
        b(a.feedbackStarClass).click(function() {
            b(a.feedbackErrorTextClass).addClass(a.aokHiddenClass);
            d.hideAllInferenceMessages();
            l == this.id[this.id.length - 1] ? (l = m, b(a.feedbackErrorTextClass).removeClass(a.aokHiddenClass)) : (l = this.id[this.id.length - 1], d.showInferenceMessage(l));
            d.fillFeedbackStars(l)
        });
        b(a.staticIngressTouchLink).click(function() {
            l = m;
            b(a.ppsFabDismissCheckBox).addClass(a.aokHiddenClass);
            b(a.ppsFabEnableCheckBox).removeClass(a.aokHiddenClass);
            e.state(a.pageStateName) && e.state(a.pageStateName).inCallWindow && (d.fillFeedbackStars(), d.hideAllInferenceMessages(), b(a.feedbackErrorTextClass).addClass(a.aokHiddenClass), d.initiatePrePurchaseSupport())
        });
        h.when("a-sheet").execute("ppsSheetCloseEventListner", function(g) {
            e.on("a:sheet:afterHide:pre-purchase-support-bottom-sheet-container", function(e) {
                b(a.feedbackScreen).hasClass(a.aokHiddenClass) || (b(a.feedbackScreen).addClass(a.aokHiddenClass), l != m ? d.logWidgetImpression(c.LOG_KEY_FAB_FEEDBACK + l) :
                    d.logWidgetImpression(c.LOG_KEY_FAB_FEEDBACK + a.ZERO), f.postCountMetric(c.METRIC_STAR_RATING + ":" + l))
            })
        });
        e.declarative("a-sheet", "click", function(b) {
            b.data.name === a.operationHoursContainerName ? (f.postCountMetric(c.METRIC_OPERATIONAL_HOURS_BOTTOM_SHEET_COUNT), f.postCountMetric(c.METRIC_FLOATING_WIDGET_CLICKED), k ? d.logWidgetImpression(c.LOG_KEY_STATIC_CLICKED) : d.logWidgetImpression(c.LOG_KEY_FAB_CLICKED)) : b.data.name === a.afterHoursContainerName && (f.postCountMetric(c.METRIC_AFTER_HOURS_BOTTOM_SHEET_COUNT),
                f.postCountMetric(c.METRIC_FLOATING_WIDGET_CLICKED), k ? d.logWidgetImpression(c.LOG_KEY_STATIC_CLICKED) : d.logWidgetImpression(c.LOG_KEY_FAB_CLICKED))
        });
        b(a.prePurchaseSupportHelpLinkDiv).click(function(a) {
            f.postCountMetric(c.METRIC_HELP_LINK_CLICKED)
        })
    });
    h.when("A", "ready").register("weblabUtils", function(e) {
        return {
            triggerWeblab: function() {
                e.$.post("/gp/detailpage/hardlines-util/get-treatment-and-record-weblabs.html", {
                    weblabs: "DP_PRE_PURCHASE_SUPPORT_169891"
                })
            }
        }
    });
    h.when("A", "prePurchaseSupportConstants",
        "prePurchaseSupportMetricConstants", "postMetric", "ready").register("prePurchaseSupportUtils", function(e, a, f, d) {
        var c = e.$,
            n, b = a.bottomSheetSections.screens[1],
            p = "undefined",
            k = !1,
            l = function(c, d) {
                e.ajax(c, {
                    method: "get",
                    cache: !1,
                    contentType: "application/json",
                    success: function(a, b, c) {
                        d(a)
                    },
                    error: function(c) {
                        q(a.bottomSheetSections.screens[4]);
                        b = a.bottomSheetSections.screens[1];
                        r(f.LOG_KEY_CALL_FAILURE)
                    }
                })
            },
            q = function(b) {
                for (var d = a.bottomSheetSections.screens.length, e = 0; e < d; e++) c("#" + a.bottomSheetSections.screens[e]).addClass("aok-hidden");
                c("#" + b).removeClass("aok-hidden")
            },
            v = function(c) {
                switch (c) {
                    case a.callState.DIALING:
                        return b = a.bottomSheetSections.screens[2], n = a.callState.DIALINGclear, k = !1;
                    case a.callState.CONNECTED:
                        return b = a.bottomSheetSections.screens[3], k = !0, a.callState.CONNECTED != n && (q(b), r(f.LOG_KEY_CALL_SUCCESS), u("#" + a.operationHoursContainerName), d.postCountMetric(f.METRIC_CALL_CONNECTED)), n = a.callState.CONNECTED, !1;
                    case a.callState.DISCONNECTED:
                        return k ? (b = a.bottomSheetSections.screens[5], q(b)) : A(), b = a.bottomSheetSections.screens[1],
                            n = a.callState.DISCONNECTED, d.postCountMetric(f.METRIC_CALL_DISCONNECTED), !0;
                    default:
                        return !1
                }
            },
            A = function() {
                h.when("a-sheet").execute("close-sheet", function(b) {
                    b.get(a.operationHoursContainerName).hide()
                })
            },
            u = function(a) {
                c(a).length && c(a).scrollTop(0)
            },
            w = function(e, t) {
                c.ajax({
                    url: e,
                    data: {
                        Operation: "getCallStatus",
                        callContextId: t,
                        supportAgentJoined: !0,
                        ContentType: "JSON"
                    },
                    dataType: "json",
                    success: function(c, g, h) {
                        try {
                            null == c || null == c.getCallStatusResponse || null == c.getCallStatusResponse.getCallStatusResult ||
                                v(c.getCallStatusResponse.getCallStatusResult.callStatusCode) || w(e, t)
                        } catch (k) {
                            d.postCountMetric(f.C2C_API_PARSE_RESPONSE_ERROR), b = a.bottomSheetSections.screens[1]
                        }
                    },
                    error: function(c) {
                        d.postCountMetric(f.C2C_API_FAILED);
                        b = a.bottomSheetSections.screens[1]
                    }
                })
            },
            B = function(e, t) {
                c.ajax({
                    url: e,
                    data: {
                        Operation: "disconnectCall",
                        callContextId: t,
                        supportAgentJoined: !0,
                        ContentType: "JSON"
                    },
                    dataType: "json",
                    success: function(a, b, c) {
                        d.postCountMetric(f.METRIC_CALL_DISCONNECTED);
                        t = "NA"
                    },
                    error: function(c) {
                        d.postCountMetric(f.C2C_API_FAILED);
                        b = a.bottomSheetSections.screens[1]
                    }
                })
            },
            x = function() {
                return c("#" + a.bottomSheetSections.screens[1]).hasClass(a.loginTrue)
            },
            y = function() {
                return c(a.proceedButton).hasClass(a.signedProceedButtonClass.substring(1))
            },
            r = function(b) {
                var d = e.state(a.pageStateName) ? e.state(a.pageStateName).asin : "";
                b && 32 >= b.length && d && c.get("/gp/detailpage/pps/recordImpressions.html/ref\x3d" + b + "?pageTypeId\x3d" + d)
            },
            z = function() {
                for (var b = 1; 5 >= b; b++) c(a.ppsInferenceStarMessageClass + b).addClass(a.aokHiddenClass)
            };
        return {
            isBelow: function(a) {
                if (c(a).length) {
                    a =
                        c(a).offset().top;
                    var b = c(g).scrollTop() + c(g).height();
                    return a < b
                }
                return !1
            },
            isValidPhoneNumber: function(b) {
                return b && null != b.match(a.findNumberRegex) ? 10 === b.match(a.findNumberRegex).length && "0" != b[0] : !1
            },
            isCustomerLoggedInFromBottomSheet: x,
            isCustomerAuthenticated: y,
            logWidgetImpression: r,
            initiatePrePurchaseSupport: function() {
                c("#" + a.operationHoursContainerName).removeClass(a.aokHiddenClass);
                c(a.phoneNumberDiv).val(a.defaultCallBackNumber);
                c("input[name\x3dprePurchaseSupportCheckbox]").prop("checked", !1);
                c(a.confirmText).addClass(a.aokHiddenClass);
                y() || n && (!n || n !== a.callState.DISCONNECTED) || (b = a.bottomSheetSections.screens[0]);
                q(b)
            },
            initiateCallBackForNumber: function(c) {
                b = a.bottomSheetSections.screens[2];
                var g = e.state(a.pageStateName) ? e.state(a.pageStateName).c2cId : "",
                    h = e.state(a.pageStateName) ? e.state(a.pageStateName).asin : "";
                c = a.callParameters.CALL_URL + "/?callContextId\x3d" + a.callParameters.CALL_CONTEXT_ID + "\x26token\x3d" + a.callParameters.TOKEN + "\x26pollId\x3d" + a.callParameters.POLL_ID + "\x26c2cId\x3d" +
                    g + "\x26callbackNumber\x3d" + c + "\x26asin\x3d" + h + "\x26pollResponseType\x3d" + a.callParameters.POLL_RESPONSE_TYPE + "\x26routeThroughReceptionist\x3d" + a.callParameters.ROUTE_THROUGH_RECEPTIONIST + "\x26screenShareRequested\x3d" + a.callParameters.SCREEN_SHARE_REQUESTED + "\x26extension\x3d" + a.callParameters.EXTENSION + "\x26callAfterMins\x3d" + a.callParameters.CALL_AFTER_MINS + "\x26country\x3d" + a.callParameters.COUNTRY + "\x26virtualCall\x3d" + a.callParameters.VIRTUAL_CALL;
                x() ? r(f.LOG_KEY_CALL_PLACED_AFTER_SIGNIN) : r(f.LOG_KEY_CALL_PLACED);
                d.postCountMetric(f.METRIC_CALL_PLACED);
                l(c, function(c) {
                    try {
                        null != c && null != c.response && c.response.contextId ? (p = c.response.contextId, w(a.jsonpURL, p)) : (q(a.bottomSheetSections.screens[4]), b = a.bottomSheetSections.screens[1], r(f.LOG_KEY_CALL_FAILURE))
                    } catch (d) {}
                });
                q(b);
                u("#" + a.operationHoursContainerName)
            },
            disconnectCall: function() {
                B(a.jsonpURL, p)
            },
            removeUserLoggedInQueryParam: function() {
                try {
                    g.history.replaceState(null, null, g.location.search.replace(a.userLoggedInQueryParam, ""))
                } catch (b) {
                    d.postCountMetric(f.FAILED_TO_REMOVE_QUERY_PARAM)
                }
            },
            hasCallEndedAndUpdateUI: v,
            scrollToTop: u,
            fillFeedbackStars: function(b) {
                if (b == m || 1 > b || 5 < b)
                    for (var d = 1; 5 >= d; d++) c(a.ppsStarId + d).removeClass(a.feedbackSelectedStar).addClass(a.feedbackUnSelectedStar);
                else
                    for (d = 1; 5 >= d; d++) d <= b ? c(a.ppsStarId + d).removeClass(a.feedbackUnSelectedStar).addClass(a.feedbackSelectedStar) : c(a.ppsStarId + d).removeClass(a.feedbackSelectedStar).addClass(a.feedbackUnSelectedStar)
            },
            showInferenceMessage: function(b) {
                z();
                b != m && 1 <= b && 5 >= b && c(a.ppsInferenceStarMessageClass + b).removeClass(a.aokHiddenClass)
            },
            hideAllInferenceMessages: z
        }
    });
    h.when("A").register("redirect-url", function(e) {
        var a = function(a) {
            g.amazon && g.amazon.mash ? g.amazon.mash.navigate({
                url: a
            }) : g.location.href = a
        };
        e.declarative("redirect-to-url", "click", function(e) {
            a(e.data.url)
        });
        return {
            redirect: a
        }
    });
    "use strict";
    h.when("A", "ready").register("prePurchaseSupportMetricConstants", function(e) {
        return {
            METRIC_FLOATING_WIDGET_SHOWN_ONCE: "mitraFloatingWidgetShown",
            METRIC_OPERATIONAL_HOURS_BOTTOM_SHEET_COUNT: "mitraOperationalHoursBottomSheetShown",
            METRIC_AFTER_HOURS_BOTTOM_SHEET_COUNT: "mitraAfterHoursBottomSheetShown",
            METRIC_PROCEED_TO_CONTINUE: "mitraProceedToContinue",
            METRIC_FLOATING_WIDGET_CLICKED: "mitraFloatingWidgetClicked",
            METRIC_HELP_LINK_CLICKED: "mitraHelpLinkClicked",
            METRIC_SIGNIN_TO_CONTINUE: "mitraSignInToContinue",
            METRIC_DISMISS_CONFIRMED: "mitraDismissConfirmed",
            METRIC_CALL_PLACED: "mitraCallPlaced",
            METRIC_CALL_DISCONNECTED: "mitraCallDisconnected",
            METRIC_CALL_CONNECTED: "mitraCallConnected",
            METRIC_STAR_RATING: "mitraStarRating",
            SEMBU_SET_CALL_FAILED: "mitraSembuSetCallFailed",
            SEMBU_GET_CALL_FAILED: "mitraSembuGetCallFailed",
            LOG_KEY_FAB_SHOWN: "dp_fab",
            LOG_KEY_FAB_CLICKED: "dp_fab_click",
            LOG_KEY_CALL_PLACED: "dp_fab_call",
            LOG_KEY_CALL_SUCCESS: "dp_fab_call_1",
            LOG_KEY_CALL_FAILURE: "dp_fab_call_0",
            LOG_KEY_FAB_SIGNIN: "dp_fab_signin",
            LOG_KEY_STATIC_CLICKED: "dp_pps_static_click",
            LOG_KEY_CALL_PLACED_AFTER_SIGNIN: "dp_fab_signin_call",
            LOG_KEY_FAB_FEEDBACK: "dp_fab_fdbck_",
            LOG_KEY_FAB_DISMISS: "dp_fab_hide",
            LOG_KEY_FAB_RETAIN: "dp_fab_show",
            C2C_API_PARSE_RESPONSE_ERROR: "mitraC2cApiParseResponseError",
            C2C_API_FAILED: "mitraC2cApiFailure",
            FAILED_TO_REMOVE_QUERY_PARAM: "mitraRemovingQueryParamsFailure",
            METRIC_CHAT_FLOATING_WIDGET_SHOWN_ONCE: "mitraChatFloatingWidgetShown",
            LOG_KEY_CHAT_FAB_SHOWN: "dp_chat_fab",
            METRIC_CHAT_LINK_CLICKED: "chatBotLinkClicked"
        }
    });
    "use strict";
    h.when("A", "ready").register("prePurchaseSupportConstants", function(e) {
        return {
            aboutThisItemDiv: "#aboutThisItem_feature_div",
            floatingActionButtonDiv: ".fab",
            signedProceedButtonClass: ".ppsSigned",
            unsignedProceedButtonClass: ".ppsUnsigned",
            prePurchaseSupportTemplateDiv: "#PrePurchaseSupport_Template_Div",
            prePurchaseSupportHelpLinkDiv: "#prePurchaseSupportHelpLink",
            operationHoursContainerName: "pre-purchase-support-bottom-sheet-container",
            afterHoursContainerName: "pre-purchase-support-bottom-sheet-container-outHours",
            callMeNowButtonClass: ".ppsCallMeNowButton",
            cancelCallButtonClass: ".ppsCancelCall",
            errorMessageDiv: ".ppsNumberErrorMessage",
            phoneNumberDiv: "#ppsInputPhoneNumber",
            confirmText: ".ppsConfirmText",
            dismissBottomSheetClass: ".dismissBottomSheet",
            confirmDismissFabClass: ".confirmDismissFab",
            inputBoxWrapperClass: ".ppswrapperdiv",
            aokHiddenClass: "aok-hidden",
            auiErrorClass: "a-form-error",
            jsonpURL: "https://c2c-eu.amazon.com",
            proceedButton: "#ppsProceedButton",
            loginTrue: "pps-login-true",
            userLoggedInQueryParam: "\x26ppsUserLoggedIn\x3d1",
            hiddenClass: "a-hidden",
            feedbackSelectedStar: "a-icon-star-large-full",
            feedbackUnSelectedStar: "a-icon-star-large",
            feedbackStarClass: ".ppsFeedbackStars",
            feedbackErrorTextClass: ".ppsFeedbackErrorText",
            feedbackScreen: "#ppsFeedbackScreen",
            ppsStarId: "#ppsStar",
            ppsInferenceStarMessageClass: ".ppsInferenceStar",
            ppsStaticIngressId: "#ppsStaticIngress",
            ppsFabEnableCheckBox: ".enableFabCheckbox",
            ppsFabDismissCheckBox: ".dismissFabCheckbox",
            staticIngressTouchLink: ".ppsStaticIngressTouchLink",
            ZERO: "0",
            initiatePrePurchaseSupportLinkId: "#initiatePrePurchaseSupportLinkId",
            initiateChatPrePurchaseSupportLinkId: "#initiateChatPrePurchaseSupportLinkId",
            chatCallLinkCss: "a.chatCallLinkCss",
            callState: {
                DIALING: "DIALING",
                CONNECTED: "CONNECTED",
                DISCONNECTED: "DISCONNECTED"
            },
            bottomSheetSections: {
                screens: "ppsSignInToContinueScreen ppsCallMeNowScreen ppsConnectingScreen ppsConnectedScreen ppsErrorScreen ppsFeedbackScreen ppsChatCallMeNowScreen".split(" ")
            },
            callParameters: {
                CALL_URL: "/gp/detailpage/hardlines-util/initiate-trusted-call.html",
                CALL_CONTEXT_ID: "",
                TOKEN: "",
                POLL_ID: "",
                POLL_RESPONSE_TYPE: "",
                ROUTE_THROUGH_RECEPTIONIST: "false",
                SCREEN_SHARE_REQUESTED: "0",
                EXTENSION: "",
                CALL_AFTER_MINS: "0",
                COUNTRY: "IN",
                VIRTUAL_CALL: "false"
            },
            findNumberRegex: RegExp(/\d/g),
            pageStateName: "ppsModel",
            defaultCallBackNumber: e.$("#ppsInputPhoneNumber").length ? e.$("#ppsInputPhoneNumber").val() : ""
        }
    })
});
/* ******** */
(function(k) {
    var f = window.AmazonUIPageJS || window.P,
        u = f._namespace || f.attributeErrors,
        c = u ? u("DetailPageMiniDPAssets", "") : f;
    c.guardFatal ? c.guardFatal(k)(c, window) : c.execute(function() {
        k(c, window)
    })
})(function(k, f, u) {
    k.when("A", "ready").register("hctp-configs", function(c) {
        var f = c.$;
        return {
            getHctpConfig: function() {
                var a = f("#hctpConfigStateData").data(),
                    d = "";
                if (!a) return null;
                "mApp" === a.deviceType && (d = a.verificationSessionId);
                return {
                    marketplaceId: a.marketplaceId,
                    customerId: a.customerId,
                    sessionId: a.sessionId,
                    languageOfPreference: a.languageOfPreference,
                    baseAsin: a.baseAsin,
                    baseAsinOfferListingId: a.baseAsinOfferListingId,
                    baseAsinThumbnailUrl: a.baseAsinThumbnailUrl,
                    attachEligible: a.attachEligible,
                    deviceType: a.deviceType,
                    itemsTitle: a.itemsTitle,
                    itemTitle: a.itemTitle,
                    verificationSessionId: d,
                    csrfAddCart: a.csrfAddCart,
                    csrfCartDesc: a.csrfCartDesc
                }
            }
        }
    });
    k.when("A", "hctp-configs", "postMetric", "ready").register("hctp-utils", function(c, n, a) {
        function d() {
            g("#hctp-attach-bottom-sheet .attach-cart-info").show();
            g("#hctp-attach-bottom-sheet .attach-cart-info-spinner").hide()
        }

        function h(e, a) {
            var b = g("#upsell-atc-container-" + a);
            if (!b) return null;
            g(b).children(".attach-atc-spinner").hide();
            e ? (g(b).children(".attach-atc").hide(), g(b).children(".upsell-asin-success").show()) : g(b).children(".attach-atc").show()
        }

        function b(e) {
            e ? (g("#hctp-attach-bottom-sheet .added-to-cart-success").show(), g("#hctp-attach-bottom-sheet .added-to-cart-error").hide()) : (g("#hctp-attach-bottom-sheet .added-to-cart-success").hide(), g("#hctp-attach-bottom-sheet .added-to-cart-error").show());
            g("#hctp-attach-bottom-sheet .atc-error-msg").hide()
        }

        function r(e) {
            k.when("mash").execute(function(b) {
                b.cart.didUpdate({
                    newCartQuantity: e
                })
            });
            k.when("nav.setCartCount").execute(function(b) {
                b(e)
            })
        }

        function l(e, a, d, p) {
            if (e) {
                e = d.itemQuantity;
                d = d.formattedTotalPrice;
                a = n.getHctpConfig();
                var c = "",
                    c = 1 >= e ? a.itemTitle : a.itemsTitle;
                g("#hctp-attach-bottom-sheet .attach-cart-quantity").html(e + " " + c);
                g("#hctp-attach-bottom-sheet .attach-cart-value").html(d);
                h(!0, p);
                b(!0)
            } else h(!1, p), b(!1)
        }

        function p(e, b, a) {
            try {
                r(e.itemQuantity), 0 < parseInt(e.totalPrice, 10) ? l(!0,
                    b.accessoryItemAsin, e, a) : l(!1, b.accessoryItemAsin)
            } catch (d) {
                l(!1, b.accessoryItemAsin, u, a)
            }
        }

        function q(e) {
            a.postCountMetric(e)
        }
        var g = c.$;
        return {
            addToCart: function(e, a, g) {
                a || (a = n.getHctpConfig());
                var l = {
                    marketplaceId: a.marketplaceId,
                    sessionId: a.sessionId,
                    languageOfPreference: a.languageOfPreference,
                    asin: a.baseAsin,
                    accessoryItemAsin: e.accessoryItemAsin,
                    accessoryItemOfferingId: e.accessoryItemOfferingId,
                    accessoryItemQuantity: e.accessoryItemQuantity,
                    csrf: a.csrfAddCart
                };
                l.customerId = a.customerId ? a.customerId :
                    "";
                c.post("/gp/product/features/aloha-ppd/udp-ajax-handler/attach-add-to-cart.html", {
                    params: l,
                    success: function(e) {
                        p(e, l, g);
                        d();
                        "mApp" === a.deviceType && f.amazon && f.amazon.cordova && f.amazon.cordova.notification && f.amazon.cordova.notification.vibrate && f.amazon.cordova.notification.vibrate(50);
                        q("hctpATCSuccess")
                    },
                    error: function() {
                        h(!1, g);
                        b(!1);
                        d();
                        q("hctpATCFailure")
                    }
                })
            },
            moveDomContent: function(e, a) {
                var b = c.$("#".concat(a)),
                    d = c.$("#".concat(e));
                try {
                    d.addClass("aok-hidden"), b.append(d)
                } catch (p) {
                    q("HCTPMoveDomContentFailure.")
                }
            },
            registerRefTag: function(e) {
                g.get("/gp/product/ajax-handlers/reftag.html/ref\x3d" + e)
            },
            logMetric: q,
            baseAsinAddtoCartInfo: function(e, a) {
                e || (e = n.getHctpConfig());
                if (e) {
                    var g = {
                        marketplaceId: e.marketplaceId,
                        sessionId: e.sessionId,
                        languageOfPreference: e.languageOfPreference,
                        asin: e.baseAsin,
                        csrf: e.csrfCartDesc
                    };
                    g.customerId = e.customerId ? e.customerId : "";
                    c.post("/gp/product/features/aloha-ppd/udp-ajax-handler/attach-get-cart-description.html", {
                        params: g,
                        success: function(e) {
                            p(e, g, a);
                            d();
                            q("HCTPSuccessToAddtoCartBaseASIN")
                        },
                        error: function() {
                            h(!1, a);
                            b(!1);
                            d();
                            q("HCTPFailureToAddtoCartBaseASIN")
                        }
                    })
                }
            },
            manualLoadImages: function() {
                var e = g("#hctp-attach-bottom-sheet .upsell-asin-item");
                c.loadImageManually(e.find(".upsell-asin-image"))
            },
            getAccessoryDataForMetrics: function(e, a, b) {
                return {
                    sessionId: a.sessionId,
                    baseAsin: a.baseAsin,
                    customerId: a.customerId,
                    refMarker: b,
                    attachAsin: e.accessoryItemAsin,
                    attachAsinPrice: e.accessoryItemPrice
                }
            },
            getBaseAsinData: function(a, b) {
                return {
                    sessionId: a.sessionId,
                    baseAsin: a.baseAsin,
                    customerId: a.customerId,
                    refMarker: b
                }
            },
            logBottomSheetRenderingMetrics: function(a) {
                f.ue && f.ue.event && f.ue.event(a, "hctp-attach", "hctpAttach.MBSRenderingExperience.1")
            },
            logCustomerEngagementMetrics: function(a) {
                f.ue && f.ue.event && f.ue.event(a, "hctp-attach", "hctpAttach.customerEngagement.3")
            }
        }
    });
    "use strict";
    k.when("A", "hctp-utils", "a-secondary-view", "a-carousel-framework", "hctp-configs").execute(function(c, f, a, d, h) {
        var b = c.$,
            r = null,
            l = "";
        d.onInit("mini-dp-carousel", function(a) {
            r = a;
            a = r.dom.$container;
            a.length && (c.loadImageManually(a.find(".mini-dp-carousel-images")),
                l = a.parent().find(".hctp-pagination"))
        });
        c.on("a:carousel:mini-dp-carousel:change:pageNumber", function(a) {
            if (a.newValue) {
                a = a.newValue;
                var b = l.find("li");
                0 < b.length && (b.removeClass("a-selected"), b.eq(a - 1).addClass("a-selected"))
            }
        });
        b(".hctp-pagination li").click(function() {
            var a = b(this).data("img-key");
            isNaN(a) || r.gotoPage(a)
        });
        c.declarative("a-secondary-view", "click", function(a) {
            if (a.data && a.data.hctpMiniDp) {
                var b = a.data.name,
                    g = "a:popover:show:" + b,
                    e = a.data.offerPrice,
                    k = h.getHctpConfig();
                c.off(g);
                c.on(g, function(c) {
                    f.registerRefTag(b);
                    c = c.popover;
                    var g = f.getAccessoryDataForMetrics({
                        accessoryItemAsin: a.data.upsellAsin,
                        accessoryItemPrice: e
                    }, k, b);
                    f.logCustomerEngagementMetrics(g);
                    l = c.getContent().find(".hctp-pagination");
                    r = d.getCarousel(c.getContent().find(".hctp-carousel"))
                })
            }
        });
        c.declarative("hctp-mini-dp-cancel", "click", function(b) {
            var d = b.data.asinIndex,
                c = a.get(b.data.popoverName),
                e = h.getHctpConfig(),
                l = b.data.offerPrice,
                d = "hctp-mdp-nt-" + d;
            f.registerRefTag(d);
            b = f.getAccessoryDataForMetrics({
                accessoryItemAsin: b.data.asin,
                accessoryItemPrice: l
            }, e, d);
            f.logCustomerEngagementMetrics(b);
            c && c.hide()
        });
        c.declarative("hctp-mini-dp-atc", "click", function(d) {
            var c = d.data;
            d = c.asinIndex;
            var g = h.getHctpConfig(),
                e = b("#upsell-atc-container-" + d);
            b(e).children(".attach-atc").hide();
            b(e).children(".attach-atc-spinner").css("display", "inline-block");
            (e = a.get(c.popoverName)) && e.hide();
            c = {
                accessoryItemAsin: c.asin,
                accessoryItemOfferingId: c.offerListingId,
                accessoryItemQuantity: 1,
                accessoryItemPrice: c.offerPrice
            };
            e = "hctp-mdp-atc-" + d;
            f.registerRefTag(e);
            f.addToCart(c, g, d);
            d = f.getAccessoryDataForMetrics(c, g, e);
            f.logCustomerEngagementMetrics(d)
        })
    });
    "use strict";
    k.when("A", "hctp-configs", "hctp-utils").register("hctp-attach-bottom-sheet", function(c, n, a) {
        var d = c.$,
            h = {
                showMoreClickHandler: function(a) {
                    a.preventDefault();
                    a = d("#hctp-attach-bottom-sheet ul.hctp-attach-upsell-list");
                    var c = this.dataset.category,
                        f = [];
                    d(a).each(function(a, b) {
                        if (d(b).data("category") === c) return f = b, !1
                    });
                    if (!f.length) {
                        a = d(f).find(".hidden-elements");
                        var h = d(f).find(".hctp-attach-show-less"),
                            k = d(f).find(".hctp-attach-show-more");
                        d(a).each(function(a, b) {
                            d(b).removeClass("hidden-elements");
                            d(b).addClass("show-elements")
                        });
                        d(k).hide();
                        d(h).show()
                    }
                },
                showLessClickHandler: function(a) {
                    a.preventDefault();
                    var c = this.dataset.category;
                    a = d("#hctp-attach-bottom-sheet ul.hctp-attach-upsell-list");
                    var f = [];
                    d(a).each(function(a, b) {
                        if (d(b).data("category") === c) return f = b, !1
                    });
                    a = d(f).find(".show-elements");
                    var h = d(f).find(".hctp-attach-show-less"),
                        k = d(f).find(".hctp-attach-show-more");
                    d(a).each(function(a,
                        b) {
                        d(b).removeClass("show-elements");
                        d(b).addClass("hidden-elements")
                    });
                    d(k).show();
                    d(h).hide()
                },
                upsellAsinATCHandler: function(b) {
                    b.preventDefault();
                    b = d(this).closest(".attach-atc-container").data().asinIndex;
                    var c = d(this).closest("li.upsell-asin-item"),
                        f = d(c).data("upsellasin"),
                        h = d(c).data("offerlistingid"),
                        c = d(c).data("offerprice").toString();
                    d(this).hide();
                    d(this).siblings(".attach-atc-spinner").css("display", "inline-block");
                    f = {
                        accessoryItemAsin: f,
                        accessoryItemOfferingId: h,
                        accessoryItemQuantity: 1,
                        accessoryItemPrice: c
                    };
                    h = n.getHctpConfig();
                    c = "hctp-bs-atc-" + b;
                    a.registerRefTag(c);
                    a.addToCart(f, h, b);
                    b = a.getAccessoryDataForMetrics(f, h, c);
                    a.logCustomerEngagementMetrics(b)
                },
                showBottomSheetHandler: function() {
                    var b = d("#hctp-attach-bottom-sheet").parent().attr("id");
                    k.when("a-sheet").execute("hctp-attach-bottom-sheet", function(d) {
                        d.create({
                            name: "hctp-attach-bottomSheet",
                            inlineContent: "content",
                            height: 500,
                            preloadDomId: "hctp-attach-bottom-sheet",
                            sheetLabel: "HCTP attach bottom sheet",
                            sheetType: "web",
                            closeType: "message",
                            closeMessage: "DONE"
                        }).show();
                        c.on("a:sheet:afterHide:hctp-attach-bottomSheet", function(c) {
                            a.moveDomContent("hctp-attach-bottom-sheet", b)
                        })
                    })
                },
                goToCartHandler: function(b) {
                    b.stopPropagation();
                    b.preventDefault();
                    b = n.getHctpConfig();
                    b = a.getBaseAsinData(b, "hctp_gtc");
                    a.logCustomerEngagementMetrics(b);
                    a.registerRefTag("hctp_gtc");
                    f.location.href = "/gp/cart/view.html?ref\x3dhctp_gtc_cartp"
                },
                proceedToCheckoutHandler: function(b) {
                    b.stopPropagation();
                    b.preventDefault();
                    b = n.getHctpConfig();
                    var c = a.getBaseAsinData(b,
                        "hctp_proceed");
                    a.logCustomerEngagementMetrics(c);
                    f.location.href = "/gp/checkoutportal/enter-checkout.html?ie\x3dUTF8\x26proceedToCheckout\x3d1\x26useDefaultCart\x3d1\x26sessionID\x3d" + b.sessionId + "\x26ref\x3dhctp_proceed"
                },
                initialize: function() {
                    d("#hctp-attach-bottom-sheet .hctp-attach-show-more").unbind("click", h.showMoreClickHandler).click(h.showMoreClickHandler);
                    d("#hctp-attach-bottom-sheet .hctp-attach-show-less").unbind("click", h.showLessClickHandler).click(h.showLessClickHandler);
                    d("#hctp-attach-bottom-sheet .bottomsheet-go-to-cart").unbind("click",
                        h.goToCartHandler).click(h.goToCartHandler);
                    d("#hctp-attach-bottom-sheet .bottomsheet-checkout").unbind("click", h.proceedToCheckoutHandler).click(h.proceedToCheckoutHandler);
                    d(".attach-atc").unbind("click", h.upsellAsinATCHandler).click(h.upsellAsinATCHandler);
                    h.showBottomSheetHandler()
                }
            };
        return h
    });
    k.when("A", "hctp-attach-bottom-sheet", "hctp-utils", "hctp-configs").execute(function(c, n, a, d) {
        function h() {
            var c = g("#add-to-cart-button"),
                d = g("#addToCart"),
                e = d.attr("action");
            t && (d = t.addBbgDataToFormMWeb(d));
            g.ajax({
                type: "POST",
                url: e,
                data: d.serialize(),
                success: function(c) {
                    b();
                    a.logMetric("hctpBaseAsinATCSuccess")
                },
                error: function(b) {
                    g("#add-to-cart-button").unbind("click.hctpAttach");
                    a.logMetric("hctpBaseAsinATCFailure");
                    c.trigger("click")
                }
            })
        }

        function b() {
            a.baseAsinAddtoCartInfo();
            try {
                n.initialize(), a.manualLoadImages(), a.logMetric("hctpSuccessWhileLaunchingBottomSheet"), a.logBottomSheetRenderingMetrics(r())
            } catch (b) {
                a.logMetric("hctpFailureWhileLaunchingBottomSheet")
            }
        }

        function r() {
            m = d.getHctpConfig();
            return {
                sessionId: m.sessionId,
                baseAsin: m.baseAsin,
                customerId: m.customerId
            }
        }

        function l(c) {
            a.logMetric("hctpClickOnATCButton");
            "mWeb" === m.deviceType && (c.stopPropagation(), c.preventDefault());
            "mWeb" === w ? h() : b();
            e && v && !e.isAddToCartApiCalled() ? (v.addToCart("#add-to-cart-button"), a.logMetric("AddonsAddtoCartCalledFromAttach")) : a.logMetric("AddonsAddtoCartNotCalledFromAttach");
            x && x.addServiceUpsellToCart();
            y && t && !y.isBbgAddToCartApiCalled() ? (t.attachEventsToBbgButtons(), "mWeb" !== w && t.bbgATCToastButtonClickHandler(),
                a.logMetric("BbgAddtoCartCalledFromAttach")) : a.logMetric("BbgAddtoCartNotCalledFromAttach")
        }

        function p() {
            var a = g("#hctp-attach-bottom-sheet");
            return m && m.attachEligible && a.length
        }

        function q() {
            var a = g("#add-to-cart-button");
            m = d.getHctpConfig();
            k.when("atc-handler-component", "addons-cart-api").execute("attach_add_to_cart", function(a, b) {
                a && b && (e = a, v = b)
            });
            k.when("bbg-atc-handler-component", "buyBackGuarantee-widget", "BBPageState").execute("bbg_attach_add_to_cart", function(a, b, c) {
                c.init();
                c = c.get();
                c !==
                    u && "T1" === c.bbgWeblabTreatment && a && b && (y = a, t = b)
            });
            if (!p() || !a.length) return a.unbind("click.hctpAttach"), null;
            w = m.deviceType;
            "mWeb" === w && a.unbind("click.hctpAttach").bind("click.hctpAttach", l);
            k.when("atc-handler-component", "addons-cart-api").execute("attach_add_to_cart", function(a, b) {
                a && b && (e = a, v = b)
            });
            k.when("vas-twister-mobile").execute("vas_add_to_cart", function(a) {
                a && (x = a)
            })
        }
        var g = c.$,
            e = null,
            v = null,
            x = null,
            y = null,
            t = null,
            m = null,
            w;
        c.on("hctp:attach:addon-cart-update", a.baseAsinAddtoCartInfo);
        c.on("vas:ldbb-upsell-added:mobile",
            a.baseAsinAddtoCartInfo);
        c.on("hctp:attach:bbg-cart-update", a.baseAsinAddtoCartInfo);
        g.isFunction(f.markFeatureInteractive) && f.markFeatureInteractive("atc", {
            hasComponents: !0,
            components: [{
                name: "show-hctp-attach"
            }]
        });
        c.declarative("show-hctp-attach", "click", function(b) {
            b && b.data && "add-to-cart" === b.data.buttonID && a.logMetric("DetailPage_MobileApp_AddToCart");
            (m = d.getHctpConfig()) && b.data && b.data.inputs && (b.data.inputs.verificationSessionID === u || null === b.data.inputs.verificationSessionID) && (b.data.inputs.verificationSessionID =
                m.verificationSessionId);
            b = {
                inputs: b.data.inputs,
                strings: b.data.strings
            };
            var e;
            t && (e = t.getBaseAsinCustomParams());
            for (var f in e) e.hasOwnProperty(f) && (b.inputs[f] = e[f]);
            p() ? c.trigger("js-trigger-aw-mash", b, l) : (c.trigger("js-trigger-aw-mash", b), a.logMetric("hctpClickOnATCButton"))
        });
        c.declarative("show-hctp-attach", ["touchstart"], function(b) {
            var c = b.$event.originalEvent;
            c.acknowledge && (c.acknowledge(0 < b.$currentTarget.length ? b.$currentTarget[0] : u), a.logMetric("tnr-post-ack-atc"))
        });
        c.on("a:pageUpdate",
            function() {
                q()
            });
        q()
    });
    "use strict";
    k.when("A", "GlowTriggerMetrics", "jQuery", "ready").execute(function(c, k, a) {
        function d() {
            f.setTimeout(function() {
                var a = document.querySelectorAll("#glowContextualIngressPt_feature_div")[0] && document.querySelectorAll("#glowContextualIngressPt_feature_div")[0].querySelector("span");
                a && a.click()
            }, 500)
        }

        function h() {
            var b = a("#dfl_feature_div");
            b.length && a("html,body").animate({
                scrollTop: b.offset().top - 120
            }, 300)
        }(c.capabilities.android || c.capabilities.ios) && f.URLSearchParams &&
            (c = new URLSearchParams(f.location.search), "1" === c.get("dflChangePin") && (h(), c.set("dflChangePin", "0"), history.replaceState(null, "", f.location.pathname + "?" + c.toString()), d()))
    })
});
/* ******** */
(function(e) {
    var d = window.AmazonUIPageJS || window.P,
        f = d._namespace || d.attributeErrors,
        c = f ? f("ABPricingFreeFormQuantityPickerAssets", "") : d;
    c.guardFatal ? c.guardFatal(e)(c, window) : c.execute(function() {
        e(c, window)
    })
})(function(e, d, f) {
    e.when("jQuery", "A", "ready").execute(function(c, m) {
        function k(c) {
            d.ue !== f && d.ue.count !== f && d.ue.count(c, (d.ue.count(c) || 0) + 1)
        }

        function n() {
            return m.state("ABPricingFreeFormQuantityPicker")
        }

        function g(c, b) {
            return 0 !== c.find('option[value\x3d"' + b.toString() + '"]').length
        }

        function l() {
            p ||
                n() === f || (p = !0, e.register("abPricingFfqp_utils", function() {
                    return {
                        PACKAGE_PREFIX: "ABPricingFreeFormQuantityPicker",
                        getPageState: n,
                        incrementMetricByOne: k,
                        dropdownContainsQuantity: g
                    }
                }))
        }
        var p = !1;
        l();
        e.register("abPricingFfqp_lazyInitializer", function() {
            return {
                tryInitialize: l
            }
        })
    });
    "use strict";
    e.when("jQuery", "A", "abPricingFfqp_utils").register("abPricingFfqp_quantityManager", function(c, m, k) {
        function n(a) {
            for (var c = "", b = 0; b < a; b++) c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(Math.floor(62 *
                Math.random()));
            return c
        }

        function g(a, c) {
            return (a = (new RegExp("(?:^|\\?|\x26)" + c + "\x3d(?:([^\x26#]*)|\x26|#|$)")).exec(a)) ? a[1] ? decodeURIComponent(a[1].replace(/\+/g, " ")) : "" : f
        }

        function l(a, c, b) {
            var h = a.split("#");
            a = h[0];
            a = "?" === a[0] ? a.substr(1) : a;
            h = h[1];
            b !== f ? (b = c + "\x3d" + b, c = new RegExp("(^|\x26)(" + c + "\x3d[^\x26]*)"), a = c.test(a) ? a.replace(c, "$1" + b) : a + ((0 !== a.length ? "\x26" : "") + b)) : (c = new RegExp("(^|\x26)(" + c + "\x3d[^\x26]*)"), c.test(a) && (a = a.replace(c, ""), "\x26" === a[0] && (a = a.substr(1))));
            return "?" +
                a + (h !== f ? "#" + h : "")
        }

        function p(a) {
            var c = d.location.protocol + "//" + d.location.host + d.location.pathname,
                b = d.location.search,
                h;
            for (h in a) a.hasOwnProperty(h) && (b = l(b, h, a[h]));
            return c + b
        }

        function q(a) {
            if (d.history !== f && d.history.pushState !== f) {
                var c = {};
                c.qty = a;
                d.history.pushState({}, "", p(c))
            }
        }

        function b() {
            var a = parseInt(g(d.location.search, "qty"));
            this.currentQuantity = isNaN(a) ? 1 : a;
            this.wireUpSelectorBasedEvents()
        }
        var a = k.PACKAGE_PREFIX + ".QuantityRefreshCheckError",
            h = k.PACKAGE_PREFIX + ".PriceTableLoadError";
        b.prototype.getCurrentQuantity = function() {
            return this.currentQuantity
        };
        b.prototype.wireUpSelectorBasedEvents = function() {
            var a = this;
            e.when("A", "jQuery", "quanityChangePriceUpdate").execute(function(c, b, h) {
                a.quantityChangePriceUpdater = h;
                c.on("a:pageUpdate", function() {
                    a.handleTwisterPageRefresh()
                })
            })
        };
        b.prototype.update3PPriceBlock = function() {
            if (!(this.leastMinimumOrderQuantity === f || 1 >= this.leastMinimumOrderQuantity)) {
                var a = c(".price3P");
                a.hasClass("updatedPrice3P") || (a.addClass("updatedPrice3P"), this.quantityChangePriceUpdater.ajaxCall({
                    qt: this.leastMinimumOrderQuantity,
                    quantityPriceField: "quantity_price"
                }))
            }
        };
        b.prototype.handleTwisterPageRefresh = function() {
            this.update3PPriceBlock()
        };
        b.prototype.reloadPageForQuantity = function(a, c) {
            var b = {};
            b.qty = a;
            b.psc = 1;
            c !== f && (c.refTag !== f && (b.ref_ = c.refTag), c.activeBuyBoxId !== f && (b.selectObb = c.activeBuyBoxId));
            d.location.href = p(b)
        };
        b.prototype.notifyQuantityChanged = function(c, b) {
            m.trigger("buyBoxQuantityChanged", b.senderId, c);
            this.currentQuantity = c;
            q(c);
            if (!0 !== b.preventRefreshCheck) {
                var h = this,
                    d = k.getPageState();
                m.trigger("quantityRefreshCheckStarted");
                m.get("/gp/product/ajax-handlers/quantity-page-refresh.html", {
                    params: {
                        asin: d.asin,
                        quantity: c,
                        refreshData: d.lastRefreshData,
                        activeBuyBoxId: b.activeBuyBoxId
                    },
                    timeout: 4E3,
                    error: function() {
                        k.incrementMetricByOne(a);
                        h.reloadPageForQuantity(c, {
                            activeBuyBoxId: b.activeBuyBoxId
                        })
                    },
                    success: function() {
                        m.trigger("quantityRefreshCheckFinished")
                    }
                })
            }
        };
        b.prototype.fetchAllTiersForQuantityDiscountTable = function() {
            var a = k.getPageState();
            "T1" === a.weblab_DPX_AB_VAP_NEW_QUANTITY_PICKER_210547 && m.get("/gp/product/ajax-handlers/quantity-price-table.html", {
                params: {
                    ref: "b2b_qd_dp",
                    asin: a.asin,
                    cb: n(20),
                    qptResponseFormat: "json"
                },
                timeout: 4E3,
                error: function() {
                    k.incrementMetricByOne(h)
                },
                success: function(a) {
                    m.trigger("fetchQuantityDiscountTableCompleted", a)
                }
            })
        };
        return {
            EVENT__BUY_BOX_QUANTITY_CHANGED: "buyBoxQuantityChanged",
            EVENT__QUANTITY_REFRESH_CHECK_STARTED: "quantityRefreshCheckStarted",
            EVENT__QUANTITY_REFRESH_CHECK_FINISHED: "quantityRefreshCheckFinished",
            EVENT__FETCH_QUANTITY_DISCOUNT_TABLE_COMPLETED: "fetchQuantityDiscountTableCompleted",
            getUrlParameter: g,
            replaceUrlParameter: l,
            singleton: new b
        }
    });
    "use strict";
    e.when("jQuery", "A", "a-dropdown", "a-button", "abPricingFfqp_utils", "abPricingFfqp_quantityManager").register("abPricingFfqp_quantityPickerLogic", function(c, d, k, n, g, l) {
        function e(a) {
            return a.prop("selectedIndex") + 1 === a.prop("length")
        }

        function q(a, c) {
            if (!g.dropdownContainsQuantity(a, c)) {
                var b = document.createElement("option");
                b.value = c;
                b.text = c.toString();
                a.append(b)
            }
        }

        function b(a) {
            this.id = a.id;
            this.buyBoxId = a.buyBoxId;
            this.quantityHiddenFieldSelector =
                a.quantityHiddenFieldSelector;
            this.leastMinimumOrderQuantity = a.leastMinimumOrderQuantity;
            this.predefinedQuantitiesDropdownSelector = a.predefinedQuantitiesDropdownSelector;
            this.predefinedQuantitiesDropdownContainerSelector = a.predefinedQuantitiesDropdownContainerSelector;
            this.freeQuantityTextInputSelector = a.freeQuantityTextInputSelector;
            this.freeQuantityTextInputOuterSelector = a.freeQuantityTextInputOuterSelector;
            this.updateButtonSelector = a.updateButtonSelector;
            this.addToCartButtonSelector = a.addToCartButtonSelector;
            this.wireUpSelectorBasedEvents()
        }
        b.prototype.wireUpSelectorBasedEvents = function() {
            var a = this,
                b = c(this.predefinedQuantitiesDropdownSelector);
            d.on("a:dropdown:" + b[0].id + ":select", function(c) {
                a.handleDropdownOptionClicked(c.value)
            });
            d.on(l.EVENT__BUY_BOX_QUANTITY_CHANGED, function(c, b) {
                a.handleQuantityChangedOnOtherBuyBox(c, b)
            });
            d.on(l.EVENT__QUANTITY_REFRESH_CHECK_STARTED, function() {
                a.handleQuantityRefreshCheckStarted()
            });
            d.on(l.EVENT__QUANTITY_REFRESH_CHECK_FINISHED, function() {
                a.handleQuantityRefreshCheckFinished()
            })
        };
        b.prototype.wireUpReferenceBasedEvents = function() {
            var a = this,
                b = c(this.freeQuantityTextInputSelector),
                d = c(this.updateButtonSelector);
            b.keydown(function(c) {
                a.handleTextInputKeyDown(c)
            });
            b.keyup(function(c) {
                a.handleTextInputKeyUp(c)
            });
            b.focus(function() {
                a.handleTextInputFocused()
            });
            d.click(function() {
                a.handleButtonClick()
            })
        };
        b.prototype.attachToDOM = function() {
            this.wireUpReferenceBasedEvents();
            e(c(this.predefinedQuantitiesDropdownSelector)) ? this.switchToFreeQuantityUI() : this.switchToPredefinedQuantitiesUI();
            this.enableUI();
            this.lastSelectedQuantity = this.getCurrentQuantity();
            l.singleton.leastMinimumOrderQuantity = this.leastMinimumOrderQuantity
        };
        b.prototype.getCurrentQuantity = function() {
            if (this.isTextInputVisible()) {
                var a = c(this.freeQuantityTextInputSelector);
                return parseInt(a.val())
            }
            return this.isDropdownVisible() ? (a = c(this.predefinedQuantitiesDropdownSelector), parseInt(a.find(":selected").val())) : f
        };
        b.prototype.handleQuantityRefreshCheckStarted = function() {
            this.doesDOMExist() && this.disableUI()
        };
        b.prototype.handleQuantityRefreshCheckFinished =
            function() {
                this.doesDOMExist() && this.enableUI()
            };
        b.prototype.handleDropdownOptionClicked = function(a) {
            var b = c(this.predefinedQuantitiesDropdownSelector);
            e(b) ? (a = c(this.freeQuantityTextInputSelector), a.val(this.lastSelectedQuantity.toString()), this.switchToFreeQuantityUI(), a.focus(), g.incrementMetricByOne("freeFormQtyPickerMaxQtySelected")) : (this.lastSelectedQuantity = a = parseInt(a), this.updateQuantityHiddenField(a), l.singleton.notifyQuantityChanged(a, {
                senderId: this.id,
                activeBuyBoxId: this.buyBoxId
            }))
        };
        b.prototype.handleTextInputFocused = function() {
            c(this.freeQuantityTextInputSelector).select()
        };
        b.prototype.handleTextInputKeyUp = function(a) {
            13 !== a.keyCode && n(this.updateButtonSelector).show()
        };
        b.prototype.handleTextInputKeyDown = function(a) {
            13 === a.keyCode && (a.preventDefault(), c(this.updateButtonSelector).click(), c(this.addToCartButtonSelector).focus())
        };
        b.prototype.clampQuantity = function(a) {
            999 < a && (a = 999);
            this.leastMinimumOrderQuantity !== f && a < this.leastMinimumOrderQuantity && (a = this.leastMinimumOrderQuantity);
            return a
        };
        b.prototype.handleButtonClick = function() {
            var a = c(this.predefinedQuantitiesDropdownSelector),
                b = k.getSelect(a[0]),
                d = c(this.freeQuantityTextInputSelector),
                f = d.val(),
                e = parseInt,
                m = f.match(/[1-9][0-9]*/),
                e = e(null === m ? "1" : m[0]),
                e = this.clampQuantity(e);
            g.dropdownContainsQuantity(a, e) ? (this.switchToPredefinedQuantitiesUI(), b.setValue(e.toString()), this.handleDropdownOptionClicked(e)) : (a = e.toString(), a !== f && d.val(a), n(this.updateButtonSelector).hide(), this.updateQuantityHiddenField(e), l.singleton.notifyQuantityChanged(e, {
                senderId: this.id,
                activeBuyBoxId: this.buyBoxId
            }))
        };
        b.prototype.doesDOMExist = function() {
            return 0 < c(this.predefinedQuantitiesDropdownSelector).length && 0 < c(this.freeQuantityTextInputSelector).length && 0 < c(this.updateButtonSelector).length
        };
        b.prototype.handleQuantityChangedOnOtherBuyBox = function(a, b) {
            if (a !== this.id && this.doesDOMExist() && this.getCurrentQuantity() !== b) {
                a = c(this.predefinedQuantitiesDropdownSelector);
                var d = k.getSelect(a[0]);
                g.dropdownContainsQuantity(a, b) ? (d.setValue(b.toString()), this.lastSelectedQuantity =
                    b, this.switchToPredefinedQuantitiesUI()) : (c(this.freeQuantityTextInputSelector).val(b.toString()), this.switchToFreeQuantityUI());
                "T1" === g.getPageState().weblab_DP_RD_BUZZ_FFQP_186811 && this.updateQuantityHiddenField(b)
            }
        };
        b.prototype.showDropdown = function() {
            c(this.predefinedQuantitiesDropdownContainerSelector).removeClass("aok-hidden")
        };
        b.prototype.hideDropdown = function() {
            c(this.predefinedQuantitiesDropdownContainerSelector).addClass("aok-hidden")
        };
        b.prototype.isDropdownVisible = function() {
            return !c(this.predefinedQuantitiesDropdownContainerSelector).hasClass("aok-hidden")
        };
        b.prototype.showTextInput = function() {
            "mobile" === g.getPageState().platform ? c(this.freeQuantityTextInputOuterSelector).removeClass("aok-hidden") : c(this.freeQuantityTextInputSelector).removeClass("aok-hidden")
        };
        b.prototype.hideTextInput = function() {
            "mobile" === g.getPageState().platform ? c(this.freeQuantityTextInputOuterSelector).addClass("aok-hidden") : c(this.freeQuantityTextInputSelector).addClass("aok-hidden")
        };
        b.prototype.isTextInputVisible = function() {
            return "mobile" === g.getPageState().platform ? !c(this.freeQuantityTextInputOuterSelector).hasClass("aok-hidden") :
                !c(this.freeQuantityTextInputSelector).hasClass("aok-hidden")
        };
        b.prototype.disableTextInput = function() {
            if ("mobile" === g.getPageState().platform) {
                var a = c(this.freeQuantityTextInputSelector),
                    b = c(this.freeQuantityTextInputOuterSelector);
                a.prop("disabled", "disabled");
                b.addClass("a-form-disabled")
            } else a = c(this.freeQuantityTextInputSelector), a.prop("disabled", "disabled"), a.addClass("a-form-disabled")
        };
        b.prototype.enableTextInput = function() {
            if ("mobile" === g.getPageState().platform) {
                var a = c(this.freeQuantityTextInputSelector),
                    b = c(this.freeQuantityTextInputOuterSelector);
                a.removeProp("disabled");
                b.removeClass("a-form-disabled")
            } else a = c(this.freeQuantityTextInputSelector), a.removeProp("disabled"), a.removeClass("a-form-disabled")
        };
        b.prototype.switchToFreeQuantityUI = function() {
            this.hideDropdown();
            this.showTextInput();
            n(this.updateButtonSelector).hide()
        };
        b.prototype.switchToPredefinedQuantitiesUI = function() {
            this.showDropdown();
            this.hideTextInput();
            n(this.updateButtonSelector).hide()
        };
        b.prototype.disableUI = function() {
            var a =
                k.getSelect(this.predefinedQuantitiesDropdownSelector),
                c = n(this.updateButtonSelector);
            a.update({
                status: "disabled"
            });
            this.disableTextInput();
            c.disable()
        };
        b.prototype.enableUI = function() {
            var a = k.getSelect(this.predefinedQuantitiesDropdownSelector),
                c = n(this.updateButtonSelector);
            a.update({
                status: "normal"
            });
            this.enableTextInput();
            c.enable()
        };
        b.prototype.updateQuantityHiddenField = function(a) {
            var b = c(this.quantityHiddenFieldSelector);
            b.is("select") ? (q(b, a), k.getSelect(b).val(a)) : b.val(a.toString());
            "mobile" ===
            g.getPageState().platform && "select#mobileQuantityDropDown" !== this.quantityHiddenFieldSelector && (b = c("select#mobileQuantityDropDown")) && b.is("select") && (q(b, a), k.getSelect(b).val(a))
        };
        return {
            QuantityPickerLogic: b
        }
    });
    "use strict"
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("A2IDetailPageAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageQuantityAwarePriceAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(b) {
    var c = window.AmazonUIPageJS || window.P,
        d = c._namespace || c.attributeErrors,
        a = d ? d("N2ARecommendationsMobileAssets@acx-grid", "N2ARecommendationsMobileAssets") : c;
    a.guardFatal ? a.guardFatal(b)(a, window) : a.execute(function() {
        b(a, window)
    })
})(function(b, c, d) {
    b.when("jQuery", "A", "p13n-sc-util", "p13n-sc-call-on-visible", "p13n-sc-lazy-image-loader", "p13n-sc-line-truncator", "p13n-sc-lazy-widget-loader").register("p13n-sc-static-grid", function(a, c, d, g, h, k, l) {
        function e(c) {
            this.$container = a(c);
            h.loadImages(this.$container);
            k.truncateLines(this.$container)
        }

        function f() {
            function b(a) {
                g.register(a, function() {
                    var b = new e(a);
                    c.trigger("p13n-sc-grid-log", b.$container, "view")
                }, d)
            }
            var d = {
                distanceY: -500,
                distanceX: 0
            };
            a(".p13n-sc-static-grid").each(function(a, c) {
                b(c)
            });
            l.revealWhenVisible(a(".p13n-sc-call-grid-on-visible"), function(a) {
                a = a.find(".p13n-sc-static-grid");
                a.length && b(a)
            }, d)
        }
        b.when("afterReady").execute("p13n-sc-static-grid:init", f);
        c.on("toofanBtfLoaded", f);
        return e
    });
    b.when("A", "jQuery", "p13n-sc-logger", "p13n-sc-util").register("p13n-sc-grid-logger",
        function(a, b, c, d) {
            a.on("p13n-sc-grid-log", function(a, d) {
                c.logAction(b.extend(!0, {}, {
                    featureElement: a,
                    logOnlyOnNew: !1,
                    logOnlyNew: !0,
                    replicateAsinImpressions: !0
                }, {
                    action: d
                }))
            })
        })
});
/* ******** */
(function(e) {
    var m = window.AmazonUIPageJS || window.P,
        n = m._namespace || m.attributeErrors,
        b = n ? n("N2ARecommendationsMobileAssets@acx-unified-widget", "N2ARecommendationsMobileAssets") : m;
    b.guardFatal ? b.guardFatal(e)(b, window) : b.execute(function() {
        e(b, window)
    })
})(function(e, m, n) {
    e.when("A", "ACXUnifiedWidgetController", "acx-infinite-elements-ready", "p13n-sc-line-truncator").execute("acx-unified-infinite-session:init", function(b, p, g, f) {
        function l() {
            a && a.destroy();
            var b = h(".acx-similarities-widget.acx-unified-widget-primary[data-similarity-type\x3dmobile-dp-sims_session-similarities] .acx-static-grid");
            if (0 !== b.length && 0 !== c.length) {
                var d = h(".acx-similarities-widget.acx-unified-widget-infinite .p13n-sc-static-grid"),
                    f = h(".acx-unified-widget-loading-wrapper");
                if (d.length) {
                    var g = b.attr("data-p13n-feature-name"),
                        k = b.attr("data-p13n-global");
                    g && d.attr("data-p13n-feature-name", g);
                    k && d.attr("data-p13n-global", k)
                }
                a = new p(b, c, {
                    isInfiniteWidgetHidden: !0,
                    ajaxHandlerOptions: {
                        loader: f
                    },
                    scrollHandlerOptions: {
                        triggerElement: ".acx-unified-loading-text",
                        triggerElementOffset: 2
                    }
                });
                d = h(".acx-unified-widget-link");
                d.length && b.length && d.attr("href", "#acx-infinite-session-widget");
                b = b.find(".acx-show-all-loading-text");
                d = h(".p13n-sc-static-list-buttons");
                b.addClass("a-hidden");
                d.removeClass("a-hidden")
            }
        }

        function k() {
            var a = c.data("results-container-selector"),
                a = c.find(a);
            a.length && a.html("");
            c.addClass("a-hidden");
            l()
        }
        "use-strict";
        var h = b.$,
            a = null,
            c = h(".acx-similarities-widget.acx-unified-widget-infinite[data-similarity-type\x3dmobile-dp-sims_session-similarities]");
        (function() {
            e.when("jumpLink").execute(function(a) {
                a.bind(".acx-unified-widget-link",
                    1E3, 0)
            })
        })();
        l();
        e.when("afterLoad").execute(function() {
            b.on("a:pageUpdate", k)
        });
        b.on("acx-unified-widget-after-complete", function() {
            0 === c.find(".acx-sc-grid-row").length && c.addClass("a-hidden");
            a && a.destroy()
        })
    });
    e.when("A", "ACXUnifiedWidgetScrollHandler", "ACXUnifiedWidgetProductHandler", "ACXUnifiedWidgetAjaxHandler").register("ACXUnifiedWidgetController", function(b, e, g, f) {
        function l(a, c, b) {
            if (0 != a.length && 0 != c.length) {
                this.eventHandlers = [];
                this.options = k.extend(h, b);
                this.options.ajaxHandlerOptions.ajaxURL =
                    a.data("ajax-url");
                this.options.ajaxHandlerOptions.ajaxParams = a.data("ajax-params") || this.options.ajaxHandlerOptions.ajaxParams;
                b = c.data("results-container-selector");
                this.options.ajaxHandlerOptions.resultsContainer = c.find(b);
                this.options.ajaxHandlerOptions.loader && 0 !== this.options.ajaxHandlerOptions.loader.length || (b = k('\x3cdiv class\x3d"a-hidden"\x3e\x3cdiv class\x3d"a-section a-text-center acx-show-all-loading-text acx-unified-loading-text"\x3eLoading...\x3c/div\x3e\x3cdiv class\x3d"a-spinner-wrapper acx-unified-widget-infinite-loader"\x3e\x3cspan class\x3d"a-spinner a-spinner-medium"\x3e\x3c/div\x3e'),
                    c.append(b), this.options.ajaxHandlerOptions.loader = b);
                b = 0;
                if (this.options.scrollHandlerOptions.triggerElement) {
                    b = a.data(".fetch-trigger-element-offset") || this.options.scrollHandlerOptions.triggerElementOffset;
                    var d = a.find(this.options.scrollHandlerOptions.triggerElement);
                    d.length && (this.options.scrollHandlerOptions.triggerOffsetY = d[Math.max(0, d.length - b)].offsetTop)
                }
                var d = a.data("ajax-asins") && a.data("ajax-asins").toString().split(",") || [],
                    l = a.data("filtered-amazon-global-asins") && a.data("filtered-amazon-global-asins").toString().split(",") || [],
                    m = a.data("should-filter-amazon-global-asins") || 0;
                0 < l.length && 1 === m && (d = l);
                this.options.productHandlerOptions.asins = d || [];
                this.options.productHandlerOptions.asinIndex = a.data("asin-index") || this.options.productHandlerOptions.asinIndex;
                this.options.productHandlerOptions.triggerElementOffset = b || this.options.productHandlerOptions.triggerElementOffset;
                d.length <= this.options.productHandlerOptions.asinIndex + 1 || (this.options.isInfiniteWidgetHidden && c.removeClass("a-hidden"), this.eventHandlers.push(new e(this.options.scrollHandlerOptions)),
                    this.eventHandlers.push(new f(this.options.ajaxHandlerOptions)), this.eventHandlers.push(new g(this.options.productHandlerOptions)))
            }
        }
        "use-strict";
        var k = b.$,
            h = {
                isInfiniteWidgetHidden: !1,
                ajaxHandlerOptions: {
                    ajaxParams: {},
                    ajaxURL: null,
                    subsequentRequestSize: 28,
                    requestSize: 6,
                    resultsContainer: null,
                    loader: null
                },
                scrollHandlerOptions: {
                    triggerElement: null,
                    triggerElementOffset: 0,
                    triggerOffsetY: 0
                },
                productHandlerOptions: {
                    asinIndex: 0,
                    asins: [],
                    triggerElementOffset: 0
                }
            };
        l.prototype.destroy = function() {
            this.eventHandlers &&
                this.eventHandlers.forEach(function(a) {
                    a.destroy()
                })
        };
        return l
    });
    e.when("A").register("ACXUnifiedWidgetScrollHandler", function(b) {
        function e(a) {
            this.options = k.extend(h, a);
            this.shouldBroadcast = !0;
            this.events = [b.on("acx-unified-widget-offset-updated", f.bind(this)), b.on("acx-unified-widget-ajax-error", l.bind(this))];
            this.scrollListener = g.bind(this);
            m.addEventListener("scroll", this.scrollListener)
        }

        function g() {
            m.innerHeight + m.pageYOffset >= this.options.triggerOffsetY && this.shouldBroadcast && (this.shouldBroadcast = !1, b.trigger("acx-unified-widget-check-products"))
        }

        function f(a) {
            this.options.triggerOffsetY = a.triggerOffsetY;
            this.shouldBroadcast = !0
        }

        function l() {
            this.shouldBroadcast = !0
        }
        "use-strict";
        var k = b.$,
            h = {
                triggerOffsetY: 0
            };
        e.prototype.destroy = function() {
            b.each(this.events, function(a) {
                b.off(a.event, a.callback)
            });
            m.removeEventListener("scroll", this.scrollListener)
        };
        return e
    });
    e.when("A", "p13n-sc-call-on-visible", "p13n-sc-util").register("ACXUnifiedWidgetProductHandler", function(b, e, g) {
        function f(c) {
            this.options =
                h.extend(a, c);
            this.events = [b.on("acx-unified-widget-check-products", l.bind(this)), b.on("acx-unified-widget-products-loaded", k.bind(this))]
        }

        function l() {
            this.hasAdditionalProducts() ? b.trigger("acx-unified-widget-load-products", {
                asins: this.options.asins,
                asinIndex: this.options.asinIndex
            }) : b.trigger("acx-unified-widget-after-complete")
        }

        function k(a) {
            a && (this.options.asinIndex += a.requestSize, this.options.products = a.container.products, this.monitorProducts(a.newProducts), this.recalculateProductOffset(a.container),
                this.logAdditionalProducts())
        }
        "use-strict";
        var h = b.$,
            a = {
                triggerElementOffset: 0,
                asins: [],
                asinIndex: 0,
                impressionTrackingContainerSelector: ".acx-infinite-grid"
            };
        f.prototype.destroy = function() {
            b.each(this.events, function(a) {
                b.off(a.event, a.callback)
            })
        };
        f.prototype.hasAdditionalProducts = function() {
            return this.options.asins.length > this.options.asinIndex + 1
        };
        f.prototype.monitorProducts = function(a) {
            e.register(a, function() {
                var a = g.count("acx:sc:unified-widget:last-product") || 0;
                g.count("acx:sc:unified-widget:last-product",
                    a + 1)
            }, {
                distanceY: 0,
                distanceX: 0
            })
        };
        f.prototype.recalculateProductOffset = function(a) {
            a.products.length && b.trigger("acx-unified-widget-offset-updated", {
                triggerOffsetY: a.products[Math.max(0, a.products.length - this.options.triggerElementOffset)].offsetTop
            })
        };
        f.prototype.logAdditionalProducts = function() {
            if (!this.hasAdditionalProducts()) {
                var a = h(this.options.impressionTrackingContainerSelector);
                a && b.trigger("p13n-sc-grid-log", a, "view")
            }
        };
        return f
    });
    e.when("A", "p13n-sc-line-truncator", "p13n-sc-util").register("ACXUnifiedWidgetAjaxHandler",
        function(b, e, g) {
            function f(a) {
                this.options = k.extend(h, a);
                this.errorRetryCount = 0;
                this.isLoadingProducts = this.isInErrorState = !1;
                this.events = [b.on("acx-unified-widget-load-products", l.bind(this))];
                this.ajaxObject = null
            }

            function l(a) {
                if (!this.isLoadingProducts && !this.isInErrorState && a) {
                    this.isLoadingProducts = !0;
                    this.options.loader.removeClass("a-hidden");
                    var c = a.asinIndex ? a.asinIndex : 0;
                    a = a.asins ? a.asins : [];
                    for (var e = [], d = c + 1; d <= c + this.options.requestSize && d < a.length; d++) e.push(a[d]);
                    this.options.ajaxParams.asins =
                        e.join();
                    this.options.ajaxParams.offset = c + 1;
                    this.ajaxObject = b.ajax(this.options.ajaxURL, {
                        method: "get",
                        params: this.options.ajaxParams,
                        success: function(a, b, c) {
                            this.handleAjaxComplete(a, this.options.resultsContainer, c, b)
                        }.bind(this),
                        error: function(a, b) {
                            this.handleAjaxComplete(null, null, a, b)
                        }.bind(this)
                    })
                }
            }
            "use-strict";
            var k = b.$,
                h = {
                    ajaxURL: null,
                    resultsContainer: null,
                    ajaxParams: {},
                    subsequentRequestSize: 28,
                    requestSize: 6,
                    loader: null
                };
            f.prototype.destroy = function() {
                this.ajaxObject && this.ajaxObject.abort();
                b.each(this.events, function(a) {
                    b.off(a.event, a.callback)
                })
            };
            f.prototype.handleAjaxComplete = function(a, c, f, d) {
                a && c && k.isArray(a) && 0 < a.length ? (a = k(a.join("")), c.append(a), c.products = c.products ? c.products.add(a) : a, e.truncateLines(c.products), b.loadDynamicImage(a.find(".a-dynamic-image")), b.trigger("acx-unified-widget-products-loaded", {
                        requestSize: this.options.requestSize,
                        container: c,
                        newProducts: a
                    }), c = g.count("acx:acx-unified-widget:ajax:success") || 0, g.count("acx:acx-unified-widget:ajax:success", c + 1)) :
                    f && (500 === f.http.status || "Request Timeout" === d) && 3 > this.errorRetryCount ? (b.trigger("acx-unified-widget-ajax-error"), this.errorRetryCount++) : (this.isInErrorState = !0, b.trigger("acx-unified-widget-after-complete"), c = g.count("acx:acx-unified-widget:ajax:error") || 0, g.count("acx:acx-unified-widget:ajax:error", c + 1));
                this.options.requestSize = this.options.subsequentRequestSize;
                this.options.loader.addClass("a-hidden");
                this.isLoadingProducts = !1
            };
            return f
        })
});
/* ******** */
(function(b) {
    var c = window.AmazonUIPageJS || window.P,
        d = c._namespace || c.attributeErrors,
        a = d ? d("DetailPageSoftlinesPSSAssets", "") : c;
    a.guardFatal ? a.guardFatal(b)(a, window) : a.execute(function() {
        b(a, window)
    })
})(function(b, c, d) {
    b.when("A", "jQuery").register("pss-metric-utils", function(a, b) {
        return {
            updateRefTagCounters: function(a) {
                if ("object" !== typeof a) throw "Options is not an object";
                a.refTag !== d && b.ajax({
                    url: "/pss/reftag?ref_\x3d" + a.refTag,
                    type: "POST"
                })
            }
        }
    })
});
/* ******** */
(function(k) {
    var p = window.AmazonUIPageJS || window.P,
        x = p._namespace || p.attributeErrors,
        d = x ? x("DetailPageSoftlinesPDPAssets", "") : p;
    d.guardFatal ? d.guardFatal(k)(d, window) : d.execute(function() {
        k(d, window)
    })
})(function(k, p, x) {
    k.when("A", "jQuery", "pdp-aui-utils").register("softlinesPDPIngress-size-update", function(d, b, e) {
        d.state.bind("slps-fit-pdp-ingress-state", function(c, a) {
            c = c.ingressSizeRecommendationDivId;
            b("#" + c).length && b("#" + c).html(e.getState("slps-fit-pdp-ingress-state").sizeRecommendationMessage)
        })
    });
    k.when("A", "jQuery", "a-secondary-view").register("softlinesPDPIngress-url-update", function(d, b, e) {
        d.state.bind("softlines-pdp-ingress-modal-properties", function(c, a) {
            if (a.urlParameters && (a = e.get("PDPWidget"))) {
                var d = "",
                    q = c.baseUrl;
                c.urlParameters && (d = q.match(/\?/) ? "\x26" : "?", d += b.param(c.urlParameters));
                c.modalProperties.url = q + d;
                a.update(c.modalProperties)
            }
        })
    });
    "use strict";
    k.when("A", "jQuery", "pdp-aui-utils").execute(function(d, b, e) {
        function c(a) {
            K.each(function() {
                f = b(this);
                f.stop();
                f.hasClass("FT") &&
                    f.animate({
                        scrollTop: 2.5 * m
                    }, a);
                f.hasClass("IN") && f.animate({
                    scrollTop: 4.5 * m
                }, a);
                f.hasClass("CM") && f.animate({
                    scrollTop: 70.5 * m
                }, a)
            });
            n.each(function() {
                f = b(this);
                f.stop();
                var c = f.find("." + q),
                    d = c.filter("." + H);
                f.animate({
                    scrollTop: c.index(d) * m
                }, a)
            })
        }
        var a, g, q, k, w, H, r, z, m, n, K, f, y, L;
        d.on("a:popover:ajaxContentLoaded:PDPWidget", function() {
            a = e.getSelectors("height-selectors");
            g = a.scrollerCss;
            q = a.valueCss;
            k = a.containerCss;
            w = a.activeState;
            H = a.selectedState;
            r = a.errorState;
            z = b("." + g);
            n = b("." + k + "." + w + " ." + g);
            K = b("." + k + ":not(." + w + ") ." + g);
            m = b("." + q, z).first().outerHeight();
            n.hasClass("CM") && (m = b("." + q + ".CM", z).first().outerHeight());
            if (n.hasClass("FT") || n.hasClass("IN")) m = b("." + q + ".FT", z).first().outerHeight();
            c(1E3);
            z.bind("touchstart", function(a) {
                f = b(this);
                y = a.originalEvent.touches[0].clientY;
                L = f.scrollTop();
                f.closest("." + k).addClass(w);
                f.removeClass(r);
                a.preventDefault()
            }).bind("touchmove", function(a) {
                f = b(this);
                f.stop();
                f.scrollTop(L + y - a.originalEvent.touches[0].clientY)
            }).bind("touchend", function(a) {
                f =
                    b(this);
                a = Math.round(f.scrollTop() / m);
                f.animate({
                    scrollTop: a * m
                }, 50);
                var c = f.find("." + q);
                c.filter("." + H).removeClass(H);
                c.eq(a).addClass(H);
                d.trigger("pdp-card-input-updated")
            })
        });
        d.on("pdp-profile-height-units-changed", function() {
            c(0)
        })
    });
    "use strict";
    k.when("A", "jQuery", "pdp-aui-utils").execute(function(d, b, e) {
        var c, a, g;
        d.on("a:popover:ajaxContentLoaded:PDPWidget", function() {
            function k(e) {
                function r(b) {
                    v.filter("." + y).removeClass(y);
                    l = v.eq(b);
                    l.addClass(y);
                    x.text(l.data("weight-interval-text"));
                    D.addClass(f)
                }

                function q(b, a) {
                    E.animate({
                        scrollLeft: b * c
                    }, a)
                }
                var m = e.containerCss,
                    n = e.incrementCss,
                    w = e.weightValueContainerCss,
                    f = e.activeState,
                    y = e.selectedState,
                    p = e.weightMinimumValue,
                    B = e.weightIntervalIncrement,
                    C = e.defaultWeight,
                    x = b("." + e.activeWeightValueCss),
                    E = b("." + m),
                    v = b("." + n, E),
                    l = v.filter("." + y),
                    D = b("." + w);
                c = v.first().outerWidth() - 3;
                l.length ? (r(v.index(l)), q(v.index(l), 1E3)) : 0 < c && q((C - p - B) / B, 1E3);
                E.bind("touchstart", function(d) {
                    c = v.first().outerWidth() - 3;
                    g = d.originalEvent.touches[0].clientX;
                    a = b(this).scrollLeft();
                    d.preventDefault()
                }).bind("touchmove", function(d) {
                    b(this).scrollLeft(a + g - d.originalEvent.touches[0].clientX);
                    b(this).stop();
                    d = Math.round(b(this).scrollLeft() / c);
                    r(d)
                }).bind("touchend", function() {
                    var a = Math.round(b(this).scrollLeft() / c);
                    r(a, 50);
                    d.trigger("pdp-card-input-updated")
                });
                d.on("pdp-profile-weight-units-changed", function() {
                    c = v.first().outerWidth() - 3;
                    l.length ? r(v.index(l)) : E.scrollLeft(c * (C - p - B) / B)
                })
            }
            var p = e.getSelectors("weight-selectors-imperial"),
                w = e.getSelectors("weight-selectors-metric");
            k(p);
            k(w)
        })
    });
    "use strict";
    k.when("A", "jQuery").register("pdp-aui-utils", function(d, b, e) {
        function c(a) {
            var c = b("script[type\x3d'a-state']").filter(function() {
                return b(this).data("a-state").key === a
            });
            return d.parseJSON(c.html())
        }
        return {
            getState: function(b) {
                return c(b)
            },
            getSelectors: function(a) {
                return b("#" + a).data()
            }
        }
    });
    "use strict";
    k.when("A", "jQuery", "a-button", "slps-ajax", "pdp-aui-utils", "pdp-metric-utils", "a-secondary-view").execute(function(d, b, e, c, a, g, k) {
        function p() {
            b("#" + V).bind("touchend",
                function() {
                    g.updateCounters({
                        refTag: "slps_pdp_privacy_information_button_click"
                    });
                    b("#" + F).addClass("aok-hidden");
                    n(W)
                });
            b("#" + X).bind("touchend", function() {
                g.updateCounters({
                    refTag: "slps_pdp_privacy_information_done_click"
                });
                b("#" + F).removeClass("aok-hidden");
                n(J)
            });
            b("#" + Y).bind("touchend", function() {
                g.updateCounters({
                    refTag: "slps_pdp_privacy_notice_url_click"
                })
            });
            b("#" + Z).bind("touchend", function() {
                g.updateCounters({
                    refTag: "slps_pdp_contact_us_url_click"
                })
            })
        }

        function w() {
            if (e("#" + M).isEnabled()) {
                var b =
                    u[h].saveFormUrl;
                g.updateCounters({
                    refTag: A[h].refTagNextClick
                });
                b ? v(b) : z()
            }
        }

        function x() {
            if (e("#" + N).isEnabled()) {
                var b = u[h].backDiv;
                g.updateCounters({
                    refTag: A[h].refTagBackClick
                });
                n(b);
                d.trigger("pdp-card-trasition-complete", h)
            }
        }

        function r() {
            b("." + aa).addClass("aok-hidden")
        }

        function z() {
            var b = u[h].nextDiv,
                a = u[h].nextURL;
            b ? n(b) : a && (r(), K(a))
        }

        function m() {
            b("#" + F).addClass("aok-hidden");
            r();
            b("#pdpGenericErrorCard").removeClass("aok-hidden");
            g.updateCounters({
                counter: "genericErrorCardShown"
            });
            f("#slps-pdp-retry-btn")
        }

        function n(a) {
            r();
            b("#" + a).removeClass("aok-hidden");
            h = a;
            null !== A[h] && g.updateCounters({
                counter: A[h].csmCardDisplayedCounter
            })
        }

        function K(a) {
            var e = O;
            "undefined" !== typeof P && (e = Object.assign({}, O, P));
            d.state.parse();
            b("#" + F).addClass("aok-hidden");
            c(a, {
                params: e,
                method: "get",
                success: function(a) {
                    b("#sizeRecCard").html(a);
                    b("#sizeRecCard").removeClass("aok-hidden");
                    h = "sizeRecCard";
                    d.state.parse();
                    f("#slps-pdp-retry-btn");
                    f("#edit-input-link");
                    L();
                    y();
                    g.updateCounters({
                        counter: "recsCardLoadedSuccess"
                    });
                    d.trigger("pdp-card-trasition-complete", h)
                },
                error: function() {
                    g.updateCounters({
                        counter: "recsCardLoadingFailure"
                    });
                    m()
                }
            })
        }

        function f(a) {
            b(a).live("touchend", function(a) {
                r();
                b("#" + F).removeClass("aok-hidden");
                n(Object.keys(u)[0]);
                a.preventDefault();
                l()
            })
        }

        function y() {
            ba = a.getState("fit-recs-screen-buttons");
            ca = ba.editButtonId;
            b("#" + ca).bind("touchend", function(b) {
                g.updateCounters({
                    refTag: "slps_pdp_recs_card_edit_details_click"
                })
            })
        }

        function L() {
            var c = "#" + a.getState("fit-recs-screen-buttons").confirmButtonId;
            b(c).bind("touchend", function(b) {
                g.updateCounters({
                    refTag: A[h].refTagDoneClick
                });
                k.get("PDPWidget").hide();
                b.preventDefault()
            })
        }

        function B() {
            var a = {};
            Object.keys(Q).forEach(function(c) {
                c = Q[c];
                a[c] = b("input[name\x3d" + c + "]:checked").val()
            });
            a.csrfToken = b("input[name\x3dubaSubmit]").val();
            return a
        }

        function C(a) {
            return b(b("." + G.valueCss + "." + a + "." + G.selectedState)[0]).data("heightValue")
        }

        function U(a) {
            var c = b(b("." + a + "." + G.selectedState)[0]).data("weightIntervalText").split("-");
            if (2 === c.length)
                if (a =
                    parseFloat(c[0]), c = parseFloat(c[1]), isNaN(a) || isNaN(c)) g.updateCounters({
                    counter: "weightValueParsingFailure"
                }), console.log("Weight range values returned are not numbers " + a + " " + c);
                else return (a + c) / 2;
            else g.updateCounters({
                counter: "weightFormatParsingFailure"
            }), console.log("Weight range does not contain min and max values " + a)
        }

        function E() {
            if (h === J) {
                var a = {};
                b("#" + da).hasClass("a-button-selected") ? (a.unitSystem = "metric", a.heightUnitSystem = "metric", a.heightCm = C("CM")) : b("#" + ea).hasClass("a-button-selected") &&
                    (a.unitSystem = "imperial", a.heightUnitSystem = "imperial", a.heightFT = C("FT"), a.heightIN = C("IN"));
                b("#" + fa).hasClass("a-button-selected") ? (a.weightUnitSystem = "metric", a.weightKg = U(R)) : b("#" + ga).hasClass("a-button-selected") && (a.weightUnitSystem = "imperial", a.weightLb = U(S));
                a.csrfToken = b("input[name\x3dprofileSubmit]").val();
                return a
            }
            if (h === T) return B()
        }

        function v() {
            var a = u[h].saveFormUrl,
                b = Object.assign({}, O, E());
            c(a, {
                params: JSON.stringify(b),
                paramsFormat: "json",
                method: "post",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                },
                success: function(a) {
                    g.updateCounters({
                        counter: A[h].csmPostSuccessCounter
                    });
                    z();
                    d.trigger("pdp-card-trasition-complete", h)
                },
                error: function(a) {
                    console.error("Unable to post data " + a.http.response);
                    g.updateCounters({
                        counter: A[h].csmPostFailureCounter
                    });
                    m()
                }
            })
        }

        function l() {
            var a = e("#" + M),
                c = e("#" + N);
            c.disable();
            a.disable();
            u[h] && (u[h].backDiv || u[h].backURL) && c.enable();
            if (u[h] && (u[h].nextDiv || u[h].nextURL)) {
                if (c = h === J) {
                    var c = G.valueCss,
                        d = G.selectedState,
                        f = !1,
                        g = !1;
                    b("#" +
                        ha).hasClass("aok-hidden") && b("." + c + ".FT." + d).length && b("." + c + ".IN." + d).length && (g = !0);
                    b("#" + ia).hasClass("aok-hidden") && b("." + c + ".CM." + d).length && (g = !0);
                    b("#" + ja).hasClass("aok-hidden") && b("." + S + "." + d).length && (f = !0);
                    b("#" + ka).hasClass("aok-hidden") && b("." + R + "." + d).length && (f = !0);
                    c = g && f
                }(c || h === T) && a.enable()
            }
        }
        var D, t, I, ba, la, Q, T, J, O, W, M, N, X, V, Y, Z, ca, F, h, aa, G, ea, da, ga, fa, S, R, ia, ka, ha, ja, P, u = {
                pdpProfileCard: {
                    nextDiv: "pdpUniqueBodyAttributesCard",
                    saveFormUrl: "/slps/cx/pdp/s/profile"
                },
                pdpUniqueBodyAttributesCard: {
                    backDiv: "pdpProfileCard",
                    saveFormUrl: "/slps/cx/pdp/s/uba",
                    nextURL: "/slps/cx/pdp/recs"
                },
                sizeRecCard: {}
            },
            A = {
                pdpProfileCard: {
                    csmPostFailureCounter: "profileCardPostFailure",
                    csmPostSuccessCounter: "profileCardPostSuccess",
                    refTagBackClick: "slps_pdp_profile_back_button_click",
                    refTagNextClick: "slps_pdp_profile_next_button_click",
                    csmCardDisplayedCounter: "profileCardDisplayedCount"
                },
                pdpUniqueBodyAttributesCard: {
                    csmPostFailureCounter: "ubaCardPostFailure",
                    csmPostSuccessCounter: "ubaCardPostSuccess",
                    refTagBackClick: "slps_pdp_uba_back_button_click",
                    refTagNextClick: "slps_pdp_uba_next_button_click",
                    csmCardDisplayedCounter: "ubaCardDisplayedCount"
                },
                sizeRecCard: {
                    refTagDoneClick: "slps_pdp_done_click"
                },
                pdpPrivacyInfoCard: {
                    csmCardDisplayedCounter: "privacyCardDisplayedCount"
                }
            };
        d.on("a:popover:ajaxContentLoaded:PDPWidget", function() {
            D = a.getState("fit-pdp-footer");
            t = a.getState("fit-pdp-profile");
            O = a.getState("fit-pdp-profile-product-info");
            la = a.getState("fit-pdp-uba");
            I = a.getState("fit-pdp-privacy");
            G = a.getSelectors("height-selectors");
            Q = a.getState("fit-pdp-uba-attributes");
            S = a.getSelectors("weight-selectors-imperial").incrementCss;
            R = a.getSelectors("weight-selectors-metric").incrementCss;
            P = d.state("softlines-pdp-ingress-flojo-attributes");
            T = la.ubaCardId;
            W = I.privacyCardId;
            X = I.doneButtonId;
            Y = I.privacyUrlLinkId;
            Z = I.contactUsUrlLinkId;
            J = t.profileCardId;
            aa = t.pdpCardsClass;
            ea = t.heightImperialButton;
            da = t.heightMetricButton;
            ga = t.weightImperialButton;
            fa = t.weightMetricButton;
            ia = t.heightImperialDiv;
            ka = t.weightImperialDiv;
            ha = t.heightMetricDiv;
            ja = t.weightMetricDiv;
            M = D.nextButtonId;
            N = D.backButtonId;
            V = t.privacyInfoTextId;
            F = D.footerId;
            n(J);
            l();
            b("#" + M).bind("touchend", w);
            b("#" + N).bind("touchend", x);
            p()
        });
        d.on("pdp-card-trasition-complete", l);
        d.on("pdp-card-input-updated", l);
        d.on("pdp-profile-height-units-changed", l);
        d.on("pdp-profile-weight-units-changed", l)
    });
    "use strict";
    k.when("A", "jQuery", "pdp-aui-utils").execute(function(d, b, e) {
        d.on("a:popover:ajaxContentLoaded:PDPWidget", function() {
            var c = e.getState("fit-pdp-profile");
            b("#" + c.heightMetricButton).click(function() {
                b("#" + c.heightImperialDiv).addClass("aok-hidden");
                b("#" + c.heightMetricDiv).removeClass("aok-hidden");
                d.trigger("pdp-profile-height-units-changed", "metric")
            });
            b("#" + c.heightImperialButton).click(function() {
                b("#" + c.heightMetricDiv).addClass("aok-hidden");
                b("#" + c.heightImperialDiv).removeClass("aok-hidden");
                d.trigger("pdp-profile-height-units-changed", "imperial")
            });
            b("#" + c.weightMetricButton).click(function() {
                b("#" + c.weightImperialDiv).addClass("aok-hidden");
                b("#" + c.weightMetricDiv).removeClass("aok-hidden");
                d.trigger("pdp-profile-weight-units-changed",
                    "metric")
            });
            b("#" + c.weightImperialButton).click(function() {
                b("#" + c.weightMetricDiv).addClass("aok-hidden");
                b("#" + c.weightImperialDiv).removeClass("aok-hidden");
                d.trigger("pdp-profile-weight-units-changed", "imperial")
            })
        })
    });
    "use strict";
    k.when("A", "slps-ajax").register("pdp-metric-utils", function(d, b) {
        var e = p.ue,
            c = "object" === typeof e && e.count;
        return {
            updateCounters: function(a) {
                if ("object" !== typeof a) throw "Options is not an object";
                if (a.counter !== x) {
                    var d = a.counter;
                    d && c && e.count("SlpsPDP:Mobile:" + d,
                        1)
                }
                a.refTag !== x && (a = a.refTag) && b("/slps/cx/reftag", {
                    params: {
                        ref_: a
                    }
                })
            }
        }
    });
    "use strict";
    k.when("A", "jQuery", "pdp-aui-utils", "pdp-common-widget").register("pdp-common-utils", function(d, b, e, c) {
        return {
            showProfileCard: function() {
                var a = e.getState("fit-pdp-profile");
                c.showCard(a.profileCardId)
            },
            showFooter: function() {
                var a = e.getState("fit-pdp-footer").footerId;
                b("#" + a).removeClass("aok-hidden")
            },
            showSpinner: function() {
                var a = e.getState("fit-spinner-meta-data");
                c.showCard(a.pdpSpinnerCardId)
            },
            getProfileIdAndAsin: function() {
                var a =
                    e.getState("fit-pdp-profile-product-info");
                return {
                    profileId: a.profileId,
                    asin: a.asin
                }
            }
        }
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("AmazonFamilyLandingPageOptimizationAssets@sifterAssets", "AmazonFamilyLandingPageOptimization") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageTextLinkIngressAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(e) {
    var m = window.AmazonUIPageJS || window.P,
        C = m._namespace || m.attributeErrors,
        c = C ? C("TurboCheckoutBaseAssets", "") : m;
    c.guardFatal ? c.guardFatal(e)(c, window) : c.execute(function() {
        e(c, window)
    })
})(function(e, m, C) {
    "use strict";
    e.register("turbo-function-adapter", function() {
        return {
            adapt: function(c) {
                return function() {
                    if ("function" !== typeof c) throw "Parameter 'property' is invalid. Expected a function but got " + typeof c;
                    return c.apply(c, arguments)
                }
            }
        }
    });
    "use strict";
    e.when("turbo-configuration", "turbo-function-adapter").execute("turbo-signin-adapter-factory",
        function(c, d) {
            e.when(c.get(c.KEYS.SHOW_SIGN_IN_INTERFACE)).register("turbo-signin-adapter", function(a) {
                return {
                    show: d.adapt(a.show)
                }
            })
        });
    "use strict";
    e.when("turbo-configuration", "turbo-function-adapter").execute("turbo-view-adapter-factory", function(c, d) {
        e.when(c.get(c.KEYS.VIEW_ADAPTER)).register("turbo-view-adapter", function(a) {
            return {
                registerCallbacks: d.adapt(a.registerCallbacks),
                close: d.adapt(a.close),
                show: d.adapt(a.show),
                removeContent: d.adapt(a.removeContent),
                setContent: d.adapt(a.setContent),
                closeImmediatelyThenExecute: d.adapt(a.closeImmediatelyThenExecute),
                closeAndNavigate: d.adapt(a.closeAndNavigate),
                closeToFullscreen: d.adapt(a.closeToFullscreen),
                updateBounds: d.adapt(a.updateBounds)
            }
        })
    });
    "use strict";
    e.when("turbo-checkout-page-ready").execute(function() {
        e.declare("turbo-eligibility-override", !1)
    });
    "use strict";
    e.when("turbo-checkout-page-ready").execute(function() {
        e.declare("turbo-interstitial-suppression", !1)
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-configuration", "turbo-checkout-page-ready").register("turbo-checkout-address-id",
        function(c, d, a) {
            function b(a) {
                for (var b = 0; b < a.length; b++) {
                    var c = g(a[b]);
                    if (0 < c.length) return d.logCount("turboCheckoutAddressSelectorIndex" + b), c
                }
                d.logCount("turboCheckoutAddressSelectorMissing");
                return g()
            }
            var g = c.$;
            return {
                getAddressId: function() {
                    return b(a.get(a.KEYS.ADDRESS_INPUT_SELECTORS)).val() || ""
                },
                set: function(d) {
                    b(a.get(a.KEYS.ADDRESS_INPUT_SELECTORS)).val() !== d && b(a.get(a.KEYS.ADDRESS_INPUT_SELECTORS)).val(d).trigger("change", [d])
                }
            }
        });
    "use strict";
    e.when("A", "turbo-checkout-utils", "turbo-callback-list",
        "turbo-configuration", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkbox-exclusion-listener", function(c, d, a, b, g) {
        function f(a) {
            var d = r;
            r = !1;
            for (var b = 0; b < k.length; b++) {
                var c = p(k[b]).find("input[type\x3dcheckbox]");
                a(c)
            }
            d !== r && (w("Exclusion checkbox state changed"), n.callAll("exclusionCheckbox"))
        }

        function h(a) {
            var d;
            if (!(d = r)) {
                d = !1;
                for (var b = 0; b < a.length && !d; b++) {
                    var c = p(a[b]);
                    (d = c.prop("checked")) && w("Exclusion checkbox is checked", c)
                }
            }
            r = d
        }

        function w(a, b) {
            d.logDebug("turbo-checkbox-exclusion-listener",
                a, b)
        }

        function l() {
            f(h)
        }
        var k = b.get(b.KEYS.CHECKBOX_EXCLUSION_ROOT_NODES),
            p = c.$,
            n = a.create(),
            r = !1;
        g.bind(function() {
            f(function(a) {
                w("Listening for change events on:", a);
                a.unbind("change", l).bind("change", l);
                h(a)
            })
        });
        return {
            onStateChange: function(a) {
                n.push(a)
            },
            isAnyCheckboxChecked: function() {
                return r
            }
        }
    });
    "use strict";
    e.when("A", "turbo-callback-list", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkout-custom-price-input", function(c, d, a) {
        function b() {
            var a = g();
            w !== a && (w =
                a, h.callAll())
        }

        function g() {
            return f("#gcPriceOverride").val() || ""
        }
        var f = c.$,
            h = d.create(),
            w;
        a.bind(function() {
            w = g();
            f("#gcPriceOverride").unbind("change", b).bind("change", b)
        });
        return {
            getCustomPrice: g,
            onChange: function(a) {
                h.push(a)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-configuration", "turbo-callback-list", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkout-quantity-input", function(c, d, a, b, g, f) {
        function h(d) {
            var b;
            b = d ? d.value ? parseInt(d.value,
                10) : d.target && d.target.value ? parseInt(d.target.value, 10) : void 0 : void 0;
            r === b ? a.logDebug("turbo-checkout-quantity-input", "Quantity change event does NOT have new quantity. Suppressing callbacks", void 0) : (r = b, a.logDebug("turbo-checkout-quantity-input", "Quantity change event", d), k.callAll())
        }

        function w(a) {
            a = a.val();
            (a = parseInt(a, 10)) || d.logCount("turboCheckoutNoQuantityFromPage");
            return a || 1
        }
        var l = c.$,
            k = g.create(),
            p = b.get(b.KEYS.QUANTITY_SELECT_SELECTOR),
            n = "Multiple quantity nodes present on the page. This may lead to an incorrect quantity being used in Turbo! Selector \x3d " +
            p,
            r;
        f.bind(function() {
            var b = l(p);
            r = w(b);
            b.unbind("change", h).bind("change", h);
            1 < b.length && (a.logError(n, "turbo-checkout-quantity-input"), a.logDebug("turbo-checkout-quantity-input", n, b));
            d.logCount("turboCheckoutQuantityNodes", b.length)
        });
        return {
            getQuantity: function() {
                return w(l(p))
            },
            setQuantity: function(a) {
                var d = l(p),
                    b = w(d);
                a = parseInt(a, 10);
                b !== a && d.val(a).change()
            },
            onChange: function(a) {
                k.push(a)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-callback-list", "turbo-configuration",
        "turbo-checkout-quantity-input", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkout-warranty-input", function(c, d, a, b, g, f, h) {
        var w = c.$,
            l = b.create(),
            k = g.get(g.KEYS.WARRANTY_CHECKBOX_INPUT_SELECTOR),
            p = g.get(g.KEYS.WARRANTY_CHECKBOX_RELATIVE_PARENT_SELECTOR),
            n = g.get(g.KEYS.WARRANTY_ASIN_INPUT_NAME),
            r = g.get(g.KEYS.WARRANTY_OFFER_INPUT_SELECTOR);
        h.bind(function() {
            w(k).unbind("click", l.callAll).bind("click", l.callAll)
        });
        return {
            select: function(a) {
                a && w(p + " input[name^\x3d" + n +
                    "][value\x3d" + a + "]").parents(p).find(k).click()
            },
            onChange: function(a) {
                l.push(a)
            },
            getLineItem: function(b) {
                if (w(k + ":checked").length) {
                    var c = w(k + ":checked").first().parents(p).find("input[name^\x3d" + n + "]").val() || "",
                        g = w(r).val() || "";
                    b = parseInt(b, 10) || f.getQuantity() || 1;
                    if (c && g) return {
                        asin: c,
                        offerListingId: g,
                        quantity: b
                    };
                    d.logCount("turboCheckoutIncompleteWarrantyInputs");
                    a.logError("Incomplete input data for the selected warranty checkbox - asin:" + c + ", offerId:" + g + ", quantity:" + b)
                } else a.logDebug("turbo-checkout-warranty-input",
                    "No warranty checkbox is selected", void 0)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-callback-list", "turbo-configuration", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkout-vas-input", function(c, d, a, b, g) {
        function f() {
            return k(w).prop("checked") || !1
        }

        function h() {
            var a = n;
            n = f();
            a !== n && p.callAll(n)
        }
        var w = b.get(b.KEYS.VAS_CHECKBOX_SELCTOR),
            l = b.get(b.KEYS.VAS_CHANGE_EVENTS),
            k = c.$,
            p = a.create(),
            n;
        g.bind(function() {
            n = f();
            l.forEach(function(a) {
                c.off(a, h);
                c.on(a,
                    h)
            })
        });
        return {
            isSelected: f,
            onChange: function(a) {
                p.push(a)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-page-state", "turbo-checkout-product-state", "turbo-checkout-page-ready").register("turbo-checkout-joined-state", function(c, d, a, b, g) {
        function f(a, b) {
            function g() {
                var b = a.turboWeblab;
                b || d.logCount("turboCheckoutWeblabNameNotDefinedInState");
                return b
            }

            function f() {
                return a.turboWeblabTreatment
            }
            this.pageState = a;
            this.productStates = b;
            this.getLineItems = function() {
                return n.lineItemInputs
            };
            this.getActiveId = function() {
                return n.id
            };
            this.getHeaderText = function() {
                return n ? n.turboHeaderText || a.turboHeaderText : a.turboHeaderText
            };
            this.getLoadingText = function() {
                return a.turboLoadingText
            };
            this.getAddressId = function() {
                return a.addressId
            };
            this.getRequestId = function() {
                return a.requestId
            };
            this.getSessionId = function() {
                return a.sessionId
            };
            this.getInitiateSelector = function() {
                return a.initiateSelector
            };
            this.getWeblab = g;
            this.getWeblabTreatment = f;
            this.isTurboLaunched = function() {
                return !g() && "C" !== f()
            };
            this.isProductStateEligible = function() {
                return b.isTurboEligible
            };
            this.resolve = function(a) {
                if (a) {
                    n = b.states[a];
                    if (!n) throw a = "Resolved turbo checkout product state is undefined. Id \x3d " + a, h(a, b), a;
                    h("Resolved new product state", n);
                    c.trigger("turbo:checkout:state:product:resolved")
                }
            };
            var n = 1 !== b.states.length ? C : b.states[0]
        }

        function h(d, b) {
            a.logDebug("turbo-checkout-joined-state", d, b)
        }
        return {
            createTurboState: function(a, c, h, p, n) {
                if (p && h) throw "Custom item price is NOT supported with warranty";
                var r =
                    b.get();
                c && (r.addressId = c);
                c = g.get();
                if (a || p || h) a = parseInt(a, 10) || 1, c.states.forEach(function(b) {
                    b.lineItemInputs.forEach(function(b) {
                        b.quantity = a;
                        p ? (b.customItemPrice = p, d.logCount("turboCheckoutItemPriceOverrided")) : b.customItemPrice && d.logCount("turboCheckoutItemPriceSelectorFallBackToTurboState")
                    });
                    h && (h.quantity = a, b.lineItemInputs.push(h))
                });
                r = new f(r, c);
                r.resolve(n);
                return r
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-configuration", "turbo-checkout-aui-page-state-parser",
        "turbo-checkout-page-ready").register("turbo-checkout-page-state", function(c, d, a, b, g) {
        function f(a, d, b, c, g, f, h, l, k) {
            this.version = a;
            this.turboWeblab = d;
            this.turboWeblabTreatment = b;
            this.initiateSelector = c;
            this.turboLoadingText = g;
            this.turboHeaderText = f;
            this.addressId = h;
            this.requestId = l;
            this.sessionId = k
        }

        function h(d, b) {
            a.logDebug("turbo-checkout-page-state", d, b)
        }
        var w = b.get(b.KEYS.TURBO_PAGE_STATE_KEY),
            l = b.get(b.KEYS.PAGE_STATE_PARSING_ROOT_NODE_SELECTOR),
            k = new f("0", "", "C", "#buy-now-button", "", "", "",
                "", "");
        return {
            get: function(b, c) {
                b = b || w;
                c = c || l;
                c = g.parse(b, c);
                d.logCount("turboCheckoutPageStates", c.length);
                1 < c.length ? (a.logError("Multiple turbo checkout page states found! Turbo will NOT show", "turbo-checkout-page-state", void 0), h("PageStates", c), b = void 0) : (0 === c.length && h("Turbo checkout page state [" + b + "] is NOT present"), b = c[0]);
                if (b)
                    if (b.version) b = new f(b.version, b.turboWeblab || "", b.turboWeblabTreatment || "C", b.initiateSelector || ".buy-now-button", b.turboLoadingText || "", b.turboHeaderText || "",
                        b.addressId || "", b.requestId || "", b.sessionId || "");
                    else {
                        c = b.inputs || {};
                        var e = b.strings || {};
                        b = new f("1", b.turboWeblab || "", b.turboWeblabTreatment || "C", (b.configurations || {}).initiateSelector || "#buy-now-button", e.TURBO_LOADING_TEXT || "", e.TURBO_CHECKOUT_HEADER || "", c.addressId || "", c.requestId || "", c.sessionId || "")
                    }
                else d.logCount("turboCheckoutStateNotDefined"), b = k;
                h("Turbo Checkout PageState", b);
                return b
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-configuration", "turbo-checkout-aui-page-state-parser",
        "turbo-checkout-page-ready").register("turbo-checkout-product-state", function(c, d, a, b, g) {
        function f(a, b) {
            this.isTurboEligible = a;
            this.states = b
        }

        function h(a, b, d, c) {
            this.id = a;
            this.isTurboEligible = b;
            this.lineItemInputs = d;
            this.turboHeaderText = c || ""
        }

        function w(a, b, d, c, g, f) {
            this.asin = b || "";
            this.offerListingId = d || "";
            this.quantity = parseInt(c, 10) || 1;
            this.isTurboEligible = !!this.asin && !!this.offerListingId && a;
            this.productTitle = g || "";
            this.customItemPrice = f || ""
        }

        function l(b, d) {
            a.logDebug("turbo-checkout-product-state",
                b, d)
        }

        function k(a) {
            if (!a.lineItemInputs || !a.lineItemInputs.length || !a.id) return l('Versioned product state is invalid. Expected non empty "id" and "lineItemInputs". Turbo may NOT show', a), e;
            var b = !0,
                d = c.map(a.lineItemInputs, function(a) {
                    a = new w(a.isTurboEligible, a.asin, a.offerListingId, a.quantity, a.productTitle, a.customItemPrice);
                    b = b && a.isTurboEligible;
                    return a
                });
            return new h(a.id, b, d, a.turboHeaderText)
        }
        var p = b.get(b.KEYS.TURBO_PRODUCT_STATE_KEY),
            n = b.get(b.KEYS.PRODUCT_STATE_PARSING_ROOT_NODE_SELECTOR),
            e = new h("buy-now-button", !1, [], ""),
            q = new f(!1, [e]);
        return {
            get: function(b, c) {
                b = b || p;
                c = c || n;
                c = g.parse(b, c);
                d.logCount("turboCheckoutProductStates", c.length);
                1 < c.length && "turbo-checkout-page-state" === b ? (a.logError("turbo-checkout-page-state only supports the single item use case! Turbo will NOT show", "turbo-checkout-product-state", void 0), b = []) : b = c;
                if ((c = b) && c.length) {
                    var t = !1;
                    b = [];
                    for (var z = 0; z < c.length; z++) {
                        var u;
                        var v = c[z];
                        v ? v.version ? u = k(v) : v.inputs && v.eligibility ? (u = v.strings || {}, v = new w(v.eligibility.isEligible,
                            v.inputs.a, v.inputs.oid, v.inputs.quantity, u.TURBO_CHECKOUT_HEADER, v.inputs.customItemPrice), u = new h("buy-now-button", v.isTurboEligible, [v], u.TURBO_CHECKOUT_HEADER)) : (l('Legacy product state is missing "inputs" or "eligibility". Turbo will NOT show', v), u = e) : (l("Product state parsed DOM object is invalid. Turbo may NOT show", v), u = e);
                        t = t || u.isTurboEligible || !1;
                        v = u.id;
                        if (b[v]) throw c = "Duplicate product state found. id \x3d " + v, l(c, b), c;
                        b.push(u);
                        b[u.id] = u
                    }
                    b = new f(t, b)
                } else l("Parsed states are invalid. Turbo will NOT show",
                    c), b = q;
                l("Turbo Checkout Product State(s)", b);
                return b
            }
        }
    });
    "use strict";
    e.when("A", "turbo-configuration", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-auto-open", "turbo-checkout-address-id", "turbo-checkout-quantity-input", "turbo-checkout-warranty-input", "turbo-checkout-custom-price-input", "turbo-callback-list", "turbo-checkout-is-physical-gift-card-support-enabled", "turbo-checkout-joined-state", "turbo-checkout-page-ready").register("turbo-checkout-state-handler", function(c, d, a, b, g, f,
        h, w, l, k, p, n) {
        function e(a, b, d, c, g) {
            a = a || h.getQuantity();
            b = b || f.getAddressId();
            d = d || w.getLineItem(a);
            c = c || l.getCustomPrice();
            return n.createTurboState(a, b, d, c, g)
        }

        function q(a, d) {
            b.logDebug("turbo-checkout-state-handler", a, d)
        }

        function m() {
            var b = 0 !== u("#giftcardcustomtwister_feature_div").length;
            b && (q("Physical Gift Card use case"), a.logCount("turboCheckoutGiftCardUseCase"));
            return b
        }

        function x(a, b, d, c) {
            y = e(a, b, d, C, c)
        }

        function t() {
            c.trigger("turbo:checkout:product:onChange");
            D.callAll()
        }

        function z() {
            var a =
                e();
            b.isDeepEquals(y, a) || (y = a, q("New Turbo State", y), t())
        }
        var u = c.$,
            v = d.get(d.KEYS.TURBO_STATE_CHANGE_AUI_EVENTS),
            D = k.create(),
            y, E = !1;
        y = e();
        return {
            isProductTurboEligible: function() {
                return !E && y.isProductStateEligible() && (!m() || p) || d.get(d.KEYS.OVERRIDE_ELIGIBILITY)
            },
            getLineItems: function() {
                return y.getLineItems()
            },
            getAddressId: function() {
                return y.getAddressId()
            },
            getWeblabAllocation: function() {
                return y.getWeblabTreatment()
            },
            registerCallback: function(a) {
                D.push(a)
            },
            startMonitoringPage: function() {
                g.updateInputsAndThen(x);
                h.onChange(z);
                w.onChange(z);
                l.onChange(z);
                v.forEach(function(a) {
                    c.off(a, z);
                    c.on(a, z)
                });
                t()
            },
            getRequestId: function() {
                return y.getRequestId()
            },
            getSessionId: function() {
                return y.getSessionId()
            },
            getExperimentName: function() {
                return y.getWeblab()
            },
            getStrings: function() {
                return {
                    TURBO_LOADING_TEXT: y.getLoadingText(),
                    TURBO_CHECKOUT_HEADER: y.getHeaderText()
                }
            },
            getInitiateSelector: function() {
                return y.getInitiateSelector()
            },
            isTurboLaunched: function() {
                return y.isTurboLaunched()
            },
            isPhysicalGiftCardExperimentEligible: m,
            setTurboStateNotEligible: function() {
                E = !0
            },
            resolveProductState: function(a) {
                y.resolve(a)
            },
            getActiveId: function() {
                return y.getActiveId()
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-aui-page-state-parser", function(c, d) {
        var a = c.$;
        return {
            parse: function(b, c) {
                b = "script[data-a-state*\x3d'" + b + "']";
                c = c ? a(c).find(b) : a(b);
                b = [];
                for (var f = 0; f < c.length; f++) {
                    var h;
                    a: {
                        try {
                            var e = a(c[f]).text();
                            h = JSON.parse(e);
                            break a
                        } catch (l) {
                            d.logError("JSON::parse exception. Exception \x3d " +
                                l, "turbo-checkout-aui-page-state-parser", void 0)
                        }
                        h = void 0
                    }
                    h && b.push(h)
                }
                return b
            }
        }
    });
    "use strict";
    e.when("jQuery", "turbo-checkout-auto-open", "turbo-checkout-page-ready").register("turbo-checkout-page-load-spinner", function(c, d) {
        function a() {
            0 !== c("#turbo-checkout-auto-load-spinner-container").length && (c("#turbo-checkout-auto-load-spinner-container").remove(), g.unbind("touchmove touchstart touchend touchcancel click scroll", b))
        }

        function b(a) {
            a.preventDefault();
            a.stopPropagation()
        }
        var g = c("body");
        d.isAutoOpenEligible() &&
            (g.bind("touchmove touchstart touchend touchcancel click scroll", b), g.append("\x3cdiv id\x3d'turbo-checkout-auto-load-spinner-container' class\x3d'turbo-checkout-auto-load-spinner-container'\x3e\x3cdiv id\x3d'turbo-checkout-auto-load-circle-container' class\x3d'turbo-checkout-auto-load-circle-container'\x3e\x3cdiv id\x3d'turbo-checkout-auto-load-spinner' class\x3d'a-spinner a-spinner-medium turbo-checkout-auto-load-spinner'\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e"), setTimeout(a, 5E3));
        return {
            removePageLoadSpinner: a
        }
    });
    "use strict";
    e.when("turbo-configuration", "turbo-checkout-ref-tagger", "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-urls", function(c, d, a) {
        function b(a, b) {
            var d = c.get(c.KEYS.DEVICE_OVERRIDE);
            return "\x26pipelineType\x3dturbo\x26clientId\x3dretailwebsite" + (d ? "\x26devicestring-override\x3d" + d : "") + e(a, b)
        }

        function g() {
            var a = c.get(c.KEYS.HOST_PAGE_TYPE_IDENTIFIER);
            return d.generateRefTag(a, d.ACTIONS.BUY_NOW) + "\x26referrer\x3d" + a
        }

        function f(b) {
            return a.isNonEmptyString(b) ? "\x26weblab\x3d" +
                b : ""
        }

        function h() {
            return c.get(c.KEYS.IS_ADD_TO_CART_ENABLED) ? "\x26temporaryAddToCart\x3d1" : ""
        }

        function e(b, d) {
            var c = "";
            a.isNonEmptyString(b) && (c += "\x26pageRequestId\x3d" + b);
            a.isNonEmptyString(d) && (c += "\x26pageSessionId\x3d" + d);
            return c
        }
        return {
            buildInitiatePathWith: function(a, d, c, e) {
                a = "/checkout/turbo-initiate?" + g() + b(c, e) + f(a);
                return a + (d ? "\x26checkEligibilityOnly\x3dtrue" : "") + h()
            },
            buildConfirmPathWith: function(a, d, c) {
                return "/checkout/turbo-initiate/confirm?" + g() + b(d, c) + f(a) + h()
            },
            buildLogPageHitPathWith: function(a,
                c) {
                return "/checkout/log-page-hit?" + d.generateRefTag(a, d.ACTIONS.CLOSE, c) + b()
            },
            buildTriggerWeblabPathWith: function(a, b, d, c) {
                return "/checkout/triggerWeblab?" + g() + f(a) + "\x26weblabAllocation\x3d" + b + e(d, c)
            },
            buildTriggerWeblabPathWithoutWeblab: function(a, b) {
                return "/checkout/triggerWeblab?" + g() + e(a, b)
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-page-ready").register("turbo-callback-list", function() {
        function c() {
            var d = [];
            this.callAll = function() {
                for (var a = 0; a < d.length; a++) {
                    var b = d[a];
                    b.apply(b, arguments)
                }
            };
            this.push =
                function(a) {
                    if ("function" !== typeof a) throw "Invalid callback. Expected typeof 'callback' to be 'function'. typeof \x3d " + typeof a; - 1 === d.indexOf(a) && d.push(a)
                };
            this.remove = function(a) {
                a = d.indexOf(a); - 1 !== a && d.splice(a, 1)
            }
        }
        return {
            create: function() {
                return new c
            }
        }
    });
    "use strict";
    e.when("turbo-callback-list", "turbo-checkout-page-ready").register("turbo-filtered-callback-list", function(c) {
        function d(a) {
            var b = c.create();
            this.callAll = b.callAll;
            this.remove = b.remove;
            this.push = function(d) {
                (d = d[a]) && "function" ===
                typeof d && b.push(d)
            }
        }
        return {
            create: function(a) {
                if (!a || "string" !== typeof a) throw "Invalid filter parameter. Expected 'filter' to be a non empty string. typeof \x3d " + typeof a + " value \x3d " + a;
                return new d(a)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-page-ready").register("turbo-checkout-ajax-wrapper", function(c, d) {
        return {
            load: function(a, b) {
                b.hasOwnProperty("timeout") || (b.timeout = 2E4);
                return c.ajax(a, b)
            },
            loadWithJQXHR: function(a, b) {
                b.hasOwnProperty("timeout") || (b.timeout = 2E4);
                return c.$.ajax(a, b)
            },
            createXHRRequest: function() {
                var a = new XMLHttpRequest;
                a.timeout = 2E4;
                return a
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-session-storage", "turbo-checkout-quantity-input", "turbo-checkout-address-id", "turbo-checkout-warranty-input", "turbo-checkout-page-ready").register("turbo-checkout-auto-open", function(c, d, a, b, g, f, h) {
        function e(b, d) {
            a.logDebug("turbo-checkout-auto-open", b, d)
        }

        function l() {
            return k() && 0 !== q
        }

        function k() {
            var c;
            if (c = "1" ===
                x.trb_open || "1" === a.getUrlQueryParam("trb_open"))(c = b.isPresent("hasTurboAutoOpened")) && d.logCount("turboCheckoutAutoOpenLoopPrevented"), c = !c;
            return c
        }

        function p() {
            return 1 === q && k()
        }

        function n() {
            p() && (l() && (q = 2, b.set("hasTurboAutoOpened", "1")), t(x.trb_bid))
        }
        var r = c.$,
            q = 0,
            A = "trb_open trb_addr trb_qty trb_warrAsin trb_auth trb_sid trb_bid".split(" "),
            x = {},
            t = function() {};
        return {
            setup: function(b, d) {
                if (k()) {
                    q = 1;
                    var g = m.location.href;
                    r.each(A, function(b, d) {
                        b = a.getUrlQueryParam(d);
                        x[d] = b;
                        g = a.removeQueryParam(d,
                            b, g)
                    });
                    e("Parameters:", x);
                    a.replaceHistory(g);
                    "function" === typeof b ? t = b : a.logError("Initiate action must be supplied, and it must be a function.");
                    c.on("turbo:checkout:prefetcher:state:dataStale", n);
                    d()
                } else q = 0, e("Disabled")
            },
            reset: function() {
                b.remove("hasTurboAutoOpened")
            },
            isAutoOpenEligible: k,
            isAutoOpenEnabled: l,
            isAutoOpenReadyToBeOpened: p,
            updateInputsAndThen: function(a) {
                var b = x.trb_qty,
                    d = x.trb_addr,
                    c = x.trb_warrAsin,
                    l = x.trb_bid;
                if (b || d || c || l) {
                    b && g.setQuantity(b);
                    d && f.set(d);
                    var e;
                    c && (h.select(c),
                        e = h.getLineItem(b));
                    a(b, d, e, l)
                }
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-page-ready").register("turbo-checkout-utils", function() {
        function c() {
            return navigator.userAgent
        }

        function d(a, b) {
            if (a === b || "function" === typeof a && "function" === typeof b) return !0;
            if (typeof a !== typeof b) return !1;
            if ("object" !== typeof a || null === a || null === b) return a === b || a !== a && b !== b;
            var c = Object.getOwnPropertyNames(a);
            if (c.length !== Object.getOwnPropertyNames(b).length) return !1;
            for (var f = 0; f < c.length; f++) {
                var h = c[f];
                if (!a.hasOwnProperty(h) ||
                    !b.hasOwnProperty(h) || !d(a[h], b[h])) return !1
            }
            return !0
        }
        return {
            logError: function(a, b) {
                e.log(a, "ERROR", b || "turbo-checkout-utils")
            },
            logWarning: function(a, b) {
                e.log(a, "WARN", b || "turbo-checkout-utils")
            },
            logDebug: function() {},
            getUserAgent: c,
            isAndroid: function() {
                return !!c().match(/[a|A]ndroid/)
            },
            isIPhone: function() {
                return !!c().match(/iPhone/)
            },
            isIPad: function() {
                return !!c().match(/iPad/)
            },
            isInternetExplorer: function() {
                return !!c().match(/MSIE/)
            },
            createFQDN: function(a) {
                /^http/.test(a) || (a = m.location.origin ? m.location.origin +
                    a : m.location.protocol + "//" + m.location.hostname + ":" + m.location.port + a);
                return a
            },
            getUrlQueryParam: function(a, b) {
                b || (b = m.location.href);
                a = a.replace(/[\[\]]/g, "\\$\x26");
                return (a = (new RegExp("[?\x26]" + a + "(\x3d([^\x26#]*)|\x26|#|$)")).exec(b)) ? a[2] ? decodeURIComponent(a[2].replace(/\+/g, " ")) : "" : C
            },
            removeQueryParam: function(a, b, d) {
                var c = d;
                a && b && d && (a = a + "\x3d" + b, c = d.replace(new RegExp("\\?" + a + "[\x26]?", "g"), "?"), c = c.replace(new RegExp("[\x26]?" + a, "g"), ""));
                return c
            },
            replaceHistory: function(a) {
                m.history.pushState &&
                    m.history.replaceState(null, m.title, a)
            },
            isNonEmptyString: function(a) {
                return "string" === typeof a && 0 < a.length
            },
            isDeepEquals: d
        }
    });
    "use strict";
    e.when("turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-csm", function(c) {
        function d(a, d, c, g) {
            return "function" === typeof m.uet ? m.uet.apply(m.uet, arguments) : g || b()
        }

        function a(a, b, d) {
            return "function" === typeof m.ues ? m.ues.apply(m.ues, arguments) : d
        }

        function b() {
            return +new Date
        }

        function g(c) {
            function g() {
                q && h && e && f && !w && "function" === typeof x &&
                    (x(q, h, e, f), w = !0)
            }
            var h, f, e, q, w = !1,
                x;
            this.getId = function() {
                return c
            };
            this.markClick = function() {
                q = d("tc", c)
            };
            this.markFirstByte = function() {
                h = a("t0", c, b())
            };
            this.markAboveTheFold = function() {
                e = d("af", c);
                g()
            };
            this.markCriticalFeature = function() {
                f = d("cf", c);
                g()
            };
            this.whenDataSet = function(a) {
                x = a;
                g()
            }
        }

        function f(a) {
            "undefined" !== typeof m.ue_t0 && m.ue.count(a, Date.now() - m.ue_t0)
        }
        var h = 0,
            e = [];
        return {
            createScope: function() {
                return new g("chk_turbo_" + ++h)
            },
            logCount: function(a, b) {
                b = b || 1;
                c.logDebug("Logging counter " +
                    a + " with value " + b);
                if (m.ue && m.ue.count) {
                    var d = a + "_time";
                    m.ue.count(a, b);
                    f(d);
                    for (var g = 0; g < e.length; ++g) m.ue.count(a + "." + e[g], b), f(d + "." + e[g])
                }
            },
            addCounterExtraSuffix: function(a) {
                e.push(a)
            },
            timestamp: b
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-page-ready").register("turbo-checkout-counter", function(c, d) {
        var a = 0,
            b = 0,
            g = 0,
            f = 0,
            h = 0,
            e = 0,
            l = "u";
        c.on("turbo:checkout:sheet:beforeOpen", function() {
            d.logCount("turboCheckoutSheetOpen", a);
            "u" !== l ? (++h, d.logCount("turboCheckoutPrefetchUsed",
                h), "p" === l ? d.logCount("turboCheckoutPrefetchUsedInProgress", h) : d.logCount("turboCheckoutPrefetchUsedFull", h)) : (++e, d.logCount("turboCheckoutPrefetchMissing", e))
        });
        c.on("turbo:checkout:sheet:beforeClose", function() {
            ++b;
            d.logCount("turboCheckoutSheetClose", b)
        });
        c.on("turbo:checkout:prefetcher:state:dataPrefetching", function() {
            d.logCount("turboCheckoutPrefetchRequested", g);
            l = "p"
        });
        c.on("turbo:checkout:prefetcher:state:dataFresh", function() {
            ++f;
            d.logCount("turboCheckoutPrefetchAvailable", f);
            l = "a"
        });
        c.on("turbo:checkout:prefetcher:state:dataStale",
            function() {
                l = "u"
            });
        return {
            incrementSheetOpenedCounter: function() {
                a++
            },
            incrementPrefetchCounter: function() {
                g++
            },
            getSheetOpenCount: function() {
                return a
            },
            getPrefetchCount: function() {
                return g
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-page-ready").register("turbo-checkout-cacher", function() {
        return {
            createCache: function(c) {
                var d = !1,
                    a;
                return function() {
                    d || (a = c(), d = !0);
                    return a
                }
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-counter", "turbo-checkout-page-ready").register("turbo-checkout-ref-tagger", function(c, d) {
        function a(a,
            c, f) {
            a = "chk_" + a + "_" + c + "_" + d.getPrefetchCount() + "*" + d.getSheetOpenCount();
            return f ? a + "_" + f : a
        }
        return {
            generateRefTag: function(b, d, c) {
                return "ref_\x3d" + a(b, d, c)
            },
            generateValue: a,
            ACTIONS: {
                BUY_NOW: "buyNow",
                CLOSE: "close"
            },
            TAGS: {
                TOUCH: "touch",
                TOUCH_X: "touchX",
                BACK: "back",
                ROTATION: "rotation"
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-page-ready").register("turbo-checkout-prefetch-timer", function(c) {
        function d() {
            f || (f = !0, c.trigger("turbo:checkout:timer:onTimeout"))
        }

        function a() {
            if (f) return !0;
            var a = (new Date).getTime();
            return g ? 6E5 <= a - g : !1
        }
        var b, g, f = !1;
        return {
            startTimer: function() {
                b || (b = m.setTimeout(d, 6E5));
                g || (g = (new Date).getTime())
            },
            isTimeout: a,
            resetTimer: function() {
                m.clearTimeout(b);
                f = !1;
                g = b = null
            },
            checkTimeout: function() {
                a() && d()
            }
        }
    });
    "use strict";
    e.when("A", "jQuery", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-state-handler", "turbo-configuration", "turbo-checkout-page-ready").register("turbo-checkout-buy-now-button", function(c, d, a, b, g, f) {
        function h(a, d) {
            b.logDebug("turbo-checkout-buy-now-button",
                a, d)
        }

        function e(a) {
            a = a || k();
            a.unbind("click.turboCheckout").bind("click.turboCheckout", p).each(l)
        }

        function l(b, c) {
            b = (b = d._data(c, "events").click) ? b.length : 0;
            1 < b && (a.logCount("turboCheckoutBuyNowButtonMultipleClickEventsBound"), a.logCount("turboCheckoutBuyNowButtonMultipleClickEventsBoundQuantity:" + b))
        }

        function k(a) {
            return a ? d("#" + a) : d(g.getInitiateSelector())
        }

        function p(b) {
            h("Buy now button clicked");
            a.logCount("turboCheckoutBuyNowClicked");
            b && b.target && b.target.id || (h("Click event target is INVALID. Expected event target with an id. Turbo will NOT show",
                b), u = !0);
            if (u) u = !1, h("Buy now button callbacks supressed");
            else {
                g.resolveProductState(b.target.id);
                var c;
                h("Calling buy now button callbacks...");
                c = !1;
                for (var f = 0; f < z.length; f++) c = c || z[f]();
                c ? (h("Supressing default buy now button action"), b.preventDefault(), b.stopPropagation(), b.stopImmediatePropagation(), c = !0) : c = void 0;
                if (c) return !1
            }
            d(b.target).closest("form").attr("data-action", n());
            a.logCount("turboCheckoutBuyNowDefault");
            return !0
        }

        function n() {
            return k().attr("name") || "submit.buy-now"
        }

        function r(a) {
            for (var b =
                    z.length - 1; 0 <= b; --b) z[b] === a && z.splice(b, 1)
        }

        function q(a) {
            if (!a && 1 < k().length) throw "Button id parameter is NOT present. Cannot execute action without a button id on a page with multiple buy now buttons!";
        }

        function m(a) {
            a = k(a);
            x(a);
            e(a);
            a.click()
        }

        function x(a) {
            for (var b = 0; b < t.length; b++) {
                var c = t[b];
                h("Unbound configured event '" + c + "' from buy now button");
                a.unbind(c);
                d(document.body).undelegate(a.selector, c)
            }
        }
        var t = f.get(f.KEYS.CONFLICTING_INITIATE_LISTENERS),
            z = [],
            u = !1;
        c.on("turbo:checkout:clickInitiate",
            m);
        a.logCount("turboCheckoutBuyNowButtonBound");
        return {
            registerOnClickCallback: function(a) {
                r(a);
                z.push(a)
            },
            deregisterOnClickCallback: r,
            executeOriginalBuyNowAction: function(a) {
                q(a);
                u = !0;
                c.trigger("turbo:checkout:buyNowDisabled");
                c.trigger("turbo:checkout:clickInitiate", a)
            },
            executeTurboBuyNowAction: function(a) {
                q(a);
                u = !1;
                m(a)
            },
            getSubmitAction: n,
            bindTurboClickEvent: e,
            removeConflictingListeners: x
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-utils", "turbo-checkout-buy-now-button", "turbo-checkout-page-ready").register("turbo-checkout-buy-now-integration",
        function(c, d, a) {
            function b(a, b) {
                d.logDebug(a, "turbo-checkout-buy-now-integration", b)
            }
            var g = c.$,
                f = [];
            c.on("turbo:checkout:page:reappear", function() {
                b("Removing additional form inputs from form", f);
                for (var a;
                    (a = f.shift()) !== C;) a.remove()
            });
            return {
                isBuyNow: function(b) {
                    return b instanceof g && b.attr("data-action") === a.getSubmitAction()
                },
                checkoutWith: function(a, c) {
                    if (Array.isArray(a) && c instanceof g) {
                        var e;
                        e = c;
                        for (var k = 1; 0 < e.find('input[name\x3d"asin.' + k + '"]').length || 0 < e.find('input[name\x3d"offeringID.' +
                                k + '"]').length;) k++;
                        e = k;
                        for (var k = [], p = 0; p < a.length; p++) {
                            var n = a[p];
                            if (n !== C && n.asin && n.offerListingId) {
                                var m = e,
                                    n = [g("\x3cinput /\x3e", {
                                        type: "hidden",
                                        name: "asin." + m,
                                        value: n.asin
                                    }), g("\x3cinput /\x3e", {
                                        type: "hidden",
                                        name: "offeringID." + m,
                                        value: n.offerListingId
                                    }), g("\x3cinput /\x3e", {
                                        type: "hidden",
                                        name: "quantity." + m,
                                        value: n.quantity || 1
                                    })];
                                Array.prototype.push.apply(k, n);
                                e++
                            } else b('Line item inputs are invalid. Expected "asin" and "offerListingId" keys in object. Customer purchase inputs ignored!', n),
                                d.logError('Line item inputs are invalid. Expected "asin" and "offerListingId" keys in object. Customer purchase inputs ignored!')
                        }
                        p = c.find('input[name\x3d"itemCount"]');
                        1 === p.length ? p.val(e) : c.append(g("\x3cinput /\x3e", {
                            type: "hidden",
                            name: "itemCount",
                            value: e
                        }));
                        b("Appended additional buy now inputs.", k);
                        c.append.apply(c, k);
                        f = k
                    } else e = "Inputs are invalid. Expected array and jQuery object. lineItems \x3d " + a + " $form \x3d " + c, b(e, arguments), d.logError(e)
                }
            }
        });
    "use strict";
    e.when("turbo-checkout-page-ready").register("turbo-configuration-keys",
        function(c) {
            var d = {
                HOST_PAGE_TYPE_IDENTIFIER: "HOST_PAGE_TYPE_IDENTIFIER",
                BUY_NOW_BUTTON_SELECTOR: "BUY_NOW_BUTTON_SELECTOR",
                QUANTITY_SELECT_SELECTOR: "QUANTITY_SELECT_SELECTOR",
                ADDRESS_INPUT_SELECTORS: "ADDRESS_INPUT_SELECTORS",
                WARRANTY_CHECKBOX_INPUT_SELECTOR: "WARRANTY_CHECKBOX_INPUT_SELECTOR",
                WARRANTY_CHECKBOX_RELATIVE_PARENT_SELECTOR: "WARRANTY_CHECKBOX_RELATIVE_PARENT_SELECTOR",
                WARRANTY_ASIN_INPUT_NAME: "WARRANTY_ASIN_INPUT_NAME",
                WARRANTY_OFFER_INPUT_SELECTOR: "WARRANTY_OFFER_INPUT_SELECTOR",
                TURBO_STATE_CHANGE_AUI_EVENTS: "TURBO_STATE_CHANGE_AUI_EVENTS",
                TWISTER_PAGE_UPDATE_AUI_EVENT: "TWISTER_PAGE_UPDATE_AUI_EVENT",
                PREFETCH_TREATMENT: "PREFETCH_TREATMENT",
                NO_PREFETCH_TREATMENT: "NO_PREFETCH_TREATMENT",
                BUY_NOW_ONLY_TREATMENT: "BUY_NOW_ONLY_TREATMENT",
                IS_DEVICE_FILTER_REQUIRED: "IS_DEVICE_FILTER_REQUIRED",
                IS_SIGN_IN_SUPPORTED: "IS_SIGN_IN_SUPPORTED",
                USES_MASH_WILL_REAPPEAR: "USES_MASH_WILL_REAPPEAR",
                SHOW_SIGN_IN_INTERFACE: "SHOW_SIGN_IN_INTERFACE",
                IFRAME_ID: "IFRAME_ID",
                EXTEND_ELIGIBLE_STATE: "EXTEND_ELIGIBLE_STATE",
                VIEW_ADAPTER: "VIEW_ADAPTER",
                PAGE_STATE_PARSING_ROOT_NODE_SELECTOR: "PAGE_STATE_PARSING_ROOT_NODE_SELECTOR",
                PRODUCT_STATE_PARSING_ROOT_NODE_SELECTOR: "PRODUCT_STATE_PARSING_ROOT_NODE_SELECTOR",
                TURBO_PAGE_STATE_KEY: "TURBO_PAGE_STATE_KEY",
                TURBO_PRODUCT_STATE_KEY: "TURBO_PRODUCT_STATE_KEY",
                DEVICE_OVERRIDE: "DEVICE_OVERRIDE",
                CONFLICTING_INITIATE_LISTENERS: "CONFLICTING_INITIATE_LISTENERS",
                VAS_CHANGE_EVENTS: "VAS_CHANGE_EVENTS",
                VAS_CHECKBOX_SELCTOR: "VAS_CHECKBOX_SELCTOR",
                CHECKBOX_EXCLUSION_ROOT_NODES: "CHECKBOX_EXCLUSION_ROOT_NODES",
                MASH_ADAPTER: "MASH_ADAPTER",
                IS_ADD_TO_CART_ENABLED: "IS_ADD_TO_CART_ENABLED",
                IS_BUYNOW_ENABLED_FOR_SCREENREADER: "IS_BUYNOW_ENABLED_FOR_SCREENREADER",
                BACKGROUND_SCROLL_TARGET_SELECTOR: "BACKGROUND_SCROLL_TARGET_SELECTOR",
                OVERRIDE_ELIGIBILITY: "OVERRIDE_ELIGIBILITY",
                validate: function(a) {
                    if ("string" !== typeof a || !d[a]) throw "The key '" + a + "' is not defined within 'turbo-configuration-keys'.";
                }
            };
            return d
        });
    "use strict";
    e.when("A", "turbo-configuration-keys", "turbo-device-configuration", "turbo-client-configuration", "turbo-eligibility-override", "turbo-checkout-page-ready").register("turbo-configuration", function(c, d, a, b, g) {
        function f(a, b) {
            var c = h(a);
            k[a] =
                c === C ? b : c
        }

        function h(c) {
            var d = b[c];
            c = a[c];
            if (e(d)) return d;
            if (e(c)) return c
        }

        function e(a) {
            return "boolean" === typeof a || a
        }

        function l(c) {
            if (!e(b[c]) && !e(a[c])) throw "Required configuration override for key '" + c + "' is missing";
            k[c] = h(c)
        }
        var k;
        return {
            get: function(a) {
                d.validate(a);
                var b;
                k || (k = {}, l(d.HOST_PAGE_TYPE_IDENTIFIER), l(d.SHOW_SIGN_IN_INTERFACE), l(d.EXTEND_ELIGIBLE_STATE), l(d.VIEW_ADAPTER), f(d.BUY_NOW_BUTTON_SELECTOR, "#buy-now-button"), f(d.QUANTITY_SELECT_SELECTOR, 'select[name\x3d"quantity"]'), f(d.ADDRESS_INPUT_SELECTORS, ["#unifiedLocation1ClickAddress", "#unifiedLocationAddress"]), f(d.WARRANTY_CHECKBOX_INPUT_SELECTOR, ".mbb-checkbox input[name\x3dmbba]"), f(d.WARRANTY_CHECKBOX_RELATIVE_PARENT_SELECTOR, ".mbb-checkbox-column"), f(d.WARRANTY_ASIN_INPUT_NAME, "mbba"), f(d.WARRANTY_OFFER_INPUT_SELECTOR, "#mbb-offering-id"), f(d.TURBO_STATE_CHANGE_AUI_EVENTS, ["a:pageUpdate", "LocationUX_OnAddressChange"]), f(d.TWISTER_PAGE_UPDATE_AUI_EVENT, "a:pageUpdate"), f(d.PREFETCH_TREATMENT, "PREFETCH_DISABLED"), f(d.NO_PREFETCH_TREATMENT, "T1"),
                    f(d.BUY_NOW_ONLY_TREATMENT, "BUY_NOW_LAUNCHED"), f(d.IS_DEVICE_FILTER_REQUIRED, !1), f(d.IS_SIGN_IN_SUPPORTED, !0), f(d.USES_MASH_WILL_REAPPEAR, !1), f(d.IFRAME_ID, "turbo-checkout-iframe"), f(d.PAGE_STATE_PARSING_ROOT_NODE_SELECTOR, "#turboState"), f(d.PRODUCT_STATE_PARSING_ROOT_NODE_SELECTOR, "#turboState"), f(d.TURBO_PAGE_STATE_KEY, "turbo-checkout-page-state"), f(d.TURBO_PRODUCT_STATE_KEY, "turbo-checkout-page-state"), f(d.DEVICE_OVERRIDE, ""), f(d.CONFLICTING_INITIATE_LISTENERS, []), f(d.CHECKBOX_EXCLUSION_ROOT_NODES,
                        ".simpleBundleCheckBoxArea #simpleBundle_feature_div #monthlyPayments_feature_div #bbg_feature_div #addons_feature_div #mobile-accessory-upsell #detailPageGifting_feature_div".split(" ")), f(d.MASH_ADAPTER, ""), f(d.IS_ADD_TO_CART_ENABLED, !0), f(d.IS_BUYNOW_ENABLED_FOR_SCREENREADER, !0), f(d.BACKGROUND_SCROLL_TARGET_SELECTOR, "#productTitleGroupAnchor"), f(d.VAS_CHANGE_EVENTS, ["turbo:checkout:sheet:doClose"]), f(d.VAS_CHECKBOX_SELCTOR, "#vas-checkbox-input"), f(d.VAS_CHANGE_EVENTS, ["turbo:checkout:sheet:doClose"]),
                    f(d.VAS_CHECKBOX_SELCTOR, "#vas-checkbox-input"), f(d.OVERRIDE_ELIGIBILITY, g));
                b = k;
                return b[a]
            },
            KEYS: c.copy(d)
        }
    });
    "use strict";
    e.when("turbo-checkout-utils", "turbo-checkout-weblab-allocation", "turbo-checkout-state-handler", "turbo-checkbox-exclusion-listener", "turbo-checkout-content-loader", "turbo-checkout-device-filter", "turbo-callback-list", "turbo-checkout-auto-open", "turbo-checkout-vas-input", "turbo-checkout-page-ready").register("turbo-base-eligible-state", function(c, d, a, b, g, f, h, e, l) {
        function k() {
            t = !0
        }

        function m() {
            t = !1
        }

        function n() {
            var c = new r;
            f.isDeviceTurboEligible() || c.invalidate("Device is NOT eligible");
            g.isError() && !d.isNoPrefetch() && c.invalidate("Prefetch failed");
            a.isProductTurboEligible() || c.invalidate("Product is NOT eligible");
            e.isAutoOpenEnabled() || t || c.invalidate("Cheetah eligibility response is false");
            d.isControl() && c.invalidate("Weblab is in CONTROL");
            d.isBuyNowOnly() && c.invalidate("Weblab is in buy now only treatment");
            l.isSelected() && c.invalidate("Value added service is selected and NOT supported");
            b.isAnyCheckboxChecked() && c.invalidate("Exclusion case checkbox is checked");
            A.callAll(c);
            c.logInvalidState();
            return c.canShow()
        }

        function r() {
            var a = !0,
                b = [];
            this.invalidate = function(c) {
                a = !1;
                b.push(c)
            };
            this.logInvalidState = function() {
                a || c.logDebug("turbo-base-eligible-state", "Cannot show turbo because: " + b)
            };
            this.canShow = function() {
                return a
            }
        }

        function q(a) {
            x.callAll(n(), a)
        }
        var A = h.create(),
            x = h.create(),
            t = !1;
        return {
            addStateCheck: function(a) {
                A.push(a)
            },
            canShow: n,
            registerStateChangeCallback: function(a) {
                x.push(a)
            },
            onStateChange: q,
            setup: function() {
                g.registerCallback({
                    onTurboEligible: k,
                    onFinish: k,
                    onTurboIneligible: m
                });
                a.registerCallback(q);
                b.onStateChange(q);
                l.onChange(q)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-callback-list", "turbo-checkout-page-ready").register("turbo-checkout-base-view", function(c, d) {
        function a(a) {
            if ("string" !== typeof a) throw "Parameter 'iFrameContainerSelector' is not a string.";
            this.onBoundsAdjustedCallbacks = d.create();
            this.IFRAME_CONTAINER_SELECTOR = a
        }
        var b = c.$;
        a.prototype.updateBounds = function(a) {
            if ("number" !==
                typeof a) throw 'Parameter "iFrameContentHeight" is not a number. Cannot validate bounds.';
            var b = this.$getIFrameContainer().height(),
                c = a - b;
            a = b + c;
            0 !== c && (this.$getIFrameContainer().height(a), c = parseInt(this.$getIFrameContainer().css("min-height"), 10), a = a > c ? a : c, b !== a && this.onBoundsAdjustedCallbacks.callAll(a))
        };
        a.prototype.$getIFrameContainer = function() {
            return b(this.IFRAME_CONTAINER_SELECTOR)
        };
        a.prototype.pushBoundsAdjustedCallback = function(a) {
            this.onBoundsAdjustedCallbacks.push(a)
        };
        return {
            extend: function() {
                function b() {
                    a.apply(this,
                        arguments)
                }
                b.prototype = Object.create(a.prototype);
                return b.prototype.constructor = b
            }
        }
    });
    "use strict";
    e.when("turbo-configuration", "turbo-checkout-page-ready").execute("turbo-eligible-state-check", function(c) {
        c.get(c.KEYS.EXTEND_ELIGIBLE_STATE) || e.when("turbo-base-eligible-state").register("turbo-checkout-eligible-state", function(c) {
            return {
                canShow: c.canShow,
                registerStateChangeCallback: c.registerStateChangeCallback,
                setup: c.setup
            }
        })
    });
    "use strict";
    e.when("A", "turbo-checkout-state-handler", "turbo-configuration",
        "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-weblab-allocation", function(c, d, a) {
        function b() {
            return d.getWeblabAllocation()
        }
        return {
            getAllocation: b,
            getExperimentName: function() {
                return d.getExperimentName()
            },
            isControl: function() {
                return "C" === b()
            },
            isBuyNowOnly: function() {
                return b() === a.get(a.KEYS.BUY_NOW_ONLY_TREATMENT)
            },
            isPrefetch: function() {
                return b() === a.get(a.KEYS.PREFETCH_TREATMENT)
            },
            isNoPrefetch: function() {
                var c = a.get(a.KEYS.NO_PREFETCH_TREATMENT);
                return !!b().match(c)
            }
        }
    });
    "use strict";
    e.when("A", "jQuery", "turbo-checkout-ajax-wrapper", "turbo-checkout-utils", "turbo-checkout-urls", "turbo-checkout-csm", "turbo-checkout-weblab-allocation", "turbo-checkout-buy-now-button", "turbo-configuration", "turbo-checkout-state-handler", "turbo-checkout-eligibility-response-weblabs", "turbo-checkout-page-ready").register("turbo-checkout-weblab-trigger", function(c, d, a, b, g, f, e, m, l, k, p) {
        function n() {
            c.on("turbo:checkout:prefetch:onTurboEligible", function() {
                E = !0;
                A()
            })
        }

        function r() {
            c.on("turbo:checkout:prefetch:onTurboIneligible",
                function() {
                    E = !1;
                    A()
                })
        }

        function q() {
            c.on("a:pageUpdate", function() {
                A()
            })
        }

        function A() {
            0 === x().length ? f.logCount("turboCheckoutBuyNowButtonMissing") : 0 === t().length && f.logCount("turboCheckoutBuyNowFormMissing");
            0 < t().length && (E ? (b.logDebug("turbo-checkout-weblab-trigger", "Adding trigger to form: " + e.getAllocation()), u.val(e.getAllocation()), v.val(e.getExperimentName()), D.val(k.getRequestId()), y.val(k.getSessionId()), t().append(u, v, D, y)) : (b.logDebug("turbo-checkout-weblab-trigger", "Removing trigger from form: " +
                e.getAllocation()), u.remove(), v.remove(), D.remove(), y.remove()))
        }

        function x() {
            var a = l.get(l.KEYS.BUY_NOW_BUTTON_SELECTOR);
            return d(a)
        }

        function t() {
            return x().closest("form")
        }

        function z() {
            function c(b, d, e) {
                b = !E || k.isTurboLaunched() ? g.buildTriggerWeblabPathWithoutWeblab(k.getRequestId(), k.getSessionId()) : g.buildTriggerWeblabPathWith(b, d, k.getRequestId(), k.getSessionId());
                a.load(b, {
                    method: "POST",
                    params: {
                        additionalWeblabsToTrigger: JSON.stringify(e)
                    },
                    error: function(a, b, c) {
                        a && 204 === a.http.status || f.logCount("turboCheckoutTriggerRecordingFailed")
                    },
                    abort: function(a) {
                        f.logCount("turboCheckoutTriggerRecordingFailed")
                    }
                })
            }
            if (p.get() && 0 < p.get().length || E && !k.isTurboLaunched()) b.logDebug("turbo-checkout-weblab-trigger", "Calling cheetah to trigger: " + e.getAllocation()), 0 < t().find(u).length || f.logCount("turboCheckoutTriggerMissing"), c(e.getExperimentName(), e.getAllocation(), p.get())
        }
        var u, v, D, y, E = !1;
        return {
            setup: function() {
                u = d("\x3cinput/\x3e", {
                    type: "hidden",
                    name: "triggerTurboWeblab",
                    value: ""
                });
                v = d("\x3cinput/\x3e", {
                    type: "hidden",
                    name: "triggerTurboWeblabName",
                    value: ""
                });
                D = d("\x3cinput/\x3e", {
                    type: "hidden",
                    name: "turboPageRequestId",
                    value: ""
                });
                y = d("\x3cinput/\x3e", {
                    type: "hidden",
                    name: "turboPageSessionId",
                    value: ""
                });
                q();
                n();
                r();
                m.registerOnClickCallback(z)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-state-handler", "turbo-checkout-page-ready").register("turbo-checkout-page-filter", function(c, d) {
        return {
            isCurrentViewTurboEligible: function() {
                var a = c.$(d.getInitiateSelector());
                return 0 < a.length && a.closest("form").length === a.length
            }
        }
    });
    "use strict";
    e.when("turbo-configuration",
        "turbo-checkout-page-ready").execute("turbo-device-filter-check", function(c) {
        c.get(c.KEYS.IS_DEVICE_FILTER_REQUIRED) || e.when("turbo-checkout-cacher", "turbo-checkout-page-ready").register("turbo-checkout-device-filter", function(c) {
            var a = function() {
                return !0
            };
            return {
                isDeviceTurboEligible: c.createCache(a),
                isSignInSupported: c.createCache(a)
            }
        })
    });
    "use strict";
    e.when("A", "turbo-checkout-state-handler", "turbo-checkout-device-filter", "turbo-checkout-page-filter", "turbo-checkout-weblab-allocation", "turbo-checkout-page-ready").register("turbo-checkout-eligibility-aggregator",
        function(c, d, a, b, g) {
            return {
                isTurboEligible: function() {
                    return b.isCurrentViewTurboEligible() && d.isProductTurboEligible() && !g.isBuyNowOnly()
                },
                isSignInSupported: function() {
                    return a.isSignInSupported() && !g.isBuyNowOnly()
                },
                shouldAttemptPrefetch: function() {
                    return a.isDeviceTurboEligible() && !g.isBuyNowOnly()
                }
            }
        });
    "use strict";
    e.when("A", "turbo-filtered-callback-list", "turbo-checkout-state-handler", "turbo-checkout-ajax-wrapper", "turbo-checkout-utils", "turbo-checkout-urls", "turbo-checkout-csm", "turbo-checkout-eligibility-aggregator",
        "turbo-checkout-eligibility-response-weblabs", "turbo-checkout-page-ready").register("turbo-checkout-content-loader", function(c, d, a, b, g, f, e, w, l) {
        function k(d) {
            e.logCount("turboCheckoutInitiate");
            D();
            L = !1;
            K = Date.now();
            q("Notifying loading callbacks");
            B = "started";
            M.callAll();
            c.trigger("turbo:checkout:prefetch:onStart");
            e.logCount("turboCheckoutPrefetchStart");
            var g = f.buildInitiatePathWith(a.getExperimentName(), d, a.getRequestId(), a.getSessionId());
            I = b.loadWithJQXHR(g, {
                type: "POST",
                data: p(d),
                headers: n(),
                xhr: r,
                success: t,
                error: z
            })
        }

        function p(b) {
            var c = {
                isAsync: 1
            };
            a.getAddressId() && (c.addressID = a.getAddressId());
            a.isPhysicalGiftCardExperimentEligible() && (c.isPhysicalGiftCard = a.isPhysicalGiftCardExperimentEligible());
            b || a.getLineItems().forEach(function(a, b) {
                b += 1;
                c["asin." + b] = a.asin;
                c["offerListing." + b] = a.offerListingId;
                c["quantity." + b] = a.quantity;
                a.customItemPrice && (c["customItemPrice." + b] = a.customItemPrice, c.customItemPrice = a.customItemPrice)
            });
            return c
        }

        function n() {
            var a = {
                "x-amz-support-custom-signin": 1
            };
            a["x-amz-turbo-checkout-dp-url"] = m.location.href;
            a["x-amz-checkout-entry-referer-url"] = m.location.href;
            return a
        }

        function r() {
            var a = b.createXHRRequest();
            a.addEventListener("readystatechange", function() {
                if (L || !a.readyState || 2 > a.readyState) q("Ignoring ready state changed event because headers already received or missing xhr");
                else if (L = !0, e.logCount("turboCheckoutPrefetchHeadersReceived"), e.logCount("turboCheckoutPrefetchHeadersReceivedDuration", Date.now() - K), u(a)) {
                    q("Headers received: Turbo eligible");
                    e.logCount("turboCheckoutTurboEligibleAfterCheetahChecks");
                    var b = A(a),
                        d = w.isSignInSupported();
                    b && (q("Headers received: Signin required"), e.logCount("turboCheckoutSigninRequired"), d || (q("Sign-in required but it is disabled or not supported."), e.logCount("turboCheckoutSigninNotSupported")));
                    if (d || !b) q("Notifying turbo eligible callbacks"), Q.callAll(), c.trigger("turbo:checkout:prefetch:onTurboEligible");
                    x(a) && G.callAll(a.getResponseHeader("x-amzn-checkout-login-provider"))
                } else q("Headers received: Not turbo eligible"),
                    O.callAll(), c.trigger("turbo:checkout:prefetch:onTurboIneligible")
            });
            return a
        }

        function q(a, b) {
            g.logDebug("turbo-checkout-content-loader", a, b)
        }

        function A(a) {
            return a && a.getResponseHeader("x-amzn-checkout-login-required")
        }

        function x(a) {
            return w.isSignInSupported() && A(a)
        }

        function t(a, b, d) {
            e.logCount("turboCheckoutPrefetchEnd", Date.now() - K);
            I = null;
            b = u(d);
            var f, k = a && a.match(y);
            if (k && 0 < k.length) try {
                var m = E(k[0]);
                f = E.parseJSON(m.text())
            } catch (n) {
                g.logError("Could not extract page state from cheetah page: " +
                    n)
            } else q("Could not extract page state from response data");
            var m = f && "turbo" === f.pipelineType,
                k = f && f.currentPurchaseId && 0 < String(f.currentPurchaseId).trim().length,
                t = d.getResponseHeader("x-amzn-experiment-weblabs-to-trigger");
            if (t !== C) {
                var p = [];
                try {
                    p = JSON.parse(t)
                } catch (n) {
                    console.error("Error parsing additional weblabs from xhr response header: ", n)
                }
                l.set(p)
            }
            m && !k && g.logError("No purchaseid provided, cannot show turbo");
            b && m && k ? ("started" !== B && g.logError("turbo-checkout-content-loader", "Error processing turbo available callbacks. Expected state to be started but was " +
                B), q("Notifying turbo available callbacks"), B = "success", N.callAll(a, f), c.trigger("turbo:checkout:prefetch:onSuccess"), e.logCount("turboCheckoutTurboPrefetchSuccess")) : b && x(d) ? q("Body received: Eligible and sign-in is supported and required.") : (q("Body received: No turbo page or not eligible: isTurboEligible: " + b + " isTurboPage: " + m + " hasPurchaseId: " + k), v(), e.logCount("turboCheckoutTurboPrefetchFail"))
        }

        function z(a, b, c) {
            e.logCount("turboCheckoutPrefetchEnd");
            I = null;
            q("Error while initiate", c);
            e.logCount("turboCheckoutTurboPrefetchError");
            "timeout" === b && e.logCount("turboCheckoutInitiateTimeOut");
            v()
        }

        function u(a) {
            return a && a.getResponseHeader("x-amz-turbo-checkout-eligible")
        }

        function v() {
            "started" !== B && g.logError("turbo-checkout-content-loader", "Error processing turbo not available callbacks. Expected state to be started but was " + B);
            q("Notifying error callbacks");
            B = "error";
            P.callAll();
            c.trigger("turbo:checkout:prefetch:onError")
        }

        function D() {
            I && I.abort && (q("Aborting running request..."), I.abort())
        }
        var y = /<script.*data-a-state.*checkout:conductor:page.*>.*<\/script>/,
            E = c.$,
            I, B = "stopped",
            K, L = !1,
            M = d.create("onStart"),
            N = d.create("onFinish"),
            P = d.create("onError"),
            Q = d.create("onTurboEligible"),
            O = d.create("onTurboIneligible"),
            G = d.create("onSigninRequired");
        c.on("turbo:checkout:signInController:onDoSignIn", v);
        return {
            registerCallback: function(a) {
                M.push(a);
                N.push(a);
                P.push(a);
                Q.push(a);
                G.push(a);
                O.push(a)
            },
            callInitiate: function() {
                q("Calling turbo initiate");
                k()
            },
            checkEligibility: function() {
                q("Calling turbo eligibility check only");
                k(!0)
            },
            abortCall: D,
            isSuccess: function() {
                return "success" ===
                    B
            },
            isError: function() {
                return "error" === B
            },
            isStarted: function() {
                return "started" === B
            }
        }
    });
    "use strict";
    e.when("A", "jQuery", "turbo-checkout-ref-tagger", "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-history-manager", function(c, d, a, b) {
        function g() {
            if (m.history.state && m.history.state.turboAction) return m.history.state.turboAction
        }
        d(m).bind("popstate.turbo", function(d) {
            g();
            g() ? (b.logDebug("turbo-checkout-history-manager", "Trigger sheet open"), c.trigger("turbo:checkout:sheet:doOpen")) :
                (b.logDebug("turbo-checkout-history-manager", "Trigger sheet close"), c.trigger("turbo:checkout:sheet:doClose", {
                    immediate: !1,
                    reason: a.TAGS.BACK
                }))
        });
        return {
            sheetOpened: function() {
                g();
                g() || (b.logDebug("turbo-checkout-history-manager", "Adding turbo history state"), m.history.pushState({
                    turboAction: "popover"
                }, document.title + " Turbo open"))
            },
            sheetClosed: function() {
                g();
                g() && (b.logDebug("turbo-checkout-history-manager", "Removing turbo history state"), m.history.back())
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-page-ready").register("turbo-base-visibility-manager",
        function(c) {
            function d() {
                c.trigger("turbo:checkout:page:gone")
            }
            return {
                setup: function() {
                    c.on("turbo:checkout:sheet:onNavigateAway", d)
                }
            }
        });
    e.when("turbo-configuration", "turbo-checkout-page-ready").execute("turbo-mash-will-reappear-check", function(c) {
        c.get(c.KEYS.USES_MASH_WILL_REAPPEAR) || e.when("turbo-base-visibility-manager").register("turbo-checkout-page-visibility-manager", function(c) {
            return c
        })
    });
    "use strict";
    e.when("A", "jQuery", "turbo-checkout-view-state", "turbo-checkout-weblab-allocation", "turbo-checkout-state-handler",
        "turbo-checkout-content-loader", "turbo-checkout-prefetch-timer", "turbo-checkout-page-visibility-manager", "turbo-checkout-counter", "turbo-checkout-utils", "turbo-checkout-eligibility-aggregator", "turbo-checkout-auto-open", "turbo-checkout-page-ready").register("turbo-checkout-prefetcher", function(c, d, a, b, g, e, h, m, l, k, p, n) {
        function r(a) {
            var b = A;
            A = a;
            k.logDebug("turbo-checkout-prefetcher", "Transitioning from " + b.name + " to " + a.name);
            if (b.onExit) b.onExit(a.name);
            if (a.onEnter) a.onEnter(b.name);
            c.trigger("turbo:checkout:prefetcher:state:" +
                a.name);
            c.trigger("turbo:checkout:prefetcher:state", a.name)
        }
        var q, A, x = function() {
                var a = e.isError(),
                    b = !p.isTurboEligible(),
                    c = h.isTimeout(),
                    d = 0 === q;
                k.logDebug("turbo-checkout-prefetcher", "Test is data stale: isStaleWhenCheetahReturnsError: " + a + " isStaleWhenProductNotEligiblie: " + b + " isStaleWhenTimeoutOccurs: " + c + " isStaleWhenNoMorePrefetchesAvailable: " + d);
                return a || b || c || d
            },
            t = function() {
                var a = p.isTurboEligible() && !h.isTimeout() && 0 < q;
                k.logDebug("turbo-checkout-prefetcher", "Test should prefetch: eligibilityAggregator.isTurboEligible(): " +
                    p.isTurboEligible() + " !timer.isTimeout(): " + !h.isTimeout() + " _prefetchesAvailable: " + q);
                return a
            },
            z = {
                name: "start",
                onEvent: function(a) {
                    p.shouldAttemptPrefetch() ? "controller:onPageLoaded" === a && r(u) : r(y)
                },
                onExit: function() {
                    g.startMonitoringPage()
                }
            },
            u = {
                name: "dataStale",
                onEvent: function(a) {
                    "page:gone" !== a && "prefetch:onError" !== a && "sheet:afterClose" !== a && t() && r(v)
                }
            },
            v = {
                name: "dataPrefetching",
                onEnter: function() {
                    l.incrementPrefetchCounter();
                    b.isPrefetch() || a.isOpeningOrOpen() || n.isAutoOpenReadyToBeOpened() ?
                        e.callInitiate() : e.checkEligibility();
                    --q
                },
                onEvent: function(a) {
                    if ("page:gone" === a) r(u);
                    else {
                        var c = e.isSuccess() && b.isPrefetch(),
                            d = e.isSuccess() && b.isNoPrefetch();
                        k.logDebug("turbo-checkout-prefetcher", "Test is data fresh: isFreshWhenPrefetchResultOKInT1: " + c + " isFreshWhenPrefetchResultOKInT4: " + d);
                        c || d ? r(D) : x() ? r(u) : "product:onChange" === a && t() && r(v)
                    }
                },
                onExit: function(a) {
                    "dataFresh" !== a && e.abortCall()
                }
            },
            D = {
                name: "dataFresh",
                onEnter: function() {
                    h.startTimer()
                },
                onEvent: function(b) {
                    "page:gone" === b ? r(u) :
                        x() ? r(u) : (a.isClosed() || "product:onChange" === b) && t() && r(v)
                },
                onExit: function() {
                    h.resetTimer()
                }
            },
            y = {
                name: "end"
            },
            E = "controller:onPageLoaded sheet:beforeOpen sheet:afterClose product:onChange prefetch:onSuccess prefetch:onError timer:onTimeout page:gone page:reappear".split(" "),
            C = {
                "sheet:beforeOpen": function() {
                    q = 10
                }
            };
        return {
            setup: function() {
                q = 10;
                A = z;
                d.each(E, function(a, b) {
                    var d = C[b];
                    c.on("turbo:checkout:" + b, function(a) {
                        k.logDebug("turbo-checkout-prefetcher", "Processing " + b);
                        d && d();
                        if (A.onEvent) A.onEvent(b)
                    })
                })
            },
            getState: function() {
                return A.name
            }
        }
    });
    "use strict";
    e.when("A", "turbo-signin-adapter", "turbo-checkout-content-loader", "turbo-checkout-buy-now-button", "turbo-checkout-csm", "turbo-checkout-weblab-allocation", "turbo-checkout-utils", "turbo-callback-list", "turbo-checkout-state-handler", "turbo-checkout-eligible-state", "turbo-checkout-page-ready").register("turbo-checkout-signin-controller", function(c, d, a, b, e, f, h, m, l, k) {
        function p() {
            t = !1
        }

        function n(a) {
            t = !0;
            z = a;
            e.logCount("turboCheckoutSigninRequired")
        }

        function r() {
            var a =
                t && k.canShow();
            a && (h.logDebug("turbo-checkout-signin-controller", "Showing sign in dialog"), e.logCount("turboCheckoutSigninPopup"), d.show(z, q, A), c.trigger("turbo:checkout:signInController:onDoSignIn"));
            return a
        }

        function q() {
            h.logDebug("turbo-checkout-signin-controller", "Signin success");
            e.logCount("turboCheckoutSigninSuccess");
            x.callAll()
        }

        function A() {
            h.logDebug("turbo-checkout-signin-controller", "Signin failed");
            e.logCount("turboCheckoutSigninFailed")
        }
        var x = m.create(),
            t = !1,
            z;
        return {
            setup: function() {
                a.registerCallback({
                    onStart: p,
                    onSigninRequired: n
                });
                b.registerOnClickCallback(r)
            },
            registerCallback: x.push
        }
    });
    "use strict";
    e.when("A", "turbo-configuration", "turbo-callback-list", "turbo-filtered-callback-list", "turbo-checkout-page-ready").register("turbo-checkout-iframe", function(c, d, a, b) {
        function e() {
            return c.$("#" + k)
        }

        function f() {
            if (!(0 < e().length)) throw "Attempted to read / write the iFrame without it being in the DOM. This would result in an undefined iFrame document.";
            var a = e()[0];
            return a.contentDocument || a.contentWindow.document
        }

        function h() {
            if (0 < e().length) throw "Attempted to insert multiple Turbo Checkout iFrames";
        }

        function m() {
            return c.$("\x3ciframe/\x3e", {
                id: k,
                src: "about:blank",
                scrolling: "no",
                "class": "turbo-checkout-blank"
            })
        }

        function l(a) {
            r.push(a)
        }
        var k = d.get(d.KEYS.IFRAME_ID),
            p = b.create("beforeFramePopulated"),
            n = b.create("afterFramePopulated"),
            r = a.create();
        l(function(a) {
            a.addClass("turbo-checkout-shown")
        });
        c.on("turbo:checkout:iframe:document:loaded", function() {
            r.callAll(e())
        });
        return {
            write: function(a) {
                p.callAll();
                a +=
                    '\x3cscript\x3e"use strict";window.parent.P.now("turbo-checkout-controller").execute("callbackPageController", function callbackPageController(controller) {controller.frameHtmlRendered();});P.when("load").execute("onTurboDocumentLoaded", function onTurboDocumentLoaded() {window.parent.P.when("A").execute("triggerTurboDocumentLoaded", function triggerTurboDocumentLoaded(A) {A.trigger("turbo:checkout:iframe:document:loaded");});});\x3c/script\x3e';
                if ("string" !== typeof a) throw "Attempted to write non-string value to iFrame. typeof \x3d " +
                    typeof a;
                var b = f();
                b.open();
                b.write(a);
                b.close();
                n.callAll(e()[0])
            },
            remove: function() {
                e().remove()
            },
            appendTo: function(a) {
                h();
                a.append(m())
            },
            insertInto: function(a) {
                h();
                a.html(m())
            },
            hasContent: function() {
                var a = 0 < e().length && f();
                return a && (a.body.hasChildNodes() || a.head.hasChildNodes())
            },
            registerCallbacks: function(a) {
                p.push(a);
                n.push(a)
            },
            onContentLoaded: l
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-page-ready").register("turbo-checkout-view-state", function(c) {
        function d(a, b) {
            return function() {
                return e ===
                    a || e === b
            }
        }

        function a(a) {
            return function() {
                e = a;
                b.apply(b, arguments)
            }
        }

        function b(a, b) {
            a && "string" === typeof a && c.trigger(a, b)
        }
        var e = 0;
        return {
            isClosed: d(0),
            isClosing: d(1),
            isOpen: d(2),
            isOpening: d(3),
            isClosingOrClosed: d(1, 0),
            isOpeningOrOpen: d(3, 2),
            setToOpen: a(2),
            setToOpening: a(3),
            setToClosed: a(0),
            setToClosing: a(1)
        }
    });
    "use strict";
    e.when("A", "turbo-view-adapter", "turbo-checkout-view-state", "turbo-checkout-eligible-state", "turbo-checkout-content-loader", "turbo-checkout-utils", "turbo-checkout-weblab-allocation",
        "turbo-checkout-weblab-trigger", "turbo-checkout-csm", "turbo-checkout-state-handler", "turbo-checkout-device-filter", "turbo-checkout-ajax-wrapper", "turbo-checkout-page-visibility-manager", "turbo-checkout-counter", "turbo-checkout-prefetcher", "turbo-checkout-prefetch-timer", "turbo-checkout-buy-now-button", "turbo-checkout-signin-controller", "turbo-checkout-auto-open", "turbo-checkout-urls", "turbo-checkout-ref-tagger", "turbo-configuration", "turbo-interstitial-suppression", "turbo-checkout-page-ready").register("turbo-checkout-controller",
        function(c, d, a, b, e, f, h, m, l, k, p, n, r, q, A, x, t, z, u, v, D, y, E) {
            function C() {
                T && E && t.removeConflictingListeners();
                t.bindTurboClickEvent()
            }

            function B(a, b) {
                f.logDebug("turbo-checkout-controller", a, b)
            }

            function K(a, b) {
                G();
                a || d.close({
                    reason: b
                })
            }

            function L() {
                B("Handling signin success");
                N()
            }

            function M() {
                B("Handling buy now button click");
                N();
                return !0
            }

            function N() {
                W = setTimeout(P, 2E4);
                H = l.createScope();
                H.markClick();
                J = "loading";
                S = !1;
                x.checkTimeout();
                q.incrementSheetOpenedCounter();
                d.show()
            }

            function P() {
                l.logCount("turboCheckoutContenLoadTimeout")
            }

            function Q() {
                G();
                d.removeContent()
            }

            function O() {
                G()
            }

            function G() {
                b.canShow() ? (B("Registering with buy now button"), c.trigger("turbo:checkout:buyNowEnabled"), T = !0, t.registerOnClickCallback(M)) : (B("Unregistering from buy now button"), c.trigger("turbo:checkout:buyNowDisabled"), T = !1, t.deregisterOnClickCallback(M))
            }

            function Y(a, b) {
                l.logCount("turboCheckoutPrefetchSuccess");
                a && (h.isControl() || h.isBuyNowOnly()) && (B("Received content in control: " + a.substring(0, 255)), l.logCount("turboCheckoutControlContentReceived"));
                U = b;
                d.setContent(a);
                G()
            }

            function Z() {
                G();
                a.isOpeningOrOpen() && (l.logCount("turboCheckoutYieldNewPurchase"), d.closeImmediatelyThenExecute(V))
            }

            function aa() {
                clearTimeout(W);
                J = "unknown";
                !F || F.isResolved() || F.isRejected() || (B("Initiate confirm called for " + U.currentPurchaseId + " with existing confirm still executing. Aborting"), l.logCount("turboCheckoutConfirmPending"), F._supersedByNewPurchase = !0, F.abort());
                ba()
            }

            function ba() {
                l.logCount("turboCheckoutConfirm");
                var a = U.currentPurchaseId,
                    b = v.buildConfirmPathWith(h.getExperimentName(),
                        k.getRequestId(), k.getSessionId());
                F = n.loadWithJQXHR(b, {
                    type: "POST",
                    data: {
                        pid: a,
                        isInitiateLoggingFixEnabled: 1
                    },
                    success: function(a, b, c) {
                        l.logCount("turboCheckoutConfirmSuccess")
                    },
                    error: function(b, c, e) {
                        "abort" === c ? l.logCount("turboCheckoutConfirmAborted") : ("timeout" === c && l.logCount("turboCheckoutConfirmTimeOut"), l.logCount("turboCheckoutConfirmFailed"));
                        b._supersedByNewPurchase || (f.logError("Issue confirming turbo initiate prefetch for pid " + a + ": " + e + ", " + c), l.logCount("turboCheckoutYieldNewPurchase"),
                            d.closeImmediatelyThenExecute(V))
                    }
                })
            }

            function ca() {
                H.markFirstByte()
            }

            function R() {
                return y.get(y.KEYS.HOST_PAGE_TYPE_IDENTIFIER)
            }

            function V() {
                t.executeOriginalBuyNowAction(k.getActiveId())
            }

            function ea(a) {
                c.trigger("turbo:checkout:embedded:page:showSpinner");
                F.done(a)
            }

            function da(a, b, c) {
                J = c;
                S = !1
            }

            function fa() {
                S = !0
            }

            function ga(a) {
                a && a.doNotLog || (a && !a.doNotLog ? X(J, a.reason) : X(J, !1));
                J = "closed"
            }

            function X(a, b) {
                var c = v.buildLogPageHitPathWith(S ? a + "2" : a, b);
                B("Logging page hit from " + a + " to " + R() + " reason " +
                    b);
                n.load(c, {
                    method: "POST",
                    params: {
                        pageType: R(),
                        referrer: a
                    },
                    timeout: 4E3
                })
            }

            function ha() {
                a.isOpeningOrOpen() && l.logCount("turboCheckoutProductChangedWhileOpening")
            }
            var H, J, U, S, W, F, T = !1;
            c.on("a:pageUpdate", C);
            C();
            return {
                pageLoaded: function() {
                    var a = h.getExperimentName();
                    if (a) {
                        var f = h.getAllocation();
                        l.addCounterExtraSuffix("wl:" + f);
                        l.addCounterExtraSuffix(a + ":" + f)
                    }
                    p.isDeviceTurboEligible() && (b.setup(), b.registerStateChangeCallback(K), r.setup(), e.registerCallback({
                        onStart: Q,
                        onTurboEligible: O,
                        onFinish: Y,
                        onError: Z
                    }), m.setup(), z.setup(), z.registerCallback(L), H = l.createScope(), d.registerCallbacks({
                        beforeFramePopulated: aa,
                        afterFramePopulated: ca
                    }), k.registerCallback(ha), c.on("turbo:checkout:sheet:beforeClose", ga), c.on("turbo:checkout:embedded:page:beforeReload", da), c.on("turbo:checkout:embedded:page:animation:start", fa), u.setup(t.executeTurboBuyNowAction, O), A.setup(), c.trigger("turbo:checkout:controller:onPageLoaded"))
                },
                loadFullscreen: function(a, b) {
                    function c() {
                        a = f.createFQDN(a);
                        "thankyou" === b ? (l.logCount("turboCheckoutYieldTYP"),
                            d.closeAndNavigate(a)) : (l.logCount("turboCheckoutYield"), d.closeToFullscreen(a))
                    }!F || F.isResolved() || F.isRejected() ? c() : (l.logCount("turboCheckoutWaitYield"), ea(c))
                },
                frameContentReady: function(a, b, d) {
                    c.trigger("turbo:checkout:embedded:page:ready", a, b);
                    (function() {
                        var a = function() {
                            H.markCriticalFeature();
                            d.confirmHit(R(), D.generateValue(R(), D.ACTIONS.BUY_NOW));
                            H.whenDataSet(d.recordClientSideMetrics);
                            b.off("checkout:afterReload", a)
                        };
                        b.on("checkout:afterReload", a)
                    })();
                    (function() {
                        b.on("checkout:beforeReload",
                            function(d) {
                                c.trigger("turbo:checkout:embedded:page:beforeReload", a, b, d)
                            });
                        b.on("checkout:reload", function(d) {
                            c.trigger("turbo:checkout:embedded:page:reload", a, b, d)
                        });
                        b.on("checkout:afterReload", function(d) {
                            c.trigger("turbo:checkout:embedded:page:afterReload", a, b, d)
                        });
                        b.on("turbo:checkout:animation:start", function() {
                            c.trigger("turbo:checkout:embedded:page:animation:start")
                        });
                        c.on("turbo:checkout:embedded:page:showSpinner", function() {
                            d.showSpinner()
                        })
                    })()
                },
                frameHtmlRendered: function() {
                    H.markAboveTheFold()
                },
                updateBounds: function(a) {
                    d.updateBounds(a)
                }
            }
        });
    "use strict";
    e.when("turbo-checkout-page-load-spinner", "turbo-checkout-controller", "turbo-checkout-csm", "turbo-checkout-page-ready").register("turbo-checkout-startup", function(c, d, a) {
        c.removePageLoadSpinner();
        a.logCount("turboCheckoutControllerPageLoaded");
        d.pageLoaded()
    });
    "use strict";
    e.when("turbo-checkout-assets-load-trigger").register("turbo-checkout-page-ready", function() {
        m.ue && m.ue.count && "undefined" !== typeof m.ue_t0 && m.ue.count("turboCheckoutPageReady",
            Date.now() - m.ue_t0)
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-state-handler", "turbo-checkout-quantity-input", "turbo-checkout-warranty-input", "turbo-checkout-page-ready").register("turbo-checkout-authportal-return-query", function(c, d, a, b, e, f) {
        function h(b) {
            a.logDebug("turbo-checkout-authportal-return-query", b)
        }

        function w(a) {
            a = a.match(q);
            a = c.reduce(a, function(a, b) {
                var c = b.split("\x3d");
                b = c[0];
                c = c[1] || "";
                a.hasOwnProperty(b) && l("Duplicate query key detected @ key \x3d  " +
                    b + " -- Redirect URL will contain only last value read!");
                a[b] = c;
                return a
            }, {});
            return "?" + c.$.param(a)
        }

        function l(b) {
            a.logWarning(b, "turbo-checkout-authportal-return-query")
        }

        function k(a) {
            return !!a.match("trb_auth\x3d1")
        }

        function p(c) {
            if (k(c)) {
                c = ((c || "").match(A) || [])[1] || "";
                var e = b.getSessionId();
                a.isNonEmptyString(c) || d.logCount("turboCheckoutPostAuthEmptySessionParameter");
                a.isNonEmptyString(e) || d.logCount("turboCheckoutPostAuthEmptySessionPageState");
                a.isNonEmptyString(c) && a.isNonEmptyString(e) &&
                    c !== e && (l("Turbo Session Flip Detected. Post authentication sessionId \x3d " + e + ", Expected \x3d " + c), d.logCount("turboCheckoutPostAuthSessionFlip"))
            }
        }
        var n = /&?(openid|aToken|serial)[^&]*/g,
            r = /&?trb_(open|auth|qty|warrAsin|sid)=[^&]*/g,
            q = /[^(=\?&)]+[^&]*/g,
            A = /&?trb_sid=([^&]*)/;
        p(m.location.search);
        return {
            buildFrom: function(a) {
                h("Initial Query \x3d " + a);
                a = (a || "?").replace(n, "");
                a = a.replace(r, "");
                a = w(a);
                a += "\x26trb_auth\x3d1\x26trb_open\x3d1";
                var c = e.getQuantity();
                a += 1 < c ? "\x26trb_qty\x3d" + c : "";
                c = f.getLineItem();
                a += c && c.asin ? "\x26trb_warrAsin\x3d" + c.asin : "";
                c = b.getSessionId();
                a += 0 < c.length ? "\x26trb_sid\x3d" + c : "";
                c = b.getActiveId();
                a = (a + (c ? "\x26trb_bid\x3d" + c : "")).replace(/\?+&*/, "?").replace(/\?*&+\?*&*/g, "\x26");
                h("Final Query \x3d " + a);
                return a
            },
            isReturningFromAuthPortal: k,
            validateSession: p
        }
    });
    "use strict";
    e.when("turbo-checkout-csm", "turbo-checkout-auto-open", "turbo-checkout-authportal-return-query", "turbo-checkout-page-ready").register("turbo-checkout-browser-signin", function(c, d, a) {
        function b() {
            var a =
                m.location.search.match(e) ? "turboCheckoutSigninSuccess" : "turboCheckoutSigninFailed";
            c.logCount(a)
        }
        var e = /openid\.mode=id_res/,
            f = /(\/ref=[^/]*\/?$|\/?$)/;
        a.isReturningFromAuthPortal(m.location.search) && (c.logCount("turboCheckoutAuthPortalReturn"), b());
        return {
            show: function(b) {
                b = b + (-1 === b.indexOf("?") ? "?" : "\x26") + "openid.return_to\x3d";
                var e;
                e = a.buildFrom(m.location.search);
                e = encodeURIComponent("https://" + m.location.hostname + m.location.pathname.replace(f, "/ref\x3dtrb_chk_auth") + e);
                b += e;
                c.logCount("turboCheckoutSignInUrlSize",
                    b.length);
                d.reset();
                m.location.href = b
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-utils", "turbo-checkout-state-handler", "turbo-checkout-page-ready").register("turbo-checkout-strings", function(c, d) {
        function a(a) {
            return function() {
                var e = d.getStrings()[a];
                if (e) return e;
                c.logDebug("turbo-checkout-strings", 'String for key "' + a + '" is undefined! Returning empty string.');
                return ""
            }
        }
        return {
            getHeaderText: a("TURBO_CHECKOUT_HEADER"),
            getLoadingText: a("TURBO_LOADING_TEXT")
        }
    });
    "use strict";
    e.when("jQuery", "turbo-checkout-page-ready").register("turbo-checkout-loading-spinner",
        function(c) {
            function d() {
                return c("#turbo-loading-container")
            }

            function a(a) {
                var d = c("\x3cdiv\x3e", {
                    id: "turbo-loading-content"
                }).append(c("\x3cdiv\x3e", {
                    id: "turbo-loading-spinner",
                    "class": "a-spinner a-spinner-medium"
                }));
                "string" === typeof a && a && d.append(c("\x3cdiv\x3e", {
                    id: "turbo-loading-text",
                    text: a
                }));
                return d
            }
            return {
                create: function(b) {
                    return c("\x3cdiv\x3e", {
                        id: "turbo-loading-container"
                    }).append(a(b))
                },
                get: d,
                show: function() {
                    d().addClass("turbo-checkout-shown")
                }
            }
        });
    "use strict";
    e.when("A", "turbo-checkout-utils",
        "turbo-checkout-page-ready").register("turbo-checkout-eligibility-response-weblabs", function(c, d) {
        var a = [];
        return {
            set: function(b) {
                c.$.isArray(b) && (a = b)
            },
            get: function() {
                return a
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-session-storage", function(c, d) {
        function a(a, c) {
            d.logDebug("turbo-checkout-session-storage", a, c)
        }
        return {
            isPresent: function(b) {
                var d;
                a: {
                    try {
                        d = m.sessionStorage.getItem(b);
                        break a
                    } catch (e) {
                        c.logCount("turboCheckoutSessionStorageExceptionGet"),
                            a("get() exception", e)
                    }
                    d = null
                }
                return null !== d && d !== C
            },
            set: function(b, d) {
                try {
                    m.sessionStorage.setItem(b, d)
                } catch (e) {
                    c.logCount("turboCheckoutSessionStorageExceptionSet"), a("set() exception", e)
                }
            },
            remove: function(b) {
                try {
                    return m.sessionStorage.removeItem(b)
                } catch (d) {
                    c.logCount("turboCheckoutSessionStorageExceptionRemove"), a("remove() exception", d)
                }
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-page-ready").execute(function() {
        e.declare("turbo-checkout-is-physical-gift-card-support-enabled", !1)
    });
    "use strict";
    e.when("A", "turbo-configuration", "turbo-checkout-page-ready").register("turbo-checkout-load-events", function(c, d) {
        var a = d.get(d.KEYS.TWISTER_PAGE_UPDATE_AUI_EVENT);
        return {
            bind: function(b) {
                c.off(a, b);
                c.off("turbo:checkout:controller:onPageLoaded", b);
                c.on(a, b);
                c.on("turbo:checkout:controller:onPageLoaded", b)
            }
        }
    })
});
/* ******** */
(function(d) {
    var k = window.AmazonUIPageJS || window.P,
        l = k._namespace || k.attributeErrors,
        b = l ? l("TurboCheckoutSharedMobileAssets", "") : k;
    b.guardFatal ? b.guardFatal(d)(b, window) : b.execute(function() {
        d(b, window)
    })
})(function(d, k, l) {
    d.when("A", "turbo-checkout-page-ready").register("turbo-checkout-scroll-stopper", function(b) {
        function c(b) {
            b.preventDefault()
        }

        function a(b, a) {
            b = a.$;
            1 === b("#turbo-checkout-select-form").length ? f(b) : b("#checkout-page-container").bind("touchmove", c)
        }

        function f(b) {
            var a = b("#turbo-checkout-select-form");
            a.bind("touchstart", function(b) {
                b = a[0].scrollHeight;
                var c = a.height(),
                    f = b - c;
                b > c && (0 >= a.scrollTop() && a.scrollTop(1), a.scrollTop() >= f && a.scrollTop(a.scrollTop() - 1))
            });
            b("#checkout-page-container").bind("touchmove", function(a) {
                var c = b("#turbo-checkout-select-form"),
                    f = c[0].scrollHeight,
                    r = c.height(),
                    d = f - r,
                    d = 0 < c.scrollTop() && c.scrollTop() < d,
                    f = f > r && d;
                0 !== c.has(a.target).length && f || a.preventDefault()
            })
        }
        var r;
        b.on("turbo:checkout:embedded:page:ready", a);
        b.on("turbo:checkout:embedded:page:beforeReload", a);
        return {
            disablePageScrolling: function(a) {
                a =
                    b.$;
                r = a(document.body).css("overflow");
                a(document.body).css("overflow", "hidden")
            },
            restoreScrolling: function(a) {
                a = b.$;
                a(document.body).css("overflow", r)
            }
        }
    });
    "use strict";
    d.when("A", "turbo-callback-list", "turbo-checkout-page-ready").register("turbo-checkout-orientation-listener", function(b, c) {
        function a() {
            b.on("orientationchange", function() {
                f()
            })
        }

        function f() {
            var a = d();
            b.trigger("turbo:checkout:orientation:onChange", {
                orientation: a
            });
            l.callAll(a)
        }

        function d() {
            return k("html").hasClass("a-ws") ? "landscape" :
                "portrait"
        }
        var k = b.$,
            l = c.create();
        return {
            startListening: function() {
                a();
                f()
            },
            registerCallback: l.push,
            getOrientation: d
        }
    });
    "use strict";
    d.when("A", "turbo-checkout-iframe", "turbo-checkout-view-state", "turbo-checkout-base-view", "turbo-checkout-scroll-stopper", "turbo-checkout-history-manager", "turbo-checkout-utils", "turbo-checkout-mash-integration-adapter", "turbo-checkout-ref-tagger", "turbo-checkout-device-filter", "turbo-checkout-strings", "turbo-checkout-loading-spinner", "turbo-configuration", "turbo-checkout-page-ready").register("turbo-checkout-bottom-sheet",
        function(b, c, a, f, d, z, A, t, B, C, L, p, D) {
            function E() {
                a.setToOpening("turbo:checkout:sheet:beforeOpen");
                t.dispatchEvent({
                    type: "appOverlays.Hide"
                });
                u();
                F();
                M()
            }

            function u() {
                e || N();
                c.remove();
                e.html(p.create(L.getLoadingText()))
            }

            function N() {
                e = g("\x3cdiv/\x3e", {
                    id: "turbo-checkout-bottom-sheet"
                });
                h = g("\x3cdiv/\x3e", {
                    id: "turbo-checkout-bottom-sheet-dimmer"
                });
                n = g("\x3cspan/\x3e", {
                    id: "turbo-checkout-bottom-sheet-dimmer-close"
                });
                h.append(n);
                g(document.body).append(e);
                g(document.body).append(h);
                h.bind("touchmove",
                    function() {
                        return !1
                    })
            }

            function F() {
                v && (u(), p.show(), c.appendTo(e), d.disablePageScrolling(h), c.write(v))
            }

            function M() {
                var a = O();
                x = document.body.scrollTop;
                y = g(document.body).css("top");
                document.body.scrollTop !== a && g(document.body).animate({
                    scrollTop: a
                }, 400, function() {
                    var b = -1 * a;
                    g(document.body).css({
                        top: b
                    })
                });
                w(e, P);
                e.addClass("turbo-checkout-bottom-sheet-visible").css({
                    bottom: 0
                });
                h.css({
                    width: "100%"
                }).addClass("turbo-checkout-bottom-sheet-dimmer-visible");
                z.sheetOpened()
            }

            function P() {
                a.setToOpen();
                h.bind("click", G);
                n.bind("click", H);
                g(document.body).addClass("turbo-checkout-fix-body");
                p.show();
                "function" === typeof C.isAtleast_iOS_10_3 && C.isAtleast_iOS_10_3() && g(e).hide().show(0)
            }

            function O() {
                var a = g(Q),
                    b;
                1 === a.length && (b = a.offset().top);
                if (!b || 1 > b) b = 1;
                return b
            }

            function m(q) {
                function c() {
                    a.setToClosed(p);
                    g(document.body).removeClass("turbo-checkout-fix-body");
                    u()
                }
                var f = q && q.immediate,
                    k = q === l || q.notify === l || q.notify,
                    m = k && "turbo:checkout:sheet:beforeClose",
                    p = k && "turbo:checkout:sheet:afterClose";
                a.isOpeningOrOpen() && (n.css("margin-bottom", ""), e.css("height", ""), n.css("bottom", ""), a.setToClosing(m, q), t.dispatchEvent({
                        type: "appOverlays.Show"
                    }), document.body.scrollTop !== x && g(document.body).animate({
                        scrollTop: x
                    }, f ? 0 : 400, function() {
                        if (y !== l) {
                            var b = y;
                            g(document.body).css({
                                top: b
                            })
                        }
                    }), f && (e.addClass("turbo-checkout-no-animation"), h.addClass("turbo-checkout-no-animation"), b.defer(function() {
                        e.removeClass("turbo-checkout-no-animation");
                        h.removeClass("turbo-checkout-no-animation")
                    })), e.removeClass("turbo-checkout-bottom-sheet-visible"),
                    h.removeClass("turbo-checkout-bottom-sheet-dimmer-visible"), h.unbind("click", G), n.unbind("click", H), d.restoreScrolling(h), z.sheetClosed(), w(e, c))
            }

            function I(a) {
                var c = A.isAndroid();
                c && e.addClass("turbo-checkout-bottom-sheet-fullscreen");
                w(e, function(f) {
                    m({
                        notify: !1,
                        immediate: !0,
                        doNotLog: !0
                    });
                    c && e.removeClass("turbo-checkout-bottom-sheet-fullscreen");
                    b.trigger("turbo:checkout:sheet:onNavigateAway");
                    a()
                })
            }

            function R(a) {
                m({
                    notify: !1,
                    doNotLog: !0
                });
                w(e, function(c) {
                    b.trigger("turbo:checkout:sheet:onNavigateAway");
                    a()
                })
            }

            function w(a, b) {
                a = J(a.css("transition-duration")) + J(a.css("transition-delay"));
                setTimeout(b, a)
            }

            function J(a) {
                var b = 0;
                a && (b = /ms$/.test(a) ? parseFloat(a) : 1E3 * parseFloat(a));
                return b
            }

            function G() {
                m({
                    reason: B.TAGS.TOUCH
                })
            }

            function H() {
                m({
                    reason: B.TAGS.TOUCH_X
                })
            }
            var Q = D.get(D.KEYS.BACKGROUND_SCROLL_TARGET_SELECTOR),
                g = b.$,
                v, e, h, n, x, y, K = new(f.extend())("#turbo-checkout-bottom-sheet");
            (function() {
                A.isIPhone() && k.addEventListener("message", function(a) {
                    if (/.*\.amazon\.com/.test(a.origin)) {
                        if ("turbo:checkout:virtualkeyboard:opened" ===
                            a.data) {
                            var b = e[0].getBoundingClientRect().bottom;
                            e.css({
                                bottom: -1 * (k.innerHeight - b)
                            })
                        }
                        "turbo:checkout:virtualkeyboard:closed" === a.data && e.css({
                            bottom: 0
                        })
                    }
                })
            })();
            K.pushBoundsAdjustedCallback(function(a) {
                n.css("bottom", a)
            });
            c.onContentLoaded(function(a) {
                p.get().remove()
            });
            b.on("turbo:checkout:sheet:doOpen", E);
            b.on("turbo:checkout:sheet:doClose", m);
            return {
                show: E,
                setContent: function(b) {
                    v = b;
                    a.isOpeningOrOpen() && !c.hasContent() && F()
                },
                removeContent: function() {
                    v = null;
                    u()
                },
                close: m,
                closeToFullscreen: function(a) {
                    I(function() {
                        t.modalOpen(a)
                    })
                },
                closeImmediatelyThenExecute: I,
                closeAndNavigate: function(a) {
                    R(function() {
                        t.navigate(a)
                    })
                },
                registerCallbacks: function(a) {
                    c.registerCallbacks(a)
                },
                updateBounds: function(a) {
                    K.updateBounds(a)
                }
            }
        });
    "use strict";
    d.when("turbo-base-eligible-state", "turbo-checkout-ref-tagger", "turbo-checkout-orientation-listener").register("turbo-checkout-eligible-state", function(b, c, a) {
        function f(b) {
            "portrait" !== a.getOrientation() && b.invalidate("Landscape orientation")
        }

        function d() {
            b.onStateChange(c.TAGS.ROTATION)
        }
        return {
            canShow: b.canShow,
            registerStateChangeCallback: b.registerStateChangeCallback,
            setup: function() {
                b.setup();
                b.addStateCheck(f);
                a.registerCallback(d);
                a.startListening()
            }
        }
    });
    "use strict";
    d.when("turbo-configuration-keys", "turbo-device-configuration", "turbo-function-adapter", "turbo-checkout-page-ready").execute("turbo-mash-integration-adapter-factory", function(b, c, a) {
        d.when(c[b.MASH_ADAPTER]).register("turbo-checkout-mash-integration-adapter", function(b) {
            return {
                dispatchEvent: a.adapt(b.dispatchEvent),
                modalOpen: a.adapt(b.modalOpen),
                navigate: a.adapt(b.navigate),
                showLoginDialog: a.adapt(b.showLoginDialog),
                show: a.adapt(b.show)
            }
        })
    })
});
/* ******** */
(function(b) {
    var d = window.AmazonUIPageJS || window.P,
        e = d._namespace || d.attributeErrors,
        a = e ? e("TurboCheckoutMobileWebAssets", "") : d;
    a.guardFatal ? a.guardFatal(b)(a, window) : a.execute(function() {
        b(a, window)
    })
})(function(b, d, e) {
    b.when("turbo-checkout-page-ready").execute(function() {
        b.declare("turbo-device-override", "Browser-SmartPhone")
    });
    "use strict";
    b.when("turbo-configuration-keys", "turbo-device-override", "turbo-interstitial-suppression", "turbo-checkout-page-ready").register("turbo-device-configuration",
        function(a, b, d) {
            var c;
            c || (c = {}, c[a.IS_DEVICE_FILTER_REQUIRED] = !1, c[a.USES_MASH_WILL_REAPPEAR] = !1, c[a.SHOW_SIGN_IN_INTERFACE] = "turbo-checkout-browser-signin", c[a.IFRAME_ID] = "turbo-checkout-bottom-sheet-frame", c[a.EXTEND_ELIGIBLE_STATE] = !0, c[a.VIEW_ADAPTER] = "turbo-checkout-bottom-sheet", c[a.DEVICE_OVERRIDE] = b, c[a.MASH_ADAPTER] = "turbo-checkout-mash-facade", d && (c[a.CONFLICTING_INITIATE_LISTENERS] = ["click"]));
            return c
        });
    "use strict";
    b.when("turbo-checkout-page-ready").register("turbo-checkout-mash-facade",
        function() {
            function a(a) {
                d.location.href = a
            }

            function b() {
                throw "Unsupported method. Interface exists to preserve legacy interface.";
            }
            return {
                navigate: a,
                modalOpen: a,
                dispatchEvent: function() {},
                showLoginDialog: b,
                show: b
            }
        })
});
/* ******** */
(function(c) {
    var d = window.AmazonUIPageJS || window.P,
        e = d._namespace || d.attributeErrors,
        a = e ? e("DetailPageTurboCheckoutMobileWebAssets", "") : d;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, d, e) {
    c.when("turbo-configuration-keys", "turbo-checkout-page-ready").register("turbo-client-configuration", function(a) {
        var b;
        b || (b = {}, b[a.HOST_PAGE_TYPE_IDENTIFIER] = "detail", b[a.PREFETCH_TREATMENT] = "T1", b[a.NO_PREFETCH_TREATMENT] = "T2", b[a.BUY_NOW_ONLY_TREATMENT] = "T3", b[a.QUANTITY_SELECT_SELECTOR] =
            "#mobileQuantityDropDown");
        return b
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageVoltageComplianceAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(a) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        c = d ? d("DetailPageAToZGuaranteeAssets", "") : b;
    c.guardFatal ? c.guardFatal(a)(c, window) : c.execute(function() {
        a(c, window)
    })
})(function(a, b, d) {
    a.when("A").register("atoz-csm-counters", function(c) {
        var a = function(a) {
                return ue.count(a) || 0
            },
            b = function(a, b) {
                ue.count(a, b)
            };
        return {
            getCounter: a,
            setCounter: b,
            incrementCounter: function(c, d) {
                d = d || 1;
                b(c, a(c) + d)
            }
        }
    })
});
/* ******** */
(function(b) {
    var e = window.AmazonUIPageJS || window.P,
        f = e._namespace || e.attributeErrors,
        c = f ? f("MOBBAssets@mobile", "MOBB") : e;
    c.guardFatal ? c.guardFatal(b)(c, window) : c.execute(function() {
        b(c, window)
    })
})(function(b, e, f) {
    b.declare("mobb-handler-constants", {
        BODY_SELECTOR: "body *",
        NEW_ACCORDION_ROW_SELECTOR: "#newAccordionRow",
        SECOND_NEW_ACCORDION_ROW_SELECTOR: "#SecondNewAccordionRow",
        pageUpdate: "a:pageUpdate",
        PAGE_STATE_PREFIX: '\'script[data-a-state\x3d"{"key":"',
        PAGE_STATE_POSTFIX: '"}"]\'',
        OFFER_CONTEXT_PARAMETER: "offerContext",
        MOBB_OFFER_CONTEXT: "mobb"
    });
    b.when("A", "mobb-handler-constants").register("mobb-helper", function(c, d) {
        return {
            getInitialState: function() {
                var g;
                g = c.$(d.NEW_ACCORDION_ROW_SELECTOR);
                var b = c.$(d.SECOND_NEW_ACCORDION_ROW_SELECTOR);
                g = g && g.length && b && b.length ? !0 : !1;
                return g ? d.NEW_ACCORDION_ROW_SELECTOR : d.BODY_SELECTOR
            },
            parsePageState: function(b, e) {
                var a = d.PAGE_STATE_PREFIX + e + d.PAGE_STATE_POSTFIX;
                return (a = c.$(b).find(a)) && a.length && a.html() ? c.$.parseJSON(a.html()) : null
            }
        }
    });
    b.when("A", "mobb-helper", "mobb-handler-constants").register("mobb-state-handler",
        function(c, d, e) {
            function f() {
                a = null
            }
            var a = null;
            b.when("TwisterCore", "twister-page-state").execute("MOBBTwisterMonitor", function(a, c) {
                (new a(c)).registerActive({
                    viewAttribution: "a2i-dpx",
                    viewName: "mobbAssets"
                }, {
                    updateView: f,
                    pageRefreshView: f
                })
            });
            a = d.getInitialState();
            c.on("a:accordion:buybox-accordion:select", function(b) {
                var d = a;
                a = "#" + b.selectedRow.rowName;
                c.trigger("a2idpx:mobb:accordion-change", a, d)
            });
            return {
                getAccordionName: function() {
                    return a
                },
                getElementById: function(b) {
                    a || (a = d.getInitialState());
                    return c.$(a).find(b)
                },
                getElementByClass: function(b) {
                    a || (a = d.getInitialState());
                    return c.$(a).find(b)
                },
                getPageState: function(b) {
                    return d.parsePageState(a, b)
                },
                accordionChangeRegistration: function(a) {
                    return c.on("a2idpx:mobb:accordion-change", a)
                }
            }
        })
});
/* ******** */
(function(b) {
    var c = window.AmazonUIPageJS || window.P,
        d = c._namespace || c.attributeErrors,
        a = d ? d("DetailPageSellerProfileMobileAssets", "") : c;
    a.guardFatal ? a.guardFatal(b)(a, window) : a.execute(function() {
        b(a, window)
    })
})(function(b, c, d) {
    b.when().register("seller-profile-treatment", function() {
        return "C"
    })
});
/* ******** */
(function(f) {
    var g = window.AmazonUIPageJS || window.P,
        h = g._namespace || g.attributeErrors,
        b = h ? h("DetailPageFluxComponents", "") : g;
    b.guardFatal ? b.guardFatal(f)(b, window) : b.execute(function() {
        f(b, window)
    })
})(function(f, g, h) {
    f.when("dp-flux-utils").register("dp-flux-action", function(b) {
        function e(d, a, c) {
            if (b.isNonEmptyString(d) && b.isNonEmptyString(a)) this._name = d, this._source = a, this._metadata = c;
            else throw Error("Action(...): Action must be created with valid name and source");
        }
        e.prototype = {
            getName: function() {
                return this._name
            },
            getSource: function() {
                return this._source
            },
            getMetaData: function() {
                return this._metadata
            }
        };
        return e.prototype.constructor = e
    });
    f.when("dp-flux-utils").register("dp-flux-attribution", function(b) {
        function e(d, a, c, k) {
            if (b.isNonEmptyString(d) && b.isNonEmptyString(a) && b.isNonEmptyString(c) && b.isNonEmptyString(k)) this._name = d, this._category = a, this._type = c, this._item = k;
            else throw Error("All parameters (name, categoty, type, item) must be a non-empty string");
        }
        e.prototype = {
            getName: function() {
                return this._name
            },
            getAttribution: function() {
                return "name: " + this._name + "; CTI\x3d " + this._category + "/" + this._type + "/" + this._item
            }
        };
        return e.prototype.constructor = e
    });
    f.when("A", "dp-flux-action", "dp-flux-attribution").register("dp-flux-dispatcher", function(b, e, d) {
        function a() {
            this._callbacks = {};
            this._isDispatching = !1;
            this._pendingAction = null;
            this._lastID = 1
        }
        var c = b.$;
        a.prototype = {
            register: function(a, b) {
                if (!(a instanceof d)) throw Error("Dispatch.register(...): attribution must be instance of Attribution");
                if (!c.isFunction(b)) throw Error("Dispatch.register(...): callback must be a function");
                var e = "ID_" + this._lastID++;
                this._callbacks[e] = {
                    attribution: a,
                    callback: b,
                    _isCallbackExecutionStarted: !1,
                    _isCallbackExecutionCompleted: !1
                };
                return e
            },
            unregister: function(a) {
                if (this._callbacks[a]) delete this._callbacks[a];
                else throw Error("Dispatcher.unregister(...): " + a + " does not map to a registered callback");
            },
            dispatch: function(a) {
                if (this._isDispatching) throw Error("Dispatch.dispatch(...): Cannot dispatch in the middle of a dispatch");
                if (!(a instanceof e)) throw Error("Dispatch.dispatch(...): action param must be of type Action");
                this._startDispatching(a);
                for (var c in this._callbacks) this._callbacks[c]._isCallbackExecutionStarted || this._invokeCallback(c);
                this._stopDispatching()
            },
            waitFor: function(a) {
                if (!this._isDispatching) throw Error("Dispatcher.waitFor(...): Must be invoked while dispatching");
                if (!c.isArray(a)) throw Error("Dispatcher.waitFor(...): dispatchTokenList must be an array");
                for (var b = 0; b < a.length; b++) {
                    var d = a[b];
                    if (!this._callbacks[d]) throw Error("Dispatcher.waitFor(...): " + d + " does not map to a registered callback. ");
                    if (this._callbacks[d]._isCallbackExecutionStarted)
                        if (this._callbacks[d]._isCallbackExecutionCompleted) continue;
                        else throw Error("Dispatcher.waitFor(...): Circular dependency detected while waiting for " + d);
                    this._invokeCallback(d)
                }
            },
            _invokeCallback: function(a) {
                this._callbacks[a]._isCallbackExecutionStarted = !0;
                try {
                    this._callbacks[a].callback(this._pendingAction)
                } catch (c) {
                    f.log("Dispatcher._invokeCallback(...): Error while calling dispatcher callback: error message \x3d " + c.message, "FATAL", this._callbacks[a].attribution.getAttribution())
                }
                this._callbacks[a]._isCallbackExecutionCompleted = !0
            },
            _startDispatching: function(a) {
                for (var c in this._callbacks) this._callbacks[c]._isCallbackExecutionStarted = !1, this._callbacks[c]._isCallbackExecutionCompleted = !1;
                this._pendingAction = a;
                this._isDispatching = !0
            },
            _stopDispatching: function() {
                this._pendingAction = null;
                this._isDispatching = !1
            }
        };
        return a.prototype.constructor = a
    });
    f.when("A", "dp-flux-utils").register("dp-flux-emitter", function(b, e) {
        function d() {
            this._subscriptions = {}
        }
        var a = b.$;
        d.prototype = {
            emit: function(a) {
                if (e.isNonEmptyString(a)) b.each(this._subscriptions[a] || [], function(a) {
                    a()
                });
                else throw Error("Emitter.emit()...: eventType must be a non empty string");
            },
            addListener: function(c, b) {
                if (e.isNonEmptyString(c) && a.isFunction(b)) this._subscriptions[c] = this._subscriptions[c] || [], this._subscriptions[c].push(b);
                else throw Error("Emitter.addListener()...: Invalid arguments - eventType must be a non empty string \x26 callback must be a function ");
            },
            removeListener: function(c, b) {
                if (e.isNonEmptyString(c) && a.isFunction(b)) {
                    if (c = this._subscriptions[c]) b = a.inArray(b,
                        c), -1 !== b && c.splice(b, 1)
                } else throw Error("Emitter.removeListener()...: Invalid arguments - eventType must be a non empty string \x26 callback must be a function");
            }
        };
        return d
    });
    f.when("A", "dp-flux-emitter", "dp-flux-attribution", "dp-flux-dispatcher", "dp-flux-utils").register("dp-flux-store", function(b, e, d, a, c) {
        function f(b, k, g, h) {
            if (!(b instanceof d)) throw Error("storeAttribution should be instance of Attribution");
            if (!(g instanceof a)) throw Error("dispatcher must be an instance of Dispatcher");
            if (!l.isFunction(k)) throw Error("Store must provide a reduce callback method");
            this.reduce = k;
            this.dispatcher = g;
            this._storeAttribution = b;
            this._state = h || {};
            c.deepFreeze(this._state);
            this._dispatchToken = this.dispatcher.register(this._storeAttribution, this._invokeOnDispatch.bind(this));
            this._changed = !1;
            this._changeEvent = this._storeAttribution.getName() + ":change";
            this._emitter = new e
        }
        var l = b.$;
        f.prototype = {
            addListener: function(a) {
                return this._emitter.addListener(this._changeEvent, a)
            },
            removeListener: function(a) {
                this._emitter.removeListener(this._changeEvent, a)
            },
            getDispatcher: function() {
                return this.dispatcher
            },
            getDispatchToken: function() {
                return this._dispatchToken
            },
            getState: function() {
                return this._state
            },
            getStoreAttribution: function() {
                return this._storeAttribution
            },
            _invokeOnDispatch: function(a) {
                this._changed = !1;
                var b = this._state;
                (a = this.reduce(this._state, a) || b) && a !== b && (this._state = a, c.deepFreeze(this._state), this._changed = !0, this._emitter.emit(this._changeEvent))
            }
        };
        return f.prototype.constructor = f
    });
    f.when("A", "dp-flux-attribution").register("dp-flux-store-group", function(b) {
        function e(b, a, c) {
            this._stores =
                a;
            this._callBack = c;
            this._attribution = b;
            this._registerStoreGroup()
        }
        e.prototype = {
            _registerStoreGroup: function() {
                var b = this._getUniformDispatcher();
                this._dispatchToken = b.register(this._attribution, function() {
                    b.waitFor(this._getStoreTokens());
                    this._callBack()
                }.bind(this))
            },
            unregisterStoreGroup: function() {
                this._getUniformDispatcher().unregister(this._dispatchToken)
            },
            _getUniformDispatcher: function() {
                var d = this._stores[0].getDispatcher();
                b.each(this._stores, function(a) {
                    if (d !== a.getDispatcher()) throw Error("All stores must have common dispatcher");
                });
                return d
            },
            _getStoreTokens: function() {
                return b.map(this._stores, function(b) {
                    return b.getDispatchToken()
                })
            }
        };
        return e.prototype.constructor = e
    });
    f.when("A", "dp-flux-store-group").register("dp-flux-store-subscription", function(b, e) {
        function d(a, b, d) {
            this._stores = b;
            this._changed = !1;
            this._updatedStores = [];
            this._viewUpdateCallBack = d;
            this._viewAttribution = a;
            this._allListeners = [];
            this._addListenerToAllStores();
            this._storeGroup = new e(a, b, this._viewCallBack.bind(this))
        }
        d.prototype = {
            _storeListener: function(a) {
                this._changed = !0;
                this._updatedStores.push(a)
            },
            _addListenerToAllStores: function() {
                var a;
                b.each(this._stores, function(b) {
                    a = this._storeListener.bind(this, b);
                    this._allListeners.push({
                        listener: a,
                        store: b
                    });
                    b.addListener(a)
                }, this)
            },
            _removeListenerFromAllStores: function() {
                b.each(this._allListeners, function(a) {
                    a.store.removeListener(a.listener)
                })
            },
            _viewCallBack: function() {
                if (this._changed) {
                    try {
                        this._viewUpdateCallBack(this._updatedStores)
                    } catch (a) {
                        f.log("StoreSubscription._viewCallBack(...): view callback failed", "FATAL",
                            this._viewAttribution.getAttribution())
                    }
                    this._changed = !1;
                    this._updatedStores = []
                }
            },
            reset: function() {
                this._removeListenerFromAllStores();
                this._storeGroup.unregisterStoreGroup()
            }
        };
        return d.prototype.constructor = d
    });
    f.when("A").register("dp-flux-utils", function(b) {
        function e(a) {
            return "string" === typeof a || "[object String]" === Object.prototype.toString.call(a)
        }

        function d(a) {
            if (!Object.isFrozen(a)) {
                var c = Object.getOwnPropertyNames(a);
                b.each(c, function(b) {
                    var c = a[b];
                    a[b] = c && "object" === typeof c ? d(c) : c
                });
                Object.freeze(a)
            }
            return a
        }
        return {
            isString: e,
            isNonEmptyString: function(a) {
                return !(!e(a) || !b.trim(a).length)
            },
            deepFreeze: function(a) {
                return Object.freeze && Object.getOwnPropertyNames && Object.isFrozen ? (d(a), !0) : !1
            }
        }
    });
    f.when("A", "dp-flux-attribution", "dp-flux-store", "dp-flux-store-subscription").register("dp-flux-view", function(b, e, d, a) {
        function c(c, g, h) {
            if (!(c instanceof e)) throw Error("View(...): viewAttribution should be an instance of Attribution");
            if (f.isArray(g) && 1 <= g.length) b.each(g, function(a) {
                if (!(a instanceof d)) throw Error("View(...): storeList contains an object which is not of type Store");
            });
            else throw Error("View(...): View must listen on at least one store");
            if (!f.isFunction(h)) throw Error("View(...): View must provide update callback method");
            this._viewAttribution = c;
            this._storeSubscription = new a(c, g, h)
        }
        var f = b.$;
        c.prototype.getViewAttribution = function() {
            return this._viewAttribution
        };
        c.prototype.unregisterStores = function() {
            this._storeSubscription.reset()
        };
        return c
    })
});
/* ******** */
(function(e) {
    var n = window.AmazonUIPageJS || window.P,
        B = n._namespace || n.attributeErrors,
        C = B ? B("DetailPageUSSAssets", "") : n;
    C.guardFatal ? C.guardFatal(e)(C, window) : C.execute(function() {
        e(C, window)
    })
})(function(e, n, B) {
    e.when("A").register("uss-constants-common", function(e) {
        return {
            classList: {
                SHOW_ELEMENT: "aok-block",
                HIDE_ELEMENT: "aok-hidden",
                STOP_SCROLLING: "uss-u-no-scroll",
                LIGHT_BOX_JS_HOOK: "js-light-box",
                LIGHT_BOX_IDENTIFIER: "uss-o-light-box",
                RIGHT_SIDE_SHEET: "uss-o-right-side-sheet",
                RIGHT_SIDE_SHEET_LAYOUT: "uss-l-right-side-sheet",
                SHEET_OPEN: "is-open",
                SHEET_CLOSE: "is-close",
                USS_SHEET_VIEW_IDENTIFIER: "uss-sheet-view",
                CLOSE_ICON: "uss-o-close-icon",
                CLOSE_ICON_MEDIUM: "uss-o-close-icon-medium",
                USS_SHEET_VIEW_CLOSE_ICON: "uss-sheet-view-close-icon",
                PROMISING_UI_ELEMENT: "uss-o-promising-ui-element",
                PROMISING_UI_ELEMENT_ANIMATION: "uss-o-promising-ui-element-animation",
                IS_LOADING: "is-loading",
                IS_RESOLVED: "is-resolved",
                UI_PROMISE: "ui-promise",
                UI_VALUE: "ui-value",
                TEMPLATE_STORE: "uss-template-store",
                TEMPLATE: "uss-template",
                TEMPLATE_NAME: "template-name",
                ATC_ACKNOWLEDGEMENT_MESSAGE: "atc-acknowledgement-message",
                ATC_GENERIC_ERROR: "atc-generic-error",
                ATC_STATUS_MESSAGE_COMPONENT: "uss-c-atc-status-msg",
                ATC_SUCCESS: "atc-success",
                ATC_ERROR: "atc-error",
                ITEM_IN_CART: "item-in-cart",
                CART_STATUS_MESSAGE_COMPONENT: "uss-c-cart-status-msg",
                CART_SUB_TOTAL: "cart-sub-total",
                CART_COUNT: "cart-count",
                SHIPPING_DETAILS: "uss-c-shipping-details",
                SHIPPING_MESSAGE_PLACEHOLDER: "shipping-message-placeholder",
                MAIN_IMAGE: "main-image",
                SUB_NAV: "uss-c-sub-nav",
                CHECKOUT_BUTTON: "checkout-btn",
                CART_BUTTON: "cart-btn",
                CHECKOUT_FORM: "checkout-form",
                FACEOUT_IMAGE: "p13n-sc-dynamic-image",
                FACEOUT_TITLE: "uss-asin-title",
                FACEOUT_REVIEW_STARS: "uss-review-stars",
                FACEOUT_BEST_SELLER: "p13n-best-seller",
                FACEOUT_PRICE: "uss-price",
                CONTINUE_SHOPPING_LINK: "continue-shopping",
                SUCCESS_ELEMENT: ".p13n-sc-atc-success",
                ERROR_ELEMENT: ".p13n-sc-atc-error",
                BUTTON_ELEMENT: ".a-button-primary",
                DISABLE_BUTTON: "a-button-disabled"
            },
            fatalMessagesList: {
                INVALID_SHEET_ID: "sheetID must be valid string",
                INVALID_CONSTRUCTOR_USAGE: "Constructor needs to be called with 'new' keyword",
                INCORRECT_PARAMETER_PASSED: "Incorrect parameter passed."
            },
            widgetType: {
                WIDGET: "uss-widget",
                RECOMMENDATION_WIDGET: "uss-recommendation-widget",
                NO_RECOMMENDATION_WIDGET: "uss-no-recommendation-widget",
                LIST_RECOMMENDATION: "uss-list-recommendation-widget",
                CAROUSEL_RECOMMENDATION: "uss-carousel-recommendation-widget",
                PRIMARY_ACTION_STATUS_WIDGET: "uss-primary-action-status-widget",
                ATCStatusWidget: "uss-c-atc-status-widget",
                ATC_STATUS_IMB_WIDGET: "atc-status-imb-widget",
                MAPLE_WIDGET: "maple-recommendation-widget"
            },
            layout: {
                defaultLayout: {
                    DEFAULT_LAYOUT: "uss-l-default-layout",
                    HEAD: "uss-c-head",
                    BODY: "uss-c-body",
                    HEAD_DIVIDER: "uss-c-head-divider",
                    BOTTOM_MARGIN_BETWEEN_WIDGETS: "a-spacing-medium",
                    TOP_MARGIN_BETWEEN_WIDGETS: "a-spacing-top-medium",
                    SKELETON_LOADER: "uss-loading-skeleton",
                    RECOMMENDATION_LOADING_MESSAGE: "loading-message",
                    RECOMMENDATION_LOADED_MESSAGE: "uss-recommendations-loaded-message"
                }
            },
            actionSources: {
                DP_ATC_CLICK: "dp-atc-click",
                USS_INGRESS_CLICK: "uss-ingress-click",
                USS_INLINE_ATC_CLICK: "uss-inline-atc-click",
                SHEET_CLOSE_BUTTON_CLICK: "sheet-close",
                CONTINUE_SHOPPING_CLICK: "continue-shopping-click"
            },
            stores: {
                ATC_STATUS_STORE: "uss-atc-status-store",
                RECOMMENDATION_DATA_STORE: "uss-recommendation-data-store",
                USS_SHEET_STORE: "uss-sheet-store"
            },
            actions: {
                USS_OPEN: "uss-open",
                USS_CLOSE: "uss-close",
                RECOMMENDATION_DATA_RECEIVE: "recommendation-data-receive",
                ATC_RECEIVE: "atc-receive"
            },
            metrics: {
                ATC_PROMISE_RESOLVED_TIMER: "atcPromiseResolve",
                PERCOLATE_DATA_PROMISE_RESOLVED_TIMER: "percolateDataPromiseResolve",
                ATC_PROMISE_REJECTED_COUNTER: "atcPromiseRejected",
                PERCOLATE_DATA_PROMISE_REJECTED_COUNTER: "percolateDataPromiseRejected",
                SECONDARY_ADD_TO_CART_CLICK_COUNTER: "secondaryAtcClick",
                COMPATIBLE_BROWSER_COUNTER: "compatibleBrowser",
                NON_COMPATIBLE_BROWSER_COUNTER: "nonCompatibleBrowser",
                FACEOUT_IMAGE_CLICK_COUNTER: "faceout:imageClick",
                FACEOUT_REVIEW_STARS_CLICK_COUNTER: "faceout:reviewStarClick",
                FACEOUT_TITLE_CLICK_COUNTER: "faceout:titleClick",
                FACEOUT_PRICE_CLICK_COUNTER: "faceout:priceClick",
                FACEOUT_BEST_SELLER_CLICK_COUNTER: "faceout:bestSellerClick",
                SEE_MORE_EXISTENCE_COUNTER: "ussListWidget:seeMore",
                SEE_MORE_CLICK_COUNTER: "ussListWidget:seeMoreClick",
                SEE_LESS_CLICK_COUNTER: "ussListWidget:seeLessClick",
                CHECKOUT_FORM_CLICK_COUNTER: "checkoutFormClick",
                CART_BUTTON_CLICK_COUNTER: "cartButtonClick",
                CONTINUE_SHOPPING_CLICK: "continueShoppingClick",
                PAGE_LANDING_PRECONDITIONS_PASSED: "pageLandingPreconditionsPassed",
                POST_ATC_PRECONDITIONS_FAILED: "postATCPreconditionsFailed"
            },
            transitionTimingFunction: {
                EVEN_EASE: "cubic-bezier(0.4, 0, 0.6, 1)",
                ENTER_EASE: "cubic-bezier(0, 0, 0.2, 1)",
                EXIT_EASE: "cubic-bezier(0.4, 0, 1, 1)",
                EASE_IN: "ease-in",
                EASE_OUT: "ease-out"
            },
            animationType: {
                FADE_IN: "fadeIn",
                NO_ANIMATION: "noAnimation"
            }
        }
    });
    e.when("A", "dp-flux-attribution", "uss-constants-common").register("uss-constants", function(e, n, m) {
        m.ussCTI = {
            CATEGORY: "Website",
            TYPE: "Personalization",
            ITEM: "Shared Components"
        };
        e = "true" === e.$("#uss-mobileApp").val();
        m.metrics.PREFIX = e ? "uss:mobileApp:" : "uss:mobile:";
        m.ajaxParams = {
            BASE_URL: "/gp/aw/cart/",
            REFTAG: "mw_dp_buy_crt",
            ASIN: "a",
            AJAX_TIMEOUT: 1E4
        };
        m.deviceOrientation = {
            ORIENTATION_LANDSCAPE: "landscape",
            ORIENTATION_PORTRAIT: "portrait"
        };
        m.actionSources.SHEET_CLOSE_BUTTON_CLICK = "sheet-close";
        m.actionSources.MASH_REAPPEAR = "mash-reappear";
        m.metrics.MASH_REAPPEAR = "mash-reappear";
        m.classList.FACEOUT_PRICE = "p13n-sc-price";
        m.classList.USS_C_HEAD_STICKY = "uss-c-head-sticky";
        m.ussCommonAttribution = new n("uss-common", m.ussCTI.CATEGORY, m.ussCTI.TYPE, m.ussCTI.ITEM);
        m.defaultAtcAnimationType = m.animationType.NO_ANIMATION;
        return m
    });
    e.when("dp-flux-utils", "uss-constants").register("uss-logger-service", function(e,
        n) {
        function m(a, d) {
            if (e.isNonEmptyString(a)) a = n.metrics.PREFIX + a, ue && ue.count && (void 0 === d && (d = (ue.count(a) || 0) + 1), ue.count(a, d));
            else throw Error("counterKey must be non empty string");
        }

        function A(a) {
            if (e.isNonEmptyString(a)) this._timerName = a, this._startTime = 0;
            else throw Error("timerName must be non empty string");
        }
        A.prototype = {
            start: function() {
                this._startTime = Date.now()
            },
            stop: function() {
                this._startTime && m(this._timerName, Date.now() - this._startTime)
            }
        };
        return {
            logCounter: m,
            Timer: A
        }
    });
    e.when("A", "uss-utils",
        "uss-logger-service", "uss-constants").register("uss-preconditions", function(e, n, m, A) {
        function a(a) {
            a = e.$("#" + a + "_feature_div").html();
            null !== a && (a = a.trim());
            return null !== a && 0 < a.length
        }

        function d() {
            return e.capabilities.transform && e.capabilities.transition && n.isFlexBoxSupported()
        }

        function f() {
            return d() && !a("scheduledDelivery") && !a("simpleBundle") && !a("partialStateBuyBox")
        }

        function b() {
            return e.$("#uss-weblabTreatment").val()
        }
        var k = /^T[0-9]+$/;
        d() ? m.logCounter(A.metrics.COMPATIBLE_BROWSER_COUNTER) :
            m.logCounter(A.metrics.NON_COMPATIBLE_BROWSER_COUNTER);
        return {
            isUssConditionsPassed: function() {
                return "true" === e.$("#uss-serverPreconditionsPassed").val() && f()
            },
            isUssConditionsPassedUssVsDss: function() {
                return "true" === e.$("#ussDss-enabled").val() && "true" === e.$("#ussDss-serverPreconditionsPassed").val() && f()
            },
            isUssWeblabInTreatment: function() {
                return k.test(b())
            },
            triggerUSSWeblabValue: function() {
                return k.test(e.$("#uss-miniFrameworkWeblabTreatment").val()) ? e.$("#uss-weblabValue").val() : 1
            },
            ussWeblabTreatmentValue: b,
            isBrowserUssCompatible: d
        }
    });
    e.when("A", "3p-promise", "uss-constants", "uss-logger-service").register("uss-utils", function(e, B, m, A) {
        var a = e.$,
            d = m.classList,
            f = a("body"),
            b = {},
            k = ["isPreview", "forceWidgets", "previewCampaigns", "auditEnabled"];
        (function() {
            var a = n.location.search,
                a = a.substr(1);
            a.split("\x26").forEach(function(c) {
                c = c.split("\x3d");
                2 === c.length && (b[c[0]] = c[1])
            })
        })();
        return {
            loadImage: function(b, c) {
                return new B(function(h, l) {
                    c = c || "";
                    var w = a("\x3cimg src\x3d'" + b + "' alt\x3d'" + c + "'\x3e");
                    w.load(function() {
                        h(w)
                    });
                    w.error(function(c) {
                        l(c)
                    });
                    w[0].complete && h(w)
                })
            },
            isFlexBoxSupported: function() {
                var a = e.$("\x3cdiv\x3e\x3c/div\x3e")[0];
                return "" === a.style.flex || "" === a.style.webkitFlex || "" === a.style.msFlex || "" === a.style.MozBoxFlex || "" === a.style.webkitBoxFlex ? !0 : !1
            },
            disablePageScroll: function() {
                f.addClass(d.STOP_SCROLLING)
            },
            enablePageScroll: function() {
                f.removeClass(d.STOP_SCROLLING)
            },
            isMobileApp: function() {
                return "true" === e.$("#uss-mobileApp").val()
            },
            getDebugParams: function() {
                var a = {};
                k.forEach(function(c) {
                    var h;
                    h =
                        null;
                    b.hasOwnProperty(c) && (h = b[c]);
                    h && (a[c] = h)
                });
                return a
            },
            shouldFireAndForgetWeblabTrigger: function() {
                var b = !1;
                0 != a("#uss-shouldFireAndForgetWeblabTrigger").length && (b = "true" === a("#uss-shouldFireAndForgetWeblabTrigger").val());
                return b
            },
            fireAndForgetWeblabTrigger: function(a, c) {
                var h = "/gp/uss/weblab-trigger.html?",
                    h = /^T[0-9]+$/.test(e.$("#uss-miniFrameworkWeblabTreatment").val()) ? h + ("weblabValue\x3d" + a + "\x26treatment\x3d" + c) : h + ("triggerWeblab\x3d" + a + "\x26treatment\x3d" + c);
                n.navigator && navigator.sendBeacon ?
                    navigator.sendBeacon(h) || e.$.ajax({
                        url: h
                    }) : e.$.ajax({
                        url: h
                    })
            }
        }
    });
    e.when("A", "atf", "uss-utils").register("uss-init-helper", function(n, B, m, A) {
        return {
            loadUssCommonAssets: function() {
                e.when("dp-flux-dispatcher").register("uss-dispatcher", function(a) {
                    return new a
                });
                e.when("A", "uss-constants").register("promising-ui-element", function(a, d) {
                    var f = d.classList;
                    return a.createClass({
                        _element: null,
                        _uiPromiseElement: null,
                        _uiValueElement: null,
                        _isResolved: !1,
                        init: function(a) {
                            var d = a.find("." + f.UI_PROMISE),
                                g = a.find("." +
                                    f.UI_VALUE);
                            if ((a.hasClass(f.PROMISING_UI_ELEMENT) || a.hasClass(f.PROMISING_UI_ELEMENT_ANIMATION)) && d.length && g.length) this._uiPromiseElement = d, this._uiValueElement = g, this._element = a, this.showUIPromise();
                            else throw Error("PromisingUIElement.init()...: HTML structure is not compatible with PromisingUIElement");
                        },
                        showUIPromise: function() {
                            this._element.addClass(f.IS_LOADING);
                            this._element.removeClass(f.IS_RESOLVED);
                            this._isResolved = !1
                        },
                        showUIValue: function() {
                            this._element.addClass(f.IS_RESOLVED);
                            this._element.removeClass(f.IS_LOADING);
                            this._isResolved = !0
                        },
                        getValueElement: function() {
                            return this._uiValueElement
                        },
                        getElement: function() {
                            return this._element
                        },
                        isResolved: function() {
                            return this._isResolved
                        }
                    })
                });
                e.when("A", "uss-sheet-component", "uss-constants", "uss-store-repository", "dp-flux-attribution", "uss-layout", "dp-flux-view", "widget-creation-helper", "dp-flux-action", "uss-dispatcher").register("uss-sheet-view", function(a, d, f, b, k, g, c, h, l, w) {
                    function v() {
                        y = !0;
                        var a = f.classList,
                            v = f.ussCTI,
                            p = b.getStore(f.stores.USS_SHEET_STORE),
                            q = b.getStore(f.stores.RECOMMENDATION_DATA_STORE),
                            t = [p, q],
                            v = new k("uss-sheet-view", v.CATEGORY, v.TYPE, v.ITEM),
                            r = new d(a.USS_SHEET_VIEW_IDENTIFIER, {
                                beforeClose: function() {
                                    w.dispatch(new l(f.actions.USS_CLOSE, f.actionSources.SHEET_CLOSE_BUTTON_CLICK))
                                }
                            }),
                            a = r.getSheetElement(),
                            z = new g(a);
                        new c(v, t, function(c) {
                            var a;
                            if (-1 !== e.inArray(p, c))
                                if (a = p.getState(), a.isSheetOpen()) {
                                    if (a.getActionSource() === f.actionSources.DP_ATC_CLICK) {
                                        z.reset();
                                        var l = h.createAtcStatusWidget();
                                        a = h.createIMBWidget(a.getActionSource());
                                        z.renderWidgets([l, a])
                                    }
                                    r.open()
                                } else a.getActionSource() !==
                                    f.actionSources.SHEET_CLOSE_BUTTON_CLICK && r.close(); - 1 !== e.inArray(q, c) && z.renderWidgets(h.createRecommendationWidget(q))
                        })
                    }
                    var e = a.$,
                        y = !1;
                    return {
                        initializeUSSSheetView: function() {
                            y || v()
                        }
                    }
                });
                e.when("A", "uss-constants", "uss-template-store", "uss-widget-factory").register("widget-creation-helper", function(a, d, f, b) {
                    return {
                        createAtcStatusWidget: function() {
                            var a = {
                                content: f.getTemplate(d.widgetType.ATCStatusWidget),
                                widgetType: d.widgetType.ATCStatusWidget
                            };
                            return b.getWidget(a)
                        },
                        createRecommendationWidget: function(d) {
                            var f,
                                c = [];
                            d = d.getState().getNewRecommendations();
                            a.each(d, function(a) {
                                (f = b.getWidget(a)) && c.push(f)
                            });
                            return c
                        },
                        createIMBWidget: function() {
                            return b.getWidget({
                                content: "\x3cdiv\x3e\x3c/div\x3e",
                                widgetType: d.widgetType.ATC_STATUS_IMB_WIDGET
                            })
                        }
                    }
                });
                e.when("A", "dp-flux-store", "uss-dispatcher").register("uss-store-repository", function(a, d, f) {
                    var b = {};
                    return {
                        registerStore: function(a, g, c) {
                            g = new d(a, g, f, c);
                            return b[a.getName()] = g
                        },
                        getStore: function(a) {
                            return b[a]
                        },
                        getDispatcher: function() {
                            return f
                        }
                    }
                });
                e.when("A",
                    "uss-store-repository", "dp-flux-attribution", "uss-sheet-store", "uss-constants").register("uss-recommendation-data-store", function(a, d, f, b, k) {
                    function g(c, a, h) {
                        this._unprocessedChunkIndex = h || 0;
                        this._recommendationBaseIdentifier = c;
                        this._dataChunks = a || []
                    }
                    var c = a.$,
                        h = k.ussCTI;
                    f = new f(k.stores.RECOMMENDATION_DATA_STORE, h.CATEGORY, h.TYPE, h.ITEM);
                    b = d.getStore(k.stores.USS_SHEET_STORE);
                    g.prototype = {
                        _getRecommendations: function(c) {
                            var h = [];
                            c < this._dataChunks.length && a.each(this._dataChunks, function(b, d) {
                                d >=
                                    c && a.each(b, function(c) {
                                        h.push(c)
                                    })
                            });
                            return h
                        },
                        getAllRecommendations: function() {
                            return this._getRecommendations(0)
                        },
                        getNewRecommendations: function() {
                            return this._getRecommendations(this._unprocessedChunkIndex)
                        },
                        getRecommendationBaseIdentifier: function() {
                            return this._recommendationBaseIdentifier
                        },
                        addRecommendationChunk: function(h) {
                            var b = [];
                            a.each(h, function(c) {
                                c.widgetType = c.widgetType || k.widgetType.RECOMMENDATION_WIDGET
                            });
                            b = c.merge(b, this._dataChunks);
                            b = c.merge(b, [h]);
                            return new g(this._recommendationBaseIdentifier,
                                b, this._dataChunks.length)
                        }
                    };
                    h = new g;
                    return d.registerStore(f, function(c, a) {
                        var h = c,
                            f = k.actions;
                        switch (a.getName()) {
                            case f.USS_OPEN:
                                d.getDispatcher().waitFor([b.getDispatchToken()]);
                                b.getState().getActionSource() === k.actionSources.DP_ATC_CLICK && (h = new g(b.getState().getRecommendationBaseIdentifier()));
                                break;
                            case f.RECOMMENDATION_DATA_RECEIVE:
                                f = b.getState().getRecommendationBaseIdentifier(), a = a._metadata, a.recommendationBaseIdentifier === f && (h = c.addRecommendationChunk(a.widgets))
                        }
                        return h
                    }, h)
                });
                e.when("uss-store-repository",
                    "dp-flux-attribution", "uss-constants").register("uss-sheet-store", function(a, d, f) {
                    function b(c, a, l) {
                        this._isSheetOpen = c || !1;
                        this._actionSource = a;
                        this._recommendationBaseIdentifier = l
                    }
                    var k = f.actions,
                        g = f.ussCTI;
                    d = new d(f.stores.USS_SHEET_STORE, g.CATEGORY, g.TYPE, g.ITEM);
                    b.prototype = {
                        isSheetOpen: function() {
                            return this._isSheetOpen
                        },
                        getActionSource: function() {
                            return this._actionSource
                        },
                        getRecommendationBaseIdentifier: function() {
                            return this._recommendationBaseIdentifier
                        }
                    };
                    g = new b(!1);
                    return a.registerStore(d,
                        function(c, a) {
                            var l = c;
                            switch (a.getName()) {
                                case k.USS_OPEN:
                                    c.isSheetOpen() || (a.getSource() === f.actionSources.DP_ATC_CLICK ? l = new b(!0, a.getSource(), a.getMetaData().recommendationBaseIdentifier) : a.getSource() === f.actionSources.USS_INGRESS_CLICK && c.getRecommendationBaseIdentifier() && (l = new b(!0, a.getSource(), c.getRecommendationBaseIdentifier())));
                                    break;
                                case k.USS_CLOSE:
                                    c.isSheetOpen() && (l = new b(!1, a.getSource(), c.getRecommendationBaseIdentifier()))
                            }
                            return l
                        }, g)
                });
                e.when("A", "uss-store-repository", "dp-flux-attribution",
                    "uss-constants", "dp-flux-utils").register("uss-atc-status-store", function(a, d, f, b, k) {
                    function g() {
                        this.status = void 0;
                        this.cart = {
                            subTotal: {}
                        };
                        this.mainImage = {};
                        this.isAtcGenericError = this.shippingMessageHTML = this.imbHTML = void 0
                    }
                    a = new f("uss-atc-status-store", b.ussCTI.CATEGORY, b.ussCTI.TYPE, b.ussCTI.ITEM);
                    g.prototype = {
                        setStatus: function(c) {
                            this.status = 1 === c || c === b.classList.ATC_SUCCESS ? b.classList.ATC_SUCCESS : b.classList.ATC_ERROR
                        },
                        setCart: function(c, a, l) {
                            k.isNonEmptyString(c) && (this.cart.count = parseInt(c));
                            a && (this.cart.subTotal = a);
                            k.isNonEmptyString(l) && (this.cart.checkoutUrl = l)
                        },
                        setMainImage: function(c, a) {
                            k.isNonEmptyString(c) && (this.mainImage.src = c, k.isNonEmptyString(a) ? this.mainImage.altText : this.mainImage.altText = "")
                        },
                        setImbHTML: function(c) {
                            k.isNonEmptyString(c) && (this.imbHTML = c)
                        },
                        setShippingMessageHTML: function(c) {
                            k.isNonEmptyString(c) && (this.shippingMessageHTML = c)
                        },
                        setIsAtcGenericError: function(c) {
                            this.isAtcGenericError = c
                        }
                    };
                    f = new g;
                    d.registerStore(a, function(c, a) {
                        var l = c;
                        switch (a.getName()) {
                            case b.actions.ATC_RECEIVE:
                                var d =
                                    a.getMetaData();
                                a.getSource() === b.actionSources.DP_ATC_CLICK ? (l = new g, d.isAtcGenericError ? l.setIsAtcGenericError(!0) : (l.setStatus(d.status), l.setCart(d.cart.count, d.cart.subTotal, d.cart.checkoutUrl), l.setMainImage(d.mainImage.src, d.mainImage.altText), l.setImbHTML(d.imbHTML), l.setShippingMessageHTML(d.shippingMessageHTML))) : a.getSource() !== b.actionSources.USS_INLINE_ATC_CLICK || d.isAtcGenericError || (l = new g, l.setStatus(c.status), l.setMainImage(c.mainImage.src, c.mainImage.altText), l.setImbHTML(c.imbHTML),
                                    l.setShippingMessageHTML(c.shippingMessageHTML), d.cart && l.setCart(d.cart.count, d.cart.subTotal, c.cart.checkoutUrl));
                                break;
                            case b.actions.USS_OPEN:
                                a.getSource() === b.actionSources.DP_ATC_CLICK && (l = new g)
                        }
                        return l
                    }, f)
                });
                e.when("A", "uss-constants").register("uss-template-store", function(a, d) {
                    var f = a.$,
                        b = d.classList,
                        k = {};
                    return {
                        init: function() {
                            var a = f("." + b.TEMPLATE_STORE),
                                c;
                            1 === a.length && a.find("." + b.TEMPLATE).each(function(a, l) {
                                c = f("\x3cdiv\x3e\x3c/div\x3e");
                                l = f(l);
                                c.append(l);
                                (a = l.data(b.TEMPLATE_NAME)) &&
                                (k[a] = c.html())
                            })
                        },
                        getTemplate: function(a) {
                            return k[a]
                        },
                        _nameToTemplateMap: k
                    }
                });
                e.when("A", "dp-flux-attribution", "dp-flux-utils", "uss-store-repository", "uss-widget", "uss-constants").register("uss-widget-factory", function(a, d, f, b, k, g) {
                    var c = a.$,
                        h = {};
                    h[g.widgetType.WIDGET] = k;
                    a = g.ussCTI;
                    var l = new d("uss-widget-factory", a.CATEGORY, a.TYPE, a.ITEM);
                    return {
                        registerWidgetType: function(a, c) {
                            if (!f.isNonEmptyString(a)) throw Error("uss-widget-factory.registerWidgetType()... : name parameter must be valid string. provided name param is \x3d " +
                                a);
                            if (!(c.prototype instanceof k)) throw Error("uss-widget-factory.registerWidgetType()... : constructor.prototype must be instance of Widget. provided constructor param is \x3d " + c);
                            h[a] = c
                        },
                        getWidgetType: function(a) {
                            return h[a]
                        },
                        getWidget: function(a) {
                            var b, f = l;
                            try {
                                var k = a.widgetType || g.widgetType.WIDGET,
                                    u = h[k];
                                if (!u) return e.log("Widget.getWidget()... : Constructor not exist for type : " + k, "FATAL", f.getAttribution()), b;
                                var x = u.getAttribution && u.getAttribution();
                                x && (f = x);
                                if (a.attribution) var p = a.attribution,
                                    f = new d(p.name, p.category, p.type, p.item);
                                var q = c(a.content),
                                    t = c("\x3cdiv\x3e\x3c/div\x3e");
                                t.append(q);
                                b = new u(f, t)
                            } catch (r) {
                                e.log("Widget.getWidget()... : " + r.message, "FATAL", f.getAttribution && f.getAttribution())
                            }
                            return b
                        }
                    }
                });
                e.when("A", "uss-constants", "dp-flux-view", "uss-store-repository", "uss-dispatcher").register("uss-widget", function(a, d, f, b, k) {
                    function e(c) {
                        var d = [];
                        a.each(c, function(a) {
                            var c = b.getStore(a);
                            if (c) d.push(c);
                            else throw Error("Widget.getWidget().getStores()... : store with name \x3d " +
                                a + " not exists");
                        });
                        return d
                    }
                    var c = d.classList,
                        h = d.widgetType;
                    return a.createClass({
                        init: function(a, d) {
                            this._element = d;
                            this._element.addClass(h.WIDGET);
                            this._element.addClass(c.HIDE_ELEMENT);
                            this._attribution = a;
                            this._dispacther = k;
                            this.getStoreNames().length && (d = e(this.getStoreNames()), this._fluxView = new f(a, d, this.update.bind(this)), this.update(d))
                        },
                        show: function(b) {
                            b = b || {};
                            b = b.showWidgetAnimation || {};
                            var h = d.animationType;
                            b.animationType = b.animationType || h.NO_ANIMATION;
                            switch (b.animationType) {
                                case h.FADE_IN:
                                    a.fadeIn(this._element,
                                        b.timeDuration || 100, b.transitionTimingFunction || d.transitionTimingFunction.EVEN_EASE);
                                    break;
                                case h.NO_ANIMATION:
                                    this._element.addClass(c.SHOW_ELEMENT), this._element.removeClass(c.HIDE_ELEMENT)
                            }
                        },
                        hide: function() {
                            this._element.addClass(c.HIDE_ELEMENT);
                            this._element.removeClass(c.SHOW_ELEMENT)
                        },
                        beforeRender: function() {},
                        afterRender: function() {},
                        getElement: function() {
                            return this._element
                        },
                        getAttribution: function() {
                            return this._attribution
                        },
                        getDispatcher: function() {
                            return this._dispacther
                        },
                        update: function(a) {},
                        getStoreNames: function() {
                            return []
                        },
                        deleteWidget: function() {
                            this._element.remove();
                            this._fluxView && this._fluxView.unregisterStores()
                        }
                    })
                });
                e.when("A", "uss-constants", "uss-widget-factory", "uss-logger-service").register("uss-recommendation-widget", function(a, d, f, b) {
                    var k = d.widgetType;
                    a = f.getWidgetType(k.WIDGET);
                    var e = d.classList,
                        c = d.metrics;
                    d = a.extend({
                        init: function(a, c) {
                            this._super(a, c);
                            this._element.addClass(k.RECOMMENDATION_WIDGET);
                            this._addTrackingMetrics()
                        },
                        _addTrackingMetrics: function() {
                            this._element.find("." +
                                e.FACEOUT_IMAGE).click(function() {
                                b.logCounter(c.FACEOUT_IMAGE_CLICK_COUNTER)
                            });
                            this._element.find("." + e.FACEOUT_REVIEW_STARS).click(function() {
                                b.logCounter(c.FACEOUT_REVIEW_STARS_CLICK_COUNTER)
                            });
                            this._element.find("." + e.FACEOUT_PRICE).click(function() {
                                b.logCounter(c.FACEOUT_PRICE_CLICK_COUNTER)
                            });
                            this._element.find("." + e.FACEOUT_TITLE).click(function() {
                                b.logCounter(c.FACEOUT_TITLE_CLICK_COUNTER)
                            });
                            this._element.find("." + e.FACEOUT_BEST_SELLER).click(function() {
                                b.logCounter(c.FACEOUT_BEST_SELLER_CLICK_COUNTER)
                            })
                        }
                    });
                    f.registerWidgetType(k.RECOMMENDATION_WIDGET, d);
                    return d
                });
                e.when("A", "uss-constants", "uss-widget-factory", "dp-flux-attribution", "uss-template-store", "dp-flux-action", "uss-logger-service").register("uss-no-recommendation-widget", function(a, d, f, b, e, g, c) {
                    var h = d.widgetType;
                    a = f.getWidgetType(h.WIDGET);
                    var l = d.ussCTI,
                        w = new b(d.widgetType.NO_RECOMMENDATION_WIDGET, l.CATEGORY, l.TYPE, l.ITEM);
                    b = a.extend({
                        init: function(a, b) {
                            this._super(a, b);
                            this._element.addClass(h.NO_RECOMMENDATION_WIDGET);
                            a = e.getTemplate(d.widgetType.NO_RECOMMENDATION_WIDGET);
                            this._element.append(a);
                            this._continueShoppingLink = this._element.find("." + d.classList.CONTINUE_SHOPPING_LINK);
                            this._continueShoppingLink.click(function(a) {
                                a.preventDefault();
                                c.logCounter(d.metrics.CONTINUE_SHOPPING_CLICK);
                                this.getDispatcher().dispatch(new g(d.actions.USS_CLOSE, d.actionSources.CONTINUE_SHOPPING_CLICK))
                            }.bind(this))
                        }
                    });
                    b.getAttribution = function() {
                        return w
                    };
                    f.registerWidgetType(h.NO_RECOMMENDATION_WIDGET, b);
                    return b
                });
                e.when("A", "uss-constants", "uss-widget-factory").register("primary-action-status-widget",
                    function(a, d, f) {
                        var b = d.widgetType;
                        a = f.getWidgetType(b.WIDGET).extend({
                            init: function(a, d) {
                                this._super(a, d);
                                this.getElement().addClass(b.PRIMARY_ACTION_STATUS_WIDGET)
                            }
                        });
                        f.registerWidgetType(b.PRIMARY_ACTION_STATUS_WIDGET, a);
                        return a
                    });
                e.when("A", "promising-ui-element", "uss-utils", "uss-constants").register("promising-image", function(a, d, f, b) {
                    var k = a.$,
                        g = b.classList;
                    return d.extend({
                        init: function(a, b) {
                            this._element = k(b);
                            this._attribution = a;
                            this._super(this._element);
                            this._eventHandle = void 0
                        },
                        _showTickMarkImage: function(c) {
                            switch (c) {
                                case g.ATC_SUCCESS:
                                    this._showSuccessTickMark();
                                    break;
                                case g.ATC_ERROR:
                                    this._showErrorTickMark();
                                    break;
                                default:
                                    return
                            }
                            a.off(this._eventHandle.event, this._eventHandle.callback)
                        },
                        _showSuccessTickMark: function() {
                            k(".main-image").find(".success-tick-mark-placeholder").addClass("success-tick-mark-image")
                        },
                        _showErrorTickMark: function() {
                            var c = k(".main-image").find(".error-tick-mark-placeholder");
                            c.addClass("error-tick-mark-image");
                            a.fadeIn(c, 200, b.transitionTimingFunction.EASE_OUT)
                        },
                        showUIValue: function(c, d, l) {
                            var g = this,
                                v = b.defaultAtcAnimationType,
                                D =
                                this._super.bind(this);
                            v === b.animationType.FADE_IN && (this._eventHandle = a.on(b.atcAnimationStatusEvent, this._showTickMarkImage.bind(this, l)));
                            return f.loadImage(c, d).then(function(c) {
                                    if (v === b.animationType.FADE_IN) {
                                        var d = k(".main-image").find(".ui-promise");
                                        a.fadeOut(d, 200, b.transitionTimingFunction.EASE_IN, function() {
                                            g._appendImageToUIValue(c);
                                            D();
                                            var d = k(".main-image").find(".ui-value");
                                            a.fadeIn(d, 200, b.transitionTimingFunction.EASE_OUT)
                                        })
                                    } else this._appendImageToUIValue(c), D();
                                    return !0
                                }.bind(this),
                                function() {
                                    e.log("PromisingImage.showUIValue() ... : failed to load image", "FATAL", this._attribution.getAttribution());
                                    return !1
                                }.bind(this))
                        },
                        _appendImageToUIValue: function(a) {
                            this.getValueElement().empty();
                            this.getValueElement().append(a)
                        }
                    })
                });
                e.when("A", "promising-ui-element", "uss-constants").register("atc-status-msg", function(a, d, f) {
                    var b = f.classList;
                    return d.extend({
                        init: function(a) {
                            this._atcStatusElement = a;
                            this._super(this._atcStatusElement)
                        },
                        _showSuccessMessage: function() {
                            this._atcStatusElement.addClass(b.ATC_SUCCESS);
                            this._atcStatusElement.removeClass(b.ATC_ERROR);
                            this._atcStatusElement.removeClass(b.ITEM_IN_CART)
                        },
                        _showFailureMessage: function() {
                            this._atcStatusElement.addClass(b.ATC_ERROR);
                            this._atcStatusElement.removeClass(b.ATC_SUCCESS);
                            this._atcStatusElement.removeClass(b.ITEM_IN_CART)
                        },
                        _showItemInCartMessage: function() {
                            this._atcStatusElement.addClass(b.ITEM_IN_CART);
                            this._atcStatusElement.removeClass(b.ATC_ERROR);
                            this._atcStatusElement.removeClass(b.ATC_SUCCESS)
                        },
                        showUIValue: function(d) {
                            var e = this,
                                c = f.defaultAtcAnimationType;
                            switch (d) {
                                case b.ATC_SUCCESS:
                                    this._showSuccessMessage();
                                    break;
                                case b.ATC_ERROR:
                                    this._showFailureMessage();
                                    break;
                                case b.ITEM_IN_CART:
                                    this._showItemInCartMessage();
                                    break;
                                default:
                                    return
                            }
                            this._super();
                            c === f.animationType.FADE_IN && (d = this._atcStatusElement.find("." + b.UI_PROMISE), a.fadeOut(d, 200, f.transitionTimingFunction.EASE_IN, function() {
                                var c = e._atcStatusElement.find("." + b.UI_VALUE);
                                a.fadeIn(c, 200, f.transitionTimingFunction.EASE_OUT, function() {
                                    a.trigger(f.atcAnimationStatusEvent)
                                })
                            }))
                        }
                    })
                });
                e.when("A",
                    "promising-ui-element", "uss-constants", "dp-flux-utils").register("cart-status-message", function(a, d, f, b) {
                    var e = f.classList;
                    return d.extend({
                        init: function(a) {
                            this._cartStatusElement = a;
                            this._subTotalElement = this._cartStatusElement.find("." + e.CART_SUB_TOTAL);
                            this._cartCountElement = this._cartStatusElement.find("." + e.CART_COUNT);
                            this._cartCountSingularTemplate = this._cartCountElement.data("cart-count-singular-template");
                            this._cartCountPluralTemplate = this._cartCountElement.data("cart-count-plural-template");
                            this._super(this._cartStatusElement);
                            this._eventHandle = void 0
                        },
                        _atcAnimationStatusResolved: function() {
                            setTimeout(function() {
                                this._cartStatusElement.addClass("uss-c-cart-status-msg-transition");
                                a.off(this._eventHandle.event, this._eventHandle.callback)
                            }.bind(this), 200)
                        },
                        showUIValue: function(d, c) {
                            var h = f.defaultAtcAnimationType;
                            if ("number" === typeof d && b.isNonEmptyString(c)) {
                                var l;
                                1 === d ? l = this._cartCountSingularTemplate.replace("###cartCount", d) : 1 < d && (l = this._cartCountPluralTemplate.replace("###cartCount",
                                    d));
                                this._cartCountElement.html(l);
                                this._subTotalElement.html(c);
                                this._super();
                                h === f.animationType.FADE_IN && (this._eventHandle = a.on(f.atcAnimationStatusEvent, this._atcAnimationStatusResolved.bind(this)))
                            }
                        }
                    })
                });
                e.when("A", "a-button", "uss-constants", "uss-logger-service").register("uss-sub-nav", function(a, d, f, b) {
                    var e = f.classList,
                        g = f.metrics;
                    return {
                        getInstance: function(c) {
                            var h = {},
                                l = c.find("." + e.CHECKOUT_FORM);
                            d("." + e.CHECKOUT_BUTTON, c);
                            var w = c.find("." + e.CART_BUTTON),
                                v = void 0;
                            l.submit(function() {
                                b.logCounter(g.CHECKOUT_FORM_CLICK_COUNTER)
                            });
                            w.click(function() {
                                b.logCounter(g.CART_BUTTON_CLICK_COUNTER)
                            });
                            h.updateCheckoutUrl = function(a) {
                                l.attr("action", a)
                            };
                            h.hide = function() {
                                a.$(c).addClass("is-hidden")
                            };
                            h.atcAnimationStatusResolved = function() {
                                setTimeout(function() {
                                    a.$(c).addClass("uss-c-sub-nav-margin");
                                    a.$(c).addClass("uss-c-sub-nav-transition");
                                    a.off(v.event, v.callback)
                                }.bind(), 200)
                            };
                            h.show = function() {
                                a.$(c).removeClass("is-hidden");
                                f.defaultAtcAnimationType === f.animationType.FADE_IN && (v = a.on(f.atcAnimationStatusEvent, h.atcAnimationStatusResolved.bind()))
                            };
                            h.preInitiate = function() {
                                var a = l.parent();
                                a.find("iframe#ussCheckoutPrefetch").remove();
                                var c = (new Date).getTime(),
                                    d = "/gp/checkoutprefetch/checkout-prefetch.html?checkoutInitiateId\x3d" + c,
                                    b = document.createElement("iframe");
                                b.setAttribute("src", d);
                                b.setAttribute("style", "width:0px;height:0px;display:none;position:absolute;");
                                b.setAttribute("name", "ussCheckoutPrefetch");
                                b.setAttribute("id", "ussCheckoutPrefetch");
                                a.append(b);
                                a = l.find("#checkoutInitiateId");
                                a.length ? a.val(c) : l.append("\x3cinput type\x3d'hidden' name\x3d'checkoutInitiateId' id\x3d'checkoutInitiateId' value\x3d'" +
                                    c + "'\x3e")
                            };
                            h.hide();
                            return h
                        }
                    }
                });
                e.when("A", "uss-constants").register("uss-shipping-details", function(a, d) {
                    var f = a.$;
                    return {
                        getInstance: function(b) {
                            var e = b.find("." + d.classList.SHIPPING_DETAILS),
                                g = e.find("." + d.classList.SHIPPING_MESSAGE_PLACEHOLDER),
                                c = d.defaultAtcAnimationType,
                                h = void 0,
                                l = function() {
                                    var a = g.find(".a-row").find("a"),
                                        c = a.attr("onclick");
                                    if ("undefined" !== typeof c && c.includes("amz_js_PopWin")) {
                                        var d = [];
                                        f.each(a[0].attributes, function(a, c) {
                                            d.push(c.name)
                                        });
                                        f.each(d, function(c, d) {
                                            a.removeAttr(d)
                                        });
                                        a.attr("href", "/gp/help/customer/display.html?nodeId\x3d527692")
                                    }
                                },
                                w = {
                                    hide: function() {
                                        e.addClass(d.classList.HIDE_ELEMENT);
                                        e.removeClass(d.classList.SHOW_ELEMENT)
                                    },
                                    atcAnimationStatusResolved: function() {
                                        setTimeout(function() {
                                            e.addClass("uss-c-shipping-details-transition");
                                            a.off(h.event, h.callback)
                                        }.bind(), 200)
                                    },
                                    show: function(b) {
                                        g.empty();
                                        g.append(a.$(b));
                                        l();
                                        e.addClass(d.classList.SHOW_ELEMENT);
                                        e.removeClass(d.classList.HIDE_ELEMENT);
                                        c === d.animationType.FADE_IN && (h = a.on(d.atcAnimationStatusEvent, w.atcAnimationStatusResolved.bind()))
                                    }
                                };
                            w.hide();
                            return w
                        }
                    }
                });
                e.when("A", "uss-constants", "primary-action-status-widget", "dp-flux-attribution", "uss-widget-factory", "atc-status-msg", "cart-status-message", "promising-image", "uss-sub-nav", "uss-shipping-details").register("atc-status-widget", function(a, d, f, b, e, g, c, h, l, w) {
                    var v = d.ussCTI,
                        D = d.widgetType,
                        y = d.classList,
                        u = new b(d.widgetType.ATCStatusWidget, v.CATEGORY, v.TYPE, v.ITEM);
                    f = f.extend({
                        init: function(a, d) {
                            this._atcGenericError = d.find("." + y.ATC_GENERIC_ERROR);
                            this._atcAcknowledgementMessage =
                                d.find("." + y.ATC_ACKNOWLEDGEMENT_MESSAGE);
                            this._mainImage = new h(a, this._atcAcknowledgementMessage.find("." + y.MAIN_IMAGE));
                            this._atcStatusMessage = new g(this._atcAcknowledgementMessage.find("." + y.ATC_STATUS_MESSAGE_COMPONENT));
                            this._cartStatusMessage = new c(this._atcAcknowledgementMessage.find("." + y.CART_STATUS_MESSAGE_COMPONENT));
                            this._subNav = l.getInstance(this._atcAcknowledgementMessage.find("." + y.SUB_NAV));
                            this._shippingDetails = w.getInstance(this._atcAcknowledgementMessage);
                            this._viewState = {};
                            this._super(a,
                                d)
                        },
                        update: function(c) {
                            var b;
                            a.each(c, function(c) {
                                c.getStoreAttribution().getName() === d.stores.ATC_STATUS_STORE && (this._subNav.preInitiate(), b = c.getState(), b.isAtcGenericError ? this.showGenericError() : (c = a.diff(this._viewState, b), c.status && b.status && this._atcStatusMessage.showUIValue(b.status), c.cart.count && b.cart.count && (this._cartStatusMessage.showUIValue(b.cart.count, b.cart && b.cart.subTotal && b.cart.subTotal.displayString || ""), c.cart.checkoutUrl && b.cart.checkoutUrl && this._subNav.updateCheckoutUrl(b.cart.checkoutUrl),
                                    this._subNav.show()), c.mainImage.src && b.mainImage.src && this._mainImage.showUIValue(b.mainImage.src, b.mainImage.altText, b.status), c.shippingMessageHTML && b.shippingMessageHTML && this._shippingDetails.show(b.shippingMessageHTML)), this._viewState = b)
                            }.bind(this))
                        },
                        showGenericError: function() {
                            this._atcAcknowledgementMessage.addClass(y.HIDE_ELEMENT);
                            this._atcAcknowledgementMessage.removeClass(y.SHOW_ELEMENT);
                            this._atcGenericError.removeClass(y.HIDE_ELEMENT);
                            this._atcGenericError.addClass(y.SHOW_ELEMENT)
                        },
                        getStoreNames: function() {
                            return [d.stores.ATC_STATUS_STORE]
                        }
                    });
                    f.getAttribution = function() {
                        return u
                    };
                    e.registerWidgetType(D.ATCStatusWidget, f);
                    return f
                });
                e.when("A", "uss-constants", "dp-flux-attribution", "uss-widget-factory").register("atc-status-imb-widget", function(a, d, f, b) {
                    var k = b.getWidgetType(d.widgetType.WIDGET),
                        g = d.ussCTI,
                        c = new f("atc-status-imb-widget", g.CATEGORY, g.TYPE, g.ITEM);
                    f = k.extend({
                        init: function(a, c) {
                            c.addClass(d.widgetType.ATC_STATUS_IMB_WIDGET);
                            this._super(a, c)
                        },
                        update: function(b) {
                            var f;
                            a.each(b, function(b) {
                                if (b.getStoreAttribution().getName() === d.stores.ATC_STATUS_STORE)
                                    if (f = b.getState(), f.imbHTML) {
                                        this.getElement().empty();
                                        b = a.$(f.imbHTML);
                                        var h = b.children().length;
                                        if (1 <= h) {
                                            b.find(".a-declarative a").unwrap();
                                            var g = b.find(".a-declarative span");
                                            g.removeClass("a-color-link huc-cursor-pointer");
                                            g.unwrap();
                                            this.getElement().append(b);
                                            this.show();
                                            1 < h && e.log("ImbWidget.update(...): More than one IMB message exist : html \x3d " + f.imbHTML, "WARN", c.getAttribution())
                                        } else this.hide()
                                    } else this.hide()
                            }.bind(this))
                        },
                        afterRender: function() {
                            this.hide()
                        },
                        getStoreNames: function() {
                            return [d.stores.ATC_STATUS_STORE]
                        }
                    });
                    f.getAttribution = function() {
                        return c
                    };
                    b.registerWidgetType(d.widgetType.ATC_STATUS_IMB_WIDGET, f);
                    return f
                });
                e.when("A").register("uss-base-layout", function(a) {
                    return a.createClass({
                        init: function(a) {
                            this._ussSheetElement = a
                        },
                        renderWidgets: function(a) {
                            throw Error("Layout.renderWidgets()...: Subclass must implement update method");
                        },
                        reset: function() {
                            throw Error("Layout.reset()...: Subclass must implement reset method");
                        },
                        getUssSheetElement: function() {
                            return this._ussSheetElement
                        }
                    })
                });
                e.when("A", "uss-base-layout", "promising-ui-element", "uss-constants", "primary-action-status-widget", "atc-status-imb-widget").register("uss-default-layout", function(a, d, f, b, e, g) {
                    var c = b.layout.defaultLayout;
                    return d.extend({
                        init: function(d) {
                            this._super(d);
                            this._element = d.find("." + c.DEFAULT_LAYOUT);
                            this._ussHead = this._element.find("." + c.HEAD);
                            this._ussBody = this._element.find("." + c.BODY);
                            this._widgetList = [];
                            this._recommendationLoader = a.$("." +
                                c.SKELETON_LOADER);
                            this._recommendationLoadingMessage = a.$("." + c.RECOMMENDATION_LOADING_MESSAGE);
                            this._recommendationLoadedMessage = a.$("." + c.RECOMMENDATION_LOADED_MESSAGE);
                            this._ussBody.append(this._recommendationLoader);
                            this._recommendationLoaderFadeOutOptions = {
                                timeDuration: 200,
                                transitionTimingFunction: b.transitionTimingFunction.EASE_IN
                            };
                            this._recommendationLoaderFadeInOptions = {
                                timeDuration: 200,
                                transitionTimingFunction: b.transitionTimingFunction.EASE_OUT
                            };
                            this._recommendationWidgetOptions = {
                                showWidgetAnimation: {
                                    animationType: b.animationType.FADE_IN,
                                    timeDuration: 200,
                                    transitionTimingFunction: b.transitionTimingFunction.EASE_OUT
                                }
                            }
                        },
                        renderWidgets: function(b) {
                            var d, f = !1;
                            a.each(b, function(b) {
                                d = {};
                                b.beforeRender();
                                this._widgetList.push(b);
                                if (b instanceof e) this._ussHead.prepend(b.getElement());
                                else if (b.getElement().addClass(c.BOTTOM_MARGIN_BETWEEN_WIDGETS), b.getElement().addClass(c.TOP_MARGIN_BETWEEN_WIDGETS), b instanceof g) this._ussBody.prepend(b.getElement());
                                else {
                                    if (!f) {
                                        f = !0;
                                        var h = this;
                                        a.fadeOut(this._recommendationLoader, this._recommendationLoaderFadeOutOptions.timeDuration,
                                            this._recommendationLoaderFadeOutOptions.transitionTimingFunction,
                                            function() {
                                                a.fadeIn(h._recommendationLoadedMessage, h._recommendationLoaderFadeInOptions.timeDuration, h._recommendationLoaderFadeInOptions.transitionTimingFunction)
                                            })
                                    }
                                    d = this._recommendationWidgetOptions;
                                    this._ussBody.append(b.getElement())
                                }
                                b.show(d);
                                b.afterRender()
                            }.bind(this))
                        },
                        reset: function() {
                            a.each(this._widgetList, function(a) {
                                a.deleteWidget()
                            });
                            this._widgetList = [];
                            this._ussBody.empty();
                            this._ussBody.append(this._recommendationLoader);
                            this._ussBody.append(this._recommendationLoadedMessage);
                            this._recommendationLoader.css({
                                display: "block"
                            });
                            this._recommendationLoadingMessage.css({
                                display: "none"
                            });
                            this._recommendationLoadedMessage.css({
                                display: "none"
                            });
                            this.resetScrollPosition()
                        },
                        resetScrollPosition: function() {
                            this._ussBody.scrollTop(0)
                        }
                    })
                });
                e.when("uss-constants", "dp-flux-action", "uss-dispatcher").register("uss-action-creator-helper", function(a, d, f) {
                    return {
                        primaryATCClick: function(b, e) {
                            var g = new d(a.actions.USS_OPEN, a.actionSources.DP_ATC_CLICK, {
                                recommendationBaseIdentifier: b
                            });
                            f.dispatch(g);
                            e.atcData.then(function(c) {
                                var b = {};
                                1 === c.isOk ? b = c.atcStatusData : b.isAtcGenericError = !0;
                                c = new d(a.actions.ATC_RECEIVE, a.actionSources.DP_ATC_CLICK, b);
                                f.dispatch(c)
                            }, function() {
                                var c = new d(a.actions.ATC_RECEIVE, a.actionSources.DP_ATC_CLICK, {
                                    isAtcGenericError: !0
                                });
                                f.dispatch(c)
                            });
                            e.percolateData.then(function(c) {
                                var e = {
                                    isContainsRecommendation: !1,
                                    widgets: []
                                };
                                c.recommendationData && (e.widgets = c.recommendationData.widgets || []);
                                e.widgets.length || e.widgets.push({
                                    widgetType: a.widgetType.NO_RECOMMENDATION_WIDGET
                                });
                                e.recommendationBaseIdentifier = b;
                                c = new d(a.actions.RECOMMENDATION_DATA_RECEIVE, a.actionSources.DP_ATC_CLICK, e);
                                f.dispatch(c)
                            }, function() {
                                var c = {
                                    widgets: []
                                };
                                c.widgets.push({
                                    widgetType: a.widgetType.NO_RECOMMENDATION_WIDGET
                                });
                                c.recommendationBaseIdentifier = b;
                                c = new d(a.actions.RECOMMENDATION_DATA_RECEIVE, a.actionSources.DP_ATC_CLICK, c);
                                f.dispatch(c)
                            })
                        },
                        secondaryATCClick: function(b) {
                            b.atcData.then(function(b) {
                                var e = {};
                                1 === b.isOk ? e = b.atcStatusData : e.isAtcGenericError = !0;
                                b = new d(a.actions.ATC_RECEIVE, a.actionSources.USS_INLINE_ATC_CLICK,
                                    e);
                                f.dispatch(b)
                            }, function() {})
                        }
                    }
                })
            },
            initializeUSSComponents: function() {
                e.when("uss-template-store", "uss-sheet-store", "uss-recommendation-data-store", "uss-store-repository", "uss-widget", "uss-recommendation-widget", "primary-action-status-widget", "uss-widget-factory", "uss-sheet-view", "uss-layout").register("uss-framework-ready", function(a) {
                    a.init()
                });
                e.when("uss-sheet-view", "uss-framework-ready").register("uss-sheet-view-ready", function(a) {
                    a.initializeUSSSheetView()
                })
            },
            initializeBuyBox: function() {
                e.when("buy-box-override",
                    "atc-status-widget", "atc-status-imb-widget", "uss-atc-status-store", "uss-framework-ready", "uss-sheet-view-ready").execute(function(a) {
                    a.init()
                })
            }
        }
    });
    e.when("A", "atf", "uss-init-helper", "uss-utils", "uss-preconditions", "uss-logger-service", "uss-constants").register("uss-init", function(C, B, m, A, a, d, f) {
        function b() {
            m.loadUssCommonAssets();
            e.when("A", "3p-promise", "uss-constants", "a-sheet", "uss-logger-service").register("uss-sheet-component", function(a, b, d, f, e) {
                function g() {
                    var b = p("#image-block").offset().top;
                    a.requestAnimationFrame(function() {
                        t.css({
                            position: "fixed",
                            top: "-" + b + "px"
                        })
                    }, t[0])
                }

                function k() {
                    a.requestAnimationFrame(function() {
                        t.css({
                            position: "",
                            top: ""
                        })
                    }, t[0])
                }

                function u(a) {
                    var c = a.find("." + z.HEAD_DIVIDER);
                    a.scroll(function() {
                        0 < a.scrollTop() ? c.removeClass(d.classList.HIDE_ELEMENT) : c.addClass(d.classList.HIDE_ELEMENT)
                    })
                }

                function x(b, h) {
                    if (!(this instanceof x)) throw Error(q.INVALID_CONSTRUCTOR_USAGE);
                    if ("string" === typeof b)
                        if (p("#" + b).length) {
                            var t = this;
                            this._sheetID = b;
                            this._sheet = f.create({
                                name: "uss_bottom_sheet",
                                preloadDomId: b,
                                height: 1E3,
                                closeType: "message",
                                sheetType: "web",
                                closeMessage: "DONE"
                            });
                            this._sheetElement = p("#" + b);
                            m() === d.deviceOrientation.ORIENTATION_LANDSCAPE && this._sheetElement.find("." + z.HEAD).removeClass(d.classList.USS_C_HEAD_STICKY);
                            a.on("a:sheet:beforeHide:uss_bottom_sheet", function() {
                                r && h.beforeClose && h.beforeClose();
                                k();
                                e.logCounter("uss_bottom_sheet:close")
                            });
                            a.on("orientationchange", function() {
                                var a = m(),
                                    c = t._sheetElement.find("." + z.HEAD);
                                a === d.deviceOrientation.ORIENTATION_PORTRAIT ? c.addClass(d.classList.USS_C_HEAD_STICKY) :
                                    c.removeClass(d.classList.USS_C_HEAD_STICKY)
                            });
                            a.on("a:sheet:beforeShow:uss_bottom_sheet", function(a) {
                                g();
                                u(t._sheetElement)
                            })
                        } else throw Error("Unique element with id '" + b + "' must exist inside a DOM");
                    else throw Error(q.INVALID_SHEET_ID);
                }
                var p = a.$,
                    q = d.fatalMessagesList,
                    t = p("#a-page");
                p("body");
                var r = !0,
                    z = d.layout.defaultLayout,
                    m = function() {
                        return p(n).height() > p(n).width() ? d.deviceOrientation.ORIENTATION_PORTRAIT : d.deviceOrientation.ORIENTATION_LANDSCAPE
                    };
                x.prototype.open = function() {
                    return new b(function(a) {
                        r = !0;
                        this._sheet.show();
                        e.logCounter("uss_bottom_sheet:open");
                        a(!0)
                    }.bind(this))
                };
                x.prototype.close = function() {
                    return new b(function(a) {
                        r = !1;
                        this._sheet.hide();
                        a(!0)
                    }.bind(this))
                };
                x.prototype.getSheetElement = function() {
                    return this._sheetElement
                };
                return x
            });
            e.when("A", "a-checkbox").register("buy-box-utility", function(a, b) {
                return {
                    isWarrantySelectedInBuyBox: function() {
                        var a = b(".mbb-checkbox");
                        return 0 < a.size() && a.isChecked()
                    }
                }
            });
            e.when("jQuery", "A", "uss-utils", "uss-atc", "uss-constants").execute("uss-inline-atc",
                function(a, b, d, f, e) {
                    function g(a) {
                        var c = {};
                        c.a = a.cartArgs.ASIN;
                        c.oid = a.cartArgs.offerListingID;
                        c.verificationSessionID = a.cartArgs.verificationSessionID;
                        c.quantity = a.cartArgs.quantity;
                        c.o = "add";
                        return c
                    }

                    function k(a, c, b, d) {
                        a && 1 === a.isOk && a.atcStatusData && 1 === a.atcStatusData.status ? (d.addClass(u.HIDE_ELEMENT), c.removeClass(u.HIDE_ELEMENT)) : (d.addClass(u.HIDE_ELEMENT), b.removeClass(u.HIDE_ELEMENT))
                    }
                    var u = e.classList;
                    (function() {
                        b.declarative("p13n-overflow-atc", "click", function(b) {
                            var e = b.data;
                            b = b.$declarativeParent;
                            var h = b.parent().find(u.SUCCESS_ELEMENT),
                                t = b.parent().find(u.ERROR_ELEMENT),
                                r = b.find(u.BUTTON_ELEMENT);
                            b = {};
                            r.attr("disabled", "disabled");
                            r.addClass(u.DISABLE_BUTTON);
                            b = "";
                            e.linkParams && (b = a.param(e.linkParams));
                            if (d.isMobileApp()) e.inputs = g(e), e.inputs.isSecondaryAtc = 1, b && "" !== b.trim() && ("\x26" === b.charAt(b.length - 1) && (b = b.substring(0, b.length - 1)), e.reftag = e.reftag + "?" + b), b = f.addToCart("RecommendationsWidget", e);
                            else {
                                var z = {
                                    params: g(e)
                                };
                                b = f.addToCart("RecommendationsWidget", z, {
                                    linkParams: b,
                                    ref: e.reftag
                                })
                            }
                            b.atcData.done(function(a) {
                                k(a,
                                    h, t, r)
                            });
                            b.atcData.fail(function() {
                                k(null, h, t, r)
                            })
                        })
                    })()
                });
            e.when("jQuery", "A", "a-component", "a-truncate", "uss-constants").register("uss-list-widget", function(a, b, d, e, f) {
                var g = d.create({
                    _componentName: "ussListWidget",
                    init: function(a, c) {
                        var d = f.classList;
                        this._super(a, c);
                        a = this._$element.find(".a-truncate");
                        a.length && a.each(function() {
                            e.get(this).update()
                        });
                        this._$element.find(".a-icon-row").addClass(d.FACEOUT_REVIEW_STARS);
                        b.loadDynamicImage(this._$element.find("." + d.FACEOUT_IMAGE))
                    }
                });
                return function(a,
                    b) {
                    return new g(a, b)
                }
            });
            e.when("A", "uss-default-layout").register("uss-mobile-default-layout", function(a, b) {
                return b.extend({
                    init: function(a) {
                        this._super(a)
                    },
                    resetScrollPosition: function() {
                        a.animationFrameDelay(function() {
                            this._ussSheetElement.scrollTop(0)
                        }.bind(this))
                    }
                })
            });
            A.isMobileApp() ? (e.when("A", "mash", "uss-constants", "uss-store-repository", "dp-flux-attribution", "dp-flux-view", "dp-flux-action", "uss-dispatcher", "uss-logger-service").register("uss-mash-reappear", function(a, b, d, e, f, g, k, u, m) {
                function p() {
                    q.isFunction(r) &&
                        r.apply(n.app, arguments);
                    m.logCounter(d.metrics.MASH_REAPPEAR);
                    u.dispatch(new k(d.actions.USS_CLOSE, d.actionSources.MASH_REAPPEAR))
                }
                var q = a.$;
                a = d.ussCTI;
                var t = e.getStore(d.stores.USS_SHEET_STORE);
                e = new f("uss-mash-reappear-view", a.CATEGORY, a.TYPE, a.ITEM);
                new g(e, [t], function(a) {
                    n.app.willReappear !== p && (r = n.app.willReappear); - 1 !== q.inArray(t, a) && (a = t.getState(), a.isSheetOpen() ? n.app.willReappear = p : n.app.willReappear = r)
                });
                var r
            }), e.when("A", "uss-constants", "uss-logger-service").register("percolateUI-ajax-utility",
                function(a, b, d) {
                    var e = b.ajaxParams.AJAX_TIMEOUT,
                        f = b.metrics;
                    return {
                        callPercolateUI: function(b) {
                            b = {
                                pageType: "DetailAW",
                                baseAsin: b,
                                subPageType: "mobile-uss"
                            };
                            var h = a.$.Deferred(),
                                g = new d.Timer(f.PERCOLATE_DATA_PROMISE_RESOLVED_TIMER);
                            g.start();
                            a.post("/gp/uss/mobile/", {
                                params: b,
                                success: function(a, b, c) {
                                    h.resolve(a)
                                },
                                error: function(a, b) {
                                    h.reject()
                                },
                                timeout: e
                            });
                            h.done(function(a) {
                                g.stop()
                            });
                            h.fail(function() {
                                d.logCounter(f.PERCOLATE_DATA_PROMISE_REJECTED_COUNTER)
                            });
                            return h.promise()
                        }
                    }
                }), e.when("A", "uss-action-creator-helper",
                "percolateUI-ajax-utility", "uss-preconditions", "uss-logger-service", "uss-constants", "uss-utils").register("uss-atc", function(a, b, d, e, f, g, k) {
                function m(a, b, c, d) {
                    if (e.isUssWeblabInTreatment()) return r.bind(null, a, b, c, d)
                }

                function n(a) {
                    this.widgetName = a;
                    this.isPrimaryAtc = "DetailPageBuyBox" === a
                }
                var p = a.$,
                    q = {},
                    t = g.metrics,
                    r = function(a, c, e, g, k) {
                        var r = {};
                        k && k.atcStatusData && 1 === k.atcStatusData.isOk ? e.resolve(k.atcStatusData) : (e.reject(), f.logCounter(t.ATC_PROMISE_REJECTED_COUNTER));
                        r.atcData = e;
                        c ? (g = d.callPercolateUI(a),
                            r.percolateData = g, b.primaryATCClick(a, r)) : (f.logCounter(t.SECONDARY_ADD_TO_CART_CLICK_COUNTER), b.secondaryATCClick(r))
                    };
                n.prototype._addUssParameters = function(a) {
                    e.isUssWeblabInTreatment() ? (a.inputs.isUSSAjax = 1, this.isPrimaryAtc && (k.shouldFireAndForgetWeblabTrigger() || (a.inputs.triggerUSSWeblab = e.triggerUSSWeblabValue()))) : k.shouldFireAndForgetWeblabTrigger() || (a.inputs.triggerUSSWeblab = e.triggerUSSWeblabValue());
                    var b = k.getDebugParams();
                    Object.keys(b).forEach(function(c) {
                        a.params[c] = b[c]
                    });
                    return a
                };
                n.prototype._addToCart = function(b) {
                    var d = p.Deferred(),
                        e = p.Deferred(),
                        h = {},
                        g = b.inputs.a;
                    b = this._addUssParameters(b);
                    h.atcData = d;
                    var l = new f.Timer(t.ATC_PROMISE_RESOLVED_TIMER);
                    l.start();
                    d.done(function(a) {
                        l.stop()
                    });
                    a.trigger("js-trigger-aw-mash", b, m(g, this.isPrimaryAtc, d, e));
                    return h
                };
                return {
                    addToCart: function(a, b) {
                        if (!a || !a.trim().length || "object" !== typeof b) throw g.fatalMessagesList.INCORRECT_PARAMETER_PASSED;
                        q[a] || (q[a] = new n(a));
                        return q[a]._addToCart(b)
                    }
                }
            }), e.when("A", "uss-atc", "buy-box-utility",
                "uss-preconditions", "uss-logger-service", "uss-constants", "uss-utils").register("buy-box-override", function(a, b, d, e, f, g, k) {
                var m = !1,
                    x = {
                        init: function() {
                            a.$.isFunction(n.markFeatureInteractive) && n.markFeatureInteractive("atc", {
                                hasComponents: !0,
                                components: [{
                                    name: "show-uss-interstitial"
                                }]
                            });
                            a.declarative("show-uss-interstitial", "click", function(p) {
                                var q = n.ue;
                                q && q.count && p && p.data && "add-to-cart" === p.data.buttonID && q.count("DetailPage_MobileApp_AddToCart", (q.count("DetailPage_MobileApp_AddToCart") || 0) + 1);
                                var q = e.isUssConditionsPassed(),
                                    t = d.isWarrantySelectedInBuyBox();
                                q && !t ? (k.shouldFireAndForgetWeblabTrigger() && k.fireAndForgetWeblabTrigger(e.triggerUSSWeblabValue(), e.ussWeblabTreatmentValue()), b.addToCart("DetailPageBuyBox", p.data)) : (f.logCounter(g.metrics.POST_ATC_PRECONDITIONS_FAILED), a.trigger("js-trigger-aw-mash", p.data))
                            });
                            a.declarative("show-uss-interstitial", ["touchstart"], function(a) {
                                var b = a.$event.originalEvent,
                                    c = n.ue;
                                b.acknowledge && (b.acknowledge(0 < a.$currentTarget.length ? a.$currentTarget[0] :
                                    void 0), c && c.count && c.count("tnr-post-ack-atc", (c.count("tnr-post-ack-atc") || 0) + 1))
                            })
                        }
                    };
                return {
                    init: function() {
                        m || (m = !0, x.init())
                    }
                }
            })) : (e.when("A", "uss-constants", "dp-flux-attribution", "dp-flux-view", "uss-store-repository", "uss-atc-status-store").register("nav-bar-cart-count-view", function(a, b, d, e, f, g) {
                var k = a.$;
                a = b.ussCTI;
                d = new d("nav-bar-cart-count-view", a.CATEGORY, a.TYPE, a.ITEM);
                g = f.getStore(b.stores.ATC_STATUS_STORE);
                new e(d, [g], function(a) {
                    if (-1 !== k.inArray(g, a)) {
                        var b = g.getState();
                        n.$Nav.when("api.setCartCount").run(function(a) {
                            b.cart.count &&
                                a(b.cart.count)
                        })
                    }
                })
            }), e.when("A", "uss-action-creator-helper", "uss-preconditions", "uss-logger-service", "uss-constants", "uss-utils").register("uss-atc", function(a, b, d, e, f, g) {
                function k(a) {
                    this.widgetName = a;
                    this.isPrimaryAtc = "DetailPageBuyBox" === a
                }
                var m = a.$,
                    x = f.ajaxParams.AJAX_TIMEOUT,
                    p = f.ajaxParams.BASE_URL,
                    q = {};
                k.prototype._getAtcUrl = function(a) {
                    var b = p;
                    a.hasOwnProperty("ref") && (b = b + "/ref\x3d" + a.ref);
                    (a = a.linkParams) && "" !== a.trim() && ("\x26" === a.charAt(a.length - 1) && (a = a.substring(0, a.length - 1)), b =
                        b + "?" + a);
                    return b
                };
                k.prototype._addUssParameters = function(a) {
                    a.params.isUSSAjax = 1;
                    this.isPrimaryAtc && (a.params.isPrimaryATC = 1, g.shouldFireAndForgetWeblabTrigger() || (a.params.triggerUSSWeblab = d.triggerUSSWeblabValue()));
                    var b = g.getDebugParams();
                    Object.keys(b).forEach(function(c) {
                        a.params[c] = b[c]
                    });
                    return a
                };
                k.prototype._callback = function() {
                    var a = arguments[0],
                        b = Array.prototype.slice.call(arguments, 1);
                    "function" === typeof a && a.apply(this, b)
                };
                k.prototype._addToCart = function(b, d) {
                    var e = this;
                    b = this._getAtcUrl(b);
                    d = this._addUssParameters(d);
                    var f = m.Deferred(),
                        h = m.Deferred(),
                        g = {};
                    a.post(b, {
                        params: d.params,
                        success: function(b, f, h) {
                            d.hasOwnProperty("success") && e._callback(d.success, b, f, h);
                            a.trigger("USS ATC: Success")
                        },
                        error: function(b, g, k) {
                            f.reject();
                            h.reject();
                            d.hasOwnProperty("error") && e._callback(d.error, b, g, k);
                            a.trigger("USS ATC : Failure")
                        },
                        abort: function(a) {
                            f.reject();
                            h.reject();
                            d.hasOwnProperty("abort") && e._callback(d.abort, a)
                        },
                        chunk: function(a) {
                            if (a && a.hasOwnProperty("name")) {
                                switch (a.name) {
                                    case "atc-data":
                                        f.resolve(a.response);
                                        break;
                                    case "percolate-data":
                                        h.resolve(a.response);
                                        break;
                                    default:
                                        var b = {
                                            message: "ATC Failed for widget " + e.widgetName + ". Unrecognized chunk name found. ",
                                            logLevel: "FATAL"
                                        };
                                        n.ueLogError && n.ueLogError("USS ATC Failure for widget " + e.widgetName, b)
                                }
                                d.hasOwnProperty("chunk") && e._callback(d.chunk, a)
                            }
                        },
                        timeout: d.timeout || x
                    });
                    g.atcData = f;
                    this.isPrimaryAtc && (g.percolateData = h);
                    return g
                };
                return {
                    addToCart: function(a, c, d) {
                        if (!a || !a.trim().length || "object" !== typeof c) throw f.fatalMessagesList.INCORRECT_PARAMETER_PASSED;
                        var g = "DetailPageBuyBox" === a;
                        q[a] || (q[a] = new k(a));
                        a = q[a]._addToCart(d, c);
                        g || (e.logCounter(f.metrics.SECONDARY_ADD_TO_CART_CLICK_COUNTER), b.secondaryATCClick(a));
                        return a
                    }
                }
            }), e.when("A", "uss-atc", "uss-action-creator-helper", "uss-preconditions", "uss-logger-service", "uss-constants", "buy-box-utility", "uss-utils").register("buy-box-override", function(a, b, d, e, f, g, k, m) {
                var n = a.$,
                    p = g.metrics;
                a = {
                    actionButton: null,
                    whitelistedActions: {
                        "submit.add-to-cart": 1
                    },
                    init: function() {
                        this.checkPreconditionsAndManipulateBuyBox()
                    },
                    checkPreconditionsAndManipulateBuyBox: function() {
                        this.buyBoxForm = n("#addToCart");
                        (e.isUssConditionsPassed() || e.isUssConditionsPassedUssVsDss()) && this.attachFormHandler()
                    },
                    attachFormHandler: function() {
                        this.buyBoxForm.submit(this.submitForm.bind(this));
                        this.buyBoxForm.find("input[type\x3dsubmit], input[type\x3dbutton]").click(function(a) {
                            this.actionButton = a.target
                        }.bind(this))
                    },
                    isValidAction: function() {
                        return this.actionButton && this.actionButton.name in this.whitelistedActions
                    },
                    submitForm: function(a) {
                        if (!k.isWarrantySelectedInBuyBox() &&
                            this.isValidAction())
                            if (e.isUssWeblabInTreatment()) {
                                a.preventDefault();
                                a = this.getAddToCartParameters();
                                var c = {
                                        params: a
                                    },
                                    n = {
                                        ref: g.ajaxParams.REFTAG
                                    };
                                m.shouldFireAndForgetWeblabTrigger() && m.fireAndForgetWeblabTrigger(e.triggerUSSWeblabValue(), e.ussWeblabTreatmentValue());
                                var c = b.addToCart("DetailPageBuyBox", c, n),
                                    z = new f.Timer(p.ATC_PROMISE_RESOLVED_TIMER),
                                    x = new f.Timer(p.PERCOLATE_DATA_PROMISE_RESOLVED_TIMER);
                                z.start();
                                x.start();
                                c.atcData.then(function(a) {
                                    1 === a.isOk && z.stop()
                                }, function() {
                                    f.logCounter(p.ATC_PROMISE_REJECTED_COUNTER)
                                });
                                c.percolateData.then(function() {
                                    x.stop()
                                }, function() {
                                    f.logCounter(p.PERCOLATE_DATA_PROMISE_REJECTED_COUNTER)
                                });
                                d.primaryATCClick(a[g.ajaxParams.ASIN], c)
                            } else f.logCounter(g.metrics.POST_ATC_PRECONDITIONS_FAILED), m.shouldFireAndForgetWeblabTrigger() ? m.fireAndForgetWeblabTrigger(e.triggerUSSWeblabValue(), e.ussWeblabTreatmentValue()) : this.addHiddenUSSField("triggerUSSWeblab", e.triggerUSSWeblabValue());
                        else f.logCounter(g.metrics.POST_ATC_PRECONDITIONS_FAILED)
                    },
                    addHiddenUSSField: function(a, b) {
                        n("\x3cinput\x3e").attr({
                            type: "hidden",
                            id: a,
                            name: a,
                            value: b
                        }).appendTo(this.buyBoxForm)
                    },
                    getAddToCartParameters: function() {
                        var a = {},
                            b = this.buyBoxForm.serializeArray();
                        n.each(b, function(b, c) {
                            a[c.name] = c.value
                        });
                        return a
                    }
                };
                return {
                    init: a.init.bind(a)
                }
            }))
        }

        function k() {
            var c = a.isUssConditionsPassed();
            c && d.logCounter(f.metrics.PAGE_LANDING_PRECONDITIONS_PASSED);
            if (A.isMobileApp() || c) g || (b(), g = !0, m.initializeUSSComponents()), m.initializeBuyBox()
        }
        var g = !1;
        C.on("PageRefresh:ATF", function() {
            k()
        });
        k()
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("InteractionTrackingAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */