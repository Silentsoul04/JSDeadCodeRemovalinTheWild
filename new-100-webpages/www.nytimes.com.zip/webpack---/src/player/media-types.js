/**
 * This file is responsible for storing all media types
 */
export default {
    AUDIO: 'audio',
    VIDEO: 'video'
};



// WEBPACK FOOTER //
// ./src/player/media-types.js