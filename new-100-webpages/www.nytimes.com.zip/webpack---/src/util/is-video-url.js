export default function isVideoUrl(url = '') {
    return /\.mp4$/.test(url);
}



// WEBPACK FOOTER //
// ./src/util/is-video-url.js