const getNavigator = (win = window) => win.navigator;

export default getNavigator;



// WEBPACK FOOTER //
// ./src/util/get-navigator.js