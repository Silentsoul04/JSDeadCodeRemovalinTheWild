import getScriptNative from './get-script-native';

const getScript = config => {
    getScriptNative(config);
};

export default getScript;



// WEBPACK FOOTER //
// ./src/util/get-script.js