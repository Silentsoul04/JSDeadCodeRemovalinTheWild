const getReferrer = () => document.referrer;

export default getReferrer;



// WEBPACK FOOTER //
// ./src/util/get-referrer.js