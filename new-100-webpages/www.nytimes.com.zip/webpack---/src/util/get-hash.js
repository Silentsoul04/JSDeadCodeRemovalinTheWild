const getHash = () => window.location.hash;

export default getHash;



// WEBPACK FOOTER //
// ./src/util/get-hash.js