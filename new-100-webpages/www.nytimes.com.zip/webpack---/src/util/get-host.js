export default (win = window) => win.location.host;



// WEBPACK FOOTER //
// ./src/util/get-host.js