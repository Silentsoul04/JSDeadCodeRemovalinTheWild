const getCurrentURL = () => window.location.href;

export default getCurrentURL;



// WEBPACK FOOTER //
// ./src/util/get-current-url.js