const getDocument = () => document;

export default getDocument;



// WEBPACK FOOTER //
// ./src/util/get-document.js