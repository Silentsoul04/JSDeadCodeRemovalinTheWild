const getWindow = () => window;

export default getWindow;



// WEBPACK FOOTER //
// ./src/util/get-window.js