const types = {
    INIT: 'plugins/sharetools/INIT'
};

export default {
    init: () => ({
        type: types.INIT
    })
};

export {
    types
};



// WEBPACK FOOTER //
// ./src/plugins/sharetools/actions.js