import preact from 'preact'; // eslint-disable-line no-unused-vars
import styles from '../styles.css';

const Spinner = () => ( <
    div className = {
        styles.spinner
    } >
    <
    span / >
    <
    /div>
);

export default Spinner;



// WEBPACK FOOTER //
// ./src/plugins/audio-controls/component/spinner/index.js