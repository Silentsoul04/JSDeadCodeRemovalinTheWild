(function() {
    window['optimizely'] = window['optimizely'] || [];
    window['optimizely'].push(['activateGeoDelayedExperiments', {
        'location': {
            'city': "AMSTERDAM",
            'continent': "EU",
            'country': "NL",
            'region': ""
        },
        'ip': "80.113.225.15"
    }]);
})
//
()

;