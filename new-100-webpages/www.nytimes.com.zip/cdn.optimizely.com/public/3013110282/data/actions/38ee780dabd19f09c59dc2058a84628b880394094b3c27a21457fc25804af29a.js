window.optimizely.push({
    type: "load",
    data: {
        changes: [{
            "name": "Killset",
            "config": {
                "selected_asset": "vi_welcome"
            },
            "id": "4D2B8306-DE9D-424E-B8C2-F450F0046A17",
            "dependencies": [],
            "type": "widget",
            "widget_id": "10620201952"
        }]
    }
});