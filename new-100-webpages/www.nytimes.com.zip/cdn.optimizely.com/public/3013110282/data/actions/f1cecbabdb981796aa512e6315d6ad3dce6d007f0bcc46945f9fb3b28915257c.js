window.optimizely.push({
    type: "load",
    data: {
        changes: [{
            "name": "Bar1",
            "config": {
                "mobile_url": "",
                "subscribe_url": "https://www.nytimes.com/subscription?campaignId=797YR",
                "button_label": "Subscribe Now"
            },
            "id": "CA2C3821-83D9-46AA-8DF5-6937E4727769",
            "dependencies": [],
            "type": "widget",
            "widget_id": "10649375220"
        }]
    }
});