//show-ads.js
window.adBlockDetected = false;