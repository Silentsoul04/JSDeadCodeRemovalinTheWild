(window.webpackJsonp = window.webpackJsonp || []).push([
    [4], {
        "+ZLY": function(e, t, a) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.fourthBarParentCollapsedClass = t.fourthBarCollapsedClass = t.thirdBarParentCollapsedClass = t.thirdBarCollapsedClass = t.secondBarParentCollapsedClass = t.secondBarCollapsedClass = t.firstBarParentCollapsedClass = t.firstBarCollapsedClass = t.fourthBarParentClass = t.fourthBarClass = t.thirdBarParentClass = t.thirdBarClass = t.secondBarParentClass = t.secondBarClass = t.firstBarParentClass = t.firstBarClass = void 0;
            var r = a("UmXO"),
                l = (0, r.keyframes)("0%{transform:translate(0px,0px) scale(1,1) translate(0px,0px);}25%{transform:translate(0px,0px) scale(1,0.95) translate(0px,0px);}50%{transform:translate(0px,0px) scale(1,0.9) translate(0px,0px);}75%{transform:translate(0px,0px) scale(1,0.95) translate(0px,0px);}100%{transform:translate(0px,0px) scale(1,1) translate(0px,0px);}"),
                n = (0, r.keyframes)("0%{transform:translate(0px,0px) translate(0px,0px) translate(0px,0px);}25%{transform:translate(0px,0px) translate(0px,0px) translate(0px,5px);}50%{transform:translate(0px,0px) translate(0px,0px) translate(0px,10px);}75%{transform:translate(0px,0px) translate(0px,0px) translate(0px,5px);}100%{transform:translate(0px,0px) translate(0px,0px) translate(0px,0px);}"),
                s = (0, r.keyframes)("0%{transform:translate(11.329999923706055px,0px) scale(1,0.95) translate(-11.329999923706055px,0px);}25%{transform:translate(11.329999923706055px,0px) scale(1,1) translate(-11.329999923706055px,0px);}50%{transform:translate(11.329999923706055px,0px) scale(1,0.95) translate(-11.329999923706055px,0px);}75%{transform:translate(11.329999923706055px,0px) scale(1,0.9) translate(-11.329999923706055px,0px);}100%{transform:translate(11.329999923706055px,0px) scale(1,0.95) translate(-11.329999923706055px,0px);}"),
                i = (0, r.keyframes)("0%{transform:translate(11.329999923706055px,0px) translate(-11.329999923706055px,0px) translate(0px,5px);}25%{transform:translate(11.329999923706055px,0px) translate(-11.329999923706055px,0px) translate(0px,0px);}50%{transform:translate(11.329999923706055px,0px) translate(-11.329999923706055px,0px) translate(0px,5px);}75%{transform:translate(11.329999923706055px,0px) translate(-11.329999923706055px,0px) translate(0px,10px);}100%{transform:translate(11.329999923706055px,0px) translate(-11.329999923706055px,0px) translate(0px,5px);}"),
                o = (0, r.keyframes)("0%{transform:translate(22.670000076293945px,0px) scale(1,0.9) translate(-22.670000076293945px,0px);}25%{transform:translate(22.670000076293945px,0px) scale(1,0.95) translate(-22.670000076293945px,0px);}50%{transform:translate(22.670000076293945px,0px) scale(1,1) translate(-22.670000076293945px,0px);}75%{transform:translate(22.670000076293945px,0px) scale(1,0.95) translate(-22.670000076293945px,0px);}100%{transform:translate(22.670000076293945px,0px) scale(1,0.9) translate(-22.670000076293945px,0px);}"),
                d = (0, r.keyframes)("0%{transform:translate(22.670000076293945px,0px) translate(-22.670000076293945px,0px) translate(0px,10px);}25%{transform:translate(22.670000076293945px,0px) translate(-22.670000076293945px,0px) translate(0px,5px);}50%{transform:translate(22.670000076293945px,0px) translate(-22.670000076293945px,0px) translate(0px,0px);}75%{transform:translate(22.670000076293945px,0px) translate(-22.670000076293945px,0px) translate(0px,5px);}100%{transform:translate(22.670000076293945px,0px) translate(-22.670000076293945px,0px) translate(0px,10px);}"),
                p = (0, r.keyframes)("0%{transform:translate(34px,0px) translate(-34px,0px) translate(0px,5px);}25%{transform:translate(34px,0px) translate(-34px,0px) translate(0px,10px);}50%{transform:translate(34px,0px) translate(-34px,0px) translate(0px,5px);}75%{transform:translate(34px,0px) translate(-34px,0px) translate(0px,0px);}100%{transform:translate(34px,0px) translate(-34px,0px) translate(0px,5px);}"),
                u = (0, r.keyframes)("0%{transform:translate(34px,0px) scale(1,0.95) translate(-34px,0px);}25%{transform:translate(34px,0px) scale(1,0.9) translate(-34px,0px);}50%{transform:translate(34px,0px) scale(1,0.95) translate(-34px,0px);}75%{transform:translate(34px,0px) scale(1,1) translate(-34px,0px);}100%{transform:translate(34px,0px) scale(1,0.95) translate(-34px,0px);}"),
                c = (0, r.keyframes)("0%{transform:translate(0px,0px) scale(1,0.85) translate(0px,0px);}33.33%{transform:translate(0px,0px) scale(1,0.9) translate(0px,0px);}100%{transform:translate(0px,0px) scale(1,0.1) translate(0px,0px);}"),
                f = (0, r.keyframes)("0%{transform:translate(0px,0px) translate(0px,0px) translate(0px,15px);}33.33%{transform:translate(0px,0px) translate(0px,0px) translate(0px,10px);}100%{transform:translate(0px,0px) translate(0px,0px) translate(0px,30px);}"),
                m = (0, r.keyframes)("0%{transform:translate(11.329999923706055px,0px) scale(1,0.85) translate(-11.329999923706055px,0px);}33.33%{transform:translate(11.329999923706055px,0px) scale(1,0.9) translate(-11.329999923706055px,0px);}100%{transform:translate(11.329999923706055px,0px) scale(1,0.1) translate(-11.329999923706055px,0px);}"),
                x = (0, r.keyframes)("0%{transform:translate(11.329999923706055px,0px) translate(-11.329999923706055px,0px) translate(0px,15px);}33.33%{transform:translate(11.329999923706055px,0px) translate(-11.329999923706055px,0px) translate(0px,10px);}100%{transform:translate(11.329999923706055px,0px) translate(-11.329999923706055px,0px) translate(0px,30px);}"),
                h = (0, r.keyframes)("0%{transform:translate(22.670000076293945px,0px) scale(1,0.85) translate(-22.670000076293945px,0px);}33.33%{transform:translate(22.670000076293945px,0px) scale(1,0.9) translate(-22.670000076293945px,0px);}100%{transform:translate(22.670000076293945px,0px) scale(1,0.1) translate(-22.670000076293945px,0px);}"),
                g = (0, r.keyframes)("0%{transform:translate(22.670000076293945px,0px) translate(-22.670000076293945px,0px) translate(0px,15px);}33.33%{transform:translate(22.670000076293945px,0px) translate(-22.670000076293945px,0px) translate(0px,10px);}100%{transform:translate(22.670000076293945px,0px) translate(-22.670000076293945px,0px) translate(0px,30px);}"),
                v = (0, r.keyframes)("0%{transform:translate(34px,0px) translate(-34px,0px) translate(0px,15px);}33.33%{transform:translate(34px,0px) translate(-34px,0px) translate(0px,10px);}100%{transform:translate(34px,0px) translate(-34px,0px) translate(0px,30px);}"),
                y = (0, r.keyframes)("0%{transform:translate(34px,0px) scale(1,0.85) translate(-34px,0px);}33.33%{transform:translate(34px,0px) scale(1,0.9) translate(-34px,0px);}100%{transform:translate(34px,0px) scale(1,0.1) translate(-34px,0px);}"),
                b = (0, r.css)("animation:", l, " 0.8s cubic-bezier(0,0,1,1) infinite;");
            t.firstBarClass = b;
            var C = (0, r.css)("animation:", n, " 0.8s cubic-bezier(0,0,1,1) infinite;");
            t.firstBarParentClass = C;
            var _ = (0, r.css)("animation:", s, " 0.8s cubic-bezier(0,0,1,1) infinite;");
            t.secondBarClass = _;
            var M = (0, r.css)("animation:", i, " 0.8s cubic-bezier(0,0,1,1) infinite;");
            t.secondBarParentClass = M;
            var E = (0, r.css)("animation:", o, " 0.8s cubic-bezier(0,0,1,1) infinite;");
            t.thirdBarClass = E;
            var k = (0, r.css)("animation:", d, " 0.8s cubic-bezier(0,0,1,1) infinite;");
            t.thirdBarParentClass = k;
            var w = (0, r.css)("animation:", p, " 0.8s cubic-bezier(0,0,1,1) infinite;");
            t.fourthBarClass = w;
            var T = (0, r.css)("animation:", u, " 0.8s cubic-bezier(0,0,1,1) infinite;");
            t.fourthBarParentClass = T;
            var L = (0, r.css)("animation:", c, " 0.8s cubic-bezier(0,0,1,1) forwards;");
            t.firstBarCollapsedClass = L;
            var B = (0, r.css)("animation-fill-mode:forwards;animation:", f, " 0.8s cubic-bezier(0,0,1,1) forwards;");
            t.firstBarParentCollapsedClass = B;
            var P = (0, r.css)("animation-fill-mode:forwards;animation:", m, " 0.8s cubic-bezier(0,0,1,1) forwards;");
            t.secondBarCollapsedClass = P;
            var N = (0, r.css)("animation-fill-mode:forwards;animation:", x, " 0.8s cubic-bezier(0,0,1,1) forwards;");
            t.secondBarParentCollapsedClass = N;
            var Y = (0, r.css)("animation-fill-mode:forwards;animation:", h, " 0.8s cubic-bezier(0,0,1,1) forwards;");
            t.thirdBarCollapsedClass = Y;
            var D = (0, r.css)("animation-fill-mode:forwards;animation:", g, " 0.8s cubic-bezier(0,0,1,1) forwards;");
            t.thirdBarParentCollapsedClass = D;
            var O = (0, r.css)("animation-fill-mode:forwards;animation:", y, " 0.8s cubic-bezier(0,0,1,1) forwards;");
            t.fourthBarCollapsedClass = O;
            var S = (0, r.css)("animation-fill-mode:forwards;animation:", v, " 0.8s cubic-bezier(0,0,1,1) forwards;");
            t.fourthBarParentCollapsedClass = S
        },
        "+rYN": function(e, t, a) {
            "use strict";
            var r = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.dismissButtonClass = t.Document = t.Background = t.TranscriptContainer = void 0;
            var l = a("UmXO"),
                n = r(a("3NoI")),
                s = r(a("wXC7")),
                i = (0, n.default)("div", {
                    target: "e1drnplw0"
                })("position:fixed;z-index:", s.default.zIndex.overlay, ";top:0px;left:0px;right:0px;bottom:0px;display:flex;flex-direction:row;justify-content:center;opacity:", (function(e) {
                    return e.isVisible ? "1" : "0"
                }), ";transition:opacity 0.2s;pointer-events:", (function(e) {
                    return e.isVisible ? "all" : "none"
                }), ";@media print{position:static;}");
            t.TranscriptContainer = i;
            var o = (0, n.default)("div", {
                target: "e1drnplw1"
            })("position:absolute;top:0px;left:0px;bottom:0px;right:0px;background-color:rgba(0,0,0,0.8);z-index:1;@media print{background-color:white;}");
            t.Background = o;
            var d = (0, n.default)("div", {
                target: "e1drnplw2"
            })("position:absolute;top:0;bottom:0;background-color:", s.default.color.white, ";width:100%;overflow-y:scroll;-webkit-overflow-scrolling:touch;z-index:2;", s.default.breakpoint.small, "{max-width:calc(100% - 60px);width:1080px;}", s.default.breakpoint.medium, "{max-width:calc(100% - 100px);}", s.default.breakpoint.mediumLarge, "{max-width:930px;}", s.default.breakpoint.large, "{max-width:930px;}@media print{position:static;}");
            t.Document = d;
            var p = (0, l.css)("display:none;position:absolute;right:20px;top:20px;background-color:rgba(0,0,0,0);z-index:3;svg circle{transition:fill-opacity 0.2s;&:hover{fill-opacity:1;}}", s.default.breakpoint.large, "{display:block;}@media print{display:none;}");
            t.dismissButtonClass = p
        },
        "0bZC": function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = (l(a("17x9")), a("7FfI")),
                i = r(a("xXO4")),
                o = function(e) {
                    var t = e.episodeTitle,
                        a = e.hostedBy,
                        r = e.summary,
                        l = e.pubDate;
                    return n.default.createElement("div", {
                        className: i.episodeMetadataClass
                    }, n.default.createElement("p", {
                        className: i.kickerClass
                    }, "transcript"), t && n.default.createElement("h2", {
                        className: i.episodeTitleClass
                    }, t), a && n.default.createElement("h3", {
                        className: i.hostedByClass
                    }, a), r && n.default.createElement("h4", {
                        className: i.episodeSummaryClass
                    }, r), l && n.default.createElement("time", {
                        dateTime: l,
                        className: i.episodePubdateClass
                    }, (0, s.formatDate)(new Date(l).toISOString(), "dddd, MMMM Do, YYYY")))
                };
            o.displayName = "EpisodeMetadata", o.defaultProps = {
                episodeTitle: "",
                hostedBy: "",
                summary: "",
                pubDate: ""
            };
            var d = o;
            t.default = d
        },
        "64gi": function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = (l(a("17x9")), r(a("xXO4"))),
                i = function(e) {
                    var t = e.blocks,
                        a = !1,
                        r = [],
                        l = [];
                    return (null == t ? void 0 : t.length) ? (t.forEach((function(e) {
                        var t = n.default.createElement(n.default.Fragment, null, n.default.createElement("dt", {
                            className: s.speakerClass
                        }, e.speaker), n.default.createElement("dd", {
                            className: s.textClass
                        }, e.text));
                        e.isArchived ? (a || (a = !0), r.push(t)) : (a && r.length && (l.push(n.default.createElement("dl", {
                            className: s.archivedBlocks
                        }, r)), a = !1, r = []), l.push(t))
                    })), n.default.createElement("dl", {
                        className: s.transcriptBlocksClass
                    }, l.map((function(e, t) {
                        return n.default.cloneElement(e, {
                            key: t.toString()
                        })
                    })))) : null
                };
            i.displayName = "TranscriptBlocks", i.defaultProps = {
                blocks: []
            };
            var o = i;
            t.default = o
        },
        "7FfI": function(e, t, a) {
            "use strict";
            var r = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.formatDate = function(e, t) {
                var a, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "en",
                    l = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
                    u = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                    c = i(r);
                if (s.localesConfig[c]) {
                    var f = ["elapsed-year", "elapsed", "short-elapsed"];
                    if (f.indexOf(t) > -1) {
                        var m = t.replace(/\b[a-z]/g, (function(e) {
                                return e.toUpperCase()
                            })).replace("-", ""),
                            x = s.localesConfig[c]["relativeTime".concat(m)] || s.DEFAULT_RELATIVE_TIME;
                        s.localesConfig[c].relativeTime = x, n.default.relativeTimeThreshold("s", 59), n.default.relativeTimeThreshold("ss", 59), n.default.relativeTimeThreshold("m", 60), n.default.relativeTimeThreshold("h", 24)
                    }
                    n.default.locale(c, s.localesConfig[c]);
                    var h = (0, n.default)(e);
                    if (n.default.updateLocale(c, s.localesConfig[c]), h.locale(!1), f.indexOf(t) > -1) {
                        var g = "elapsed" === t || "short-elapsed" === t ? 12 : 24;
                        if (p("hours", g = "elapsed-year" === t && u ? 3 * g : g, e, (0, n.default)().toISOString())) return h.fromNow(l);
                        if ("short-elapsed" === t) {
                            var v = (0, n.default)().diff(h, "days");
                            return n.default.localeData().relativeTime(v, l, "dd")
                        }
                        var y = t;
                        t = l ? "ll" : "LL", "elapsed" === y && h.year() === (0, n.default)().year() && (t = l ? "L" : "l")
                    }
                    var b = "MMM D, YYYY" === t && s.localesConfig[c].longDateFormat.LL ? "LL" : t;
                    "MMM D, YYYY, h:mm a z" === t && s.localesConfig[c].longDateFormat.LLLL && (b = "LLLL"), a = h.tz("America/New_York").format(b)
                } else a = (0, n.default)(e).tz("America/New_York").format(t);
                if ("zh-cn" === c) return d(a);
                return o(a)
            }, Object.defineProperty(t, "NYT_MONTHS", {
                enumerable: !0,
                get: function() {
                    return s.NYT_MONTHS
                }
            }), Object.defineProperty(t, "FULL_MONTHS", {
                enumerable: !0,
                get: function() {
                    return s.FULL_MONTHS
                }
            }), Object.defineProperty(t, "ABBREVIATED_MONTHS", {
                enumerable: !0,
                get: function() {
                    return s.ABBREVIATED_MONTHS
                }
            }), Object.defineProperty(t, "FULL_DAYS", {
                enumerable: !0,
                get: function() {
                    return s.FULL_DAYS
                }
            }), t.getISOFromString = t.isSame = t.isAfterISO = t.isISOToday = t.getElapsedMinutes = t.getISOFromUnix = t.getUnixFromISO = t.getFullDate = t.getDisplayDate = t.parseISODate = t.timeDiff = t.getTimestampLocale = void 0;
            var l = r(a("J4zp")),
                n = r(a("wd/R")),
                s = (a("f0Wu"), a("Y6Mw"));
            n.default.updateLocale("en", {
                monthsShort: s.ABBREVIATED_MONTHS
            });
            var i = function() {
                var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "en",
                    a = (null == (e = t) ? void 0 : e.split("-")) || "en",
                    r = (0, l.default)(a, 1),
                    n = {
                        en: "en",
                        es: "es",
                        zh: "zh-cn"
                    };
                return (t = r[0]) && n[t] ? n[t] : "en"
            };
            t.getTimestampLocale = i;
            var o = function(e) {
                    return e.replace(/am/i, "a.m.").replace(/pm/i, "p.m.").replace(/EST/, "ET").replace(/EDT/, "ET")
                },
                d = function(e) {
                    return e.replace(/EST/, "美国东部时间").replace(/EDT/, "美国东部时间")
                },
                p = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "hours",
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 24,
                        a = arguments.length > 2 ? arguments[2] : void 0,
                        r = arguments.length > 3 ? arguments[3] : void 0,
                        l = (0, n.default)(a),
                        s = (0, n.default)(r);
                    return Math.abs(s.diff(l, e)) < t
                };
            t.timeDiff = p;
            var u = /^([0-9]{4})-([0-1][0-9])-([0-3][0-9])T([0-2][0-9]):([0-5][0-9]):([0-5][0-9])\./,
                c = function(e) {
                    if (!e) return null;
                    var t = e.substring(e.length - 3);
                    if ("EDT" === t || "EST" === t) {
                        if (!u.exec(e)) return null;
                        var a = "EDT" === t ? 4 : 5,
                            r = u.exec(e),
                            s = (0, l.default)(r, 7),
                            i = s[0],
                            o = s[1],
                            d = s[2],
                            p = s[3],
                            c = s[4],
                            f = s[5],
                            m = s[6];
                        return {
                            full: i,
                            year: o,
                            month: d,
                            day: p,
                            hours: c,
                            minutes: f,
                            seconds: m,
                            unix: n.default.utc([parseInt(o, 10), parseInt(d, 10) - 1, parseInt(p, 10), parseInt(c, 10) - 1, parseInt(f, 10) - 1, parseInt(m, 10) - 1, 0]).add(a, "hours").unix()
                        }
                    }
                    var x = (0, n.default)(e).tz("America/New_York");
                    return {
                        full: e,
                        year: x.year(),
                        month: x.month() + 1 < 10 ? "0".concat(x.month() + 1) : x.month() + 1,
                        day: x.date() < 10 ? "0".concat(x.date()) : x.date(),
                        hours: x.hour() < 10 ? "0".concat(x.hour()) : x.hour(),
                        minutes: x.minute() < 10 ? "0".concat(x.minute()) : x.minute(),
                        seconds: x.second() < 10 ? "0".concat(x.second()) : x.second(),
                        unix: x.unix(),
                        dayOfWeek: x.day()
                    }
                };
            t.parseISODate = c;
            t.getDisplayDate = function(e) {
                var t = c(e);
                return t ? "".concat(s.ABBREVIATED_MONTHS[parseInt(t.month, 10) - 1], " ").concat(parseInt(t.day, 10), ", ").concat(t.year) : null
            };
            t.getFullDate = function(e) {
                var t = c(e);
                return t ? "".concat(s.FULL_MONTHS[parseInt(t.month, 10) - 1], " ").concat(parseInt(t.day, 10), ", ").concat(t.year) : null
            };
            t.getUnixFromISO = function(e) {
                var t = c(e);
                return t ? t.unix : null
            };
            t.getISOFromUnix = function(e) {
                return e ? new Date(1e3 * e).toISOString() : null
            };
            t.getElapsedMinutes = function(e) {
                var t = ((new Date).getTime() - e.getTime()) / 1e3;
                return Math.floor(t / 60)
            };
            t.isISOToday = function(e) {
                var t = (0, n.default)().tz("America/New_York"),
                    a = (0, n.default)(e).tz("America/New_York");
                return t.isSame(a, "day")
            };
            t.isAfterISO = function(e, t) {
                return (0, n.default)(e).isAfter(t)
            };
            t.isSame = function(e, t) {
                return (0, n.default)(e).isSame(t)
            };
            t.getISOFromString = function(e) {
                return (0, n.default)(e).toISOString()
            }
        },
        "9jcr": function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = r(a("+rYN"));
            t.default = function(e) {
                var t = e.onClick;
                return n.default.createElement("button", {
                    tabIndex: "100",
                    className: s.dismissButtonClass,
                    type: "button",
                    onClick: t,
                    "aria-label": "close"
                }, n.default.createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "60",
                    height: "60",
                    viewBox: "0 0 60 60",
                    fill: "none"
                }, n.default.createElement("circle", {
                    cx: "30",
                    cy: "30",
                    r: "30",
                    fill: "white",
                    fillOpacity: "0.9"
                }), n.default.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M38.4844 20.1006L39.8986 21.5148L21.5138 39.8996L20.0996 38.4854L38.4844 20.1006Z",
                    fill: "black"
                }), n.default.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M21.5156 20.1006L20.1014 21.5148L38.4862 39.8996L39.9004 38.4854L21.5156 20.1006Z",
                    fill: "black"
                })))
            }
        },
        AmnM: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = r(a("+ZLY"));
            t.default = function() {
                return n.default.createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 40 36",
                    id: "el_0kpS9qL_S"
                }, n.default.createElement("title", null, "bars"), n.default.createElement("g", {
                    id: "el_oZ84Hna1GC_65hRV2Qwn",
                    className: s.fourthBarParentClass,
                    "data-animator-group": "true",
                    "data-animator-type": "0"
                }, n.default.createElement("g", {
                    id: "el_oZ84Hna1GC_ILVvi2tqx",
                    className: s.fourthBarClass,
                    "data-animator-group": "true",
                    "data-animator-type": "2"
                }, n.default.createElement("g", {
                    id: "el_oZ84Hna1GC"
                }, n.default.createElement("rect", {
                    x: "34",
                    width: "6",
                    height: "36",
                    id: "el_qw_T_tngXw"
                })))), n.default.createElement("g", {
                    id: "el_mYVjkduhMU_p_9Pm85Ac",
                    className: s.thirdBarParentClass,
                    "data-animator-group": "true",
                    "data-animator-type": "0"
                }, n.default.createElement("g", {
                    id: "el_mYVjkduhMU_WxG3R40yd",
                    className: s.thirdBarClass,
                    "data-animator-group": "true",
                    "data-animator-type": "2"
                }, n.default.createElement("g", {
                    id: "el_mYVjkduhMU"
                }, n.default.createElement("rect", {
                    x: "22.67",
                    width: "6",
                    height: "36",
                    id: "el_lf9GrROk6j"
                })))), n.default.createElement("g", {
                    id: "el_o-EuxhgoAw_kYNRGDfcw",
                    className: s.secondBarParentClass,
                    "data-animator-group": "true",
                    "data-animator-type": "0"
                }, n.default.createElement("g", {
                    id: "el_o-EuxhgoAw_3c3bzSjOJ",
                    className: s.secondBarClass,
                    "data-animator-group": "true",
                    "data-animator-type": "2"
                }, n.default.createElement("g", {
                    id: "el_o-EuxhgoAw"
                }, n.default.createElement("rect", {
                    x: "11.33",
                    width: "6",
                    height: "36",
                    id: "el_-iueO8klO0"
                })))), n.default.createElement("g", {
                    id: "el_F7mSMPhqpC_y_fKcpSxn",
                    className: s.firstBarParentClass,
                    "data-animator-group": "true",
                    "data-animator-type": "0"
                }, n.default.createElement("g", {
                    id: "el_F7mSMPhqpC_R6bNB6_Ys",
                    className: s.firstBarClass,
                    "data-animator-group": "true",
                    "data-animator-type": "2"
                }, n.default.createElement("g", {
                    id: "el_F7mSMPhqpC"
                }, n.default.createElement("rect", {
                    width: "6",
                    height: "36",
                    id: "el_dS5TKNZZ5w"
                })))))
            }
        },
        "Bf1/": function(e, t, a) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.balanceText = t.textElementHasMultipleWords = t.squeezeContainer = t.findMiddle = void 0;
            var r = function(e, t) {
                return e + (t - e) / 2
            };
            t.findMiddle = r;
            var l = function e(t, a, l, n) {
                if (n <= 0) t.style.maxWidth = "";
                else {
                    var s = r(l, n);
                    t.style.maxWidth = "".concat(s, "px");
                    var i = t.getBoundingClientRect().height;
                    l >= n ? t.style.maxWidth = "".concat(n, "px") : i > a ? e(t, a, s + 1, n) : e(t, a, l + 1, s)
                }
            };
            t.squeezeContainer = l;
            var n = function(e) {
                return e.textContent.split(" ").length > 1
            };
            t.textElementHasMultipleWords = n;
            var s = function(e) {
                var t, a = e.getBoundingClientRect(),
                    r = a.height,
                    n = a.width,
                    s = e.parentNode.querySelector(".balancedHeadline");
                s && "ghost" === e.className ? (t = s).innerHTML = e.innerHTML : ((t = e.cloneNode(!0)).style.display = "inline-block", t.className = "balancedHeadline", e.parentNode.appendChild(t), e.className = "ghost", e.setAttribute("aria-hidden", "true"), e.style.position = "absolute", e.style.left = "0", e.style.visibility = "hidden"), t.style.maxWidth = "", l(t, r, 0, n)
            };
            t.balanceText = s;
            var i = function(e) {
                e && n(e) && s(e)
            };
            t.default = i
        },
        "FOj+": function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("lwsE")),
                s = l(a("W8MJ")),
                i = l(a("a1gu")),
                o = l(a("Nsbk")),
                d = l(a("7W2i")),
                p = r(a("q1tI")),
                u = (l(a("17x9")), l(a("9/5/"))),
                c = l(a("Bf1/")),
                f = function(e) {
                    function t() {
                        var e, a;
                        (0, n.default)(this, t);
                        for (var r = arguments.length, l = new Array(r), s = 0; s < r; s++) l[s] = arguments[s];
                        return (a = (0, i.default)(this, (e = (0, o.default)(t)).call.apply(e, [this].concat(l)))).rebalanceText = (0, u.default)((function() {
                            (0, c.default)(a.text)
                        }), 300), a
                    }
                    return (0, d.default)(t, e), (0, s.default)(t, [{
                        key: "componentDidMount",
                        value: function() {
                            window.addEventListener("resize", this.rebalanceText)
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            (0, c.default)(this.text)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            window.removeEventListener("resize", this.rebalanceText)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return p.default.createElement("span", {
                                ref: function(t) {
                                    e.text = t
                                }
                            }, this.props.children)
                        }
                    }]), t
                }(p.Component);
            f.displayName = "TextBalancer", f.defaultProps = {
                children: null
            };
            var m = f;
            t.default = m
        },
        H0lQ: function(e, t, a) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = function(e) {
                var t = Math.ceil(e / 1e3 % 60) || 0,
                    a = Math.floor(e / 6e4 % 60) || 0,
                    r = Math.floor(e / 36e5 % 24) || 0;
                return r = r < 10 && r > 0 ? "0".concat(r) : r, a = a < 10 && r > 0 ? "0".concat(a) : a, t = t < 10 ? "0".concat(t) : t, "".concat(r > 0 ? "".concat(r, ":") : "").concat(a, ":").concat(t)
            };
            t.default = r
        },
        OXmc: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = l(a("WUXL")),
                i = l(a("xCAf")),
                o = l(a("9jcr")),
                d = r(a("+rYN")),
                p = function(e) {
                    return n.default.createElement(d.TranscriptContainer, {
                        isVisible: e.isVisible
                    }, n.default.createElement(o.default, {
                        onClick: e.hideTranscript
                    }), n.default.createElement(d.Background, {
                        isVisible: e.isVisible,
                        onClick: e.hideTranscript
                    }), n.default.createElement(d.Document, {
                        isVisible: e.isVisible
                    }, n.default.createElement("div", {
                        "aria-labelledby": "modal-title",
                        role: "region"
                    }, n.default.createElement(s.default, e), n.default.createElement(i.default, e))))
                };
            p.displayName = "Transcript";
            var u = p;
            t.default = u
        },
        RqMI: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = r(a("+ZLY"));
            t.default = function() {
                return n.default.createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 40 36",
                    id: "el_0kpS9qL_S"
                }, n.default.createElement("title", null, "bars"), n.default.createElement("g", {
                    id: "el_oZ84Hna1GC_65hRV2Qwn",
                    className: s.fourthBarParentCollapsedClass,
                    "data-animator-group": "true",
                    "data-animator-type": "0"
                }, n.default.createElement("g", {
                    id: "el_oZ84Hna1GC_ILVvi2tqx",
                    className: s.fourthBarCollapsedClass,
                    "ata-animator-group": "true",
                    "data-animator-type": "2"
                }, n.default.createElement("g", {
                    id: "el_oZ84Hna1GC"
                }, n.default.createElement("rect", {
                    x: "34",
                    width: "6",
                    height: "36",
                    id: "el_qw_T_tngXw"
                })))), n.default.createElement("g", {
                    id: "el_mYVjkduhMU_p_9Pm85Ac",
                    className: s.thirdBarParentCollapsedClass,
                    "data-animator-group": "true",
                    "data-animator-type": "0"
                }, n.default.createElement("g", {
                    id: "el_mYVjkduhMU_WxG3R40yd",
                    className: s.thirdBarCollapsedClass,
                    "data-animator-group": "true",
                    "data-animator-type": "2"
                }, n.default.createElement("g", {
                    id: "el_mYVjkduhMU"
                }, n.default.createElement("rect", {
                    x: "22.67",
                    width: "6",
                    height: "36",
                    id: "el_lf9GrROk6j"
                })))), n.default.createElement("g", {
                    id: "el_o-EuxhgoAw_kYNRGDfcw",
                    className: s.secondBarParentCollapsedClass,
                    "data-animator-group": "true",
                    "data-animator-type": "0"
                }, n.default.createElement("g", {
                    id: "el_o-EuxhgoAw_3c3bzSjOJ",
                    className: s.secondBarCollapsedClass,
                    "ata-animator-group": "true",
                    "data-animator-type": "2"
                }, n.default.createElement("g", {
                    id: "el_o-EuxhgoAw"
                }, n.default.createElement("rect", {
                    x: "11.33",
                    width: "6",
                    height: "36",
                    id: "el_-iueO8klO0"
                })))), n.default.createElement("g", {
                    id: "el_F7mSMPhqpC_y_fKcpSxn",
                    className: s.firstBarParentCollapsedClass,
                    "data-animator-group": "true",
                    "data-animator-type": "0"
                }, n.default.createElement("g", {
                    id: "el_F7mSMPhqpC_R6bNB6_Ys",
                    className: s.firstBarCollapsedClass,
                    "ata-animator-group": "true",
                    "data-animator-type": "2"
                }, n.default.createElement("g", {
                    id: "el_F7mSMPhqpC"
                }, n.default.createElement("rect", {
                    width: "6",
                    height: "36",
                    id: "el_dS5TKNZZ5w"
                })))))
            }
        },
        UMeL: function(e, t, a) {
            "use strict";
            var r = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.mobileDurationClass = t.desktopDurationClass = t.playbackAnimationClass = t.playPauseClass = t.playbackControlsClass = t.fileControlsClass = t.controlsClass = t.leftArrowClass = t.kickerClass = t.backToClass = t.transcriptHeaderClass = void 0;
            var l = a("UmXO"),
                n = r(a("wXC7")),
                s = (0, l.css)("display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;font-family:", n.default.font.franklin, ";font-weight:", n.default.font.weight.mediumBold, ";color:#333;padding:0 20px;height:50px;*{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility;-webkit-touch-callout:none;}", n.default.breakpoint.medium, "{padding:0 50px;height:42px;}", n.default.breakpoint.mediumLarge, "{padding:0 74px 0 112px;}");
            t.transcriptHeaderClass = s;
            var i = (0, l.css)("background-color:rgba(0,0,0,0);font-family:", n.default.font.franklin, ";font-size:14px;font-weight:", n.default.font.weight.medium, ";display:flex;align-items:center;transition:opacity 0.2s;height:15px;&:hover{opacity:0.6;}", n.default.breakpoint.large, "{display:none;}span{margin-top:1px;}");
            t.backToClass = i;
            var o = (0, l.css)("display:none;font-size:13px;letter-spacing:0.04em;text-transform:uppercase;font-weight:", n.default.font.weight.bold, ";", n.default.breakpoint.large, "{display:block;}");
            t.kickerClass = o;
            var d = (0, l.css)("width:9px;height:9px;margin-right:5px;transform:rotate(45deg);border-left:1px solid #333;border-bottom:1px solid #333;");
            t.leftArrowClass = d;
            var p = (0, l.css)("display:flex;flex-direction:row;font-size:12px;align-items:center;");
            t.controlsClass = p;
            var u = (0, l.css)("flex-direction:row;align-items:baseline;justify-content:space-between;width:55px;margin-right:40px;display:none;", n.default.breakpoint.large, "{display:flex;}");
            t.fileControlsClass = u;
            var c = (0, l.css)("display:flex;flex-direction:row;align-items:center;justify-content:space-between;");
            t.playbackControlsClass = c;
            var f = (0, l.css)("display:flex;justify-content:center;align-items:center;background-color:rgba(0,0,0,0);margin-right:10px;transition:opacity 0.2s;width:22px;height:22px;transform:scale(1.3);&:hover{opacity:0.6;}", n.default.breakpoint.medium, "{transform:none;}");
            t.playPauseClass = f;
            var m = (0, l.css)("height:14px;width:14px;margin-right:10px;");
            t.playbackAnimationClass = m;
            var x = (0, l.css)("display:none;", n.default.breakpoint.small, "{display:block;}");
            t.desktopDurationClass = x;
            var h = (0, l.css)("display:block;", n.default.breakpoint.small, "{display:none;}");
            t.mobileDurationClass = h
        },
        WCQj: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = a("UmXO"),
                i = r(a("UMeL")),
                o = l(a("AmnM")),
                d = l(a("RqMI"));
            t.default = function(e) {
                var t = e.isPlaying;
                return n.default.createElement("div", {
                    className: (0, s.cx)(i.playbackAnimationClass)
                }, t && n.default.createElement(o.default, null) || n.default.createElement(d.default, null))
            }
        },
        WUXL: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = (l(a("17x9")), r(a("UMeL"))),
                i = l(a("giFd")),
                o = l(a("ZssJ")),
                d = function(e) {
                    var t = e.podcastName,
                        a = e.onPlayPause,
                        r = e.playerRef,
                        l = e.hideTranscript,
                        d = e.isPlaying,
                        p = e.audioDuration,
                        u = e.currentTime,
                        c = e.isVisible;
                    return n.default.createElement("header", {
                        className: s.transcriptHeaderClass
                    }, n.default.createElement("div", {
                        className: s.kickerClass,
                        id: "modal-title"
                    }, "transcript"), n.default.createElement(i.default, {
                        podcastName: t,
                        hideTranscript: l
                    }), n.default.createElement(o.default, {
                        playerRef: r,
                        isPlaying: d,
                        onPlayPause: a,
                        audioDuration: p,
                        currentTime: u,
                        isVisible: c
                    }))
                };
            d.displayName = "TranscriptHeader", d.defaultProps = {
                podcastName: "",
                onPlayPause: null,
                playerRef: null,
                hideTranscript: null,
                isPlaying: !1,
                audioDuration: null,
                currentTime: null
            };
            var p = d;
            t.default = p
        },
        Y6Mw: function(e, t, a) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.localesConfig = t.DEFAULT_RELATIVE_TIME = t.FULL_DAYS = t.ABBREVIATED_MONTHS = t.FULL_MONTHS = t.NYT_MONTHS = void 0;
            t.NYT_MONTHS = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
            t.FULL_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            var r = ["Jan.", "Feb.", "March", "April", "May", "June", "July", "Aug.", "Sept.", "Oct.", "Nov.", "Dec."];
            t.ABBREVIATED_MONTHS = r;
            t.FULL_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            var l = {
                future: "%s",
                past: "%s",
                s: function(e, t) {
                    return t ? null : "just now"
                },
                ss: function(e, t) {
                    return t ? null : "just now"
                },
                m: function(e, t) {
                    return "".concat(e, t ? " minute ago" : "m ago")
                },
                mm: function(e, t) {
                    return t ? "".concat(e, " ").concat(1 === e ? "minute" : "minutes", " ago") : "".concat(e, "m ago")
                },
                h: function(e, t) {
                    return t ? "1 hour ago" : "1h ago"
                },
                hh: function(e, t) {
                    return "".concat(e, t ? " hours ago" : "h ago")
                },
                d: "%dd ago",
                dd: "%dd ago"
            };
            t.DEFAULT_RELATIVE_TIME = l;
            var n = {
                monthsShort: r,
                en: {
                    relativeTimeElapsed: l,
                    relativeTimeElapsedYear: {
                        future: "%s",
                        past: "%s",
                        s: "%ds ago",
                        ss: "%ds ago",
                        m: "%dm ago",
                        mm: "%dm ago",
                        h: "%dh ago",
                        hh: "%dh ago",
                        d: "%dd ago",
                        dd: "%dd ago"
                    },
                    relativeTimeShortElapsed: {
                        future: "%s",
                        past: "%s",
                        s: "%ds",
                        ss: "%ds",
                        m: "%dm",
                        mm: "%dm",
                        h: "%dh",
                        hh: "%dh",
                        d: "%dd",
                        dd: "%dd"
                    },
                    longDateFormat: {
                        l: "MMM D",
                        L: "MMMM D",
                        LL: "MMM D, YYYY",
                        ll: "MMMM D, YYYY",
                        LLL: "dddd, MMMM D, YYYY",
                        LLLL: "MMM D, YYYY, h:mm a z",
                        llll: "h:mm a z"
                    }
                },
                es: {
                    months: "enero_febrero_marzo_abril_mayo_junio_julio_agosto_septiembre_octubre_noviembre_diciembre".split("_"),
                    monthsShort: "en._febr._mzo._abr._mayo_jun._jul._ag._sept._oct._nov._dic.".split("_"),
                    weekdays: function(e, t) {
                        var a = "domingo_lunes_martes_miércoles_jueves_viernes_sábad".split("_"),
                            r = a[e.day()];
                        return e.localeData().longDateFormat("LLL") === t && (r = r.charAt(0).toUpperCase() + r.slice(1)), r
                    },
                    relativeTimeElapsed: {
                        future: "%s",
                        past: "%s",
                        s: function(e, t) {
                            return t ? null : "justo ahora"
                        },
                        ss: function(e, t) {
                            return t ? null : "justo ahora"
                        },
                        m: function(e, t) {
                            return "Hace ".concat(e, t ? " minuto" : " m")
                        },
                        mm: function(e, t) {
                            return t ? "Hace ".concat(e, " ").concat(1 === e ? "minuto" : "minutos") : "Hace ".concat(e, " m")
                        },
                        h: function(e, t) {
                            return "Hace ".concat(e, t ? " hora" : " h")
                        },
                        hh: function(e, t) {
                            return "Hace ".concat(e, t ? " horas" : " h")
                        },
                        d: "Hace %d d",
                        dd: "Hace %d d"
                    },
                    relativeTimeElapsedYear: {
                        future: "%s",
                        past: "%s",
                        s: "Hace %d s",
                        ss: "Hace %d s",
                        m: "Hace %d m",
                        mm: "Hace %d m",
                        h: "Hace %d h",
                        hh: "Hace %d h",
                        d: "Hace %d d",
                        dd: "Hace %d d"
                    },
                    relativeTimeShortElapsed: {
                        future: "%s",
                        past: "%s",
                        s: "%d s",
                        ss: "%d s",
                        m: "%d m",
                        mm: "%d m",
                        h: "%d h",
                        hh: "%d h",
                        d: "%d d",
                        dd: "%d d"
                    },
                    longDateFormat: {
                        l: "D [de] MMMM",
                        L: "D [de] MMMM",
                        LL: "D [de] MMMM [de] YYYY",
                        ll: "D [de] MMMM [de] YYYY",
                        LLL: "dddd, D [de] MMMM [de] YYYY",
                        LLLL: "D [de] MMMM [de] YYYY [a las] HH:mm z",
                        llll: "HH:mm z"
                    }
                },
                "zh-cn": {
                    months: "一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月".split("_"),
                    weekdays: "星期天_星期一_星期二_星期三_星期四_星期五_星期六".split("_"),
                    relativeTimeElapsed: {
                        future: "%s",
                        past: "%s",
                        s: function(e, t) {
                            return t ? null : "刚刚"
                        },
                        ss: function(e, t) {
                            return t ? null : "刚刚"
                        },
                        m: "%d分钟前",
                        mm: "%d分钟前",
                        h: "%d小时前",
                        hh: "%d小时前",
                        d: "%d天前",
                        dd: "%d天前"
                    },
                    relativeTimeElapsedYear: {
                        future: "%s",
                        past: "%s",
                        s: "%d秒前",
                        ss: "%d秒前",
                        m: "%d分钟前",
                        mm: "%d分钟前",
                        h: "%d小时前",
                        hh: "%d小时前",
                        d: "%d天前",
                        dd: "%d天前"
                    },
                    relativeTimeShortElapsed: {
                        future: "%s",
                        past: "%s",
                        s: "%d秒",
                        ss: "%d秒",
                        m: "%d分钟",
                        mm: "%d分钟",
                        h: "%d小时",
                        hh: "%d小时",
                        d: "%d天",
                        dd: "%d天"
                    },
                    longDateFormat: {
                        l: "M月D日",
                        L: "M月D日",
                        LL: "YYYY年M月D日",
                        ll: "YYYY年M月D日",
                        LLL: "YYYY年M月D日 dddd",
                        LLLL: "YYYY年M月D日，HH:mm z",
                        llll: "HH:mm z"
                    }
                }
            };
            t.localesConfig = n
        },
        ZssJ: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = l(a("h3Sg")),
                i = l(a("hXGK")),
                o = l(a("WCQj")),
                d = r(a("UMeL"));
            t.default = function(e) {
                var t = e.playerRef,
                    a = e.isPlaying,
                    r = e.onPlayPause,
                    l = e.audioDuration,
                    p = e.currentTime,
                    u = e.isVisible;
                return n.default.createElement("div", {
                    className: d.controlsClass
                }, n.default.createElement("div", {
                    className: d.playbackControlsClass
                }, n.default.createElement(s.default, {
                    playerRef: t,
                    isPlaying: a,
                    isVisible: u,
                    onPlayPause: r
                }), n.default.createElement(o.default, {
                    isPlaying: a,
                    playerRef: t
                }), n.default.createElement(i.default, {
                    playerRef: t,
                    audioDuration: l,
                    currentTime: p
                })))
            }
        },
        cFZn: function(e, t, a) {
            "use strict";
            var r = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = null,
                    a = null,
                    r = [];
                (null == e ? void 0 : e.length) && (e.forEach((function(e) {
                    var n = e.speaker,
                        s = e.text,
                        i = (0, l.default)(s);
                    if (n !== t) {
                        a && r.push(a), t = n;
                        var o = n.match(/^[<|^](.+)[\^|>]$/);
                        a = {
                            isArchived: !!o,
                            speaker: o && o[1].toLowerCase() || n.toLowerCase(),
                            text: i
                        }
                    } else a.text = "".concat(a.text, " ").concat(i)
                })), r.push(a));
                return r
            };
            var l = r(a("pq3b"))
        },
        giFd: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = r(a("UMeL"));
            t.default = function(e) {
                var t = e.podcastName,
                    a = e.hideTranscript;
                return n.default.createElement("button", {
                    type: "button",
                    className: s.backToClass,
                    onClick: a
                }, n.default.createElement("div", {
                    className: s.leftArrowClass
                }), n.default.createElement("span", null, t && "Back to ".concat(t) || "TRANSCRIPT"))
            }
        },
        h3Sg: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("lwsE")),
                s = l(a("W8MJ")),
                i = l(a("a1gu")),
                o = l(a("Nsbk")),
                d = l(a("7W2i")),
                p = r(a("q1tI")),
                u = r(a("UMeL")),
                c = l(a("qsmR")),
                f = l(a("rnec")),
                m = function(e) {
                    function t() {
                        return (0, n.default)(this, t), (0, i.default)(this, (0, o.default)(t).apply(this, arguments))
                    }
                    return (0, d.default)(t, e), (0, s.default)(t, [{
                        key: "componentDidUpdate",
                        value: function(e) {
                            !e.isVisible && this.props.isVisible && this.playPauseButton && this.playPauseButton.focus()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return p.default.createElement("button", {
                                tabIndex: "99",
                                ref: function(t) {
                                    e.playPauseButton = t
                                },
                                type: "button",
                                className: u.playPauseClass,
                                onClick: this.props.onPlayPause,
                                "aria-label": this.props.isPlaying ? "pause" : "play"
                            }, this.props.isPlaying && p.default.createElement(f.default, null) || p.default.createElement(c.default, null))
                        }
                    }]), t
                }(p.Component);
            t.default = m, m.displayName = "PlayPause"
        },
        hXGK: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = l(a("H0lQ")),
                i = r(a("UMeL"));
            t.default = function(e) {
                e.playerRef;
                var t = e.currentTime,
                    a = e.audioDuration;
                return n.default.createElement("div", null, n.default.createElement("div", {
                    className: i.desktopDurationClass
                }, (0, s.default)(1e3 * t), "/", (0, s.default)(a)), n.default.createElement("div", {
                    className: i.mobileDurationClass
                }, "-", (0, s.default)(1e3 * (a / 1e3 - t))))
            }
        },
        pq3b: function(e, t, a) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return (e || "").replace(/"([\w,.?!)])/g, "“$1").replace(/"/g, "”").replace(/([^a-zA-Z\d]|^|\s+)'([\w,.?!)])/g, "$1‘$2").replace(/'/g, "’").replace(/(-{2})/g, "—")
            }
        },
        qsmR: function(e, t, a) {
            "use strict";
            var r = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var l = r(a("q1tI"));
            t.default = function() {
                return l.default.createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "20",
                    height: "20",
                    viewBox: "0 0 20 20",
                    fill: "none"
                }, l.default.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M8 13.7683V6L14.5 9.88415L8 13.7683Z",
                    fill: "#333333"
                }), l.default.createElement("circle", {
                    cx: "10",
                    cy: "10",
                    r: "9.25",
                    stroke: "#333333",
                    strokeWidth: "1.5"
                }))
            }
        },
        rnec: function(e, t, a) {
            "use strict";
            var r = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var l = r(a("q1tI"));
            t.default = function() {
                return l.default.createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "20",
                    height: "20",
                    viewBox: "0 0 20 20",
                    fill: "none"
                }, l.default.createElement("path", {
                    d: "M19.25 10C19.25 15.1086 15.1086 19.25 10 19.25C4.89137 19.25 0.75 15.1086 0.75 10C0.75 4.89137 4.89137 0.75 10 0.75C15.1086 0.75 19.25 4.89137 19.25 10Z",
                    stroke: "#333333",
                    strokeWidth: "1.5"
                }), l.default.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M11 5.66699H13.3333V14.3337H11V5.66699Z",
                    fill: "#333333"
                }), l.default.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M6.66797 5.66699H9.0013V14.3337H6.66797V5.66699Z",
                    fill: "#333333"
                }))
            }
        },
        xCAf: function(e, t, a) {
            "use strict";
            var r = a("284h"),
                l = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(a("q1tI")),
                s = (l(a("17x9")), r(a("xXO4"))),
                i = l(a("0bZC")),
                o = l(a("64gi")),
                d = l(a("cFZn")),
                p = function(e) {
                    var t = e.headline,
                        a = e.credits,
                        r = e.summary,
                        l = e.date,
                        p = e.transcript,
                        u = (0, d.default)(null == p ? void 0 : p.transcriptFragment);
                    return (null == u ? void 0 : u.length) ? n.default.createElement("div", {
                        className: s.transcriptBodyClass
                    }, n.default.createElement(i.default, {
                        episodeTitle: t,
                        hostedBy: a,
                        summary: r,
                        pubDate: l
                    }), n.default.createElement(o.default, {
                        blocks: u
                    })) : null
                };
            p.defaultProps = {
                headline: "",
                credits: "",
                summary: "",
                date: "",
                transcript: null
            };
            var u = p;
            t.default = u
        },
        xXO4: function(e, t, a) {
            "use strict";
            var r = a("TqRt");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.archivedBlocks = t.textClass = t.speakerClass = t.transcriptBlocksClass = t.episodePubdateClass = t.episodeSummaryClass = t.hostedByClass = t.episodeTitleClass = t.kickerClass = t.episodeMetadataClass = t.transcriptBodyClass = void 0;
            var l = a("UmXO"),
                n = r(a("wXC7")),
                s = (0, l.css)("position:relative;padding:0 20px;border-top:1px solid #dadada;height:calc(100% - 40px);overflow-y:scroll;*{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility;-webkit-touch-callout:none;}", n.default.breakpoint.medium, "{padding:0 50px;}", n.default.breakpoint.mediumLarge, "{margin:0 4px;padding:0 74px 0 112px;}");
            t.transcriptBodyClass = s;
            var i = (0, l.css)("padding:25px 0 20px;border-bottom:1px solid #dadada;");
            t.episodeMetadataClass = i;
            var o = (0, l.css)("font-size:13px;text-transform:uppercase;font-family:", n.default.font.franklinBase, ";font-weight:", n.default.font.weight.bold, ";letter-spacing:0.04em;color:#333;margin-bottom:15px;", n.default.breakpoint.large, "{display:none;}");
            t.kickerClass = o;
            var d = (0, l.css)("font-size:40px;line-height:48px;font-family:", n.default.font.serifMedium, ";margin-bottom:14px;");
            t.episodeTitleClass = d;
            var p = (0, l.css)("font-family:", n.default.font.franklinBase, ";font-weight:", n.default.font.weight.bold, ";font-size:15px;line-height:22px;margin-bottom:5px;");
            t.hostedByClass = p;
            var u = (0, l.css)("font-family:", n.default.font.franklinBase, ";font-size:15px;line-height:22px;margin-bottom:10px;");
            t.episodeSummaryClass = u;
            var c = (0, l.css)("font-family:", n.default.font.franklinBase, ";font-size:15px;line-height:22px;padding:4px 0;display:block;");
            t.episodePubdateClass = c;
            var f = (0, l.css)("padding-top:30px;", n.default.breakpoint.medium, "{padding-bottom:35px;}");
            t.transcriptBlocksClass = f;
            var m = (0, l.css)("font-family:", n.default.font.franklinBase, ";font-size:14px;line-height:16px;color:#999;text-transform:capitalize;padding-bottom:5px;");
            t.speakerClass = m;
            var x = (0, l.css)("font-family:", n.default.font.imperial, ";font-size:17px;line-height:26px;color:#333;", n.default.breakpoint.large, "{font-size:18px;line-height:28px;}margin-bottom:25px;", n.default.breakpoint.medium, "{margin-bottom:33px;}");
            t.textClass = x;
            var h = (0, l.css)("border-left:3px solid lightgray;padding-left:20px;.", x, "{font-style:italic;}", n.default.breakpoint.small, "{padding-left:40px;}");
            t.archivedBlocks = h
        }
    }
]);
//# sourceMappingURL=vendors~audio~capsule~home~paidpost~story-8abef87171cf46fe2401.js.map