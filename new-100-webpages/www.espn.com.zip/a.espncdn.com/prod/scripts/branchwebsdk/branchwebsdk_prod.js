(function(b, r, a, n, c, h, _, s, d, k) {
    if (!b[n] || !b[n]._q) {
        for (; s < _.length;) c(h, _[s++]);
        d = r.createElement(a);
        d.async = 1;
        d.src = "https://cdn.branch.io/branch-latest.min.js";
        k = r.getElementsByTagName(a)[0];
        k.parentNode.insertBefore(d, k);
        b[n] = h
    }
})(window, document, "script", "branch", function(b, r) {
    b[r] = function() {
        b._q.push([r, arguments])
    }
}, {
    _q: [],
    _v: 1
}, "addListener applyCode autoAppIndex banner closeBanner closeJourney creditHistory credits data deepviewdeepviewCta first getCode init link logout redeem referrals removeListener sendSMS setBranchViewData setIdentity track validateCodetrackCommerceEvent logEvent".split(" "), 0);
branch.init('key_live_jnaWBg9DU4lXp11UZBW0ZcnoxqoUrQjS', function(err, data) {
    if (document.querySelectorAll("meta[name='twitter:app:url:iphone']").length > 0) {
        var meta = document.querySelector("meta[name='twitter:app:url:iphone']").getAttribute("content");
        branch.setBranchViewData({
            data: {
                '$deeplink_path': meta
            }
        });
    }
});