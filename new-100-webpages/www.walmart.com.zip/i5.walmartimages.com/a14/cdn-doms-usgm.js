window.TB_CDN_Config = window.TB_CDN_Config || {
    DomainList: ['ak-us.wal.co', 'ec-us.wal.co', 'zy-us.wal.co', 'll-us.wal.co', 'us.tb.wal.co', 'cf-us.wal.co'],
    DynamicDomainList: ['ak-us-dyn.wal.co', 'us-dyn.tb.wal.co', 'll-us-dyn.wal.co', 'ec-us-dyn.wal.co', 'cf-us-dyn.wal.co', 'zy-us-dyn.wal.co'],
    BeaconHost: 'beacon.walmart.com'
};