processGoogleToken({
    "newToken": "ChAI8K377AUQ2M__gqiooptUEi8AnMhKYcojEDbmLy1fKzYMJbsqIwq-tCLVdZFNbBXl3g3MqFzQwKUsE90XkyRMvg",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-10-11",
    "pucrd": ""
});