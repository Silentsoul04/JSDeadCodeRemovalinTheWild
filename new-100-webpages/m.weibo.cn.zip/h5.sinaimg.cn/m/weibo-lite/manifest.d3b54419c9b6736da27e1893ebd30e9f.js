self.__precacheManifest = [{
        "revision": "7f107779beaea8fab70c",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/profile.785ccd5e.css"
    },
    {
        "revision": "dcfee9d6cf529bdbbd799fa6121245b5",
        "url": "//h5.sinaimg.cn/m/weibo-lite/mask-icon.svg"
    },
    {
        "revision": "7f107779beaea8fab70c",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/profile.8e929aed.js"
    },
    {
        "revision": "eda94935a97574ab979c",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/app.5f37cf49.css"
    },
    {
        "revision": "0bcf27abc04ed8da10be",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/chat.25394196.css"
    },
    {
        "revision": "0bcf27abc04ed8da10be",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/chat.c1fd46bd.js"
    },
    {
        "revision": "7a198c522be3dde871d2",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/chat-composer-miniComposer.0ca6db68.css"
    },
    {
        "revision": "7a198c522be3dde871d2",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/chat-composer-miniComposer.19919573.js"
    },
    {
        "revision": "271bc0924781382bab5b",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/chunk-03b287bb.4df35807.css"
    },
    {
        "revision": "271bc0924781382bab5b",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/chunk-03b287bb.1d8f08ff.js"
    },
    {
        "revision": "48ca975b308d80eea7fd",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/collect.48469343.css"
    },
    {
        "revision": "48ca975b308d80eea7fd",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/collect.89470af7.js"
    },
    {
        "revision": "6bafc2f15f254238055f",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/collect-main-page-profile-statusLite.3099b8c8.css"
    },
    {
        "revision": "6bafc2f15f254238055f",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/collect-main-page-profile-statusLite.7e1cef97.js"
    },
    {
        "revision": "6caf559c30efda755ceb",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/collect-main-profile-statusLite.99ec0809.css"
    },
    {
        "revision": "6caf559c30efda755ceb",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/collect-main-profile-statusLite.3f6d8bce.js"
    },
    {
        "revision": "0e65c7cafbc8aa11b651",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/composer.8f710dc0.css"
    },
    {
        "revision": "0e65c7cafbc8aa11b651",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/composer.59f8f644.js"
    },
    {
        "revision": "b802c9d900020b38eb9d",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/composer-miniComposer.ff83e4e9.css"
    },
    {
        "revision": "b802c9d900020b38eb9d",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/composer-miniComposer.e89d014a.js"
    },
    {
        "revision": "5549c5102be473a312fa",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/draft.f80fc4be.css"
    },
    {
        "revision": "5549c5102be473a312fa",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/draft.3c70f826.js"
    },
    {
        "revision": "807ef75cbfd49a66541d",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/main.a8d8496e.css"
    },
    {
        "revision": "807ef75cbfd49a66541d",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/main.8558a9f0.js"
    },
    {
        "revision": "a11e9228a35f6b1e4080",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/manifest.d87e561b.js"
    },
    {
        "revision": "5e07ee6f00726a4e5ed0",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/me.f1fb19ae.css"
    },
    {
        "revision": "5e07ee6f00726a4e5ed0",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/me.4ab25dea.js"
    },
    {
        "revision": "700132bc7f62bcf77bcc",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/miniComposer.da091168.css"
    },
    {
        "revision": "700132bc7f62bcf77bcc",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/miniComposer.ebc2b9de.js"
    },
    {
        "revision": "420223e2d1fe381aca38",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/msg.16cce35c.js"
    },
    {
        "revision": "a8586002c420df14ab5c",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/msglist.ef9f4cc0.css"
    },
    {
        "revision": "a8586002c420df14ab5c",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/msglist.12385c05.js"
    },
    {
        "revision": "b917b08c90d1e4fb951e",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/msgsublist.9ae57556.css"
    },
    {
        "revision": "b917b08c90d1e4fb951e",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/msgsublist.5b6a3285.js"
    },
    {
        "revision": "9849011e6dbdac015d6e",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/page.ad5807b5.css"
    },
    {
        "revision": "9849011e6dbdac015d6e",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/page.52546190.js"
    },
    {
        "revision": "3a440ccd30fe6abf2b4b",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/about.a34fd868.js"
    },
    {
        "revision": "eda94935a97574ab979c",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/app.34ada95a.js"
    },
    {
        "revision": "39d55e7ce818a25773a7",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/search.47fcdadd.css"
    },
    {
        "revision": "39d55e7ce818a25773a7",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/search.874c197b.js"
    },
    {
        "revision": "c68feb4152f39e537a0c",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/setting.100fd730.js"
    },
    {
        "revision": "d8871b40650cebc74b49",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/smsLogin.67228ba7.css"
    },
    {
        "revision": "d8871b40650cebc74b49",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/smsLogin.b5bf6a11.js"
    },
    {
        "revision": "25ab8f052100068ee9ef",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/statusLite.b090c6ae.css"
    },
    {
        "revision": "25ab8f052100068ee9ef",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/statusLite.2d6b3fed.js"
    },
    {
        "revision": "2ea98d49b84832e156f8",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/vendor.65ade26c.css"
    },
    {
        "revision": "2ea98d49b84832e156f8",
        "url": "//h5.sinaimg.cn/m/weibo-lite/js/vendor.d686bcb6.js"
    },
    {
        "revision": "b9870373bb8ac1d94b7ada62ed490b85",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/videofont.b9870373.svg"
    },
    {
        "revision": "c33a921cb2bc2c766314ff0fe29be0d6",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/feedstory_branding_mask.c33a921c.svg"
    },
    {
        "revision": "51298336e3f22ea747c28cb9ca4f3274",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/iconfont.51298336.svg"
    },
    {
        "revision": "b257fa9c5ac8c515ac4d77a667ce2943",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/default-skin.b257fa9c.svg"
    },
    {
        "revision": "18f1902fa2ad110d8ec09c05f410cdfd",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/delete_icon.18f1902f.svg"
    },
    {
        "revision": "72a9f840b15f5fbdbbe60d872143e0fa",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/iconfont.72a9f840.svg"
    },
    {
        "revision": "00fda3c751c72f358de80954c4aa457f",
        "url": "//h5.sinaimg.cn/m/weibo-lite/fonts/iconfont.00fda3c7.eot"
    },
    {
        "revision": "78eb594e07b52a5a177440a18f1837e8",
        "url": "//h5.sinaimg.cn/m/weibo-lite/fonts/iconfont.78eb594e.ttf"
    },
    {
        "revision": "53475cc3255fd42f10dfba9fba41d95f",
        "url": "//h5.sinaimg.cn/m/weibo-lite/fonts/iconfont.53475cc3.woff"
    },
    {
        "revision": "417d1674cf1c17eb170c7f949f72f967",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/pwalogo.417d1674.svg"
    },
    {
        "revision": "e8bfd1526b4f3244ad2e3855aef5ce28",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/icon_qq.e8bfd152.svg"
    },
    {
        "revision": "f3d22509eb0e70a62e0a450a61209659",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/aboutlogo.f3d22509.png"
    },
    {
        "revision": "4c5df4f4cd1ea28d522a3321c2ea1d6a",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/icomoon.4c5df4f4.svg"
    },
    {
        "revision": "1b838fa8ab652964d000160e98a26276",
        "url": "//h5.sinaimg.cn/m/weibo-lite/fonts/iconfont.1b838fa8.ttf"
    },
    {
        "revision": "4a8c6ae2c9ce775897ba9be6fe1a95cf",
        "url": "//h5.sinaimg.cn/m/weibo-lite/fonts/iconfont.4a8c6ae2.eot"
    },
    {
        "revision": "9fae17ad1a6336ddbee32f3b598cb8fb",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/logo.9fae17ad.svg"
    },
    {
        "revision": "f0bf332701bf7d18523bf13cd64867a3",
        "url": "//h5.sinaimg.cn/m/weibo-lite/img/compose_topic_default.f0bf3327.png"
    },
    {
        "revision": "25b01eb5f2944f39cd8b26c684073f58",
        "url": "//h5.sinaimg.cn/m/weibo-lite/fonts/iconfont.25b01eb5.woff"
    },
    {
        "revision": "976e99d219c6717de263553528f0f202",
        "url": "//h5.sinaimg.cn/m/weibo-lite/index.html"
    },
    {
        "revision": "d941233b3c0f5e58db1e3097bb1e1439",
        "url": "//h5.sinaimg.cn/m/weibo-lite/index.phtml"
    },
    {
        "revision": "1e81aa4e98f2c6b31b2082febb262bf0",
        "url": "//h5.sinaimg.cn/m/weibo-lite/icon-default-512.png"
    },
    {
        "revision": "22d4562383a1df73fa997552ec073795",
        "url": "//h5.sinaimg.cn/m/weibo-lite/favicon-16.png"
    },
    {
        "revision": "2826f9f927891c83b3ef12f662ff95bd",
        "url": "//h5.sinaimg.cn/m/weibo-lite/favicon-32.png"
    },
    {
        "revision": "a3b611462d49081c51fccd6f9b2c5ce4",
        "url": "//h5.sinaimg.cn/m/weibo-lite/icon-default-192.png"
    },
    {
        "revision": "3a440ccd30fe6abf2b4b",
        "url": "//h5.sinaimg.cn/m/weibo-lite/css/about.d8c6b004.css"
    },
    {
        "revision": "db0088e20bc03f3c002d636877314f6e",
        "url": "//h5.sinaimg.cn/m/weibo-lite/appicon.png"
    }
];