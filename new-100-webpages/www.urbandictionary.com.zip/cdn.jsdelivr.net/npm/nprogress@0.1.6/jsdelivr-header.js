/**
 * Minified by jsDelivr using UglifyJS v3.4.2.
 * Original file: /npm/nprogress@0.1.6/nprogress.js
 * 
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */