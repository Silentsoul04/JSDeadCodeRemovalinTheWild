apstag.punt({
    "cmp": "//aax-eu.amazon-adsystem.com/s/iu3?cm3ppd=1&d=dtb-pub&csif=t&dl=rbd_brt_oath_dm_dmx_3lift",
    "cb": "3071771746811570705713366"
})