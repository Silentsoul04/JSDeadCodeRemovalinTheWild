if (typeof(window.BF_Scout) !== 'object') {
    window.BF_Scout = {};
}
window.BF_Scout.adBlocked = false;