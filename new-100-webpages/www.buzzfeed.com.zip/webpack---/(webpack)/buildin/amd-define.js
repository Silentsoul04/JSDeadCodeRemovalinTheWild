module.exports = function() {
    throw new Error("define cannot be used indirect");
};



//////////////////
// WEBPACK FOOTER
// (webpack)/buildin/amd-define.js
// module id = 117
// module chunks = 1 2