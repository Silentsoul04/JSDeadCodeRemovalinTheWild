module.exports = {
    "default": require("core-js/library/fn/symbol/iterator"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/symbol/iterator.js
// module id = 52
// module chunks = 1 2