module.exports = {
    "default": require("core-js/library/fn/object/assign"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/object/assign.js
// module id = 4
// module chunks = 1 2