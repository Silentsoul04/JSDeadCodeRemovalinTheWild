module.exports = {
    "default": require("core-js/library/fn/object/keys"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/object/keys.js
// module id = 47
// module chunks = 1 2