module.exports = {
    "default": require("core-js/library/fn/json/stringify"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/json/stringify.js
// module id = 86
// module chunks = 1 2