module.exports = {
    "default": require("core-js/library/fn/promise"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/promise.js
// module id = 102
// module chunks = 1 2