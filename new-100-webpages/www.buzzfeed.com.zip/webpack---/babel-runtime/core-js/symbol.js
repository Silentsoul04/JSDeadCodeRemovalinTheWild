module.exports = {
    "default": require("core-js/library/fn/symbol"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/symbol.js
// module id = 72
// module chunks = 1 2