require('./_wks-define')('asyncIterator');


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/es7.symbol.async-iterator.js
// module id = 84
// module chunks = 1 2