module.exports = true;


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_library.js
// module id = 57
// module chunks = 1 2