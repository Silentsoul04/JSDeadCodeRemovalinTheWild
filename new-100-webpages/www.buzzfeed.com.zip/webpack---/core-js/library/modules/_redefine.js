module.exports = require('./_hide');


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_redefine.js
// module id = 58
// module chunks = 1 2