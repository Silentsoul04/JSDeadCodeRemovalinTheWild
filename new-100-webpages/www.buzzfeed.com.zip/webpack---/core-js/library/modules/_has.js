var hasOwnProperty = {}.hasOwnProperty;
module.exports = function(it, key) {
    return hasOwnProperty.call(it, key);
};


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_has.js
// module id = 25
// module chunks = 1 2