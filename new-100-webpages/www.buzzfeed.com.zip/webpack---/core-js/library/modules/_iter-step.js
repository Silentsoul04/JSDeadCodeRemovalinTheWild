module.exports = function(done, value) {
    return {
        value: value,
        done: !!done
    };
};


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_iter-step.js
// module id = 70
// module chunks = 1 2