require('./_wks-define')('observable');


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/es7.symbol.observable.js
// module id = 85
// module chunks = 1 2