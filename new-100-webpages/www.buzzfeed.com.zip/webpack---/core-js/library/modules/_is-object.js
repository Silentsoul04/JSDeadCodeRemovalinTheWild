module.exports = function(it) {
    return typeof it === 'object' ? it !== null : typeof it === 'function';
};


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_is-object.js
// module id = 15
// module chunks = 1 2