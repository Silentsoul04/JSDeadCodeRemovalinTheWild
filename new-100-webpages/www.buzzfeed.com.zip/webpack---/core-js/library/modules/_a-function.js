module.exports = function(it) {
    if (typeof it != 'function') throw TypeError(it + ' is not a function!');
    return it;
};


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_a-function.js
// module id = 11
// module chunks = 1 2