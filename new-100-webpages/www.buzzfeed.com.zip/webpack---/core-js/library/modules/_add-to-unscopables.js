module.exports = function() { /* empty */ };


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_add-to-unscopables.js
// module id = 69
// module chunks = 1 2