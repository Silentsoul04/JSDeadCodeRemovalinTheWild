// 19.1.3.1 Object.assign(target, source)
var $export = require('./_export');

$export($export.S + $export.F, 'Object', {
    assign: require('./_object-assign')
});


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/es6.object.assign.js
// module id = 6
// module chunks = 1 2