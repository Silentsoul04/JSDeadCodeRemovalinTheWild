exports.f = require('./_wks');


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_wks-ext.js
// module id = 71
// module chunks = 1 2