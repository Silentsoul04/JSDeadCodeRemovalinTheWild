module.exports = require('./_global').document && document.documentElement;


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_html.js
// module id = 63
// module chunks = 1 2