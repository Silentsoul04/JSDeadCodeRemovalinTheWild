exports.f = Object.getOwnPropertySymbols;


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_object-gops.js
// module id = 38
// module chunks = 1 2