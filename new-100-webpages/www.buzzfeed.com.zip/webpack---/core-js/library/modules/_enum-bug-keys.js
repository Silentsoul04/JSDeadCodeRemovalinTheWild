// IE 8- don't enum bug keys
module.exports = (
    'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_enum-bug-keys.js
// module id = 37
// module chunks = 1 2