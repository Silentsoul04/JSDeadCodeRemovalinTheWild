var core = module.exports = {
    version: '2.4.0'
};
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_core.js
// module id = 9
// module chunks = 1 2