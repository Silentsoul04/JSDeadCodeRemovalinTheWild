require('../modules/web.dom.iterable');
require('../modules/es6.string.iterator');
module.exports = require('../modules/core.get-iterator');


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/fn/get-iterator.js
// module id = 97
// module chunks = 1 2