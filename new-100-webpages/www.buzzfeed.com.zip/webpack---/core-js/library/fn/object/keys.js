require('../../modules/es6.object.keys');
module.exports = require('../../modules/_core').Object.keys;


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/fn/object/keys.js
// module id = 48
// module chunks = 1 2