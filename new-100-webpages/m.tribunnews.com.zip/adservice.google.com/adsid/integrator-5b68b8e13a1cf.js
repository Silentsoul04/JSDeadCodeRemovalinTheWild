processGoogleToken({
    "newToken": "ChAI8K377AUQ2M__gqiooptUEi8AnMhKYatb6vRv7m2Mga-Va2xPPQ37yFpOydByLUK-ioc8leys1xYFXwQ7peRiHg",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-10-11",
    "pucrd": ""
});