processGoogleToken({
    "newToken": "ChAI8K377AUQ2M__gqiooptUEi8AnMhKYeuaDYVn5hCzvgjZbXTuziqyVF-X23achaAhwGrZcU_MMlzx-9g8V7OtmQ",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-10-11",
    "pucrd": ""
});