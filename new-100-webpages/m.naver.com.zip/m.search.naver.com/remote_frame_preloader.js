(function() {
    var e = [
        "https://ssl.pstatic.net/sstatic/search/mobile/img/sp_common_482a5e05.png",
        "https://ssl.pstatic.net/sstatic/search/mobile/css/w_new_191010.css",
        "https://ssl.pstatic.net/gen/preconn",
        "https://search.pstatic.net/gen/preconn"
    ];
    if (e)
        for (var t = 0; t < e.length; t++) {
            (new Image).src = e[t]
        }
})()