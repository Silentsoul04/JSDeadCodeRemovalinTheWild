define(["require", "exports", "tslib", "react", "external/classnames"], function(e, r, t, a, s) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), a = t.__importDefault(a), s = t.__importDefault(s), r.LoginError = function(e) {
        var r = s.default("c-card", "c-card--error", e.className);
        return a.default.createElement("div", {
            className: r
        }, e.message)
    }
});
//# sourceMappingURL=login_error.min.js-vflSAPbxQ.map