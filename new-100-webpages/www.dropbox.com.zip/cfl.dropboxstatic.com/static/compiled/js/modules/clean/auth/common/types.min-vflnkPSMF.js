define(["require", "exports"], function(t, e) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    (function(t) {
        t.EMAIL = "email", t.PASSWORD = "password", t.TEXT = "text"
    })(e.AuthTextInputType || (e.AuthTextInputType = {}));
    (function(t) {
        t.BIG = "big", t.SMALL = "small", t.STANDARD = "standard"
    })(e.AuthButtonVariant || (e.AuthButtonVariant = {}));
    (function(t) {
        t.PAPER_COMPACT = "paper-compact", t.SMALL = "small", t.STANDARD = "standard"
    })(e.AuthFormVariant || (e.AuthFormVariant = {}));
    (function(t) {
        t.GOOGLE2 = "GOOGLE2", t.GOOGLE3 = "GOOGLE3", t.MULTISTEP = "MULTISTEP"
    })(e.GoogleAuthExperimentVariant || (e.GoogleAuthExperimentVariant = {}))
});
//# sourceMappingURL=types.min.js-vfl1jf6Q7.map