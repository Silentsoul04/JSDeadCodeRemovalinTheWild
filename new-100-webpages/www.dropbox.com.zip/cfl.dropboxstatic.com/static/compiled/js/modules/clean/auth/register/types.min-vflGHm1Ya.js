define(["require", "exports"], function(E, S) {
    "use strict";
    Object.defineProperty(S, "__esModule", {
        value: !0
    });
    (function(E) {
        E.GOOGLE_REGISTER_CLICK = "GOOGLE_REGISTER_CLICK", E.GOOGLE_REGISTER_SUCCESS = "GOOGLE_REGISTER_SUCCESS", E.REGISTER_CLICK = "REGISTER_CLICK", E.REGISTER_IMMEDIATE_SUCCESS = "REGISTER_IMMEDIATE_SUCCESS"
    })(S.RegisterFormEvent || (S.RegisterFormEvent = {}))
});
//# sourceMappingURL=types.min.js-vfl8vpMMy.map