if (awa.firstEventDone) {
    awa.firstEventDone()
};