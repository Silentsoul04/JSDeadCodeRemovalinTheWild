const propertyHelper = require('@exp/exp-utils/helper/property');

const _experiments = new propertyHelper.PropertySet();

module.exports = _experiments;