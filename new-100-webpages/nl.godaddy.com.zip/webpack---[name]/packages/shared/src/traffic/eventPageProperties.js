const propertyHelper = require('@exp/exp-utils/helper/property');

const _pageProperties = new propertyHelper.PropertySet();

module.exports = _pageProperties;