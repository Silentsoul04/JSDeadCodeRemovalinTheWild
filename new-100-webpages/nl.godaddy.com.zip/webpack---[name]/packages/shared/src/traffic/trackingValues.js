import {
    PropertySet
} from '@exp/exp-utils/helper/property';

const trackingValues = new PropertySet();

export default trackingValues;