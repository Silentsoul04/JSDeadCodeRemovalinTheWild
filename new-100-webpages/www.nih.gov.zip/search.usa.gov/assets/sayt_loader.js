var getElementsByClassName = function(e, s, t) {
        return (getElementsByClassName = document.getElementsByClassName ? function(e, s, t) {
            for (var a, n = (t = t || document).getElementsByClassName(e), c = s ? new RegExp("\\b" + s + "\\b", "i") : null, r = [], l = 0, i = n.length; l < i; l += 1) a = n[l], c && !c.test(a.nodeName) || r.push(a);
            return r
        } : document.evaluate ? function(e, s, t) {
            s = s || "*", t = t || document;
            for (var a, n, c = e.split(" "), r = "", l = "http://www.w3.org/1999/xhtml", i = document.documentElement.namespaceURI === l ? l : null, o = [], u = 0, h = c.length; u < h; u += 1) r += "[contains(concat(' ', @class, ' '), ' " + c[u] + " ')]";
            try {
                a = document.evaluate(".//" + s + r, t, i, 0, null)
            } catch (m) {
                a = document.evaluate(".//" + s + r, t, null, 0, null)
            }
            for (; n = a.iterateNext();) o.push(n);
            return o
        } : function(e, s, t) {
            s = s || "*", t = t || document;
            for (var a, n, c = e.split(" "), r = [], l = "*" === s && t.all ? t.all : t.getElementsByTagName(s), i = [], o = 0, u = c.length; o < u; o += 1) r.push(new RegExp("(^|\\s)" + c[o] + "(\\s|$)"));
            for (var h = 0, m = l.length; h < m; h += 1) {
                a = l[h], n = !1;
                for (var g = 0, d = r.length; g < d && (n = r[g].test(a.className)); g += 1);
                n && i.push(a)
            }
            return i
        })(e, s, t)
    },
    usasearch = {};
if ("object" == typeof usasearch_config && usasearch_config.constructor == Object ? usasearch.config = usasearch_config : usasearch.config = {}, usasearch.config.host === undefined && (usasearch.config.host = "//search.usa.gov"), 0 < getElementsByClassName("usagov-search-autocomplete").length) {
    var link = document.createElement("link");
    link.type = "text/css", link.href = usasearch.config.host + "/assets/sayt.css", link.rel = "stylesheet", link.media = "screen", document.getElementsByTagName("head")[0].appendChild(link);
    var script = document.createElement("script");
    script.type = "text/javascript", script.src = usasearch.config.host + "/assets/sayt_loader_libs.js", document.getElementsByTagName("head")[0].appendChild(script)
}
if (usasearch.config.siteHandle) {
    var aid = usasearch.config.siteHandle;
    if (usasearch.config.enableDiscoveryTag === undefined && "cdc-main" === aid && (usasearch.config.enableDiscoveryTag = !0), usasearch.config.enableDiscoveryTag) {
        var discoveryScript = document.createElement("script");
        discoveryScript.type = "text/javascript", discoveryScript.src = usasearch.config.host + "/assets/stats.js", document.getElementsByTagName("head")[0].appendChild(discoveryScript)
    }
}