if ("object" == typeof CE2 && CE2.uid) throw "CE: multiple userscripts installed";
"undefined" == typeof CE2 && (CE2 = {}), CE2.uid = 112616, CE2.status = "no data available";