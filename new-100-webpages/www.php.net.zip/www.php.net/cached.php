@font-face{
    font-family: 'Fira Sans';
    src: url('/fonts/Fira/eot/FiraSans-Book.eot');
    src: local('/fonts/Fira/Fira Sans Book'),
         url('/fonts/Fira/eot/FiraSans-Book.eot') format('embedded-opentype'),
         url('/fonts/Fira/woff/FiraSans-Book.woff') format('woff'),
         url('/fonts/Fira/ttf/FiraSans-Book.ttf') format('truetype');
    font-weight: 400;
    font-style: normal;
}

@font-face{
    font-family: 'Fira Sans';
    src: url('/fonts/Fira/eot/FiraSans-BookItalic.eot');
    src: local('/fonts/Fira/Fira Sans Book Italic'),
         url('/fonts/Fira/eot/FiraSans-BookItalic.eot') format('embedded-opentype'),
         url('/fonts/Fira/woff/FiraSans-BookItalic.woff') format('woff'),
         url('/fonts/Fira/ttf/FiraSans-BookItalic.ttf') format('truetype');
    font-weight: 400;
    font-style: italic;
}

@font-face{
    font-family: 'Fira Sans';
    src: url('/fonts/Fira/eot/FiraSans-Medium.eot');
    src: local('/fonts/Fira/Fira Sans Medium'),
         url('/fonts/Fira/eot/FiraSans-Medium.eot') format('embedded-opentype'),
         url('/fonts/Fira/woff/FiraSans-Medium.woff') format('woff'),
         url('/fonts/Fira/ttf/FiraSans-Medium.ttf') format('truetype');
    font-weight: 500;
    font-style: normal;
}

@font-face{
    font-family: 'Fira Sans';
    src: url('/fonts/Fira/eot/FiraSans-MediumItalic.eot');
    src: local('/fonts/Fira/Fira Sans Medium Italic'),
         url('/fonts/Fira/eot/FiraSans-MediumItalic.eot') format('embedded-opentype'),
         url('/fonts/Fira/woff/FiraSans-MediumItalic.woff') format('woff'),
         url('/fonts/Fira/ttf/FiraSans-MediumItalic.ttf') format('truetype');
    font-weight: 500;
    font-style: italic;
}

@font-face{
    font-family: 'Fira Mono';
    src: url('/fonts/Fira/eot/FiraMono-Regular.eot');
    src: local('/fonts/Fira/Fira Mono'),
         url('/fonts/Fira/eot/FiraMono-Regular.eot') format('embedded-opentype'),
         url('/fonts/Fira/woff/FiraMono-Regular.woff') format('woff'),
         url('/fonts/Fira/ttf/FiraMono-Regular.ttf') format('truetype');
    font-weight: 400;
    font-style: normal;
}

@font-face{
    font-family: 'Fira Mono';
    src: url('/fonts/Fira/eot/FiraMono-Bold.eot');
    src: local('/fonts/Fira/Fira Mono Bold'),
         url('/fonts/Fira/eot/FiraMono-Bold.eot') format('embedded-opentype'),
         url('/fonts/Fira/woff/FiraMono-Bold.woff') format('woff'),
         url('/fonts/Fira/ttf/FiraMono-Bold.ttf') format('truetype');
    font-weight: 700;
    font-style: normal;
}
