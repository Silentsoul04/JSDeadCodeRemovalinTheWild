/* Home Page */

#intro p {
  color:#fff;
  text-rendering: optimizeLegibility;
}
#intro p,
#intro ul {
    text-shadow:0 1px 2px rgba(0,0,0,.5);
    font-size:1.125rem;
}

#intro ul a {
    word-spacing: 0;
}

#intro .row .blurb p:first-child {
  margin-top:1.5rem;
}
#intro .row .blurb,
#intro .row .download {
  display:table-cell;
  float:none;
  padding:0 1.5rem;
}

#intro h3 {
  margin:1.5rem 0 0;
  color:#E6E6E6;
}
#intro h3:after {
  display:none;
}

#intro .row {
  position:relative;
  display:table-row;
}

#intro ul {
  list-style:none;
  word-spacing:.25rem;
  margin-left:0;
}

#intro .dot {
    display: inline-block;
    width: 5px;
    padding: 0 5px;
}

#intro .download {
}
#intro .download a.notes {
    font-size:.75em;
    white-space:nowrap;
}
#intro .download a {
    color:#ccc;
    border:0;
}
#intro .download a:hover,
#intro .download a:focus {
  border-bottom:1px dotted;
}

#intro .download a.download-link {
    color:#fff;
    width: 50px;
    display: inline-block;
}

#layout-content {
  border-right:.25rem solid #666;
}
.home .newsentry .newstitle a:after  {
  content:"\20 \00bb";
  color:#666;
}

p.archive {
	text-align: right;
}

@media (min-width: 480px) and (max-width: 768px) {
    #intro .download {
        width: 35%;
    }

    #intro .blurb {
        width: 65%;
    }
}

@media (min-width: 768px) {
    .navbar-search,
    #intro .download,
    #intro .background,
    aside.tips,
    .layout-menu {
        width: 25%;
    }

    #intro .blurb, #layout-content {
        width: 75%;
    }
}

@media (min-width: 480px) and (max-width: 590px) {
    #intro .dot {
        display: none;
    }
}

@media (min-width: 768px) and (max-width: 784px) {
    #intro .download, aside.tips, .navbar-search {
        width: 30%;
    }

    #intro .blurb, #layout-content {
        width:70%;
    }
}

/* Homepage mirror sponsor */
aside.tips .mirror-sponsor {
    padding-top: 1.5rem;
}

/* Social media buttons. */
aside.tips .social-media .icon-twitter {
    font-size: 1.5em;
    vertical-align: middle;
}
