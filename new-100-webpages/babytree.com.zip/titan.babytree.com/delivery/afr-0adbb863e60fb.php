<html>
<head>
<title>Advertisement</title>
</head>
<body leftmargin='0' topmargin='0' marginwidth='0' marginheight='0' style='background-color:transparent; width: 100%; text-align: center;'>
<span style='z-index: 100;position: absolute;z-index: 10000;right: 0px;bottom: 0px;color:#ffffff; font-size: 6px;background-color: #dcdcdc; font-family : 微软雅黑,宋体;'>广告</span>
<a href='http://titan.babytree.com/delivery/ck.php?oaparams=2__bannerid=1194__zoneid=230__cb=81f56200b4__maxdest=http://www.babytree.com/community/group36694/topic_78476695.html' target='_blank'><img src='http://pic07.babytreeimg.com/common_photo/original/2019/0315/FmKQ3TbNGND5lhBz9ms-cAo4KjGU' width='100' height='72' alt='' title='' border='0' /></a><div id='beacon_81f56200b4' style='position: absolute; left: 0px; top: 0px; visibility: hidden;'><img src='http://titan.babytree.com/delivery/lg.php?bannerid=1194&amp;campaignid=100&amp;zoneid=230&amp;channel_ids=,&amp;loc=http%3A%2F%2Fbabytree.com%2F&amp;cb=81f56200b4' width='0' height='0' alt='' style='width: 0px; height: 0px;' /></div>
</body>
</html>
